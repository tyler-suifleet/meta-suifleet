#!/usr/bin/env node
"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/json-typings.js
var require_json_typings = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/json-typings.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isJsonObject = exports2.typeofJsonValue = void 0;
    function typeofJsonValue6(value) {
      let t = typeof value;
      if (t == "object") {
        if (Array.isArray(value))
          return "array";
        if (value === null)
          return "null";
      }
      return t;
    }
    exports2.typeofJsonValue = typeofJsonValue6;
    function isJsonObject3(value) {
      return value !== null && typeof value == "object" && !Array.isArray(value);
    }
    exports2.isJsonObject = isJsonObject3;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/base64.js
var require_base64 = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/base64.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.base64encode = exports2.base64decode = void 0;
    var encTable = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split("");
    var decTable = [];
    for (let i = 0; i < encTable.length; i++)
      decTable[encTable[i].charCodeAt(0)] = i;
    decTable["-".charCodeAt(0)] = encTable.indexOf("+");
    decTable["_".charCodeAt(0)] = encTable.indexOf("/");
    function base64decode(base64Str) {
      let es = base64Str.length * 3 / 4;
      if (base64Str[base64Str.length - 2] == "=")
        es -= 2;
      else if (base64Str[base64Str.length - 1] == "=")
        es -= 1;
      let bytes = new Uint8Array(es), bytePos = 0, groupPos = 0, b, p = 0;
      for (let i = 0; i < base64Str.length; i++) {
        b = decTable[base64Str.charCodeAt(i)];
        if (b === void 0) {
          switch (base64Str[i]) {
            case "=":
              groupPos = 0;
            // reset state when padding found
            case "\n":
            case "\r":
            case "	":
            case " ":
              continue;
            // skip white-space, and padding
            default:
              throw Error(`invalid base64 string.`);
          }
        }
        switch (groupPos) {
          case 0:
            p = b;
            groupPos = 1;
            break;
          case 1:
            bytes[bytePos++] = p << 2 | (b & 48) >> 4;
            p = b;
            groupPos = 2;
            break;
          case 2:
            bytes[bytePos++] = (p & 15) << 4 | (b & 60) >> 2;
            p = b;
            groupPos = 3;
            break;
          case 3:
            bytes[bytePos++] = (p & 3) << 6 | b;
            groupPos = 0;
            break;
        }
      }
      if (groupPos == 1)
        throw Error(`invalid base64 string.`);
      return bytes.subarray(0, bytePos);
    }
    exports2.base64decode = base64decode;
    function base64encode(bytes) {
      let base64 = "", groupPos = 0, b, p = 0;
      for (let i = 0; i < bytes.length; i++) {
        b = bytes[i];
        switch (groupPos) {
          case 0:
            base64 += encTable[b >> 2];
            p = (b & 3) << 4;
            groupPos = 1;
            break;
          case 1:
            base64 += encTable[p | b >> 4];
            p = (b & 15) << 2;
            groupPos = 2;
            break;
          case 2:
            base64 += encTable[p | b >> 6];
            base64 += encTable[b & 63];
            groupPos = 0;
            break;
        }
      }
      if (groupPos) {
        base64 += encTable[p];
        base64 += "=";
        if (groupPos == 1)
          base64 += "=";
      }
      return base64;
    }
    exports2.base64encode = base64encode;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/protobufjs-utf8.js
var require_protobufjs_utf8 = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/protobufjs-utf8.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.utf8read = void 0;
    var fromCharCodes = (chunk3) => String.fromCharCode.apply(String, chunk3);
    function utf8read(bytes) {
      if (bytes.length < 1)
        return "";
      let pos = 0, parts = [], chunk3 = [], i = 0, t;
      let len = bytes.length;
      while (pos < len) {
        t = bytes[pos++];
        if (t < 128)
          chunk3[i++] = t;
        else if (t > 191 && t < 224)
          chunk3[i++] = (t & 31) << 6 | bytes[pos++] & 63;
        else if (t > 239 && t < 365) {
          t = ((t & 7) << 18 | (bytes[pos++] & 63) << 12 | (bytes[pos++] & 63) << 6 | bytes[pos++] & 63) - 65536;
          chunk3[i++] = 55296 + (t >> 10);
          chunk3[i++] = 56320 + (t & 1023);
        } else
          chunk3[i++] = (t & 15) << 12 | (bytes[pos++] & 63) << 6 | bytes[pos++] & 63;
        if (i > 8191) {
          parts.push(fromCharCodes(chunk3));
          i = 0;
        }
      }
      if (parts.length) {
        if (i)
          parts.push(fromCharCodes(chunk3.slice(0, i)));
        return parts.join("");
      }
      return fromCharCodes(chunk3.slice(0, i));
    }
    exports2.utf8read = utf8read;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/binary-format-contract.js
var require_binary_format_contract = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/binary-format-contract.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.WireType = exports2.mergeBinaryOptions = exports2.UnknownFieldHandler = void 0;
    var UnknownFieldHandler;
    (function(UnknownFieldHandler2) {
      UnknownFieldHandler2.symbol = /* @__PURE__ */ Symbol.for("protobuf-ts/unknown");
      UnknownFieldHandler2.onRead = (typeName, message, fieldNo, wireType, data) => {
        let container = is2(message) ? message[UnknownFieldHandler2.symbol] : message[UnknownFieldHandler2.symbol] = [];
        container.push({ no: fieldNo, wireType, data });
      };
      UnknownFieldHandler2.onWrite = (typeName, message, writer) => {
        for (let { no, wireType, data } of UnknownFieldHandler2.list(message))
          writer.tag(no, wireType).raw(data);
      };
      UnknownFieldHandler2.list = (message, fieldNo) => {
        if (is2(message)) {
          let all = message[UnknownFieldHandler2.symbol];
          return fieldNo ? all.filter((uf) => uf.no == fieldNo) : all;
        }
        return [];
      };
      UnknownFieldHandler2.last = (message, fieldNo) => UnknownFieldHandler2.list(message, fieldNo).slice(-1)[0];
      const is2 = (message) => message && Array.isArray(message[UnknownFieldHandler2.symbol]);
    })(UnknownFieldHandler = exports2.UnknownFieldHandler || (exports2.UnknownFieldHandler = {}));
    function mergeBinaryOptions(a, b) {
      return Object.assign(Object.assign({}, a), b);
    }
    exports2.mergeBinaryOptions = mergeBinaryOptions;
    var WireType;
    (function(WireType2) {
      WireType2[WireType2["Varint"] = 0] = "Varint";
      WireType2[WireType2["Bit64"] = 1] = "Bit64";
      WireType2[WireType2["LengthDelimited"] = 2] = "LengthDelimited";
      WireType2[WireType2["StartGroup"] = 3] = "StartGroup";
      WireType2[WireType2["EndGroup"] = 4] = "EndGroup";
      WireType2[WireType2["Bit32"] = 5] = "Bit32";
    })(WireType = exports2.WireType || (exports2.WireType = {}));
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/goog-varint.js
var require_goog_varint = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/goog-varint.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.varint32read = exports2.varint32write = exports2.int64toString = exports2.int64fromString = exports2.varint64write = exports2.varint64read = void 0;
    function varint64read() {
      let lowBits = 0;
      let highBits = 0;
      for (let shift = 0; shift < 28; shift += 7) {
        let b = this.buf[this.pos++];
        lowBits |= (b & 127) << shift;
        if ((b & 128) == 0) {
          this.assertBounds();
          return [lowBits, highBits];
        }
      }
      let middleByte = this.buf[this.pos++];
      lowBits |= (middleByte & 15) << 28;
      highBits = (middleByte & 112) >> 4;
      if ((middleByte & 128) == 0) {
        this.assertBounds();
        return [lowBits, highBits];
      }
      for (let shift = 3; shift <= 31; shift += 7) {
        let b = this.buf[this.pos++];
        highBits |= (b & 127) << shift;
        if ((b & 128) == 0) {
          this.assertBounds();
          return [lowBits, highBits];
        }
      }
      throw new Error("invalid varint");
    }
    exports2.varint64read = varint64read;
    function varint64write(lo, hi, bytes) {
      for (let i = 0; i < 28; i = i + 7) {
        const shift = lo >>> i;
        const hasNext = !(shift >>> 7 == 0 && hi == 0);
        const byte = (hasNext ? shift | 128 : shift) & 255;
        bytes.push(byte);
        if (!hasNext) {
          return;
        }
      }
      const splitBits = lo >>> 28 & 15 | (hi & 7) << 4;
      const hasMoreBits = !(hi >> 3 == 0);
      bytes.push((hasMoreBits ? splitBits | 128 : splitBits) & 255);
      if (!hasMoreBits) {
        return;
      }
      for (let i = 3; i < 31; i = i + 7) {
        const shift = hi >>> i;
        const hasNext = !(shift >>> 7 == 0);
        const byte = (hasNext ? shift | 128 : shift) & 255;
        bytes.push(byte);
        if (!hasNext) {
          return;
        }
      }
      bytes.push(hi >>> 31 & 1);
    }
    exports2.varint64write = varint64write;
    var TWO_PWR_32_DBL = (1 << 16) * (1 << 16);
    function int64fromString(dec) {
      let minus = dec[0] == "-";
      if (minus)
        dec = dec.slice(1);
      const base = 1e6;
      let lowBits = 0;
      let highBits = 0;
      function add1e6digit(begin, end) {
        const digit1e6 = Number(dec.slice(begin, end));
        highBits *= base;
        lowBits = lowBits * base + digit1e6;
        if (lowBits >= TWO_PWR_32_DBL) {
          highBits = highBits + (lowBits / TWO_PWR_32_DBL | 0);
          lowBits = lowBits % TWO_PWR_32_DBL;
        }
      }
      add1e6digit(-24, -18);
      add1e6digit(-18, -12);
      add1e6digit(-12, -6);
      add1e6digit(-6);
      return [minus, lowBits, highBits];
    }
    exports2.int64fromString = int64fromString;
    function int64toString(bitsLow, bitsHigh) {
      if (bitsHigh >>> 0 <= 2097151) {
        return "" + (TWO_PWR_32_DBL * bitsHigh + (bitsLow >>> 0));
      }
      let low = bitsLow & 16777215;
      let mid = (bitsLow >>> 24 | bitsHigh << 8) >>> 0 & 16777215;
      let high = bitsHigh >> 16 & 65535;
      let digitA = low + mid * 6777216 + high * 6710656;
      let digitB = mid + high * 8147497;
      let digitC = high * 2;
      let base = 1e7;
      if (digitA >= base) {
        digitB += Math.floor(digitA / base);
        digitA %= base;
      }
      if (digitB >= base) {
        digitC += Math.floor(digitB / base);
        digitB %= base;
      }
      function decimalFrom1e7(digit1e7, needLeadingZeros) {
        let partial = digit1e7 ? String(digit1e7) : "";
        if (needLeadingZeros) {
          return "0000000".slice(partial.length) + partial;
        }
        return partial;
      }
      return decimalFrom1e7(
        digitC,
        /*needLeadingZeros=*/
        0
      ) + decimalFrom1e7(
        digitB,
        /*needLeadingZeros=*/
        digitC
      ) + // If the final 1e7 digit didn't need leading zeros, we would have
      // returned via the trivial code path at the top.
      decimalFrom1e7(
        digitA,
        /*needLeadingZeros=*/
        1
      );
    }
    exports2.int64toString = int64toString;
    function varint32write(value, bytes) {
      if (value >= 0) {
        while (value > 127) {
          bytes.push(value & 127 | 128);
          value = value >>> 7;
        }
        bytes.push(value);
      } else {
        for (let i = 0; i < 9; i++) {
          bytes.push(value & 127 | 128);
          value = value >> 7;
        }
        bytes.push(1);
      }
    }
    exports2.varint32write = varint32write;
    function varint32read() {
      let b = this.buf[this.pos++];
      let result = b & 127;
      if ((b & 128) == 0) {
        this.assertBounds();
        return result;
      }
      b = this.buf[this.pos++];
      result |= (b & 127) << 7;
      if ((b & 128) == 0) {
        this.assertBounds();
        return result;
      }
      b = this.buf[this.pos++];
      result |= (b & 127) << 14;
      if ((b & 128) == 0) {
        this.assertBounds();
        return result;
      }
      b = this.buf[this.pos++];
      result |= (b & 127) << 21;
      if ((b & 128) == 0) {
        this.assertBounds();
        return result;
      }
      b = this.buf[this.pos++];
      result |= (b & 15) << 28;
      for (let readBytes = 5; (b & 128) !== 0 && readBytes < 10; readBytes++)
        b = this.buf[this.pos++];
      if ((b & 128) != 0)
        throw new Error("invalid varint");
      this.assertBounds();
      return result >>> 0;
    }
    exports2.varint32read = varint32read;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/pb-long.js
var require_pb_long = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/pb-long.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.PbLong = exports2.PbULong = exports2.detectBi = void 0;
    var goog_varint_1 = require_goog_varint();
    var BI;
    function detectBi() {
      const dv = new DataView(new ArrayBuffer(8));
      const ok = globalThis.BigInt !== void 0 && typeof dv.getBigInt64 === "function" && typeof dv.getBigUint64 === "function" && typeof dv.setBigInt64 === "function" && typeof dv.setBigUint64 === "function";
      BI = ok ? {
        MIN: BigInt("-9223372036854775808"),
        MAX: BigInt("9223372036854775807"),
        UMIN: BigInt("0"),
        UMAX: BigInt("18446744073709551615"),
        C: BigInt,
        V: dv
      } : void 0;
    }
    exports2.detectBi = detectBi;
    detectBi();
    function assertBi(bi) {
      if (!bi)
        throw new Error("BigInt unavailable, see https://github.com/timostamm/protobuf-ts/blob/v1.0.8/MANUAL.md#bigint-support");
    }
    var RE_DECIMAL_STR = /^-?[0-9]+$/;
    var TWO_PWR_32_DBL = 4294967296;
    var HALF_2_PWR_32 = 2147483648;
    var SharedPbLong = class {
      /**
       * Create a new instance with the given bits.
       */
      constructor(lo, hi) {
        this.lo = lo | 0;
        this.hi = hi | 0;
      }
      /**
       * Is this instance equal to 0?
       */
      isZero() {
        return this.lo == 0 && this.hi == 0;
      }
      /**
       * Convert to a native number.
       */
      toNumber() {
        let result = this.hi * TWO_PWR_32_DBL + (this.lo >>> 0);
        if (!Number.isSafeInteger(result))
          throw new Error("cannot convert to safe number");
        return result;
      }
    };
    var PbULong = class _PbULong extends SharedPbLong {
      /**
       * Create instance from a `string`, `number` or `bigint`.
       */
      static from(value) {
        if (BI)
          switch (typeof value) {
            case "string":
              if (value == "0")
                return this.ZERO;
              if (value == "")
                throw new Error("string is no integer");
              value = BI.C(value);
            case "number":
              if (value === 0)
                return this.ZERO;
              value = BI.C(value);
            case "bigint":
              if (!value)
                return this.ZERO;
              if (value < BI.UMIN)
                throw new Error("signed value for ulong");
              if (value > BI.UMAX)
                throw new Error("ulong too large");
              BI.V.setBigUint64(0, value, true);
              return new _PbULong(BI.V.getInt32(0, true), BI.V.getInt32(4, true));
          }
        else
          switch (typeof value) {
            case "string":
              if (value == "0")
                return this.ZERO;
              value = value.trim();
              if (!RE_DECIMAL_STR.test(value))
                throw new Error("string is no integer");
              let [minus, lo, hi] = goog_varint_1.int64fromString(value);
              if (minus)
                throw new Error("signed value for ulong");
              return new _PbULong(lo, hi);
            case "number":
              if (value == 0)
                return this.ZERO;
              if (!Number.isSafeInteger(value))
                throw new Error("number is no integer");
              if (value < 0)
                throw new Error("signed value for ulong");
              return new _PbULong(value, value / TWO_PWR_32_DBL);
          }
        throw new Error("unknown value " + typeof value);
      }
      /**
       * Convert to decimal string.
       */
      toString() {
        return BI ? this.toBigInt().toString() : goog_varint_1.int64toString(this.lo, this.hi);
      }
      /**
       * Convert to native bigint.
       */
      toBigInt() {
        assertBi(BI);
        BI.V.setInt32(0, this.lo, true);
        BI.V.setInt32(4, this.hi, true);
        return BI.V.getBigUint64(0, true);
      }
    };
    exports2.PbULong = PbULong;
    PbULong.ZERO = new PbULong(0, 0);
    var PbLong3 = class _PbLong extends SharedPbLong {
      /**
       * Create instance from a `string`, `number` or `bigint`.
       */
      static from(value) {
        if (BI)
          switch (typeof value) {
            case "string":
              if (value == "0")
                return this.ZERO;
              if (value == "")
                throw new Error("string is no integer");
              value = BI.C(value);
            case "number":
              if (value === 0)
                return this.ZERO;
              value = BI.C(value);
            case "bigint":
              if (!value)
                return this.ZERO;
              if (value < BI.MIN)
                throw new Error("signed long too small");
              if (value > BI.MAX)
                throw new Error("signed long too large");
              BI.V.setBigInt64(0, value, true);
              return new _PbLong(BI.V.getInt32(0, true), BI.V.getInt32(4, true));
          }
        else
          switch (typeof value) {
            case "string":
              if (value == "0")
                return this.ZERO;
              value = value.trim();
              if (!RE_DECIMAL_STR.test(value))
                throw new Error("string is no integer");
              let [minus, lo, hi] = goog_varint_1.int64fromString(value);
              if (minus) {
                if (hi > HALF_2_PWR_32 || hi == HALF_2_PWR_32 && lo != 0)
                  throw new Error("signed long too small");
              } else if (hi >= HALF_2_PWR_32)
                throw new Error("signed long too large");
              let pbl = new _PbLong(lo, hi);
              return minus ? pbl.negate() : pbl;
            case "number":
              if (value == 0)
                return this.ZERO;
              if (!Number.isSafeInteger(value))
                throw new Error("number is no integer");
              return value > 0 ? new _PbLong(value, value / TWO_PWR_32_DBL) : new _PbLong(-value, -value / TWO_PWR_32_DBL).negate();
          }
        throw new Error("unknown value " + typeof value);
      }
      /**
       * Do we have a minus sign?
       */
      isNegative() {
        return (this.hi & HALF_2_PWR_32) !== 0;
      }
      /**
       * Negate two's complement.
       * Invert all the bits and add one to the result.
       */
      negate() {
        let hi = ~this.hi, lo = this.lo;
        if (lo)
          lo = ~lo + 1;
        else
          hi += 1;
        return new _PbLong(lo, hi);
      }
      /**
       * Convert to decimal string.
       */
      toString() {
        if (BI)
          return this.toBigInt().toString();
        if (this.isNegative()) {
          let n = this.negate();
          return "-" + goog_varint_1.int64toString(n.lo, n.hi);
        }
        return goog_varint_1.int64toString(this.lo, this.hi);
      }
      /**
       * Convert to native bigint.
       */
      toBigInt() {
        assertBi(BI);
        BI.V.setInt32(0, this.lo, true);
        BI.V.setInt32(4, this.hi, true);
        return BI.V.getBigInt64(0, true);
      }
    };
    exports2.PbLong = PbLong3;
    PbLong3.ZERO = new PbLong3(0, 0);
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/binary-reader.js
var require_binary_reader = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/binary-reader.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.BinaryReader = exports2.binaryReadOptions = void 0;
    var binary_format_contract_1 = require_binary_format_contract();
    var pb_long_1 = require_pb_long();
    var goog_varint_1 = require_goog_varint();
    var defaultsRead = {
      readUnknownField: true,
      readerFactory: (bytes) => new BinaryReader(bytes)
    };
    function binaryReadOptions(options) {
      return options ? Object.assign(Object.assign({}, defaultsRead), options) : defaultsRead;
    }
    exports2.binaryReadOptions = binaryReadOptions;
    var BinaryReader = class {
      constructor(buf, textDecoder) {
        this.varint64 = goog_varint_1.varint64read;
        this.uint32 = goog_varint_1.varint32read;
        this.buf = buf;
        this.len = buf.length;
        this.pos = 0;
        this.view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
        this.textDecoder = textDecoder !== null && textDecoder !== void 0 ? textDecoder : new TextDecoder("utf-8", {
          fatal: true,
          ignoreBOM: true
        });
      }
      /**
       * Reads a tag - field number and wire type.
       */
      tag() {
        let tag = this.uint32(), fieldNo = tag >>> 3, wireType = tag & 7;
        if (fieldNo <= 0 || wireType < 0 || wireType > 5)
          throw new Error("illegal tag: field no " + fieldNo + " wire type " + wireType);
        return [fieldNo, wireType];
      }
      /**
       * Skip one element on the wire and return the skipped data.
       * Supports WireType.StartGroup since v2.0.0-alpha.23.
       */
      skip(wireType) {
        let start = this.pos;
        switch (wireType) {
          case binary_format_contract_1.WireType.Varint:
            while (this.buf[this.pos++] & 128) {
            }
            break;
          case binary_format_contract_1.WireType.Bit64:
            this.pos += 4;
          case binary_format_contract_1.WireType.Bit32:
            this.pos += 4;
            break;
          case binary_format_contract_1.WireType.LengthDelimited:
            let len = this.uint32();
            this.pos += len;
            break;
          case binary_format_contract_1.WireType.StartGroup:
            let t;
            while ((t = this.tag()[1]) !== binary_format_contract_1.WireType.EndGroup) {
              this.skip(t);
            }
            break;
          default:
            throw new Error("cant skip wire type " + wireType);
        }
        this.assertBounds();
        return this.buf.subarray(start, this.pos);
      }
      /**
       * Throws error if position in byte array is out of range.
       */
      assertBounds() {
        if (this.pos > this.len)
          throw new RangeError("premature EOF");
      }
      /**
       * Read a `int32` field, a signed 32 bit varint.
       */
      int32() {
        return this.uint32() | 0;
      }
      /**
       * Read a `sint32` field, a signed, zigzag-encoded 32-bit varint.
       */
      sint32() {
        let zze = this.uint32();
        return zze >>> 1 ^ -(zze & 1);
      }
      /**
       * Read a `int64` field, a signed 64-bit varint.
       */
      int64() {
        return new pb_long_1.PbLong(...this.varint64());
      }
      /**
       * Read a `uint64` field, an unsigned 64-bit varint.
       */
      uint64() {
        return new pb_long_1.PbULong(...this.varint64());
      }
      /**
       * Read a `sint64` field, a signed, zig-zag-encoded 64-bit varint.
       */
      sint64() {
        let [lo, hi] = this.varint64();
        let s = -(lo & 1);
        lo = (lo >>> 1 | (hi & 1) << 31) ^ s;
        hi = hi >>> 1 ^ s;
        return new pb_long_1.PbLong(lo, hi);
      }
      /**
       * Read a `bool` field, a variant.
       */
      bool() {
        let [lo, hi] = this.varint64();
        return lo !== 0 || hi !== 0;
      }
      /**
       * Read a `fixed32` field, an unsigned, fixed-length 32-bit integer.
       */
      fixed32() {
        return this.view.getUint32((this.pos += 4) - 4, true);
      }
      /**
       * Read a `sfixed32` field, a signed, fixed-length 32-bit integer.
       */
      sfixed32() {
        return this.view.getInt32((this.pos += 4) - 4, true);
      }
      /**
       * Read a `fixed64` field, an unsigned, fixed-length 64 bit integer.
       */
      fixed64() {
        return new pb_long_1.PbULong(this.sfixed32(), this.sfixed32());
      }
      /**
       * Read a `fixed64` field, a signed, fixed-length 64-bit integer.
       */
      sfixed64() {
        return new pb_long_1.PbLong(this.sfixed32(), this.sfixed32());
      }
      /**
       * Read a `float` field, 32-bit floating point number.
       */
      float() {
        return this.view.getFloat32((this.pos += 4) - 4, true);
      }
      /**
       * Read a `double` field, a 64-bit floating point number.
       */
      double() {
        return this.view.getFloat64((this.pos += 8) - 8, true);
      }
      /**
       * Read a `bytes` field, length-delimited arbitrary data.
       */
      bytes() {
        let len = this.uint32();
        let start = this.pos;
        this.pos += len;
        this.assertBounds();
        return this.buf.subarray(start, start + len);
      }
      /**
       * Read a `string` field, length-delimited data converted to UTF-8 text.
       */
      string() {
        return this.textDecoder.decode(this.bytes());
      }
    };
    exports2.BinaryReader = BinaryReader;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/assert.js
var require_assert = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/assert.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.assertFloat32 = exports2.assertUInt32 = exports2.assertInt32 = exports2.assertNever = exports2.assert = void 0;
    function assert(condition, msg) {
      if (!condition) {
        throw new Error(msg);
      }
    }
    exports2.assert = assert;
    function assertNever(value, msg) {
      throw new Error(msg !== null && msg !== void 0 ? msg : "Unexpected object: " + value);
    }
    exports2.assertNever = assertNever;
    var FLOAT32_MAX = 34028234663852886e22;
    var FLOAT32_MIN = -34028234663852886e22;
    var UINT32_MAX = 4294967295;
    var INT32_MAX = 2147483647;
    var INT32_MIN = -2147483648;
    function assertInt32(arg) {
      if (typeof arg !== "number")
        throw new Error("invalid int 32: " + typeof arg);
      if (!Number.isInteger(arg) || arg > INT32_MAX || arg < INT32_MIN)
        throw new Error("invalid int 32: " + arg);
    }
    exports2.assertInt32 = assertInt32;
    function assertUInt32(arg) {
      if (typeof arg !== "number")
        throw new Error("invalid uint 32: " + typeof arg);
      if (!Number.isInteger(arg) || arg > UINT32_MAX || arg < 0)
        throw new Error("invalid uint 32: " + arg);
    }
    exports2.assertUInt32 = assertUInt32;
    function assertFloat32(arg) {
      if (typeof arg !== "number")
        throw new Error("invalid float 32: " + typeof arg);
      if (!Number.isFinite(arg))
        return;
      if (arg > FLOAT32_MAX || arg < FLOAT32_MIN)
        throw new Error("invalid float 32: " + arg);
    }
    exports2.assertFloat32 = assertFloat32;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/binary-writer.js
var require_binary_writer = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/binary-writer.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.BinaryWriter = exports2.binaryWriteOptions = void 0;
    var pb_long_1 = require_pb_long();
    var goog_varint_1 = require_goog_varint();
    var assert_1 = require_assert();
    var defaultsWrite = {
      writeUnknownFields: true,
      writerFactory: () => new BinaryWriter()
    };
    function binaryWriteOptions(options) {
      return options ? Object.assign(Object.assign({}, defaultsWrite), options) : defaultsWrite;
    }
    exports2.binaryWriteOptions = binaryWriteOptions;
    var BinaryWriter = class {
      constructor(textEncoder) {
        this.stack = [];
        this.textEncoder = textEncoder !== null && textEncoder !== void 0 ? textEncoder : new TextEncoder();
        this.chunks = [];
        this.buf = [];
      }
      /**
       * Return all bytes written and reset this writer.
       */
      finish() {
        this.chunks.push(new Uint8Array(this.buf));
        let len = 0;
        for (let i = 0; i < this.chunks.length; i++)
          len += this.chunks[i].length;
        let bytes = new Uint8Array(len);
        let offset = 0;
        for (let i = 0; i < this.chunks.length; i++) {
          bytes.set(this.chunks[i], offset);
          offset += this.chunks[i].length;
        }
        this.chunks = [];
        return bytes;
      }
      /**
       * Start a new fork for length-delimited data like a message
       * or a packed repeated field.
       *
       * Must be joined later with `join()`.
       */
      fork() {
        this.stack.push({ chunks: this.chunks, buf: this.buf });
        this.chunks = [];
        this.buf = [];
        return this;
      }
      /**
       * Join the last fork. Write its length and bytes, then
       * return to the previous state.
       */
      join() {
        let chunk3 = this.finish();
        let prev = this.stack.pop();
        if (!prev)
          throw new Error("invalid state, fork stack empty");
        this.chunks = prev.chunks;
        this.buf = prev.buf;
        this.uint32(chunk3.byteLength);
        return this.raw(chunk3);
      }
      /**
       * Writes a tag (field number and wire type).
       *
       * Equivalent to `uint32( (fieldNo << 3 | type) >>> 0 )`.
       *
       * Generated code should compute the tag ahead of time and call `uint32()`.
       */
      tag(fieldNo, type) {
        return this.uint32((fieldNo << 3 | type) >>> 0);
      }
      /**
       * Write a chunk of raw bytes.
       */
      raw(chunk3) {
        if (this.buf.length) {
          this.chunks.push(new Uint8Array(this.buf));
          this.buf = [];
        }
        this.chunks.push(chunk3);
        return this;
      }
      /**
       * Write a `uint32` value, an unsigned 32 bit varint.
       */
      uint32(value) {
        assert_1.assertUInt32(value);
        while (value > 127) {
          this.buf.push(value & 127 | 128);
          value = value >>> 7;
        }
        this.buf.push(value);
        return this;
      }
      /**
       * Write a `int32` value, a signed 32 bit varint.
       */
      int32(value) {
        assert_1.assertInt32(value);
        goog_varint_1.varint32write(value, this.buf);
        return this;
      }
      /**
       * Write a `bool` value, a variant.
       */
      bool(value) {
        this.buf.push(value ? 1 : 0);
        return this;
      }
      /**
       * Write a `bytes` value, length-delimited arbitrary data.
       */
      bytes(value) {
        this.uint32(value.byteLength);
        return this.raw(value);
      }
      /**
       * Write a `string` value, length-delimited data converted to UTF-8 text.
       */
      string(value) {
        let chunk3 = this.textEncoder.encode(value);
        this.uint32(chunk3.byteLength);
        return this.raw(chunk3);
      }
      /**
       * Write a `float` value, 32-bit floating point number.
       */
      float(value) {
        assert_1.assertFloat32(value);
        let chunk3 = new Uint8Array(4);
        new DataView(chunk3.buffer).setFloat32(0, value, true);
        return this.raw(chunk3);
      }
      /**
       * Write a `double` value, a 64-bit floating point number.
       */
      double(value) {
        let chunk3 = new Uint8Array(8);
        new DataView(chunk3.buffer).setFloat64(0, value, true);
        return this.raw(chunk3);
      }
      /**
       * Write a `fixed32` value, an unsigned, fixed-length 32-bit integer.
       */
      fixed32(value) {
        assert_1.assertUInt32(value);
        let chunk3 = new Uint8Array(4);
        new DataView(chunk3.buffer).setUint32(0, value, true);
        return this.raw(chunk3);
      }
      /**
       * Write a `sfixed32` value, a signed, fixed-length 32-bit integer.
       */
      sfixed32(value) {
        assert_1.assertInt32(value);
        let chunk3 = new Uint8Array(4);
        new DataView(chunk3.buffer).setInt32(0, value, true);
        return this.raw(chunk3);
      }
      /**
       * Write a `sint32` value, a signed, zigzag-encoded 32-bit varint.
       */
      sint32(value) {
        assert_1.assertInt32(value);
        value = (value << 1 ^ value >> 31) >>> 0;
        goog_varint_1.varint32write(value, this.buf);
        return this;
      }
      /**
       * Write a `fixed64` value, a signed, fixed-length 64-bit integer.
       */
      sfixed64(value) {
        let chunk3 = new Uint8Array(8);
        let view = new DataView(chunk3.buffer);
        let long = pb_long_1.PbLong.from(value);
        view.setInt32(0, long.lo, true);
        view.setInt32(4, long.hi, true);
        return this.raw(chunk3);
      }
      /**
       * Write a `fixed64` value, an unsigned, fixed-length 64 bit integer.
       */
      fixed64(value) {
        let chunk3 = new Uint8Array(8);
        let view = new DataView(chunk3.buffer);
        let long = pb_long_1.PbULong.from(value);
        view.setInt32(0, long.lo, true);
        view.setInt32(4, long.hi, true);
        return this.raw(chunk3);
      }
      /**
       * Write a `int64` value, a signed 64-bit varint.
       */
      int64(value) {
        let long = pb_long_1.PbLong.from(value);
        goog_varint_1.varint64write(long.lo, long.hi, this.buf);
        return this;
      }
      /**
       * Write a `sint64` value, a signed, zig-zag-encoded 64-bit varint.
       */
      sint64(value) {
        let long = pb_long_1.PbLong.from(value), sign = long.hi >> 31, lo = long.lo << 1 ^ sign, hi = (long.hi << 1 | long.lo >>> 31) ^ sign;
        goog_varint_1.varint64write(lo, hi, this.buf);
        return this;
      }
      /**
       * Write a `uint64` value, an unsigned 64-bit varint.
       */
      uint64(value) {
        let long = pb_long_1.PbULong.from(value);
        goog_varint_1.varint64write(long.lo, long.hi, this.buf);
        return this;
      }
    };
    exports2.BinaryWriter = BinaryWriter;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/json-format-contract.js
var require_json_format_contract = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/json-format-contract.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.mergeJsonOptions = exports2.jsonWriteOptions = exports2.jsonReadOptions = void 0;
    var defaultsWrite = {
      emitDefaultValues: false,
      enumAsInteger: false,
      useProtoFieldName: false,
      prettySpaces: 0
    };
    var defaultsRead = {
      ignoreUnknownFields: false
    };
    function jsonReadOptions(options) {
      return options ? Object.assign(Object.assign({}, defaultsRead), options) : defaultsRead;
    }
    exports2.jsonReadOptions = jsonReadOptions;
    function jsonWriteOptions2(options) {
      return options ? Object.assign(Object.assign({}, defaultsWrite), options) : defaultsWrite;
    }
    exports2.jsonWriteOptions = jsonWriteOptions2;
    function mergeJsonOptions(a, b) {
      var _a, _b;
      let c = Object.assign(Object.assign({}, a), b);
      c.typeRegistry = [...(_a = a === null || a === void 0 ? void 0 : a.typeRegistry) !== null && _a !== void 0 ? _a : [], ...(_b = b === null || b === void 0 ? void 0 : b.typeRegistry) !== null && _b !== void 0 ? _b : []];
      return c;
    }
    exports2.mergeJsonOptions = mergeJsonOptions;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/message-type-contract.js
var require_message_type_contract = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/message-type-contract.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MESSAGE_TYPE = void 0;
    exports2.MESSAGE_TYPE = /* @__PURE__ */ Symbol.for("protobuf-ts/message-type");
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/lower-camel-case.js
var require_lower_camel_case = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/lower-camel-case.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.lowerCamelCase = void 0;
    function lowerCamelCase2(snakeCase) {
      let capNext = false;
      const sb = [];
      for (let i = 0; i < snakeCase.length; i++) {
        let next = snakeCase.charAt(i);
        if (next == "_") {
          capNext = true;
        } else if (/\d/.test(next)) {
          sb.push(next);
          capNext = true;
        } else if (capNext) {
          sb.push(next.toUpperCase());
          capNext = false;
        } else if (i == 0) {
          sb.push(next.toLowerCase());
        } else {
          sb.push(next);
        }
      }
      return sb.join("");
    }
    exports2.lowerCamelCase = lowerCamelCase2;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-info.js
var require_reflection_info = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-info.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.readMessageOption = exports2.readFieldOption = exports2.readFieldOptions = exports2.normalizeFieldInfo = exports2.RepeatType = exports2.LongType = exports2.ScalarType = void 0;
    var lower_camel_case_1 = require_lower_camel_case();
    var ScalarType;
    (function(ScalarType2) {
      ScalarType2[ScalarType2["DOUBLE"] = 1] = "DOUBLE";
      ScalarType2[ScalarType2["FLOAT"] = 2] = "FLOAT";
      ScalarType2[ScalarType2["INT64"] = 3] = "INT64";
      ScalarType2[ScalarType2["UINT64"] = 4] = "UINT64";
      ScalarType2[ScalarType2["INT32"] = 5] = "INT32";
      ScalarType2[ScalarType2["FIXED64"] = 6] = "FIXED64";
      ScalarType2[ScalarType2["FIXED32"] = 7] = "FIXED32";
      ScalarType2[ScalarType2["BOOL"] = 8] = "BOOL";
      ScalarType2[ScalarType2["STRING"] = 9] = "STRING";
      ScalarType2[ScalarType2["BYTES"] = 12] = "BYTES";
      ScalarType2[ScalarType2["UINT32"] = 13] = "UINT32";
      ScalarType2[ScalarType2["SFIXED32"] = 15] = "SFIXED32";
      ScalarType2[ScalarType2["SFIXED64"] = 16] = "SFIXED64";
      ScalarType2[ScalarType2["SINT32"] = 17] = "SINT32";
      ScalarType2[ScalarType2["SINT64"] = 18] = "SINT64";
    })(ScalarType = exports2.ScalarType || (exports2.ScalarType = {}));
    var LongType;
    (function(LongType2) {
      LongType2[LongType2["BIGINT"] = 0] = "BIGINT";
      LongType2[LongType2["STRING"] = 1] = "STRING";
      LongType2[LongType2["NUMBER"] = 2] = "NUMBER";
    })(LongType = exports2.LongType || (exports2.LongType = {}));
    var RepeatType;
    (function(RepeatType2) {
      RepeatType2[RepeatType2["NO"] = 0] = "NO";
      RepeatType2[RepeatType2["PACKED"] = 1] = "PACKED";
      RepeatType2[RepeatType2["UNPACKED"] = 2] = "UNPACKED";
    })(RepeatType = exports2.RepeatType || (exports2.RepeatType = {}));
    function normalizeFieldInfo(field) {
      var _a, _b, _c, _d;
      field.localName = (_a = field.localName) !== null && _a !== void 0 ? _a : lower_camel_case_1.lowerCamelCase(field.name);
      field.jsonName = (_b = field.jsonName) !== null && _b !== void 0 ? _b : lower_camel_case_1.lowerCamelCase(field.name);
      field.repeat = (_c = field.repeat) !== null && _c !== void 0 ? _c : RepeatType.NO;
      field.opt = (_d = field.opt) !== null && _d !== void 0 ? _d : field.repeat ? false : field.oneof ? false : field.kind == "message";
      return field;
    }
    exports2.normalizeFieldInfo = normalizeFieldInfo;
    function readFieldOptions(messageType, fieldName, extensionName, extensionType) {
      var _a;
      const options = (_a = messageType.fields.find((m, i) => m.localName == fieldName || i == fieldName)) === null || _a === void 0 ? void 0 : _a.options;
      return options && options[extensionName] ? extensionType.fromJson(options[extensionName]) : void 0;
    }
    exports2.readFieldOptions = readFieldOptions;
    function readFieldOption(messageType, fieldName, extensionName, extensionType) {
      var _a;
      const options = (_a = messageType.fields.find((m, i) => m.localName == fieldName || i == fieldName)) === null || _a === void 0 ? void 0 : _a.options;
      if (!options) {
        return void 0;
      }
      const optionVal = options[extensionName];
      if (optionVal === void 0) {
        return optionVal;
      }
      return extensionType ? extensionType.fromJson(optionVal) : optionVal;
    }
    exports2.readFieldOption = readFieldOption;
    function readMessageOption(messageType, extensionName, extensionType) {
      const options = messageType.options;
      const optionVal = options[extensionName];
      if (optionVal === void 0) {
        return optionVal;
      }
      return extensionType ? extensionType.fromJson(optionVal) : optionVal;
    }
    exports2.readMessageOption = readMessageOption;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/oneof.js
var require_oneof = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/oneof.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.getSelectedOneofValue = exports2.clearOneofValue = exports2.setUnknownOneofValue = exports2.setOneofValue = exports2.getOneofValue = exports2.isOneofGroup = void 0;
    function isOneofGroup(any) {
      if (typeof any != "object" || any === null || !any.hasOwnProperty("oneofKind")) {
        return false;
      }
      switch (typeof any.oneofKind) {
        case "string":
          if (any[any.oneofKind] === void 0)
            return false;
          return Object.keys(any).length == 2;
        case "undefined":
          return Object.keys(any).length == 1;
        default:
          return false;
      }
    }
    exports2.isOneofGroup = isOneofGroup;
    function getOneofValue(oneof, kind) {
      return oneof[kind];
    }
    exports2.getOneofValue = getOneofValue;
    function setOneofValue(oneof, kind, value) {
      if (oneof.oneofKind !== void 0) {
        delete oneof[oneof.oneofKind];
      }
      oneof.oneofKind = kind;
      if (value !== void 0) {
        oneof[kind] = value;
      }
    }
    exports2.setOneofValue = setOneofValue;
    function setUnknownOneofValue(oneof, kind, value) {
      if (oneof.oneofKind !== void 0) {
        delete oneof[oneof.oneofKind];
      }
      oneof.oneofKind = kind;
      if (value !== void 0 && kind !== void 0) {
        oneof[kind] = value;
      }
    }
    exports2.setUnknownOneofValue = setUnknownOneofValue;
    function clearOneofValue(oneof) {
      if (oneof.oneofKind !== void 0) {
        delete oneof[oneof.oneofKind];
      }
      oneof.oneofKind = void 0;
    }
    exports2.clearOneofValue = clearOneofValue;
    function getSelectedOneofValue(oneof) {
      if (oneof.oneofKind === void 0) {
        return void 0;
      }
      return oneof[oneof.oneofKind];
    }
    exports2.getSelectedOneofValue = getSelectedOneofValue;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-type-check.js
var require_reflection_type_check = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-type-check.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ReflectionTypeCheck = void 0;
    var reflection_info_1 = require_reflection_info();
    var oneof_1 = require_oneof();
    var ReflectionTypeCheck = class {
      constructor(info) {
        var _a;
        this.fields = (_a = info.fields) !== null && _a !== void 0 ? _a : [];
      }
      prepare() {
        if (this.data)
          return;
        const req = [], known = [], oneofs = [];
        for (let field of this.fields) {
          if (field.oneof) {
            if (!oneofs.includes(field.oneof)) {
              oneofs.push(field.oneof);
              req.push(field.oneof);
              known.push(field.oneof);
            }
          } else {
            known.push(field.localName);
            switch (field.kind) {
              case "scalar":
              case "enum":
                if (!field.opt || field.repeat)
                  req.push(field.localName);
                break;
              case "message":
                if (field.repeat)
                  req.push(field.localName);
                break;
              case "map":
                req.push(field.localName);
                break;
            }
          }
        }
        this.data = { req, known, oneofs: Object.values(oneofs) };
      }
      /**
       * Is the argument a valid message as specified by the
       * reflection information?
       *
       * Checks all field types recursively. The `depth`
       * specifies how deep into the structure the check will be.
       *
       * With a depth of 0, only the presence of fields
       * is checked.
       *
       * With a depth of 1 or more, the field types are checked.
       *
       * With a depth of 2 or more, the members of map, repeated
       * and message fields are checked.
       *
       * Message fields will be checked recursively with depth - 1.
       *
       * The number of map entries / repeated values being checked
       * is < depth.
       */
      is(message, depth, allowExcessProperties = false) {
        if (depth < 0)
          return true;
        if (message === null || message === void 0 || typeof message != "object")
          return false;
        this.prepare();
        let keys = Object.keys(message), data = this.data;
        if (keys.length < data.req.length || data.req.some((n) => !keys.includes(n)))
          return false;
        if (!allowExcessProperties) {
          if (keys.some((k) => !data.known.includes(k)))
            return false;
        }
        if (depth < 1) {
          return true;
        }
        for (const name of data.oneofs) {
          const group = message[name];
          if (!oneof_1.isOneofGroup(group))
            return false;
          if (group.oneofKind === void 0)
            continue;
          const field = this.fields.find((f) => f.localName === group.oneofKind);
          if (!field)
            return false;
          if (!this.field(group[group.oneofKind], field, allowExcessProperties, depth))
            return false;
        }
        for (const field of this.fields) {
          if (field.oneof !== void 0)
            continue;
          if (!this.field(message[field.localName], field, allowExcessProperties, depth))
            return false;
        }
        return true;
      }
      field(arg, field, allowExcessProperties, depth) {
        let repeated = field.repeat;
        switch (field.kind) {
          case "scalar":
            if (arg === void 0)
              return field.opt;
            if (repeated)
              return this.scalars(arg, field.T, depth, field.L);
            return this.scalar(arg, field.T, field.L);
          case "enum":
            if (arg === void 0)
              return field.opt;
            if (repeated)
              return this.scalars(arg, reflection_info_1.ScalarType.INT32, depth);
            return this.scalar(arg, reflection_info_1.ScalarType.INT32);
          case "message":
            if (arg === void 0)
              return true;
            if (repeated)
              return this.messages(arg, field.T(), allowExcessProperties, depth);
            return this.message(arg, field.T(), allowExcessProperties, depth);
          case "map":
            if (typeof arg != "object" || arg === null)
              return false;
            if (depth < 2)
              return true;
            if (!this.mapKeys(arg, field.K, depth))
              return false;
            switch (field.V.kind) {
              case "scalar":
                return this.scalars(Object.values(arg), field.V.T, depth, field.V.L);
              case "enum":
                return this.scalars(Object.values(arg), reflection_info_1.ScalarType.INT32, depth);
              case "message":
                return this.messages(Object.values(arg), field.V.T(), allowExcessProperties, depth);
            }
            break;
        }
        return true;
      }
      message(arg, type, allowExcessProperties, depth) {
        if (allowExcessProperties) {
          return type.isAssignable(arg, depth);
        }
        return type.is(arg, depth);
      }
      messages(arg, type, allowExcessProperties, depth) {
        if (!Array.isArray(arg))
          return false;
        if (depth < 2)
          return true;
        if (allowExcessProperties) {
          for (let i = 0; i < arg.length && i < depth; i++)
            if (!type.isAssignable(arg[i], depth - 1))
              return false;
        } else {
          for (let i = 0; i < arg.length && i < depth; i++)
            if (!type.is(arg[i], depth - 1))
              return false;
        }
        return true;
      }
      scalar(arg, type, longType) {
        let argType = typeof arg;
        switch (type) {
          case reflection_info_1.ScalarType.UINT64:
          case reflection_info_1.ScalarType.FIXED64:
          case reflection_info_1.ScalarType.INT64:
          case reflection_info_1.ScalarType.SFIXED64:
          case reflection_info_1.ScalarType.SINT64:
            switch (longType) {
              case reflection_info_1.LongType.BIGINT:
                return argType == "bigint";
              case reflection_info_1.LongType.NUMBER:
                return argType == "number" && !isNaN(arg);
              default:
                return argType == "string";
            }
          case reflection_info_1.ScalarType.BOOL:
            return argType == "boolean";
          case reflection_info_1.ScalarType.STRING:
            return argType == "string";
          case reflection_info_1.ScalarType.BYTES:
            return arg instanceof Uint8Array;
          case reflection_info_1.ScalarType.DOUBLE:
          case reflection_info_1.ScalarType.FLOAT:
            return argType == "number" && !isNaN(arg);
          default:
            return argType == "number" && Number.isInteger(arg);
        }
      }
      scalars(arg, type, depth, longType) {
        if (!Array.isArray(arg))
          return false;
        if (depth < 2)
          return true;
        if (Array.isArray(arg)) {
          for (let i = 0; i < arg.length && i < depth; i++)
            if (!this.scalar(arg[i], type, longType))
              return false;
        }
        return true;
      }
      mapKeys(map2, type, depth) {
        let keys = Object.keys(map2);
        switch (type) {
          case reflection_info_1.ScalarType.INT32:
          case reflection_info_1.ScalarType.FIXED32:
          case reflection_info_1.ScalarType.SFIXED32:
          case reflection_info_1.ScalarType.SINT32:
          case reflection_info_1.ScalarType.UINT32:
            return this.scalars(keys.slice(0, depth).map((k) => parseInt(k)), type, depth);
          case reflection_info_1.ScalarType.BOOL:
            return this.scalars(keys.slice(0, depth).map((k) => k == "true" ? true : k == "false" ? false : k), type, depth);
          default:
            return this.scalars(keys, type, depth, reflection_info_1.LongType.STRING);
        }
      }
    };
    exports2.ReflectionTypeCheck = ReflectionTypeCheck;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-long-convert.js
var require_reflection_long_convert = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-long-convert.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.reflectionLongConvert = void 0;
    var reflection_info_1 = require_reflection_info();
    function reflectionLongConvert(long, type) {
      switch (type) {
        case reflection_info_1.LongType.BIGINT:
          return long.toBigInt();
        case reflection_info_1.LongType.NUMBER:
          return long.toNumber();
        default:
          return long.toString();
      }
    }
    exports2.reflectionLongConvert = reflectionLongConvert;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-json-reader.js
var require_reflection_json_reader = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-json-reader.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ReflectionJsonReader = void 0;
    var json_typings_1 = require_json_typings();
    var base64_1 = require_base64();
    var reflection_info_1 = require_reflection_info();
    var pb_long_1 = require_pb_long();
    var assert_1 = require_assert();
    var reflection_long_convert_1 = require_reflection_long_convert();
    var ReflectionJsonReader = class {
      constructor(info) {
        this.info = info;
      }
      prepare() {
        var _a;
        if (this.fMap === void 0) {
          this.fMap = {};
          const fieldsInput = (_a = this.info.fields) !== null && _a !== void 0 ? _a : [];
          for (const field of fieldsInput) {
            this.fMap[field.name] = field;
            this.fMap[field.jsonName] = field;
            this.fMap[field.localName] = field;
          }
        }
      }
      // Cannot parse JSON <type of jsonValue> for <type name>#<fieldName>.
      assert(condition, fieldName, jsonValue) {
        if (!condition) {
          let what = json_typings_1.typeofJsonValue(jsonValue);
          if (what == "number" || what == "boolean")
            what = jsonValue.toString();
          throw new Error(`Cannot parse JSON ${what} for ${this.info.typeName}#${fieldName}`);
        }
      }
      /**
       * Reads a message from canonical JSON format into the target message.
       *
       * Repeated fields are appended. Map entries are added, overwriting
       * existing keys.
       *
       * If a message field is already present, it will be merged with the
       * new data.
       */
      read(input, message, options) {
        this.prepare();
        const oneofsHandled = [];
        for (const [jsonKey, jsonValue] of Object.entries(input)) {
          const field = this.fMap[jsonKey];
          if (!field) {
            if (!options.ignoreUnknownFields)
              throw new Error(`Found unknown field while reading ${this.info.typeName} from JSON format. JSON key: ${jsonKey}`);
            continue;
          }
          const localName = field.localName;
          let target;
          if (field.oneof) {
            if (jsonValue === null && (field.kind !== "enum" || field.T()[0] !== "google.protobuf.NullValue")) {
              continue;
            }
            if (oneofsHandled.includes(field.oneof))
              throw new Error(`Multiple members of the oneof group "${field.oneof}" of ${this.info.typeName} are present in JSON.`);
            oneofsHandled.push(field.oneof);
            target = message[field.oneof] = {
              oneofKind: localName
            };
          } else {
            target = message;
          }
          if (field.kind == "map") {
            if (jsonValue === null) {
              continue;
            }
            this.assert(json_typings_1.isJsonObject(jsonValue), field.name, jsonValue);
            const fieldObj = target[localName];
            for (const [jsonObjKey, jsonObjValue] of Object.entries(jsonValue)) {
              this.assert(jsonObjValue !== null, field.name + " map value", null);
              let val;
              switch (field.V.kind) {
                case "message":
                  val = field.V.T().internalJsonRead(jsonObjValue, options);
                  break;
                case "enum":
                  val = this.enum(field.V.T(), jsonObjValue, field.name, options.ignoreUnknownFields);
                  if (val === false)
                    continue;
                  break;
                case "scalar":
                  val = this.scalar(jsonObjValue, field.V.T, field.V.L, field.name);
                  break;
              }
              this.assert(val !== void 0, field.name + " map value", jsonObjValue);
              let key = jsonObjKey;
              if (field.K == reflection_info_1.ScalarType.BOOL)
                key = key == "true" ? true : key == "false" ? false : key;
              key = this.scalar(key, field.K, reflection_info_1.LongType.STRING, field.name).toString();
              fieldObj[key] = val;
            }
          } else if (field.repeat) {
            if (jsonValue === null)
              continue;
            this.assert(Array.isArray(jsonValue), field.name, jsonValue);
            const fieldArr = target[localName];
            for (const jsonItem of jsonValue) {
              this.assert(jsonItem !== null, field.name, null);
              let val;
              switch (field.kind) {
                case "message":
                  val = field.T().internalJsonRead(jsonItem, options);
                  break;
                case "enum":
                  val = this.enum(field.T(), jsonItem, field.name, options.ignoreUnknownFields);
                  if (val === false)
                    continue;
                  break;
                case "scalar":
                  val = this.scalar(jsonItem, field.T, field.L, field.name);
                  break;
              }
              this.assert(val !== void 0, field.name, jsonValue);
              fieldArr.push(val);
            }
          } else {
            switch (field.kind) {
              case "message":
                if (jsonValue === null && field.T().typeName != "google.protobuf.Value") {
                  this.assert(field.oneof === void 0, field.name + " (oneof member)", null);
                  continue;
                }
                target[localName] = field.T().internalJsonRead(jsonValue, options, target[localName]);
                break;
              case "enum":
                if (jsonValue === null)
                  continue;
                let val = this.enum(field.T(), jsonValue, field.name, options.ignoreUnknownFields);
                if (val === false)
                  continue;
                target[localName] = val;
                break;
              case "scalar":
                if (jsonValue === null)
                  continue;
                target[localName] = this.scalar(jsonValue, field.T, field.L, field.name);
                break;
            }
          }
        }
      }
      /**
       * Returns `false` for unrecognized string representations.
       *
       * google.protobuf.NullValue accepts only JSON `null` (or the old `"NULL_VALUE"`).
       */
      enum(type, json, fieldName, ignoreUnknownFields) {
        if (type[0] == "google.protobuf.NullValue")
          assert_1.assert(json === null || json === "NULL_VALUE", `Unable to parse field ${this.info.typeName}#${fieldName}, enum ${type[0]} only accepts null.`);
        if (json === null)
          return 0;
        switch (typeof json) {
          case "number":
            assert_1.assert(Number.isInteger(json), `Unable to parse field ${this.info.typeName}#${fieldName}, enum can only be integral number, got ${json}.`);
            return json;
          case "string":
            let localEnumName = json;
            if (type[2] && json.substring(0, type[2].length) === type[2])
              localEnumName = json.substring(type[2].length);
            let enumNumber = type[1][localEnumName];
            if (typeof enumNumber === "undefined" && ignoreUnknownFields) {
              return false;
            }
            assert_1.assert(typeof enumNumber == "number", `Unable to parse field ${this.info.typeName}#${fieldName}, enum ${type[0]} has no value for "${json}".`);
            return enumNumber;
        }
        assert_1.assert(false, `Unable to parse field ${this.info.typeName}#${fieldName}, cannot parse enum value from ${typeof json}".`);
      }
      scalar(json, type, longType, fieldName) {
        let e;
        try {
          switch (type) {
            // float, double: JSON value will be a number or one of the special string values "NaN", "Infinity", and "-Infinity".
            // Either numbers or strings are accepted. Exponent notation is also accepted.
            case reflection_info_1.ScalarType.DOUBLE:
            case reflection_info_1.ScalarType.FLOAT:
              if (json === null)
                return 0;
              if (json === "NaN")
                return Number.NaN;
              if (json === "Infinity")
                return Number.POSITIVE_INFINITY;
              if (json === "-Infinity")
                return Number.NEGATIVE_INFINITY;
              if (json === "") {
                e = "empty string";
                break;
              }
              if (typeof json == "string" && json.trim().length !== json.length) {
                e = "extra whitespace";
                break;
              }
              if (typeof json != "string" && typeof json != "number") {
                break;
              }
              let float = Number(json);
              if (Number.isNaN(float)) {
                e = "not a number";
                break;
              }
              if (!Number.isFinite(float)) {
                e = "too large or small";
                break;
              }
              if (type == reflection_info_1.ScalarType.FLOAT)
                assert_1.assertFloat32(float);
              return float;
            // int32, fixed32, uint32: JSON value will be a decimal number. Either numbers or strings are accepted.
            case reflection_info_1.ScalarType.INT32:
            case reflection_info_1.ScalarType.FIXED32:
            case reflection_info_1.ScalarType.SFIXED32:
            case reflection_info_1.ScalarType.SINT32:
            case reflection_info_1.ScalarType.UINT32:
              if (json === null)
                return 0;
              let int32;
              if (typeof json == "number")
                int32 = json;
              else if (json === "")
                e = "empty string";
              else if (typeof json == "string") {
                if (json.trim().length !== json.length)
                  e = "extra whitespace";
                else
                  int32 = Number(json);
              }
              if (int32 === void 0)
                break;
              if (type == reflection_info_1.ScalarType.UINT32)
                assert_1.assertUInt32(int32);
              else
                assert_1.assertInt32(int32);
              return int32;
            // int64, fixed64, uint64: JSON value will be a decimal string. Either numbers or strings are accepted.
            case reflection_info_1.ScalarType.INT64:
            case reflection_info_1.ScalarType.SFIXED64:
            case reflection_info_1.ScalarType.SINT64:
              if (json === null)
                return reflection_long_convert_1.reflectionLongConvert(pb_long_1.PbLong.ZERO, longType);
              if (typeof json != "number" && typeof json != "string")
                break;
              return reflection_long_convert_1.reflectionLongConvert(pb_long_1.PbLong.from(json), longType);
            case reflection_info_1.ScalarType.FIXED64:
            case reflection_info_1.ScalarType.UINT64:
              if (json === null)
                return reflection_long_convert_1.reflectionLongConvert(pb_long_1.PbULong.ZERO, longType);
              if (typeof json != "number" && typeof json != "string")
                break;
              return reflection_long_convert_1.reflectionLongConvert(pb_long_1.PbULong.from(json), longType);
            // bool:
            case reflection_info_1.ScalarType.BOOL:
              if (json === null)
                return false;
              if (typeof json !== "boolean")
                break;
              return json;
            // string:
            case reflection_info_1.ScalarType.STRING:
              if (json === null)
                return "";
              if (typeof json !== "string") {
                e = "extra whitespace";
                break;
              }
              try {
                encodeURIComponent(json);
              } catch (e2) {
                e2 = "invalid UTF8";
                break;
              }
              return json;
            // bytes: JSON value will be the data encoded as a string using standard base64 encoding with paddings.
            // Either standard or URL-safe base64 encoding with/without paddings are accepted.
            case reflection_info_1.ScalarType.BYTES:
              if (json === null || json === "")
                return new Uint8Array(0);
              if (typeof json !== "string")
                break;
              return base64_1.base64decode(json);
          }
        } catch (error) {
          e = error.message;
        }
        this.assert(false, fieldName + (e ? " - " + e : ""), json);
      }
    };
    exports2.ReflectionJsonReader = ReflectionJsonReader;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-json-writer.js
var require_reflection_json_writer = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-json-writer.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ReflectionJsonWriter = void 0;
    var base64_1 = require_base64();
    var pb_long_1 = require_pb_long();
    var reflection_info_1 = require_reflection_info();
    var assert_1 = require_assert();
    var ReflectionJsonWriter = class {
      constructor(info) {
        var _a;
        this.fields = (_a = info.fields) !== null && _a !== void 0 ? _a : [];
      }
      /**
       * Converts the message to a JSON object, based on the field descriptors.
       */
      write(message, options) {
        const json = {}, source = message;
        for (const field of this.fields) {
          if (!field.oneof) {
            let jsonValue2 = this.field(field, source[field.localName], options);
            if (jsonValue2 !== void 0)
              json[options.useProtoFieldName ? field.name : field.jsonName] = jsonValue2;
            continue;
          }
          const group = source[field.oneof];
          if (group.oneofKind !== field.localName)
            continue;
          const opt = field.kind == "scalar" || field.kind == "enum" ? Object.assign(Object.assign({}, options), { emitDefaultValues: true }) : options;
          let jsonValue = this.field(field, group[field.localName], opt);
          assert_1.assert(jsonValue !== void 0);
          json[options.useProtoFieldName ? field.name : field.jsonName] = jsonValue;
        }
        return json;
      }
      field(field, value, options) {
        let jsonValue = void 0;
        if (field.kind == "map") {
          assert_1.assert(typeof value == "object" && value !== null);
          const jsonObj = {};
          switch (field.V.kind) {
            case "scalar":
              for (const [entryKey, entryValue] of Object.entries(value)) {
                const val = this.scalar(field.V.T, entryValue, field.name, false, true);
                assert_1.assert(val !== void 0);
                jsonObj[entryKey.toString()] = val;
              }
              break;
            case "message":
              const messageType = field.V.T();
              for (const [entryKey, entryValue] of Object.entries(value)) {
                const val = this.message(messageType, entryValue, field.name, options);
                assert_1.assert(val !== void 0);
                jsonObj[entryKey.toString()] = val;
              }
              break;
            case "enum":
              const enumInfo = field.V.T();
              for (const [entryKey, entryValue] of Object.entries(value)) {
                assert_1.assert(entryValue === void 0 || typeof entryValue == "number");
                const val = this.enum(enumInfo, entryValue, field.name, false, true, options.enumAsInteger);
                assert_1.assert(val !== void 0);
                jsonObj[entryKey.toString()] = val;
              }
              break;
          }
          if (options.emitDefaultValues || Object.keys(jsonObj).length > 0)
            jsonValue = jsonObj;
        } else if (field.repeat) {
          assert_1.assert(Array.isArray(value));
          const jsonArr = [];
          switch (field.kind) {
            case "scalar":
              for (let i = 0; i < value.length; i++) {
                const val = this.scalar(field.T, value[i], field.name, field.opt, true);
                assert_1.assert(val !== void 0);
                jsonArr.push(val);
              }
              break;
            case "enum":
              const enumInfo = field.T();
              for (let i = 0; i < value.length; i++) {
                assert_1.assert(value[i] === void 0 || typeof value[i] == "number");
                const val = this.enum(enumInfo, value[i], field.name, field.opt, true, options.enumAsInteger);
                assert_1.assert(val !== void 0);
                jsonArr.push(val);
              }
              break;
            case "message":
              const messageType = field.T();
              for (let i = 0; i < value.length; i++) {
                const val = this.message(messageType, value[i], field.name, options);
                assert_1.assert(val !== void 0);
                jsonArr.push(val);
              }
              break;
          }
          if (options.emitDefaultValues || jsonArr.length > 0 || options.emitDefaultValues)
            jsonValue = jsonArr;
        } else {
          switch (field.kind) {
            case "scalar":
              jsonValue = this.scalar(field.T, value, field.name, field.opt, options.emitDefaultValues);
              break;
            case "enum":
              jsonValue = this.enum(field.T(), value, field.name, field.opt, options.emitDefaultValues, options.enumAsInteger);
              break;
            case "message":
              jsonValue = this.message(field.T(), value, field.name, options);
              break;
          }
        }
        return jsonValue;
      }
      /**
       * Returns `null` as the default for google.protobuf.NullValue.
       */
      enum(type, value, fieldName, optional2, emitDefaultValues, enumAsInteger) {
        if (type[0] == "google.protobuf.NullValue")
          return !emitDefaultValues && !optional2 ? void 0 : null;
        if (value === void 0) {
          assert_1.assert(optional2);
          return void 0;
        }
        if (value === 0 && !emitDefaultValues && !optional2)
          return void 0;
        assert_1.assert(typeof value == "number");
        assert_1.assert(Number.isInteger(value));
        if (enumAsInteger || !type[1].hasOwnProperty(value))
          return value;
        if (type[2])
          return type[2] + type[1][value];
        return type[1][value];
      }
      message(type, value, fieldName, options) {
        if (value === void 0)
          return options.emitDefaultValues ? null : void 0;
        return type.internalJsonWrite(value, options);
      }
      scalar(type, value, fieldName, optional2, emitDefaultValues) {
        if (value === void 0) {
          assert_1.assert(optional2);
          return void 0;
        }
        const ed = emitDefaultValues || optional2;
        switch (type) {
          // int32, fixed32, uint32: JSON value will be a decimal number. Either numbers or strings are accepted.
          case reflection_info_1.ScalarType.INT32:
          case reflection_info_1.ScalarType.SFIXED32:
          case reflection_info_1.ScalarType.SINT32:
            if (value === 0)
              return ed ? 0 : void 0;
            assert_1.assertInt32(value);
            return value;
          case reflection_info_1.ScalarType.FIXED32:
          case reflection_info_1.ScalarType.UINT32:
            if (value === 0)
              return ed ? 0 : void 0;
            assert_1.assertUInt32(value);
            return value;
          // float, double: JSON value will be a number or one of the special string values "NaN", "Infinity", and "-Infinity".
          // Either numbers or strings are accepted. Exponent notation is also accepted.
          case reflection_info_1.ScalarType.FLOAT:
            assert_1.assertFloat32(value);
          case reflection_info_1.ScalarType.DOUBLE:
            if (value === 0)
              return ed ? 0 : void 0;
            assert_1.assert(typeof value == "number");
            if (Number.isNaN(value))
              return "NaN";
            if (value === Number.POSITIVE_INFINITY)
              return "Infinity";
            if (value === Number.NEGATIVE_INFINITY)
              return "-Infinity";
            return value;
          // string:
          case reflection_info_1.ScalarType.STRING:
            if (value === "")
              return ed ? "" : void 0;
            assert_1.assert(typeof value == "string");
            return value;
          // bool:
          case reflection_info_1.ScalarType.BOOL:
            if (value === false)
              return ed ? false : void 0;
            assert_1.assert(typeof value == "boolean");
            return value;
          // JSON value will be a decimal string. Either numbers or strings are accepted.
          case reflection_info_1.ScalarType.UINT64:
          case reflection_info_1.ScalarType.FIXED64:
            assert_1.assert(typeof value == "number" || typeof value == "string" || typeof value == "bigint");
            let ulong = pb_long_1.PbULong.from(value);
            if (ulong.isZero() && !ed)
              return void 0;
            return ulong.toString();
          // JSON value will be a decimal string. Either numbers or strings are accepted.
          case reflection_info_1.ScalarType.INT64:
          case reflection_info_1.ScalarType.SFIXED64:
          case reflection_info_1.ScalarType.SINT64:
            assert_1.assert(typeof value == "number" || typeof value == "string" || typeof value == "bigint");
            let long = pb_long_1.PbLong.from(value);
            if (long.isZero() && !ed)
              return void 0;
            return long.toString();
          // bytes: JSON value will be the data encoded as a string using standard base64 encoding with paddings.
          // Either standard or URL-safe base64 encoding with/without paddings are accepted.
          case reflection_info_1.ScalarType.BYTES:
            assert_1.assert(value instanceof Uint8Array);
            if (!value.byteLength)
              return ed ? "" : void 0;
            return base64_1.base64encode(value);
        }
      }
    };
    exports2.ReflectionJsonWriter = ReflectionJsonWriter;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-scalar-default.js
var require_reflection_scalar_default = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-scalar-default.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.reflectionScalarDefault = void 0;
    var reflection_info_1 = require_reflection_info();
    var reflection_long_convert_1 = require_reflection_long_convert();
    var pb_long_1 = require_pb_long();
    function reflectionScalarDefault(type, longType = reflection_info_1.LongType.STRING) {
      switch (type) {
        case reflection_info_1.ScalarType.BOOL:
          return false;
        case reflection_info_1.ScalarType.UINT64:
        case reflection_info_1.ScalarType.FIXED64:
          return reflection_long_convert_1.reflectionLongConvert(pb_long_1.PbULong.ZERO, longType);
        case reflection_info_1.ScalarType.INT64:
        case reflection_info_1.ScalarType.SFIXED64:
        case reflection_info_1.ScalarType.SINT64:
          return reflection_long_convert_1.reflectionLongConvert(pb_long_1.PbLong.ZERO, longType);
        case reflection_info_1.ScalarType.DOUBLE:
        case reflection_info_1.ScalarType.FLOAT:
          return 0;
        case reflection_info_1.ScalarType.BYTES:
          return new Uint8Array(0);
        case reflection_info_1.ScalarType.STRING:
          return "";
        default:
          return 0;
      }
    }
    exports2.reflectionScalarDefault = reflectionScalarDefault;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-binary-reader.js
var require_reflection_binary_reader = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-binary-reader.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ReflectionBinaryReader = void 0;
    var binary_format_contract_1 = require_binary_format_contract();
    var reflection_info_1 = require_reflection_info();
    var reflection_long_convert_1 = require_reflection_long_convert();
    var reflection_scalar_default_1 = require_reflection_scalar_default();
    var ReflectionBinaryReader = class {
      constructor(info) {
        this.info = info;
      }
      prepare() {
        var _a;
        if (!this.fieldNoToField) {
          const fieldsInput = (_a = this.info.fields) !== null && _a !== void 0 ? _a : [];
          this.fieldNoToField = new Map(fieldsInput.map((field) => [field.no, field]));
        }
      }
      /**
       * Reads a message from binary format into the target message.
       *
       * Repeated fields are appended. Map entries are added, overwriting
       * existing keys.
       *
       * If a message field is already present, it will be merged with the
       * new data.
       */
      read(reader, message, options, length) {
        this.prepare();
        const end = length === void 0 ? reader.len : reader.pos + length;
        while (reader.pos < end) {
          const [fieldNo, wireType] = reader.tag(), field = this.fieldNoToField.get(fieldNo);
          if (!field) {
            let u = options.readUnknownField;
            if (u == "throw")
              throw new Error(`Unknown field ${fieldNo} (wire type ${wireType}) for ${this.info.typeName}`);
            let d = reader.skip(wireType);
            if (u !== false)
              (u === true ? binary_format_contract_1.UnknownFieldHandler.onRead : u)(this.info.typeName, message, fieldNo, wireType, d);
            continue;
          }
          let target = message, repeated = field.repeat, localName = field.localName;
          if (field.oneof) {
            target = target[field.oneof];
            if (target.oneofKind !== localName)
              target = message[field.oneof] = {
                oneofKind: localName
              };
          }
          switch (field.kind) {
            case "scalar":
            case "enum":
              let T = field.kind == "enum" ? reflection_info_1.ScalarType.INT32 : field.T;
              let L = field.kind == "scalar" ? field.L : void 0;
              if (repeated) {
                let arr = target[localName];
                if (wireType == binary_format_contract_1.WireType.LengthDelimited && T != reflection_info_1.ScalarType.STRING && T != reflection_info_1.ScalarType.BYTES) {
                  let e = reader.uint32() + reader.pos;
                  while (reader.pos < e)
                    arr.push(this.scalar(reader, T, L));
                } else
                  arr.push(this.scalar(reader, T, L));
              } else
                target[localName] = this.scalar(reader, T, L);
              break;
            case "message":
              if (repeated) {
                let arr = target[localName];
                let msg = field.T().internalBinaryRead(reader, reader.uint32(), options);
                arr.push(msg);
              } else
                target[localName] = field.T().internalBinaryRead(reader, reader.uint32(), options, target[localName]);
              break;
            case "map":
              let [mapKey, mapVal] = this.mapEntry(field, reader, options);
              target[localName][mapKey] = mapVal;
              break;
          }
        }
      }
      /**
       * Read a map field, expecting key field = 1, value field = 2
       */
      mapEntry(field, reader, options) {
        let length = reader.uint32();
        let end = reader.pos + length;
        let key = void 0;
        let val = void 0;
        while (reader.pos < end) {
          let [fieldNo, wireType] = reader.tag();
          switch (fieldNo) {
            case 1:
              if (field.K == reflection_info_1.ScalarType.BOOL)
                key = reader.bool().toString();
              else
                key = this.scalar(reader, field.K, reflection_info_1.LongType.STRING);
              break;
            case 2:
              switch (field.V.kind) {
                case "scalar":
                  val = this.scalar(reader, field.V.T, field.V.L);
                  break;
                case "enum":
                  val = reader.int32();
                  break;
                case "message":
                  val = field.V.T().internalBinaryRead(reader, reader.uint32(), options);
                  break;
              }
              break;
            default:
              throw new Error(`Unknown field ${fieldNo} (wire type ${wireType}) in map entry for ${this.info.typeName}#${field.name}`);
          }
        }
        if (key === void 0) {
          let keyRaw = reflection_scalar_default_1.reflectionScalarDefault(field.K);
          key = field.K == reflection_info_1.ScalarType.BOOL ? keyRaw.toString() : keyRaw;
        }
        if (val === void 0)
          switch (field.V.kind) {
            case "scalar":
              val = reflection_scalar_default_1.reflectionScalarDefault(field.V.T, field.V.L);
              break;
            case "enum":
              val = 0;
              break;
            case "message":
              val = field.V.T().create();
              break;
          }
        return [key, val];
      }
      scalar(reader, type, longType) {
        switch (type) {
          case reflection_info_1.ScalarType.INT32:
            return reader.int32();
          case reflection_info_1.ScalarType.STRING:
            return reader.string();
          case reflection_info_1.ScalarType.BOOL:
            return reader.bool();
          case reflection_info_1.ScalarType.DOUBLE:
            return reader.double();
          case reflection_info_1.ScalarType.FLOAT:
            return reader.float();
          case reflection_info_1.ScalarType.INT64:
            return reflection_long_convert_1.reflectionLongConvert(reader.int64(), longType);
          case reflection_info_1.ScalarType.UINT64:
            return reflection_long_convert_1.reflectionLongConvert(reader.uint64(), longType);
          case reflection_info_1.ScalarType.FIXED64:
            return reflection_long_convert_1.reflectionLongConvert(reader.fixed64(), longType);
          case reflection_info_1.ScalarType.FIXED32:
            return reader.fixed32();
          case reflection_info_1.ScalarType.BYTES:
            return reader.bytes();
          case reflection_info_1.ScalarType.UINT32:
            return reader.uint32();
          case reflection_info_1.ScalarType.SFIXED32:
            return reader.sfixed32();
          case reflection_info_1.ScalarType.SFIXED64:
            return reflection_long_convert_1.reflectionLongConvert(reader.sfixed64(), longType);
          case reflection_info_1.ScalarType.SINT32:
            return reader.sint32();
          case reflection_info_1.ScalarType.SINT64:
            return reflection_long_convert_1.reflectionLongConvert(reader.sint64(), longType);
        }
      }
    };
    exports2.ReflectionBinaryReader = ReflectionBinaryReader;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-binary-writer.js
var require_reflection_binary_writer = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-binary-writer.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ReflectionBinaryWriter = void 0;
    var binary_format_contract_1 = require_binary_format_contract();
    var reflection_info_1 = require_reflection_info();
    var assert_1 = require_assert();
    var pb_long_1 = require_pb_long();
    var ReflectionBinaryWriter = class {
      constructor(info) {
        this.info = info;
      }
      prepare() {
        if (!this.fields) {
          const fieldsInput = this.info.fields ? this.info.fields.concat() : [];
          this.fields = fieldsInput.sort((a, b) => a.no - b.no);
        }
      }
      /**
       * Writes the message to binary format.
       */
      write(message, writer, options) {
        this.prepare();
        for (const field of this.fields) {
          let value, emitDefault, repeated = field.repeat, localName = field.localName;
          if (field.oneof) {
            const group = message[field.oneof];
            if (group.oneofKind !== localName)
              continue;
            value = group[localName];
            emitDefault = true;
          } else {
            value = message[localName];
            emitDefault = false;
          }
          switch (field.kind) {
            case "scalar":
            case "enum":
              let T = field.kind == "enum" ? reflection_info_1.ScalarType.INT32 : field.T;
              if (repeated) {
                assert_1.assert(Array.isArray(value));
                if (repeated == reflection_info_1.RepeatType.PACKED)
                  this.packed(writer, T, field.no, value);
                else
                  for (const item of value)
                    this.scalar(writer, T, field.no, item, true);
              } else if (value === void 0)
                assert_1.assert(field.opt);
              else
                this.scalar(writer, T, field.no, value, emitDefault || field.opt);
              break;
            case "message":
              if (repeated) {
                assert_1.assert(Array.isArray(value));
                for (const item of value)
                  this.message(writer, options, field.T(), field.no, item);
              } else {
                this.message(writer, options, field.T(), field.no, value);
              }
              break;
            case "map":
              assert_1.assert(typeof value == "object" && value !== null);
              for (const [key, val] of Object.entries(value))
                this.mapEntry(writer, options, field, key, val);
              break;
          }
        }
        let u = options.writeUnknownFields;
        if (u !== false)
          (u === true ? binary_format_contract_1.UnknownFieldHandler.onWrite : u)(this.info.typeName, message, writer);
      }
      mapEntry(writer, options, field, key, value) {
        writer.tag(field.no, binary_format_contract_1.WireType.LengthDelimited);
        writer.fork();
        let keyValue = key;
        switch (field.K) {
          case reflection_info_1.ScalarType.INT32:
          case reflection_info_1.ScalarType.FIXED32:
          case reflection_info_1.ScalarType.UINT32:
          case reflection_info_1.ScalarType.SFIXED32:
          case reflection_info_1.ScalarType.SINT32:
            keyValue = Number.parseInt(key);
            break;
          case reflection_info_1.ScalarType.BOOL:
            assert_1.assert(key == "true" || key == "false");
            keyValue = key == "true";
            break;
        }
        this.scalar(writer, field.K, 1, keyValue, true);
        switch (field.V.kind) {
          case "scalar":
            this.scalar(writer, field.V.T, 2, value, true);
            break;
          case "enum":
            this.scalar(writer, reflection_info_1.ScalarType.INT32, 2, value, true);
            break;
          case "message":
            this.message(writer, options, field.V.T(), 2, value);
            break;
        }
        writer.join();
      }
      message(writer, options, handler, fieldNo, value) {
        if (value === void 0)
          return;
        handler.internalBinaryWrite(value, writer.tag(fieldNo, binary_format_contract_1.WireType.LengthDelimited).fork(), options);
        writer.join();
      }
      /**
       * Write a single scalar value.
       */
      scalar(writer, type, fieldNo, value, emitDefault) {
        let [wireType, method, isDefault] = this.scalarInfo(type, value);
        if (!isDefault || emitDefault) {
          writer.tag(fieldNo, wireType);
          writer[method](value);
        }
      }
      /**
       * Write an array of scalar values in packed format.
       */
      packed(writer, type, fieldNo, value) {
        if (!value.length)
          return;
        assert_1.assert(type !== reflection_info_1.ScalarType.BYTES && type !== reflection_info_1.ScalarType.STRING);
        writer.tag(fieldNo, binary_format_contract_1.WireType.LengthDelimited);
        writer.fork();
        let [, method] = this.scalarInfo(type);
        for (let i = 0; i < value.length; i++)
          writer[method](value[i]);
        writer.join();
      }
      /**
       * Get information for writing a scalar value.
       *
       * Returns tuple:
       * [0]: appropriate WireType
       * [1]: name of the appropriate method of IBinaryWriter
       * [2]: whether the given value is a default value
       *
       * If argument `value` is omitted, [2] is always false.
       */
      scalarInfo(type, value) {
        let t = binary_format_contract_1.WireType.Varint;
        let m;
        let i = value === void 0;
        let d = value === 0;
        switch (type) {
          case reflection_info_1.ScalarType.INT32:
            m = "int32";
            break;
          case reflection_info_1.ScalarType.STRING:
            d = i || !value.length;
            t = binary_format_contract_1.WireType.LengthDelimited;
            m = "string";
            break;
          case reflection_info_1.ScalarType.BOOL:
            d = value === false;
            m = "bool";
            break;
          case reflection_info_1.ScalarType.UINT32:
            m = "uint32";
            break;
          case reflection_info_1.ScalarType.DOUBLE:
            t = binary_format_contract_1.WireType.Bit64;
            m = "double";
            break;
          case reflection_info_1.ScalarType.FLOAT:
            t = binary_format_contract_1.WireType.Bit32;
            m = "float";
            break;
          case reflection_info_1.ScalarType.INT64:
            d = i || pb_long_1.PbLong.from(value).isZero();
            m = "int64";
            break;
          case reflection_info_1.ScalarType.UINT64:
            d = i || pb_long_1.PbULong.from(value).isZero();
            m = "uint64";
            break;
          case reflection_info_1.ScalarType.FIXED64:
            d = i || pb_long_1.PbULong.from(value).isZero();
            t = binary_format_contract_1.WireType.Bit64;
            m = "fixed64";
            break;
          case reflection_info_1.ScalarType.BYTES:
            d = i || !value.byteLength;
            t = binary_format_contract_1.WireType.LengthDelimited;
            m = "bytes";
            break;
          case reflection_info_1.ScalarType.FIXED32:
            t = binary_format_contract_1.WireType.Bit32;
            m = "fixed32";
            break;
          case reflection_info_1.ScalarType.SFIXED32:
            t = binary_format_contract_1.WireType.Bit32;
            m = "sfixed32";
            break;
          case reflection_info_1.ScalarType.SFIXED64:
            d = i || pb_long_1.PbLong.from(value).isZero();
            t = binary_format_contract_1.WireType.Bit64;
            m = "sfixed64";
            break;
          case reflection_info_1.ScalarType.SINT32:
            m = "sint32";
            break;
          case reflection_info_1.ScalarType.SINT64:
            d = i || pb_long_1.PbLong.from(value).isZero();
            m = "sint64";
            break;
        }
        return [t, m, i || d];
      }
    };
    exports2.ReflectionBinaryWriter = ReflectionBinaryWriter;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-create.js
var require_reflection_create = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-create.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.reflectionCreate = void 0;
    var reflection_scalar_default_1 = require_reflection_scalar_default();
    var message_type_contract_1 = require_message_type_contract();
    function reflectionCreate(type) {
      const msg = type.messagePrototype ? Object.create(type.messagePrototype) : Object.defineProperty({}, message_type_contract_1.MESSAGE_TYPE, { value: type });
      for (let field of type.fields) {
        let name = field.localName;
        if (field.opt)
          continue;
        if (field.oneof)
          msg[field.oneof] = { oneofKind: void 0 };
        else if (field.repeat)
          msg[name] = [];
        else
          switch (field.kind) {
            case "scalar":
              msg[name] = reflection_scalar_default_1.reflectionScalarDefault(field.T, field.L);
              break;
            case "enum":
              msg[name] = 0;
              break;
            case "map":
              msg[name] = {};
              break;
          }
      }
      return msg;
    }
    exports2.reflectionCreate = reflectionCreate;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-merge-partial.js
var require_reflection_merge_partial = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-merge-partial.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.reflectionMergePartial = void 0;
    function reflectionMergePartial(info, target, source) {
      let fieldValue, input = source, output;
      for (let field of info.fields) {
        let name = field.localName;
        if (field.oneof) {
          const group = input[field.oneof];
          if ((group === null || group === void 0 ? void 0 : group.oneofKind) == void 0) {
            continue;
          }
          fieldValue = group[name];
          output = target[field.oneof];
          output.oneofKind = group.oneofKind;
          if (fieldValue == void 0) {
            delete output[name];
            continue;
          }
        } else {
          fieldValue = input[name];
          output = target;
          if (fieldValue == void 0) {
            continue;
          }
        }
        if (field.repeat)
          output[name].length = fieldValue.length;
        switch (field.kind) {
          case "scalar":
          case "enum":
            if (field.repeat)
              for (let i = 0; i < fieldValue.length; i++)
                output[name][i] = fieldValue[i];
            else
              output[name] = fieldValue;
            break;
          case "message":
            let T = field.T();
            if (field.repeat)
              for (let i = 0; i < fieldValue.length; i++)
                output[name][i] = T.create(fieldValue[i]);
            else if (output[name] === void 0)
              output[name] = T.create(fieldValue);
            else
              T.mergePartial(output[name], fieldValue);
            break;
          case "map":
            switch (field.V.kind) {
              case "scalar":
              case "enum":
                Object.assign(output[name], fieldValue);
                break;
              case "message":
                let T2 = field.V.T();
                for (let k of Object.keys(fieldValue))
                  output[name][k] = T2.create(fieldValue[k]);
                break;
            }
            break;
        }
      }
    }
    exports2.reflectionMergePartial = reflectionMergePartial;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-equals.js
var require_reflection_equals = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-equals.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.reflectionEquals = void 0;
    var reflection_info_1 = require_reflection_info();
    function reflectionEquals(info, a, b) {
      if (a === b)
        return true;
      if (!a || !b)
        return false;
      for (let field of info.fields) {
        let localName = field.localName;
        let val_a = field.oneof ? a[field.oneof][localName] : a[localName];
        let val_b = field.oneof ? b[field.oneof][localName] : b[localName];
        switch (field.kind) {
          case "enum":
          case "scalar":
            let t = field.kind == "enum" ? reflection_info_1.ScalarType.INT32 : field.T;
            if (!(field.repeat ? repeatedPrimitiveEq(t, val_a, val_b) : primitiveEq(t, val_a, val_b)))
              return false;
            break;
          case "map":
            if (!(field.V.kind == "message" ? repeatedMsgEq(field.V.T(), objectValues(val_a), objectValues(val_b)) : repeatedPrimitiveEq(field.V.kind == "enum" ? reflection_info_1.ScalarType.INT32 : field.V.T, objectValues(val_a), objectValues(val_b))))
              return false;
            break;
          case "message":
            let T = field.T();
            if (!(field.repeat ? repeatedMsgEq(T, val_a, val_b) : T.equals(val_a, val_b)))
              return false;
            break;
        }
      }
      return true;
    }
    exports2.reflectionEquals = reflectionEquals;
    var objectValues = Object.values;
    function primitiveEq(type, a, b) {
      if (a === b)
        return true;
      if (type !== reflection_info_1.ScalarType.BYTES)
        return false;
      let ba = a;
      let bb = b;
      if (ba.length !== bb.length)
        return false;
      for (let i = 0; i < ba.length; i++)
        if (ba[i] != bb[i])
          return false;
      return true;
    }
    function repeatedPrimitiveEq(type, a, b) {
      if (a.length !== b.length)
        return false;
      for (let i = 0; i < a.length; i++)
        if (!primitiveEq(type, a[i], b[i]))
          return false;
      return true;
    }
    function repeatedMsgEq(type, a, b) {
      if (a.length !== b.length)
        return false;
      for (let i = 0; i < a.length; i++)
        if (!type.equals(a[i], b[i]))
          return false;
      return true;
    }
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/message-type.js
var require_message_type = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/message-type.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MessageType = void 0;
    var message_type_contract_1 = require_message_type_contract();
    var reflection_info_1 = require_reflection_info();
    var reflection_type_check_1 = require_reflection_type_check();
    var reflection_json_reader_1 = require_reflection_json_reader();
    var reflection_json_writer_1 = require_reflection_json_writer();
    var reflection_binary_reader_1 = require_reflection_binary_reader();
    var reflection_binary_writer_1 = require_reflection_binary_writer();
    var reflection_create_1 = require_reflection_create();
    var reflection_merge_partial_1 = require_reflection_merge_partial();
    var json_typings_1 = require_json_typings();
    var json_format_contract_1 = require_json_format_contract();
    var reflection_equals_1 = require_reflection_equals();
    var binary_writer_1 = require_binary_writer();
    var binary_reader_1 = require_binary_reader();
    var baseDescriptors = Object.getOwnPropertyDescriptors(Object.getPrototypeOf({}));
    var messageTypeDescriptor = baseDescriptors[message_type_contract_1.MESSAGE_TYPE] = {};
    var MessageType39 = class {
      constructor(name, fields, options) {
        this.defaultCheckDepth = 16;
        this.typeName = name;
        this.fields = fields.map(reflection_info_1.normalizeFieldInfo);
        this.options = options !== null && options !== void 0 ? options : {};
        messageTypeDescriptor.value = this;
        this.messagePrototype = Object.create(null, baseDescriptors);
        this.refTypeCheck = new reflection_type_check_1.ReflectionTypeCheck(this);
        this.refJsonReader = new reflection_json_reader_1.ReflectionJsonReader(this);
        this.refJsonWriter = new reflection_json_writer_1.ReflectionJsonWriter(this);
        this.refBinReader = new reflection_binary_reader_1.ReflectionBinaryReader(this);
        this.refBinWriter = new reflection_binary_writer_1.ReflectionBinaryWriter(this);
      }
      create(value) {
        let message = reflection_create_1.reflectionCreate(this);
        if (value !== void 0) {
          reflection_merge_partial_1.reflectionMergePartial(this, message, value);
        }
        return message;
      }
      /**
       * Clone the message.
       *
       * Unknown fields are discarded.
       */
      clone(message) {
        let copy = this.create();
        reflection_merge_partial_1.reflectionMergePartial(this, copy, message);
        return copy;
      }
      /**
       * Determines whether two message of the same type have the same field values.
       * Checks for deep equality, traversing repeated fields, oneof groups, maps
       * and messages recursively.
       * Will also return true if both messages are `undefined`.
       */
      equals(a, b) {
        return reflection_equals_1.reflectionEquals(this, a, b);
      }
      /**
       * Is the given value assignable to our message type
       * and contains no [excess properties](https://www.typescriptlang.org/docs/handbook/interfaces.html#excess-property-checks)?
       */
      is(arg, depth = this.defaultCheckDepth) {
        return this.refTypeCheck.is(arg, depth, false);
      }
      /**
       * Is the given value assignable to our message type,
       * regardless of [excess properties](https://www.typescriptlang.org/docs/handbook/interfaces.html#excess-property-checks)?
       */
      isAssignable(arg, depth = this.defaultCheckDepth) {
        return this.refTypeCheck.is(arg, depth, true);
      }
      /**
       * Copy partial data into the target message.
       */
      mergePartial(target, source) {
        reflection_merge_partial_1.reflectionMergePartial(this, target, source);
      }
      /**
       * Create a new message from binary format.
       */
      fromBinary(data, options) {
        let opt = binary_reader_1.binaryReadOptions(options);
        return this.internalBinaryRead(opt.readerFactory(data), data.byteLength, opt);
      }
      /**
       * Read a new message from a JSON value.
       */
      fromJson(json, options) {
        return this.internalJsonRead(json, json_format_contract_1.jsonReadOptions(options));
      }
      /**
       * Read a new message from a JSON string.
       * This is equivalent to `T.fromJson(JSON.parse(json))`.
       */
      fromJsonString(json, options) {
        let value = JSON.parse(json);
        return this.fromJson(value, options);
      }
      /**
       * Write the message to canonical JSON value.
       */
      toJson(message, options) {
        return this.internalJsonWrite(message, json_format_contract_1.jsonWriteOptions(options));
      }
      /**
       * Convert the message to canonical JSON string.
       * This is equivalent to `JSON.stringify(T.toJson(t))`
       */
      toJsonString(message, options) {
        var _a;
        let value = this.toJson(message, options);
        return JSON.stringify(value, null, (_a = options === null || options === void 0 ? void 0 : options.prettySpaces) !== null && _a !== void 0 ? _a : 0);
      }
      /**
       * Write the message to binary format.
       */
      toBinary(message, options) {
        let opt = binary_writer_1.binaryWriteOptions(options);
        return this.internalBinaryWrite(message, opt.writerFactory(), opt).finish();
      }
      /**
       * This is an internal method. If you just want to read a message from
       * JSON, use `fromJson()` or `fromJsonString()`.
       *
       * Reads JSON value and merges the fields into the target
       * according to protobuf rules. If the target is omitted,
       * a new instance is created first.
       */
      internalJsonRead(json, options, target) {
        if (json !== null && typeof json == "object" && !Array.isArray(json)) {
          let message = target !== null && target !== void 0 ? target : this.create();
          this.refJsonReader.read(json, message, options);
          return message;
        }
        throw new Error(`Unable to parse message ${this.typeName} from JSON ${json_typings_1.typeofJsonValue(json)}.`);
      }
      /**
       * This is an internal method. If you just want to write a message
       * to JSON, use `toJson()` or `toJsonString().
       *
       * Writes JSON value and returns it.
       */
      internalJsonWrite(message, options) {
        return this.refJsonWriter.write(message, options);
      }
      /**
       * This is an internal method. If you just want to write a message
       * in binary format, use `toBinary()`.
       *
       * Serializes the message in binary format and appends it to the given
       * writer. Returns passed writer.
       */
      internalBinaryWrite(message, writer, options) {
        this.refBinWriter.write(message, writer, options);
        return writer;
      }
      /**
       * This is an internal method. If you just want to read a message from
       * binary data, use `fromBinary()`.
       *
       * Reads data from binary format and merges the fields into
       * the target according to protobuf rules. If the target is
       * omitted, a new instance is created first.
       */
      internalBinaryRead(reader, length, options, target) {
        let message = target !== null && target !== void 0 ? target : this.create();
        this.refBinReader.read(reader, message, options, length);
        return message;
      }
    };
    exports2.MessageType = MessageType39;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-contains-message-type.js
var require_reflection_contains_message_type = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/reflection-contains-message-type.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.containsMessageType = void 0;
    var message_type_contract_1 = require_message_type_contract();
    function containsMessageType(msg) {
      return msg[message_type_contract_1.MESSAGE_TYPE] != null;
    }
    exports2.containsMessageType = containsMessageType;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/enum-object.js
var require_enum_object = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/enum-object.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.listEnumNumbers = exports2.listEnumNames = exports2.listEnumValues = exports2.isEnumObject = void 0;
    function isEnumObject(arg) {
      if (typeof arg != "object" || arg === null) {
        return false;
      }
      if (!arg.hasOwnProperty(0)) {
        return false;
      }
      for (let k of Object.keys(arg)) {
        let num = parseInt(k);
        if (!Number.isNaN(num)) {
          let nam = arg[num];
          if (nam === void 0)
            return false;
          if (arg[nam] !== num)
            return false;
        } else {
          let num2 = arg[k];
          if (num2 === void 0)
            return false;
          if (typeof num2 !== "number")
            return false;
          if (arg[num2] === void 0)
            return false;
        }
      }
      return true;
    }
    exports2.isEnumObject = isEnumObject;
    function listEnumValues(enumObject) {
      if (!isEnumObject(enumObject))
        throw new Error("not a typescript enum object");
      let values = [];
      for (let [name, number2] of Object.entries(enumObject))
        if (typeof number2 == "number")
          values.push({ name, number: number2 });
      return values;
    }
    exports2.listEnumValues = listEnumValues;
    function listEnumNames(enumObject) {
      return listEnumValues(enumObject).map((val) => val.name);
    }
    exports2.listEnumNames = listEnumNames;
    function listEnumNumbers(enumObject) {
      return listEnumValues(enumObject).map((val) => val.number).filter((num, index, arr) => arr.indexOf(num) == index);
    }
    exports2.listEnumNumbers = listEnumNumbers;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/index.js
var require_commonjs = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime@2.11.1/node_modules/@protobuf-ts/runtime/build/commonjs/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var json_typings_1 = require_json_typings();
    Object.defineProperty(exports2, "typeofJsonValue", { enumerable: true, get: function() {
      return json_typings_1.typeofJsonValue;
    } });
    Object.defineProperty(exports2, "isJsonObject", { enumerable: true, get: function() {
      return json_typings_1.isJsonObject;
    } });
    var base64_1 = require_base64();
    Object.defineProperty(exports2, "base64decode", { enumerable: true, get: function() {
      return base64_1.base64decode;
    } });
    Object.defineProperty(exports2, "base64encode", { enumerable: true, get: function() {
      return base64_1.base64encode;
    } });
    var protobufjs_utf8_1 = require_protobufjs_utf8();
    Object.defineProperty(exports2, "utf8read", { enumerable: true, get: function() {
      return protobufjs_utf8_1.utf8read;
    } });
    var binary_format_contract_1 = require_binary_format_contract();
    Object.defineProperty(exports2, "WireType", { enumerable: true, get: function() {
      return binary_format_contract_1.WireType;
    } });
    Object.defineProperty(exports2, "mergeBinaryOptions", { enumerable: true, get: function() {
      return binary_format_contract_1.mergeBinaryOptions;
    } });
    Object.defineProperty(exports2, "UnknownFieldHandler", { enumerable: true, get: function() {
      return binary_format_contract_1.UnknownFieldHandler;
    } });
    var binary_reader_1 = require_binary_reader();
    Object.defineProperty(exports2, "BinaryReader", { enumerable: true, get: function() {
      return binary_reader_1.BinaryReader;
    } });
    Object.defineProperty(exports2, "binaryReadOptions", { enumerable: true, get: function() {
      return binary_reader_1.binaryReadOptions;
    } });
    var binary_writer_1 = require_binary_writer();
    Object.defineProperty(exports2, "BinaryWriter", { enumerable: true, get: function() {
      return binary_writer_1.BinaryWriter;
    } });
    Object.defineProperty(exports2, "binaryWriteOptions", { enumerable: true, get: function() {
      return binary_writer_1.binaryWriteOptions;
    } });
    var pb_long_1 = require_pb_long();
    Object.defineProperty(exports2, "PbLong", { enumerable: true, get: function() {
      return pb_long_1.PbLong;
    } });
    Object.defineProperty(exports2, "PbULong", { enumerable: true, get: function() {
      return pb_long_1.PbULong;
    } });
    var json_format_contract_1 = require_json_format_contract();
    Object.defineProperty(exports2, "jsonReadOptions", { enumerable: true, get: function() {
      return json_format_contract_1.jsonReadOptions;
    } });
    Object.defineProperty(exports2, "jsonWriteOptions", { enumerable: true, get: function() {
      return json_format_contract_1.jsonWriteOptions;
    } });
    Object.defineProperty(exports2, "mergeJsonOptions", { enumerable: true, get: function() {
      return json_format_contract_1.mergeJsonOptions;
    } });
    var message_type_contract_1 = require_message_type_contract();
    Object.defineProperty(exports2, "MESSAGE_TYPE", { enumerable: true, get: function() {
      return message_type_contract_1.MESSAGE_TYPE;
    } });
    var message_type_1 = require_message_type();
    Object.defineProperty(exports2, "MessageType", { enumerable: true, get: function() {
      return message_type_1.MessageType;
    } });
    var reflection_info_1 = require_reflection_info();
    Object.defineProperty(exports2, "ScalarType", { enumerable: true, get: function() {
      return reflection_info_1.ScalarType;
    } });
    Object.defineProperty(exports2, "LongType", { enumerable: true, get: function() {
      return reflection_info_1.LongType;
    } });
    Object.defineProperty(exports2, "RepeatType", { enumerable: true, get: function() {
      return reflection_info_1.RepeatType;
    } });
    Object.defineProperty(exports2, "normalizeFieldInfo", { enumerable: true, get: function() {
      return reflection_info_1.normalizeFieldInfo;
    } });
    Object.defineProperty(exports2, "readFieldOptions", { enumerable: true, get: function() {
      return reflection_info_1.readFieldOptions;
    } });
    Object.defineProperty(exports2, "readFieldOption", { enumerable: true, get: function() {
      return reflection_info_1.readFieldOption;
    } });
    Object.defineProperty(exports2, "readMessageOption", { enumerable: true, get: function() {
      return reflection_info_1.readMessageOption;
    } });
    var reflection_type_check_1 = require_reflection_type_check();
    Object.defineProperty(exports2, "ReflectionTypeCheck", { enumerable: true, get: function() {
      return reflection_type_check_1.ReflectionTypeCheck;
    } });
    var reflection_create_1 = require_reflection_create();
    Object.defineProperty(exports2, "reflectionCreate", { enumerable: true, get: function() {
      return reflection_create_1.reflectionCreate;
    } });
    var reflection_scalar_default_1 = require_reflection_scalar_default();
    Object.defineProperty(exports2, "reflectionScalarDefault", { enumerable: true, get: function() {
      return reflection_scalar_default_1.reflectionScalarDefault;
    } });
    var reflection_merge_partial_1 = require_reflection_merge_partial();
    Object.defineProperty(exports2, "reflectionMergePartial", { enumerable: true, get: function() {
      return reflection_merge_partial_1.reflectionMergePartial;
    } });
    var reflection_equals_1 = require_reflection_equals();
    Object.defineProperty(exports2, "reflectionEquals", { enumerable: true, get: function() {
      return reflection_equals_1.reflectionEquals;
    } });
    var reflection_binary_reader_1 = require_reflection_binary_reader();
    Object.defineProperty(exports2, "ReflectionBinaryReader", { enumerable: true, get: function() {
      return reflection_binary_reader_1.ReflectionBinaryReader;
    } });
    var reflection_binary_writer_1 = require_reflection_binary_writer();
    Object.defineProperty(exports2, "ReflectionBinaryWriter", { enumerable: true, get: function() {
      return reflection_binary_writer_1.ReflectionBinaryWriter;
    } });
    var reflection_json_reader_1 = require_reflection_json_reader();
    Object.defineProperty(exports2, "ReflectionJsonReader", { enumerable: true, get: function() {
      return reflection_json_reader_1.ReflectionJsonReader;
    } });
    var reflection_json_writer_1 = require_reflection_json_writer();
    Object.defineProperty(exports2, "ReflectionJsonWriter", { enumerable: true, get: function() {
      return reflection_json_writer_1.ReflectionJsonWriter;
    } });
    var reflection_contains_message_type_1 = require_reflection_contains_message_type();
    Object.defineProperty(exports2, "containsMessageType", { enumerable: true, get: function() {
      return reflection_contains_message_type_1.containsMessageType;
    } });
    var oneof_1 = require_oneof();
    Object.defineProperty(exports2, "isOneofGroup", { enumerable: true, get: function() {
      return oneof_1.isOneofGroup;
    } });
    Object.defineProperty(exports2, "setOneofValue", { enumerable: true, get: function() {
      return oneof_1.setOneofValue;
    } });
    Object.defineProperty(exports2, "getOneofValue", { enumerable: true, get: function() {
      return oneof_1.getOneofValue;
    } });
    Object.defineProperty(exports2, "clearOneofValue", { enumerable: true, get: function() {
      return oneof_1.clearOneofValue;
    } });
    Object.defineProperty(exports2, "getSelectedOneofValue", { enumerable: true, get: function() {
      return oneof_1.getSelectedOneofValue;
    } });
    var enum_object_1 = require_enum_object();
    Object.defineProperty(exports2, "listEnumValues", { enumerable: true, get: function() {
      return enum_object_1.listEnumValues;
    } });
    Object.defineProperty(exports2, "listEnumNames", { enumerable: true, get: function() {
      return enum_object_1.listEnumNames;
    } });
    Object.defineProperty(exports2, "listEnumNumbers", { enumerable: true, get: function() {
      return enum_object_1.listEnumNumbers;
    } });
    Object.defineProperty(exports2, "isEnumObject", { enumerable: true, get: function() {
      return enum_object_1.isEnumObject;
    } });
    var lower_camel_case_1 = require_lower_camel_case();
    Object.defineProperty(exports2, "lowerCamelCase", { enumerable: true, get: function() {
      return lower_camel_case_1.lowerCamelCase;
    } });
    var assert_1 = require_assert();
    Object.defineProperty(exports2, "assert", { enumerable: true, get: function() {
      return assert_1.assert;
    } });
    Object.defineProperty(exports2, "assertNever", { enumerable: true, get: function() {
      return assert_1.assertNever;
    } });
    Object.defineProperty(exports2, "assertInt32", { enumerable: true, get: function() {
      return assert_1.assertInt32;
    } });
    Object.defineProperty(exports2, "assertUInt32", { enumerable: true, get: function() {
      return assert_1.assertUInt32;
    } });
    Object.defineProperty(exports2, "assertFloat32", { enumerable: true, get: function() {
      return assert_1.assertFloat32;
    } });
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/reflection-info.js
var require_reflection_info2 = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/reflection-info.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.readServiceOption = exports2.readMethodOption = exports2.readMethodOptions = exports2.normalizeMethodInfo = void 0;
    var runtime_1 = require_commonjs();
    function normalizeMethodInfo(method, service) {
      var _a, _b, _c;
      let m = method;
      m.service = service;
      m.localName = (_a = m.localName) !== null && _a !== void 0 ? _a : runtime_1.lowerCamelCase(m.name);
      m.serverStreaming = !!m.serverStreaming;
      m.clientStreaming = !!m.clientStreaming;
      m.options = (_b = m.options) !== null && _b !== void 0 ? _b : {};
      m.idempotency = (_c = m.idempotency) !== null && _c !== void 0 ? _c : void 0;
      return m;
    }
    exports2.normalizeMethodInfo = normalizeMethodInfo;
    function readMethodOptions(service, methodName, extensionName, extensionType) {
      var _a;
      const options = (_a = service.methods.find((m, i) => m.localName === methodName || i === methodName)) === null || _a === void 0 ? void 0 : _a.options;
      return options && options[extensionName] ? extensionType.fromJson(options[extensionName]) : void 0;
    }
    exports2.readMethodOptions = readMethodOptions;
    function readMethodOption(service, methodName, extensionName, extensionType) {
      var _a;
      const options = (_a = service.methods.find((m, i) => m.localName === methodName || i === methodName)) === null || _a === void 0 ? void 0 : _a.options;
      if (!options) {
        return void 0;
      }
      const optionVal = options[extensionName];
      if (optionVal === void 0) {
        return optionVal;
      }
      return extensionType ? extensionType.fromJson(optionVal) : optionVal;
    }
    exports2.readMethodOption = readMethodOption;
    function readServiceOption(service, extensionName, extensionType) {
      const options = service.options;
      if (!options) {
        return void 0;
      }
      const optionVal = options[extensionName];
      if (optionVal === void 0) {
        return optionVal;
      }
      return extensionType ? extensionType.fromJson(optionVal) : optionVal;
    }
    exports2.readServiceOption = readServiceOption;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/service-type.js
var require_service_type = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/service-type.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ServiceType = void 0;
    var reflection_info_1 = require_reflection_info2();
    var ServiceType9 = class {
      constructor(typeName, methods, options) {
        this.typeName = typeName;
        this.methods = methods.map((i) => reflection_info_1.normalizeMethodInfo(i, this));
        this.options = options !== null && options !== void 0 ? options : {};
      }
    };
    exports2.ServiceType = ServiceType9;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/rpc-error.js
var require_rpc_error = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/rpc-error.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.RpcError = void 0;
    var RpcError3 = class extends Error {
      constructor(message, code = "UNKNOWN", meta) {
        super(message);
        this.name = "RpcError";
        Object.setPrototypeOf(this, new.target.prototype);
        this.code = code;
        this.meta = meta !== null && meta !== void 0 ? meta : {};
      }
      toString() {
        const l = [this.name + ": " + this.message];
        if (this.code) {
          l.push("");
          l.push("Code: " + this.code);
        }
        if (this.serviceName && this.methodName) {
          l.push("Method: " + this.serviceName + "/" + this.methodName);
        }
        let m = Object.entries(this.meta);
        if (m.length) {
          l.push("");
          l.push("Meta:");
          for (let [k, v] of m) {
            l.push(`  ${k}: ${v}`);
          }
        }
        return l.join("\n");
      }
    };
    exports2.RpcError = RpcError3;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/rpc-options.js
var require_rpc_options = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/rpc-options.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.mergeRpcOptions = void 0;
    var runtime_1 = require_commonjs();
    function mergeRpcOptions(defaults, options) {
      if (!options)
        return defaults;
      let o = {};
      copy(defaults, o);
      copy(options, o);
      for (let key of Object.keys(options)) {
        let val = options[key];
        switch (key) {
          case "jsonOptions":
            o.jsonOptions = runtime_1.mergeJsonOptions(defaults.jsonOptions, o.jsonOptions);
            break;
          case "binaryOptions":
            o.binaryOptions = runtime_1.mergeBinaryOptions(defaults.binaryOptions, o.binaryOptions);
            break;
          case "meta":
            o.meta = {};
            copy(defaults.meta, o.meta);
            copy(options.meta, o.meta);
            break;
          case "interceptors":
            o.interceptors = defaults.interceptors ? defaults.interceptors.concat(val) : val.concat();
            break;
        }
      }
      return o;
    }
    exports2.mergeRpcOptions = mergeRpcOptions;
    function copy(a, into) {
      if (!a)
        return;
      let c = into;
      for (let [k, v] of Object.entries(a)) {
        if (v instanceof Date)
          c[k] = new Date(v.getTime());
        else if (Array.isArray(v))
          c[k] = v.concat();
        else
          c[k] = v;
      }
    }
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/deferred.js
var require_deferred = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/deferred.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Deferred = exports2.DeferredState = void 0;
    var DeferredState;
    (function(DeferredState2) {
      DeferredState2[DeferredState2["PENDING"] = 0] = "PENDING";
      DeferredState2[DeferredState2["REJECTED"] = 1] = "REJECTED";
      DeferredState2[DeferredState2["RESOLVED"] = 2] = "RESOLVED";
    })(DeferredState = exports2.DeferredState || (exports2.DeferredState = {}));
    var Deferred = class {
      /**
       * @param preventUnhandledRejectionWarning - prevents the warning
       * "Unhandled Promise rejection" by adding a noop rejection handler.
       * Working with calls returned from the runtime-rpc package in an
       * async function usually means awaiting one call property after
       * the other. This means that the "status" is not being awaited when
       * an earlier await for the "headers" is rejected. This causes the
       * "unhandled promise reject" warning. A more correct behaviour for
       * calls might be to become aware whether at least one of the
       * promises is handled and swallow the rejection warning for the
       * others.
       */
      constructor(preventUnhandledRejectionWarning = true) {
        this._state = DeferredState.PENDING;
        this._promise = new Promise((resolve, reject) => {
          this._resolve = resolve;
          this._reject = reject;
        });
        if (preventUnhandledRejectionWarning) {
          this._promise.catch((_) => {
          });
        }
      }
      /**
       * Get the current state of the promise.
       */
      get state() {
        return this._state;
      }
      /**
       * Get the deferred promise.
       */
      get promise() {
        return this._promise;
      }
      /**
       * Resolve the promise. Throws if the promise is already resolved or rejected.
       */
      resolve(value) {
        if (this.state !== DeferredState.PENDING)
          throw new Error(`cannot resolve ${DeferredState[this.state].toLowerCase()}`);
        this._resolve(value);
        this._state = DeferredState.RESOLVED;
      }
      /**
       * Reject the promise. Throws if the promise is already resolved or rejected.
       */
      reject(reason) {
        if (this.state !== DeferredState.PENDING)
          throw new Error(`cannot reject ${DeferredState[this.state].toLowerCase()}`);
        this._reject(reason);
        this._state = DeferredState.REJECTED;
      }
      /**
       * Resolve the promise. Ignore if not pending.
       */
      resolvePending(val) {
        if (this._state === DeferredState.PENDING)
          this.resolve(val);
      }
      /**
       * Reject the promise. Ignore if not pending.
       */
      rejectPending(reason) {
        if (this._state === DeferredState.PENDING)
          this.reject(reason);
      }
    };
    exports2.Deferred = Deferred;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/rpc-output-stream.js
var require_rpc_output_stream = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/rpc-output-stream.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.RpcOutputStreamController = void 0;
    var deferred_1 = require_deferred();
    var runtime_1 = require_commonjs();
    var RpcOutputStreamController = class {
      constructor() {
        this._lis = {
          nxt: [],
          msg: [],
          err: [],
          cmp: []
        };
        this._closed = false;
        this._itState = { q: [] };
      }
      // --- RpcOutputStream callback API
      onNext(callback) {
        return this.addLis(callback, this._lis.nxt);
      }
      onMessage(callback) {
        return this.addLis(callback, this._lis.msg);
      }
      onError(callback) {
        return this.addLis(callback, this._lis.err);
      }
      onComplete(callback) {
        return this.addLis(callback, this._lis.cmp);
      }
      addLis(callback, list) {
        list.push(callback);
        return () => {
          let i = list.indexOf(callback);
          if (i >= 0)
            list.splice(i, 1);
        };
      }
      // remove all listeners
      clearLis() {
        for (let l of Object.values(this._lis))
          l.splice(0, l.length);
      }
      // --- Controller API
      /**
       * Is this stream already closed by a completion or error?
       */
      get closed() {
        return this._closed !== false;
      }
      /**
       * Emit message, close with error, or close successfully, but only one
       * at a time.
       * Can be used to wrap a stream by using the other stream's `onNext`.
       */
      notifyNext(message, error, complete) {
        runtime_1.assert((message ? 1 : 0) + (error ? 1 : 0) + (complete ? 1 : 0) <= 1, "only one emission at a time");
        if (message)
          this.notifyMessage(message);
        if (error)
          this.notifyError(error);
        if (complete)
          this.notifyComplete();
      }
      /**
       * Emits a new message. Throws if stream is closed.
       *
       * Triggers onNext and onMessage callbacks.
       */
      notifyMessage(message) {
        runtime_1.assert(!this.closed, "stream is closed");
        this.pushIt({ value: message, done: false });
        this._lis.msg.forEach((l) => l(message));
        this._lis.nxt.forEach((l) => l(message, void 0, false));
      }
      /**
       * Closes the stream with an error. Throws if stream is closed.
       *
       * Triggers onNext and onError callbacks.
       */
      notifyError(error) {
        runtime_1.assert(!this.closed, "stream is closed");
        this._closed = error;
        this.pushIt(error);
        this._lis.err.forEach((l) => l(error));
        this._lis.nxt.forEach((l) => l(void 0, error, false));
        this.clearLis();
      }
      /**
       * Closes the stream successfully. Throws if stream is closed.
       *
       * Triggers onNext and onComplete callbacks.
       */
      notifyComplete() {
        runtime_1.assert(!this.closed, "stream is closed");
        this._closed = true;
        this.pushIt({ value: null, done: true });
        this._lis.cmp.forEach((l) => l());
        this._lis.nxt.forEach((l) => l(void 0, void 0, true));
        this.clearLis();
      }
      /**
       * Creates an async iterator (that can be used with `for await {...}`)
       * to consume the stream.
       *
       * Some things to note:
       * - If an error occurs, the `for await` will throw it.
       * - If an error occurred before the `for await` was started, `for await`
       *   will re-throw it.
       * - If the stream is already complete, the `for await` will be empty.
       * - If your `for await` consumes slower than the stream produces,
       *   for example because you are relaying messages in a slow operation,
       *   messages are queued.
       */
      [Symbol.asyncIterator]() {
        if (this._closed === true)
          this.pushIt({ value: null, done: true });
        else if (this._closed !== false)
          this.pushIt(this._closed);
        return {
          next: () => {
            let state = this._itState;
            runtime_1.assert(state, "bad state");
            runtime_1.assert(!state.p, "iterator contract broken");
            let first = state.q.shift();
            if (first)
              return "value" in first ? Promise.resolve(first) : Promise.reject(first);
            state.p = new deferred_1.Deferred();
            return state.p.promise;
          }
        };
      }
      // "push" a new iterator result.
      // this either resolves a pending promise, or enqueues the result.
      pushIt(result) {
        let state = this._itState;
        if (state.p) {
          const p = state.p;
          runtime_1.assert(p.state == deferred_1.DeferredState.PENDING, "iterator contract broken");
          "value" in result ? p.resolve(result) : p.reject(result);
          delete state.p;
        } else {
          state.q.push(result);
        }
      }
    };
    exports2.RpcOutputStreamController = RpcOutputStreamController;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/unary-call.js
var require_unary_call = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/unary-call.js"(exports2) {
    "use strict";
    var __awaiter = exports2 && exports2.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.UnaryCall = void 0;
    var UnaryCall = class {
      constructor(method, requestHeaders, request, headers, response, status, trailers) {
        this.method = method;
        this.requestHeaders = requestHeaders;
        this.request = request;
        this.headers = headers;
        this.response = response;
        this.status = status;
        this.trailers = trailers;
      }
      /**
       * If you are only interested in the final outcome of this call,
       * you can await it to receive a `FinishedUnaryCall`.
       */
      then(onfulfilled, onrejected) {
        return this.promiseFinished().then((value) => onfulfilled ? Promise.resolve(onfulfilled(value)) : value, (reason) => onrejected ? Promise.resolve(onrejected(reason)) : Promise.reject(reason));
      }
      promiseFinished() {
        return __awaiter(this, void 0, void 0, function* () {
          let [headers, response, status, trailers] = yield Promise.all([this.headers, this.response, this.status, this.trailers]);
          return {
            method: this.method,
            requestHeaders: this.requestHeaders,
            request: this.request,
            headers,
            response,
            status,
            trailers
          };
        });
      }
    };
    exports2.UnaryCall = UnaryCall;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/server-streaming-call.js
var require_server_streaming_call = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/server-streaming-call.js"(exports2) {
    "use strict";
    var __awaiter = exports2 && exports2.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ServerStreamingCall = void 0;
    var ServerStreamingCall = class {
      constructor(method, requestHeaders, request, headers, response, status, trailers) {
        this.method = method;
        this.requestHeaders = requestHeaders;
        this.request = request;
        this.headers = headers;
        this.responses = response;
        this.status = status;
        this.trailers = trailers;
      }
      /**
       * Instead of awaiting the response status and trailers, you can
       * just as well await this call itself to receive the server outcome.
       * You should first setup some listeners to the `request` to
       * see the actual messages the server replied with.
       */
      then(onfulfilled, onrejected) {
        return this.promiseFinished().then((value) => onfulfilled ? Promise.resolve(onfulfilled(value)) : value, (reason) => onrejected ? Promise.resolve(onrejected(reason)) : Promise.reject(reason));
      }
      promiseFinished() {
        return __awaiter(this, void 0, void 0, function* () {
          let [headers, status, trailers] = yield Promise.all([this.headers, this.status, this.trailers]);
          return {
            method: this.method,
            requestHeaders: this.requestHeaders,
            request: this.request,
            headers,
            status,
            trailers
          };
        });
      }
    };
    exports2.ServerStreamingCall = ServerStreamingCall;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/client-streaming-call.js
var require_client_streaming_call = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/client-streaming-call.js"(exports2) {
    "use strict";
    var __awaiter = exports2 && exports2.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ClientStreamingCall = void 0;
    var ClientStreamingCall = class {
      constructor(method, requestHeaders, request, headers, response, status, trailers) {
        this.method = method;
        this.requestHeaders = requestHeaders;
        this.requests = request;
        this.headers = headers;
        this.response = response;
        this.status = status;
        this.trailers = trailers;
      }
      /**
       * Instead of awaiting the response status and trailers, you can
       * just as well await this call itself to receive the server outcome.
       * Note that it may still be valid to send more request messages.
       */
      then(onfulfilled, onrejected) {
        return this.promiseFinished().then((value) => onfulfilled ? Promise.resolve(onfulfilled(value)) : value, (reason) => onrejected ? Promise.resolve(onrejected(reason)) : Promise.reject(reason));
      }
      promiseFinished() {
        return __awaiter(this, void 0, void 0, function* () {
          let [headers, response, status, trailers] = yield Promise.all([this.headers, this.response, this.status, this.trailers]);
          return {
            method: this.method,
            requestHeaders: this.requestHeaders,
            headers,
            response,
            status,
            trailers
          };
        });
      }
    };
    exports2.ClientStreamingCall = ClientStreamingCall;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/duplex-streaming-call.js
var require_duplex_streaming_call = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/duplex-streaming-call.js"(exports2) {
    "use strict";
    var __awaiter = exports2 && exports2.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.DuplexStreamingCall = void 0;
    var DuplexStreamingCall = class {
      constructor(method, requestHeaders, request, headers, response, status, trailers) {
        this.method = method;
        this.requestHeaders = requestHeaders;
        this.requests = request;
        this.headers = headers;
        this.responses = response;
        this.status = status;
        this.trailers = trailers;
      }
      /**
       * Instead of awaiting the response status and trailers, you can
       * just as well await this call itself to receive the server outcome.
       * Note that it may still be valid to send more request messages.
       */
      then(onfulfilled, onrejected) {
        return this.promiseFinished().then((value) => onfulfilled ? Promise.resolve(onfulfilled(value)) : value, (reason) => onrejected ? Promise.resolve(onrejected(reason)) : Promise.reject(reason));
      }
      promiseFinished() {
        return __awaiter(this, void 0, void 0, function* () {
          let [headers, status, trailers] = yield Promise.all([this.headers, this.status, this.trailers]);
          return {
            method: this.method,
            requestHeaders: this.requestHeaders,
            headers,
            status,
            trailers
          };
        });
      }
    };
    exports2.DuplexStreamingCall = DuplexStreamingCall;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/test-transport.js
var require_test_transport = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/test-transport.js"(exports2) {
    "use strict";
    var __awaiter = exports2 && exports2.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.TestTransport = void 0;
    var rpc_error_1 = require_rpc_error();
    var runtime_1 = require_commonjs();
    var rpc_output_stream_1 = require_rpc_output_stream();
    var rpc_options_1 = require_rpc_options();
    var unary_call_1 = require_unary_call();
    var server_streaming_call_1 = require_server_streaming_call();
    var client_streaming_call_1 = require_client_streaming_call();
    var duplex_streaming_call_1 = require_duplex_streaming_call();
    var TestTransport = class _TestTransport {
      /**
       * Initialize with mock data. Omitted fields have default value.
       */
      constructor(data) {
        this.suppressUncaughtRejections = true;
        this.headerDelay = 10;
        this.responseDelay = 50;
        this.betweenResponseDelay = 10;
        this.afterResponseDelay = 10;
        this.data = data !== null && data !== void 0 ? data : {};
      }
      /**
       * Sent message(s) during the last operation.
       */
      get sentMessages() {
        if (this.lastInput instanceof TestInputStream) {
          return this.lastInput.sent;
        } else if (typeof this.lastInput == "object") {
          return [this.lastInput.single];
        }
        return [];
      }
      /**
       * Sending message(s) completed?
       */
      get sendComplete() {
        if (this.lastInput instanceof TestInputStream) {
          return this.lastInput.completed;
        } else if (typeof this.lastInput == "object") {
          return true;
        }
        return false;
      }
      // Creates a promise for response headers from the mock data.
      promiseHeaders() {
        var _a;
        const headers = (_a = this.data.headers) !== null && _a !== void 0 ? _a : _TestTransport.defaultHeaders;
        return headers instanceof rpc_error_1.RpcError ? Promise.reject(headers) : Promise.resolve(headers);
      }
      // Creates a promise for a single, valid, message from the mock data.
      promiseSingleResponse(method) {
        if (this.data.response instanceof rpc_error_1.RpcError) {
          return Promise.reject(this.data.response);
        }
        let r;
        if (Array.isArray(this.data.response)) {
          runtime_1.assert(this.data.response.length > 0);
          r = this.data.response[0];
        } else if (this.data.response !== void 0) {
          r = this.data.response;
        } else {
          r = method.O.create();
        }
        runtime_1.assert(method.O.is(r));
        return Promise.resolve(r);
      }
      /**
       * Pushes response messages from the mock data to the output stream.
       * If an error response, status or trailers are mocked, the stream is
       * closed with the respective error.
       * Otherwise, stream is completed successfully.
       *
       * The returned promise resolves when the stream is closed. It should
       * not reject. If it does, code is broken.
       */
      streamResponses(method, stream, abort) {
        return __awaiter(this, void 0, void 0, function* () {
          const messages = [];
          if (this.data.response === void 0) {
            messages.push(method.O.create());
          } else if (Array.isArray(this.data.response)) {
            for (let msg of this.data.response) {
              runtime_1.assert(method.O.is(msg));
              messages.push(msg);
            }
          } else if (!(this.data.response instanceof rpc_error_1.RpcError)) {
            runtime_1.assert(method.O.is(this.data.response));
            messages.push(this.data.response);
          }
          try {
            yield delay(this.responseDelay, abort)(void 0);
          } catch (error) {
            stream.notifyError(error);
            return;
          }
          if (this.data.response instanceof rpc_error_1.RpcError) {
            stream.notifyError(this.data.response);
            return;
          }
          for (let msg of messages) {
            stream.notifyMessage(msg);
            try {
              yield delay(this.betweenResponseDelay, abort)(void 0);
            } catch (error) {
              stream.notifyError(error);
              return;
            }
          }
          if (this.data.status instanceof rpc_error_1.RpcError) {
            stream.notifyError(this.data.status);
            return;
          }
          if (this.data.trailers instanceof rpc_error_1.RpcError) {
            stream.notifyError(this.data.trailers);
            return;
          }
          stream.notifyComplete();
        });
      }
      // Creates a promise for response status from the mock data.
      promiseStatus() {
        var _a;
        const status = (_a = this.data.status) !== null && _a !== void 0 ? _a : _TestTransport.defaultStatus;
        return status instanceof rpc_error_1.RpcError ? Promise.reject(status) : Promise.resolve(status);
      }
      // Creates a promise for response trailers from the mock data.
      promiseTrailers() {
        var _a;
        const trailers = (_a = this.data.trailers) !== null && _a !== void 0 ? _a : _TestTransport.defaultTrailers;
        return trailers instanceof rpc_error_1.RpcError ? Promise.reject(trailers) : Promise.resolve(trailers);
      }
      maybeSuppressUncaught(...promise) {
        if (this.suppressUncaughtRejections) {
          for (let p of promise) {
            p.catch(() => {
            });
          }
        }
      }
      mergeOptions(options) {
        return rpc_options_1.mergeRpcOptions({}, options);
      }
      unary(method, input, options) {
        var _a;
        const requestHeaders = (_a = options.meta) !== null && _a !== void 0 ? _a : {}, headersPromise = this.promiseHeaders().then(delay(this.headerDelay, options.abort)), responsePromise = headersPromise.catch((_) => {
        }).then(delay(this.responseDelay, options.abort)).then((_) => this.promiseSingleResponse(method)), statusPromise = responsePromise.catch((_) => {
        }).then(delay(this.afterResponseDelay, options.abort)).then((_) => this.promiseStatus()), trailersPromise = responsePromise.catch((_) => {
        }).then(delay(this.afterResponseDelay, options.abort)).then((_) => this.promiseTrailers());
        this.maybeSuppressUncaught(statusPromise, trailersPromise);
        this.lastInput = { single: input };
        return new unary_call_1.UnaryCall(method, requestHeaders, input, headersPromise, responsePromise, statusPromise, trailersPromise);
      }
      serverStreaming(method, input, options) {
        var _a;
        const requestHeaders = (_a = options.meta) !== null && _a !== void 0 ? _a : {}, headersPromise = this.promiseHeaders().then(delay(this.headerDelay, options.abort)), outputStream = new rpc_output_stream_1.RpcOutputStreamController(), responseStreamClosedPromise = headersPromise.then(delay(this.responseDelay, options.abort)).catch(() => {
        }).then(() => this.streamResponses(method, outputStream, options.abort)).then(delay(this.afterResponseDelay, options.abort)), statusPromise = responseStreamClosedPromise.then(() => this.promiseStatus()), trailersPromise = responseStreamClosedPromise.then(() => this.promiseTrailers());
        this.maybeSuppressUncaught(statusPromise, trailersPromise);
        this.lastInput = { single: input };
        return new server_streaming_call_1.ServerStreamingCall(method, requestHeaders, input, headersPromise, outputStream, statusPromise, trailersPromise);
      }
      clientStreaming(method, options) {
        var _a;
        const requestHeaders = (_a = options.meta) !== null && _a !== void 0 ? _a : {}, headersPromise = this.promiseHeaders().then(delay(this.headerDelay, options.abort)), responsePromise = headersPromise.catch((_) => {
        }).then(delay(this.responseDelay, options.abort)).then((_) => this.promiseSingleResponse(method)), statusPromise = responsePromise.catch((_) => {
        }).then(delay(this.afterResponseDelay, options.abort)).then((_) => this.promiseStatus()), trailersPromise = responsePromise.catch((_) => {
        }).then(delay(this.afterResponseDelay, options.abort)).then((_) => this.promiseTrailers());
        this.maybeSuppressUncaught(statusPromise, trailersPromise);
        this.lastInput = new TestInputStream(this.data, options.abort);
        return new client_streaming_call_1.ClientStreamingCall(method, requestHeaders, this.lastInput, headersPromise, responsePromise, statusPromise, trailersPromise);
      }
      duplex(method, options) {
        var _a;
        const requestHeaders = (_a = options.meta) !== null && _a !== void 0 ? _a : {}, headersPromise = this.promiseHeaders().then(delay(this.headerDelay, options.abort)), outputStream = new rpc_output_stream_1.RpcOutputStreamController(), responseStreamClosedPromise = headersPromise.then(delay(this.responseDelay, options.abort)).catch(() => {
        }).then(() => this.streamResponses(method, outputStream, options.abort)).then(delay(this.afterResponseDelay, options.abort)), statusPromise = responseStreamClosedPromise.then(() => this.promiseStatus()), trailersPromise = responseStreamClosedPromise.then(() => this.promiseTrailers());
        this.maybeSuppressUncaught(statusPromise, trailersPromise);
        this.lastInput = new TestInputStream(this.data, options.abort);
        return new duplex_streaming_call_1.DuplexStreamingCall(method, requestHeaders, this.lastInput, headersPromise, outputStream, statusPromise, trailersPromise);
      }
    };
    exports2.TestTransport = TestTransport;
    TestTransport.defaultHeaders = {
      responseHeader: "test"
    };
    TestTransport.defaultStatus = {
      code: "OK",
      detail: "all good"
    };
    TestTransport.defaultTrailers = {
      responseTrailer: "test"
    };
    function delay(ms, abort) {
      return (v) => new Promise((resolve, reject) => {
        if (abort === null || abort === void 0 ? void 0 : abort.aborted) {
          reject(new rpc_error_1.RpcError("user cancel", "CANCELLED"));
        } else {
          const id = setTimeout(() => resolve(v), ms);
          if (abort) {
            abort.addEventListener("abort", (ev) => {
              clearTimeout(id);
              reject(new rpc_error_1.RpcError("user cancel", "CANCELLED"));
            });
          }
        }
      });
    }
    var TestInputStream = class {
      constructor(data, abort) {
        this._completed = false;
        this._sent = [];
        this.data = data;
        this.abort = abort;
      }
      get sent() {
        return this._sent;
      }
      get completed() {
        return this._completed;
      }
      send(message) {
        if (this.data.inputMessage instanceof rpc_error_1.RpcError) {
          return Promise.reject(this.data.inputMessage);
        }
        const delayMs = this.data.inputMessage === void 0 ? 10 : this.data.inputMessage;
        return Promise.resolve(void 0).then(() => {
          this._sent.push(message);
        }).then(delay(delayMs, this.abort));
      }
      complete() {
        if (this.data.inputComplete instanceof rpc_error_1.RpcError) {
          return Promise.reject(this.data.inputComplete);
        }
        const delayMs = this.data.inputComplete === void 0 ? 10 : this.data.inputComplete;
        return Promise.resolve(void 0).then(() => {
          this._completed = true;
        }).then(delay(delayMs, this.abort));
      }
    };
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/rpc-interceptor.js
var require_rpc_interceptor = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/rpc-interceptor.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.stackDuplexStreamingInterceptors = exports2.stackClientStreamingInterceptors = exports2.stackServerStreamingInterceptors = exports2.stackUnaryInterceptors = exports2.stackIntercept = void 0;
    var runtime_1 = require_commonjs();
    function stackIntercept9(kind, transport, method, options, input) {
      var _a, _b, _c, _d;
      if (kind == "unary") {
        let tail = (mtd, inp, opt) => transport.unary(mtd, inp, opt);
        for (const curr of ((_a = options.interceptors) !== null && _a !== void 0 ? _a : []).filter((i) => i.interceptUnary).reverse()) {
          const next = tail;
          tail = (mtd, inp, opt) => curr.interceptUnary(next, mtd, inp, opt);
        }
        return tail(method, input, options);
      }
      if (kind == "serverStreaming") {
        let tail = (mtd, inp, opt) => transport.serverStreaming(mtd, inp, opt);
        for (const curr of ((_b = options.interceptors) !== null && _b !== void 0 ? _b : []).filter((i) => i.interceptServerStreaming).reverse()) {
          const next = tail;
          tail = (mtd, inp, opt) => curr.interceptServerStreaming(next, mtd, inp, opt);
        }
        return tail(method, input, options);
      }
      if (kind == "clientStreaming") {
        let tail = (mtd, opt) => transport.clientStreaming(mtd, opt);
        for (const curr of ((_c = options.interceptors) !== null && _c !== void 0 ? _c : []).filter((i) => i.interceptClientStreaming).reverse()) {
          const next = tail;
          tail = (mtd, opt) => curr.interceptClientStreaming(next, mtd, opt);
        }
        return tail(method, options);
      }
      if (kind == "duplex") {
        let tail = (mtd, opt) => transport.duplex(mtd, opt);
        for (const curr of ((_d = options.interceptors) !== null && _d !== void 0 ? _d : []).filter((i) => i.interceptDuplex).reverse()) {
          const next = tail;
          tail = (mtd, opt) => curr.interceptDuplex(next, mtd, opt);
        }
        return tail(method, options);
      }
      runtime_1.assertNever(kind);
    }
    exports2.stackIntercept = stackIntercept9;
    function stackUnaryInterceptors(transport, method, input, options) {
      return stackIntercept9("unary", transport, method, options, input);
    }
    exports2.stackUnaryInterceptors = stackUnaryInterceptors;
    function stackServerStreamingInterceptors(transport, method, input, options) {
      return stackIntercept9("serverStreaming", transport, method, options, input);
    }
    exports2.stackServerStreamingInterceptors = stackServerStreamingInterceptors;
    function stackClientStreamingInterceptors(transport, method, options) {
      return stackIntercept9("clientStreaming", transport, method, options);
    }
    exports2.stackClientStreamingInterceptors = stackClientStreamingInterceptors;
    function stackDuplexStreamingInterceptors(transport, method, options) {
      return stackIntercept9("duplex", transport, method, options);
    }
    exports2.stackDuplexStreamingInterceptors = stackDuplexStreamingInterceptors;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/server-call-context.js
var require_server_call_context = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/server-call-context.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ServerCallContextController = void 0;
    var ServerCallContextController = class {
      constructor(method, headers, deadline, sendResponseHeadersFn, defaultStatus = { code: "OK", detail: "" }) {
        this._cancelled = false;
        this._listeners = [];
        this.method = method;
        this.headers = headers;
        this.deadline = deadline;
        this.trailers = {};
        this._sendRH = sendResponseHeadersFn;
        this.status = defaultStatus;
      }
      /**
       * Set the call cancelled.
       *
       * Invokes all callbacks registered with onCancel() and
       * sets `cancelled = true`.
       */
      notifyCancelled() {
        if (!this._cancelled) {
          this._cancelled = true;
          for (let l of this._listeners) {
            l();
          }
        }
      }
      /**
       * Send response headers.
       */
      sendResponseHeaders(data) {
        this._sendRH(data);
      }
      /**
       * Is the call cancelled?
       *
       * When the client closes the connection before the server
       * is done, the call is cancelled.
       *
       * If you want to cancel a request on the server, throw a
       * RpcError with the CANCELLED status code.
       */
      get cancelled() {
        return this._cancelled;
      }
      /**
       * Add a callback for cancellation.
       */
      onCancel(callback) {
        const l = this._listeners;
        l.push(callback);
        return () => {
          let i = l.indexOf(callback);
          if (i >= 0)
            l.splice(i, 1);
        };
      }
    };
    exports2.ServerCallContextController = ServerCallContextController;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/index.js
var require_commonjs2 = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+runtime-rpc@2.11.1/node_modules/@protobuf-ts/runtime-rpc/build/commonjs/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var service_type_1 = require_service_type();
    Object.defineProperty(exports2, "ServiceType", { enumerable: true, get: function() {
      return service_type_1.ServiceType;
    } });
    var reflection_info_1 = require_reflection_info2();
    Object.defineProperty(exports2, "readMethodOptions", { enumerable: true, get: function() {
      return reflection_info_1.readMethodOptions;
    } });
    Object.defineProperty(exports2, "readMethodOption", { enumerable: true, get: function() {
      return reflection_info_1.readMethodOption;
    } });
    Object.defineProperty(exports2, "readServiceOption", { enumerable: true, get: function() {
      return reflection_info_1.readServiceOption;
    } });
    var rpc_error_1 = require_rpc_error();
    Object.defineProperty(exports2, "RpcError", { enumerable: true, get: function() {
      return rpc_error_1.RpcError;
    } });
    var rpc_options_1 = require_rpc_options();
    Object.defineProperty(exports2, "mergeRpcOptions", { enumerable: true, get: function() {
      return rpc_options_1.mergeRpcOptions;
    } });
    var rpc_output_stream_1 = require_rpc_output_stream();
    Object.defineProperty(exports2, "RpcOutputStreamController", { enumerable: true, get: function() {
      return rpc_output_stream_1.RpcOutputStreamController;
    } });
    var test_transport_1 = require_test_transport();
    Object.defineProperty(exports2, "TestTransport", { enumerable: true, get: function() {
      return test_transport_1.TestTransport;
    } });
    var deferred_1 = require_deferred();
    Object.defineProperty(exports2, "Deferred", { enumerable: true, get: function() {
      return deferred_1.Deferred;
    } });
    Object.defineProperty(exports2, "DeferredState", { enumerable: true, get: function() {
      return deferred_1.DeferredState;
    } });
    var duplex_streaming_call_1 = require_duplex_streaming_call();
    Object.defineProperty(exports2, "DuplexStreamingCall", { enumerable: true, get: function() {
      return duplex_streaming_call_1.DuplexStreamingCall;
    } });
    var client_streaming_call_1 = require_client_streaming_call();
    Object.defineProperty(exports2, "ClientStreamingCall", { enumerable: true, get: function() {
      return client_streaming_call_1.ClientStreamingCall;
    } });
    var server_streaming_call_1 = require_server_streaming_call();
    Object.defineProperty(exports2, "ServerStreamingCall", { enumerable: true, get: function() {
      return server_streaming_call_1.ServerStreamingCall;
    } });
    var unary_call_1 = require_unary_call();
    Object.defineProperty(exports2, "UnaryCall", { enumerable: true, get: function() {
      return unary_call_1.UnaryCall;
    } });
    var rpc_interceptor_1 = require_rpc_interceptor();
    Object.defineProperty(exports2, "stackIntercept", { enumerable: true, get: function() {
      return rpc_interceptor_1.stackIntercept;
    } });
    Object.defineProperty(exports2, "stackDuplexStreamingInterceptors", { enumerable: true, get: function() {
      return rpc_interceptor_1.stackDuplexStreamingInterceptors;
    } });
    Object.defineProperty(exports2, "stackClientStreamingInterceptors", { enumerable: true, get: function() {
      return rpc_interceptor_1.stackClientStreamingInterceptors;
    } });
    Object.defineProperty(exports2, "stackServerStreamingInterceptors", { enumerable: true, get: function() {
      return rpc_interceptor_1.stackServerStreamingInterceptors;
    } });
    Object.defineProperty(exports2, "stackUnaryInterceptors", { enumerable: true, get: function() {
      return rpc_interceptor_1.stackUnaryInterceptors;
    } });
    var server_call_context_1 = require_server_call_context();
    Object.defineProperty(exports2, "ServerCallContextController", { enumerable: true, get: function() {
      return server_call_context_1.ServerCallContextController;
    } });
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+grpcweb-transport@2.11.1/node_modules/@protobuf-ts/grpcweb-transport/build/commonjs/goog-grpc-status-code.js
var require_goog_grpc_status_code = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+grpcweb-transport@2.11.1/node_modules/@protobuf-ts/grpcweb-transport/build/commonjs/goog-grpc-status-code.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.GrpcStatusCode = void 0;
    var GrpcStatusCode3;
    (function(GrpcStatusCode4) {
      GrpcStatusCode4[GrpcStatusCode4["OK"] = 0] = "OK";
      GrpcStatusCode4[GrpcStatusCode4["CANCELLED"] = 1] = "CANCELLED";
      GrpcStatusCode4[GrpcStatusCode4["UNKNOWN"] = 2] = "UNKNOWN";
      GrpcStatusCode4[GrpcStatusCode4["INVALID_ARGUMENT"] = 3] = "INVALID_ARGUMENT";
      GrpcStatusCode4[GrpcStatusCode4["DEADLINE_EXCEEDED"] = 4] = "DEADLINE_EXCEEDED";
      GrpcStatusCode4[GrpcStatusCode4["NOT_FOUND"] = 5] = "NOT_FOUND";
      GrpcStatusCode4[GrpcStatusCode4["ALREADY_EXISTS"] = 6] = "ALREADY_EXISTS";
      GrpcStatusCode4[GrpcStatusCode4["PERMISSION_DENIED"] = 7] = "PERMISSION_DENIED";
      GrpcStatusCode4[GrpcStatusCode4["UNAUTHENTICATED"] = 16] = "UNAUTHENTICATED";
      GrpcStatusCode4[GrpcStatusCode4["RESOURCE_EXHAUSTED"] = 8] = "RESOURCE_EXHAUSTED";
      GrpcStatusCode4[GrpcStatusCode4["FAILED_PRECONDITION"] = 9] = "FAILED_PRECONDITION";
      GrpcStatusCode4[GrpcStatusCode4["ABORTED"] = 10] = "ABORTED";
      GrpcStatusCode4[GrpcStatusCode4["OUT_OF_RANGE"] = 11] = "OUT_OF_RANGE";
      GrpcStatusCode4[GrpcStatusCode4["UNIMPLEMENTED"] = 12] = "UNIMPLEMENTED";
      GrpcStatusCode4[GrpcStatusCode4["INTERNAL"] = 13] = "INTERNAL";
      GrpcStatusCode4[GrpcStatusCode4["UNAVAILABLE"] = 14] = "UNAVAILABLE";
      GrpcStatusCode4[GrpcStatusCode4["DATA_LOSS"] = 15] = "DATA_LOSS";
    })(GrpcStatusCode3 = exports2.GrpcStatusCode || (exports2.GrpcStatusCode = {}));
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+grpcweb-transport@2.11.1/node_modules/@protobuf-ts/grpcweb-transport/build/commonjs/grpc-web-format.js
var require_grpc_web_format = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+grpcweb-transport@2.11.1/node_modules/@protobuf-ts/grpcweb-transport/build/commonjs/grpc-web-format.js"(exports2) {
    "use strict";
    var __awaiter = exports2 && exports2.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.readGrpcWebResponseBody = exports2.GrpcWebFrame = exports2.readGrpcWebResponseTrailer = exports2.readGrpcWebResponseHeader = exports2.createGrpcWebRequestBody = exports2.createGrpcWebRequestHeader = void 0;
    var runtime_1 = require_commonjs();
    var runtime_rpc_1 = require_commonjs2();
    var goog_grpc_status_code_1 = require_goog_grpc_status_code();
    function createGrpcWebRequestHeader(headers, format, timeout, meta, userAgent) {
      if (meta) {
        for (let [k, v] of Object.entries(meta)) {
          if (typeof v == "string")
            headers.append(k, v);
          else
            for (let i of v)
              headers.append(k, i);
        }
      }
      headers.set("Content-Type", format === "text" ? "application/grpc-web-text" : "application/grpc-web+proto");
      if (format == "text") {
        headers.set("Accept", "application/grpc-web-text");
      }
      headers.set("X-Grpc-Web", "1");
      if (userAgent)
        headers.set("X-User-Agent", userAgent);
      if (typeof timeout === "number") {
        if (timeout <= 0) {
          throw new runtime_rpc_1.RpcError(`timeout ${timeout} ms exceeded`, goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.DEADLINE_EXCEEDED]);
        }
        headers.set("grpc-timeout", `${timeout}m`);
      } else if (timeout) {
        const deadline = timeout.getTime();
        const now = Date.now();
        if (deadline <= now) {
          throw new runtime_rpc_1.RpcError(`deadline ${timeout} exceeded`, goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.DEADLINE_EXCEEDED]);
        }
        headers.set("grpc-timeout", `${deadline - now}m`);
      }
      return headers;
    }
    exports2.createGrpcWebRequestHeader = createGrpcWebRequestHeader;
    function createGrpcWebRequestBody(message, format) {
      let body = new Uint8Array(5 + message.length);
      body[0] = GrpcWebFrame.DATA;
      for (let msgLen = message.length, i = 4; i > 0; i--) {
        body[i] = msgLen % 256;
        msgLen >>>= 8;
      }
      body.set(message, 5);
      return format === "binary" ? body : runtime_1.base64encode(body);
    }
    exports2.createGrpcWebRequestBody = createGrpcWebRequestBody;
    function readGrpcWebResponseHeader(headersOrFetchResponse, httpStatus, httpStatusText) {
      if (arguments.length === 1) {
        let fetchResponse = headersOrFetchResponse;
        let responseType;
        try {
          responseType = fetchResponse.type;
        } catch (_a) {
        }
        switch (responseType) {
          case "error":
          case "opaque":
          case "opaqueredirect":
            throw new runtime_rpc_1.RpcError(`fetch response type ${fetchResponse.type}`, goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.UNKNOWN]);
        }
        return readGrpcWebResponseHeader(fetchHeadersToHttp(fetchResponse.headers), fetchResponse.status, fetchResponse.statusText);
      }
      let headers = headersOrFetchResponse, httpOk = httpStatus >= 200 && httpStatus < 300, responseMeta = parseMetadata(headers), [statusCode, statusDetail] = parseStatus(headers);
      if ((statusCode === void 0 || statusCode === goog_grpc_status_code_1.GrpcStatusCode.OK) && !httpOk) {
        statusCode = httpStatusToGrpc(httpStatus);
        statusDetail = httpStatusText;
      }
      return [statusCode, statusDetail, responseMeta];
    }
    exports2.readGrpcWebResponseHeader = readGrpcWebResponseHeader;
    function readGrpcWebResponseTrailer(data) {
      let headers = parseTrailer(data), [code, detail] = parseStatus(headers), meta = parseMetadata(headers);
      return [code !== null && code !== void 0 ? code : goog_grpc_status_code_1.GrpcStatusCode.OK, detail, meta];
    }
    exports2.readGrpcWebResponseTrailer = readGrpcWebResponseTrailer;
    var GrpcWebFrame;
    (function(GrpcWebFrame2) {
      GrpcWebFrame2[GrpcWebFrame2["DATA"] = 0] = "DATA";
      GrpcWebFrame2[GrpcWebFrame2["TRAILER"] = 128] = "TRAILER";
    })(GrpcWebFrame = exports2.GrpcWebFrame || (exports2.GrpcWebFrame = {}));
    function readGrpcWebResponseBody(stream, contentType, onFrame) {
      return __awaiter(this, void 0, void 0, function* () {
        let streamReader, base64queue = "", byteQueue = new Uint8Array(0), format = parseFormat(contentType);
        if (isReadableStream(stream)) {
          let whatWgReadableStream = stream.getReader();
          streamReader = {
            next: () => whatWgReadableStream.read()
          };
        } else {
          streamReader = stream[Symbol.asyncIterator]();
        }
        while (true) {
          let result = yield streamReader.next();
          if (result.value !== void 0) {
            if (format === "text") {
              for (let i = 0; i < result.value.length; i++)
                base64queue += String.fromCharCode(result.value[i]);
              let safeLen = base64queue.length - base64queue.length % 4;
              if (safeLen === 0)
                continue;
              byteQueue = concatBytes(byteQueue, runtime_1.base64decode(base64queue.substring(0, safeLen)));
              base64queue = base64queue.substring(safeLen);
            } else {
              byteQueue = concatBytes(byteQueue, result.value);
            }
            while (byteQueue.length >= 5 && byteQueue[0] === GrpcWebFrame.DATA) {
              let msgLen = 0;
              for (let i = 1; i < 5; i++)
                msgLen = (msgLen << 8) + byteQueue[i];
              if (byteQueue.length - 5 >= msgLen) {
                onFrame(GrpcWebFrame.DATA, byteQueue.subarray(5, 5 + msgLen));
                byteQueue = byteQueue.subarray(5 + msgLen);
              } else
                break;
            }
          }
          if (result.done) {
            if (byteQueue.length === 0)
              break;
            if (byteQueue[0] !== GrpcWebFrame.TRAILER || byteQueue.length < 5)
              throw new runtime_rpc_1.RpcError("premature EOF", goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.DATA_LOSS]);
            onFrame(GrpcWebFrame.TRAILER, byteQueue.subarray(5));
            break;
          }
        }
      });
    }
    exports2.readGrpcWebResponseBody = readGrpcWebResponseBody;
    var isReadableStream = (s) => {
      return typeof s.getReader == "function";
    };
    function concatBytes(a, b) {
      let n = new Uint8Array(a.length + b.length);
      n.set(a);
      n.set(b, a.length);
      return n;
    }
    function parseFormat(contentType) {
      switch (contentType) {
        case "application/grpc-web-text":
        case "application/grpc-web-text+proto":
          return "text";
        case "application/grpc-web":
        case "application/grpc-web+proto":
          return "binary";
        case void 0:
        case null:
          throw new runtime_rpc_1.RpcError("missing response content type", goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.INTERNAL]);
        default:
          throw new runtime_rpc_1.RpcError("unexpected response content type: " + contentType, goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.INTERNAL]);
      }
    }
    function parseStatus(headers) {
      let code, message;
      let m = headers["grpc-message"];
      if (m !== void 0) {
        if (Array.isArray(m))
          return [goog_grpc_status_code_1.GrpcStatusCode.INTERNAL, "invalid grpc-web message"];
        message = m;
      }
      let s = headers["grpc-status"];
      if (s !== void 0) {
        if (Array.isArray(s))
          return [goog_grpc_status_code_1.GrpcStatusCode.INTERNAL, "invalid grpc-web status"];
        code = parseInt(s, 10);
        if (goog_grpc_status_code_1.GrpcStatusCode[code] === void 0)
          return [goog_grpc_status_code_1.GrpcStatusCode.INTERNAL, "invalid grpc-web status"];
      }
      return [code, message];
    }
    function parseMetadata(headers) {
      let meta = {};
      for (let [k, v] of Object.entries(headers))
        switch (k) {
          case "grpc-message":
          case "grpc-status":
          case "content-type":
            break;
          default:
            meta[k] = v;
        }
      return meta;
    }
    function parseTrailer(trailerData) {
      let headers = {};
      for (let chunk3 of String.fromCharCode.apply(String, trailerData).trim().split("\r\n")) {
        if (chunk3 == "")
          continue;
        let [key, ...val] = chunk3.split(":");
        const value = val.join(":").trim();
        key = key.trim();
        let e = headers[key];
        if (typeof e == "string")
          headers[key] = [e, value];
        else if (Array.isArray(e))
          e.push(value);
        else
          headers[key] = value;
      }
      return headers;
    }
    function fetchHeadersToHttp(fetchHeaders) {
      let headers = {};
      fetchHeaders.forEach((value, key) => {
        let e = headers[key];
        if (typeof e == "string")
          headers[key] = [e, value];
        else if (Array.isArray(e))
          e.push(value);
        else
          headers[key] = value;
      });
      return headers;
    }
    function httpStatusToGrpc(httpStatus) {
      switch (httpStatus) {
        case 200:
          return goog_grpc_status_code_1.GrpcStatusCode.OK;
        case 400:
          return goog_grpc_status_code_1.GrpcStatusCode.INVALID_ARGUMENT;
        case 401:
          return goog_grpc_status_code_1.GrpcStatusCode.UNAUTHENTICATED;
        case 403:
          return goog_grpc_status_code_1.GrpcStatusCode.PERMISSION_DENIED;
        case 404:
          return goog_grpc_status_code_1.GrpcStatusCode.NOT_FOUND;
        case 409:
          return goog_grpc_status_code_1.GrpcStatusCode.ABORTED;
        case 412:
          return goog_grpc_status_code_1.GrpcStatusCode.FAILED_PRECONDITION;
        case 429:
          return goog_grpc_status_code_1.GrpcStatusCode.RESOURCE_EXHAUSTED;
        case 499:
          return goog_grpc_status_code_1.GrpcStatusCode.CANCELLED;
        case 500:
          return goog_grpc_status_code_1.GrpcStatusCode.UNKNOWN;
        case 501:
          return goog_grpc_status_code_1.GrpcStatusCode.UNIMPLEMENTED;
        case 503:
          return goog_grpc_status_code_1.GrpcStatusCode.UNAVAILABLE;
        case 504:
          return goog_grpc_status_code_1.GrpcStatusCode.DEADLINE_EXCEEDED;
        default:
          return goog_grpc_status_code_1.GrpcStatusCode.UNKNOWN;
      }
    }
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+grpcweb-transport@2.11.1/node_modules/@protobuf-ts/grpcweb-transport/build/commonjs/grpc-web-transport.js
var require_grpc_web_transport = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+grpcweb-transport@2.11.1/node_modules/@protobuf-ts/grpcweb-transport/build/commonjs/grpc-web-transport.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.GrpcWebFetchTransport = void 0;
    var runtime_rpc_1 = require_commonjs2();
    var grpc_web_format_1 = require_grpc_web_format();
    var goog_grpc_status_code_1 = require_goog_grpc_status_code();
    var GrpcWebFetchTransport2 = class {
      constructor(defaultOptions) {
        this.defaultOptions = defaultOptions;
      }
      mergeOptions(options) {
        return runtime_rpc_1.mergeRpcOptions(this.defaultOptions, options);
      }
      /**
       * Create an URI for a gRPC web call.
       *
       * Takes the `baseUrl` option and appends:
       * - slash "/"
       * - package name
       * - dot "."
       * - service name
       * - slash "/"
       * - method name
       *
       * If the service was declared without a package, the package name and dot
       * are omitted.
       *
       * All names are used exactly like declared in .proto.
       */
      makeUrl(method, options) {
        let base = options.baseUrl;
        if (base.endsWith("/"))
          base = base.substring(0, base.length - 1);
        return `${base}/${method.service.typeName}/${method.name}`;
      }
      clientStreaming(method) {
        const e = new runtime_rpc_1.RpcError("Client streaming is not supported by grpc-web", goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.UNIMPLEMENTED]);
        e.methodName = method.name;
        e.serviceName = method.service.typeName;
        throw e;
      }
      duplex(method) {
        const e = new runtime_rpc_1.RpcError("Duplex streaming is not supported by grpc-web", goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.UNIMPLEMENTED]);
        e.methodName = method.name;
        e.serviceName = method.service.typeName;
        throw e;
      }
      serverStreaming(method, input, options) {
        var _a, _b, _c, _d, _e;
        let opt = options, format = (_a = opt.format) !== null && _a !== void 0 ? _a : "text", fetch2 = (_b = opt.fetch) !== null && _b !== void 0 ? _b : globalThis.fetch, fetchInit = (_c = opt.fetchInit) !== null && _c !== void 0 ? _c : {}, url = this.makeUrl(method, opt), inputBytes = method.I.toBinary(input, opt.binaryOptions), defHeader = new runtime_rpc_1.Deferred(), responseStream = new runtime_rpc_1.RpcOutputStreamController(), responseEmptyBody = true, maybeStatus, defStatus = new runtime_rpc_1.Deferred(), maybeTrailer, defTrailer = new runtime_rpc_1.Deferred();
        fetch2(url, Object.assign(Object.assign({}, fetchInit), {
          method: "POST",
          headers: grpc_web_format_1.createGrpcWebRequestHeader(new globalThis.Headers(), format, opt.timeout, opt.meta),
          body: grpc_web_format_1.createGrpcWebRequestBody(inputBytes, format),
          signal: (_d = options.abort) !== null && _d !== void 0 ? _d : null
          // node-fetch@3.0.0-beta.9 rejects `undefined`
        })).then((fetchResponse) => {
          let [code, detail, meta] = grpc_web_format_1.readGrpcWebResponseHeader(fetchResponse);
          defHeader.resolve(meta);
          if (code != null && code !== goog_grpc_status_code_1.GrpcStatusCode.OK)
            throw new runtime_rpc_1.RpcError(detail !== null && detail !== void 0 ? detail : goog_grpc_status_code_1.GrpcStatusCode[code], goog_grpc_status_code_1.GrpcStatusCode[code], meta);
          if (code != null)
            maybeStatus = {
              code: goog_grpc_status_code_1.GrpcStatusCode[code],
              detail: detail !== null && detail !== void 0 ? detail : goog_grpc_status_code_1.GrpcStatusCode[code]
            };
          return fetchResponse;
        }).then((fetchResponse) => {
          if (!fetchResponse.body)
            throw new runtime_rpc_1.RpcError("missing response body", goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.INTERNAL]);
          return grpc_web_format_1.readGrpcWebResponseBody(fetchResponse.body, fetchResponse.headers.get("content-type"), (type, data) => {
            switch (type) {
              case grpc_web_format_1.GrpcWebFrame.DATA:
                responseStream.notifyMessage(method.O.fromBinary(data, opt.binaryOptions));
                responseEmptyBody = false;
                break;
              case grpc_web_format_1.GrpcWebFrame.TRAILER:
                let code, detail;
                [code, detail, maybeTrailer] = grpc_web_format_1.readGrpcWebResponseTrailer(data);
                maybeStatus = {
                  code: goog_grpc_status_code_1.GrpcStatusCode[code],
                  detail: detail !== null && detail !== void 0 ? detail : goog_grpc_status_code_1.GrpcStatusCode[code]
                };
                break;
            }
          });
        }).then(() => {
          if (!maybeTrailer && !responseEmptyBody)
            throw new runtime_rpc_1.RpcError(`missing trailers`, goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.DATA_LOSS]);
          if (!maybeStatus)
            throw new runtime_rpc_1.RpcError(`missing status`, goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.INTERNAL]);
          if (maybeStatus.code !== "OK")
            throw new runtime_rpc_1.RpcError(maybeStatus.detail, maybeStatus.code, maybeTrailer);
          responseStream.notifyComplete();
          defStatus.resolve(maybeStatus);
          defTrailer.resolve(maybeTrailer || {});
        }).catch((reason) => {
          let error;
          if (reason instanceof runtime_rpc_1.RpcError)
            error = reason;
          else if (reason instanceof Error && reason.name === "AbortError")
            error = new runtime_rpc_1.RpcError(reason.message, goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.CANCELLED]);
          else
            error = new runtime_rpc_1.RpcError(reason instanceof Error ? reason.message : "" + reason, goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.INTERNAL]);
          error.methodName = method.name;
          error.serviceName = method.service.typeName;
          defHeader.rejectPending(error);
          responseStream.notifyError(error);
          defStatus.rejectPending(error);
          defTrailer.rejectPending(error);
        });
        return new runtime_rpc_1.ServerStreamingCall(method, (_e = opt.meta) !== null && _e !== void 0 ? _e : {}, input, defHeader.promise, responseStream, defStatus.promise, defTrailer.promise);
      }
      unary(method, input, options) {
        var _a, _b, _c, _d, _e;
        let opt = options, format = (_a = opt.format) !== null && _a !== void 0 ? _a : "text", fetch2 = (_b = opt.fetch) !== null && _b !== void 0 ? _b : globalThis.fetch, fetchInit = (_c = opt.fetchInit) !== null && _c !== void 0 ? _c : {}, url = this.makeUrl(method, opt), inputBytes = method.I.toBinary(input, opt.binaryOptions), defHeader = new runtime_rpc_1.Deferred(), maybeMessage, defMessage = new runtime_rpc_1.Deferred(), maybeStatus, defStatus = new runtime_rpc_1.Deferred(), maybeTrailer, defTrailer = new runtime_rpc_1.Deferred();
        fetch2(url, Object.assign(Object.assign({}, fetchInit), {
          method: "POST",
          headers: grpc_web_format_1.createGrpcWebRequestHeader(new globalThis.Headers(), format, opt.timeout, opt.meta),
          body: grpc_web_format_1.createGrpcWebRequestBody(inputBytes, format),
          signal: (_d = options.abort) !== null && _d !== void 0 ? _d : null
          // node-fetch@3.0.0-beta.9 rejects `undefined`
        })).then((fetchResponse) => {
          let [code, detail, meta] = grpc_web_format_1.readGrpcWebResponseHeader(fetchResponse);
          defHeader.resolve(meta);
          if (code != null && code !== goog_grpc_status_code_1.GrpcStatusCode.OK)
            throw new runtime_rpc_1.RpcError(detail !== null && detail !== void 0 ? detail : goog_grpc_status_code_1.GrpcStatusCode[code], goog_grpc_status_code_1.GrpcStatusCode[code], meta);
          if (code != null)
            maybeStatus = {
              code: goog_grpc_status_code_1.GrpcStatusCode[code],
              detail: detail !== null && detail !== void 0 ? detail : goog_grpc_status_code_1.GrpcStatusCode[code]
            };
          return fetchResponse;
        }).then((fetchResponse) => {
          if (!fetchResponse.body)
            throw new runtime_rpc_1.RpcError("missing response body", goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.INTERNAL]);
          return grpc_web_format_1.readGrpcWebResponseBody(fetchResponse.body, fetchResponse.headers.get("content-type"), (type, data) => {
            switch (type) {
              case grpc_web_format_1.GrpcWebFrame.DATA:
                if (maybeMessage)
                  throw new runtime_rpc_1.RpcError(`unary call received 2nd message`, goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.DATA_LOSS]);
                maybeMessage = method.O.fromBinary(data, opt.binaryOptions);
                break;
              case grpc_web_format_1.GrpcWebFrame.TRAILER:
                let code, detail;
                [code, detail, maybeTrailer] = grpc_web_format_1.readGrpcWebResponseTrailer(data);
                maybeStatus = {
                  code: goog_grpc_status_code_1.GrpcStatusCode[code],
                  detail: detail !== null && detail !== void 0 ? detail : goog_grpc_status_code_1.GrpcStatusCode[code]
                };
                break;
            }
          });
        }).then(() => {
          if (!maybeTrailer && maybeMessage)
            throw new runtime_rpc_1.RpcError(`missing trailers`, goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.DATA_LOSS]);
          if (!maybeStatus)
            throw new runtime_rpc_1.RpcError(`missing status`, goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.INTERNAL]);
          if (!maybeMessage && maybeStatus.code === "OK")
            throw new runtime_rpc_1.RpcError("expected error status", goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.DATA_LOSS]);
          if (!maybeMessage)
            throw new runtime_rpc_1.RpcError(maybeStatus.detail, maybeStatus.code, maybeTrailer);
          defMessage.resolve(maybeMessage);
          if (maybeStatus.code !== "OK")
            throw new runtime_rpc_1.RpcError(maybeStatus.detail, maybeStatus.code, maybeTrailer);
          defStatus.resolve(maybeStatus);
          defTrailer.resolve(maybeTrailer || {});
        }).catch((reason) => {
          let error;
          if (reason instanceof runtime_rpc_1.RpcError)
            error = reason;
          else if (reason instanceof Error && reason.name === "AbortError")
            error = new runtime_rpc_1.RpcError(reason.message, goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.CANCELLED]);
          else
            error = new runtime_rpc_1.RpcError(reason instanceof Error ? reason.message : "" + reason, goog_grpc_status_code_1.GrpcStatusCode[goog_grpc_status_code_1.GrpcStatusCode.INTERNAL]);
          error.methodName = method.name;
          error.serviceName = method.service.typeName;
          defHeader.rejectPending(error);
          defMessage.rejectPending(error);
          defStatus.rejectPending(error);
          defTrailer.rejectPending(error);
        });
        return new runtime_rpc_1.UnaryCall(method, (_e = opt.meta) !== null && _e !== void 0 ? _e : {}, input, defHeader.promise, defMessage.promise, defStatus.promise, defTrailer.promise);
      }
    };
    exports2.GrpcWebFetchTransport = GrpcWebFetchTransport2;
  }
});

// dapp/node_modules/.pnpm/@protobuf-ts+grpcweb-transport@2.11.1/node_modules/@protobuf-ts/grpcweb-transport/build/commonjs/index.js
var require_commonjs3 = __commonJS({
  "dapp/node_modules/.pnpm/@protobuf-ts+grpcweb-transport@2.11.1/node_modules/@protobuf-ts/grpcweb-transport/build/commonjs/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var grpc_web_transport_1 = require_grpc_web_transport();
    Object.defineProperty(exports2, "GrpcWebFetchTransport", { enumerable: true, get: function() {
      return grpc_web_transport_1.GrpcWebFetchTransport;
    } });
    var grpc_web_format_1 = require_grpc_web_format();
    Object.defineProperty(exports2, "readGrpcWebResponseTrailer", { enumerable: true, get: function() {
      return grpc_web_format_1.readGrpcWebResponseTrailer;
    } });
    Object.defineProperty(exports2, "createGrpcWebRequestHeader", { enumerable: true, get: function() {
      return grpc_web_format_1.createGrpcWebRequestHeader;
    } });
    Object.defineProperty(exports2, "GrpcWebFrame", { enumerable: true, get: function() {
      return grpc_web_format_1.GrpcWebFrame;
    } });
    Object.defineProperty(exports2, "createGrpcWebRequestBody", { enumerable: true, get: function() {
      return grpc_web_format_1.createGrpcWebRequestBody;
    } });
    Object.defineProperty(exports2, "readGrpcWebResponseBody", { enumerable: true, get: function() {
      return grpc_web_format_1.readGrpcWebResponseBody;
    } });
    Object.defineProperty(exports2, "readGrpcWebResponseHeader", { enumerable: true, get: function() {
      return grpc_web_format_1.readGrpcWebResponseHeader;
    } });
    var goog_grpc_status_code_1 = require_goog_grpc_status_code();
    Object.defineProperty(exports2, "GrpcStatusCode", { enumerable: true, get: function() {
      return goog_grpc_status_code_1.GrpcStatusCode;
    } });
  }
});

// dapp/node_modules/.pnpm/dataloader@2.2.3/node_modules/dataloader/index.js
var require_dataloader = __commonJS({
  "dapp/node_modules/.pnpm/dataloader@2.2.3/node_modules/dataloader/index.js"(exports2, module2) {
    "use strict";
    var DataLoader3 = /* @__PURE__ */ (function() {
      function DataLoader4(batchLoadFn, options) {
        if (typeof batchLoadFn !== "function") {
          throw new TypeError("DataLoader must be constructed with a function which accepts " + ("Array<key> and returns Promise<Array<value>>, but got: " + batchLoadFn + "."));
        }
        this._batchLoadFn = batchLoadFn;
        this._maxBatchSize = getValidMaxBatchSize2(options);
        this._batchScheduleFn = getValidBatchScheduleFn2(options);
        this._cacheKeyFn = getValidCacheKeyFn2(options);
        this._cacheMap = getValidCacheMap2(options);
        this._batch = null;
        this.name = getValidName2(options);
      }
      var _proto = DataLoader4.prototype;
      _proto.load = function load(key) {
        if (key === null || key === void 0) {
          throw new TypeError("The loader.load() function must be called with a value, " + ("but got: " + String(key) + "."));
        }
        var batch = getCurrentBatch2(this);
        var cacheMap = this._cacheMap;
        var cacheKey;
        if (cacheMap) {
          cacheKey = this._cacheKeyFn(key);
          var cachedPromise = cacheMap.get(cacheKey);
          if (cachedPromise) {
            var cacheHits = batch.cacheHits || (batch.cacheHits = []);
            return new Promise(function(resolve) {
              cacheHits.push(function() {
                resolve(cachedPromise);
              });
            });
          }
        }
        batch.keys.push(key);
        var promise = new Promise(function(resolve, reject) {
          batch.callbacks.push({
            resolve,
            reject
          });
        });
        if (cacheMap) {
          cacheMap.set(cacheKey, promise);
        }
        return promise;
      };
      _proto.loadMany = function loadMany(keys) {
        if (!isArrayLike2(keys)) {
          throw new TypeError("The loader.loadMany() function must be called with Array<key> " + ("but got: " + keys + "."));
        }
        var loadPromises = [];
        for (var i = 0; i < keys.length; i++) {
          loadPromises.push(this.load(keys[i])["catch"](function(error) {
            return error;
          }));
        }
        return Promise.all(loadPromises);
      };
      _proto.clear = function clear(key) {
        var cacheMap = this._cacheMap;
        if (cacheMap) {
          var cacheKey = this._cacheKeyFn(key);
          cacheMap["delete"](cacheKey);
        }
        return this;
      };
      _proto.clearAll = function clearAll() {
        var cacheMap = this._cacheMap;
        if (cacheMap) {
          cacheMap.clear();
        }
        return this;
      };
      _proto.prime = function prime(key, value) {
        var cacheMap = this._cacheMap;
        if (cacheMap) {
          var cacheKey = this._cacheKeyFn(key);
          if (cacheMap.get(cacheKey) === void 0) {
            var promise;
            if (value instanceof Error) {
              promise = Promise.reject(value);
              promise["catch"](function() {
              });
            } else {
              promise = Promise.resolve(value);
            }
            cacheMap.set(cacheKey, promise);
          }
        }
        return this;
      };
      return DataLoader4;
    })();
    var enqueuePostPromiseJob2 = typeof process === "object" && typeof process.nextTick === "function" ? function(fn) {
      if (!resolvedPromise2) {
        resolvedPromise2 = Promise.resolve();
      }
      resolvedPromise2.then(function() {
        process.nextTick(fn);
      });
    } : typeof setImmediate === "function" ? function(fn) {
      setImmediate(fn);
    } : function(fn) {
      setTimeout(fn);
    };
    var resolvedPromise2;
    function getCurrentBatch2(loader) {
      var existingBatch = loader._batch;
      if (existingBatch !== null && !existingBatch.hasDispatched && existingBatch.keys.length < loader._maxBatchSize) {
        return existingBatch;
      }
      var newBatch = {
        hasDispatched: false,
        keys: [],
        callbacks: []
      };
      loader._batch = newBatch;
      loader._batchScheduleFn(function() {
        dispatchBatch2(loader, newBatch);
      });
      return newBatch;
    }
    function dispatchBatch2(loader, batch) {
      batch.hasDispatched = true;
      if (batch.keys.length === 0) {
        resolveCacheHits2(batch);
        return;
      }
      var batchPromise;
      try {
        batchPromise = loader._batchLoadFn(batch.keys);
      } catch (e) {
        return failedDispatch2(loader, batch, new TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function " + ("errored synchronously: " + String(e) + ".")));
      }
      if (!batchPromise || typeof batchPromise.then !== "function") {
        return failedDispatch2(loader, batch, new TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did " + ("not return a Promise: " + String(batchPromise) + ".")));
      }
      batchPromise.then(function(values) {
        if (!isArrayLike2(values)) {
          throw new TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did " + ("not return a Promise of an Array: " + String(values) + "."));
        }
        if (values.length !== batch.keys.length) {
          throw new TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise of an Array of the same length as the Array of keys." + ("\n\nKeys:\n" + String(batch.keys)) + ("\n\nValues:\n" + String(values)));
        }
        resolveCacheHits2(batch);
        for (var i = 0; i < batch.callbacks.length; i++) {
          var _value = values[i];
          if (_value instanceof Error) {
            batch.callbacks[i].reject(_value);
          } else {
            batch.callbacks[i].resolve(_value);
          }
        }
      })["catch"](function(error) {
        failedDispatch2(loader, batch, error);
      });
    }
    function failedDispatch2(loader, batch, error) {
      resolveCacheHits2(batch);
      for (var i = 0; i < batch.keys.length; i++) {
        loader.clear(batch.keys[i]);
        batch.callbacks[i].reject(error);
      }
    }
    function resolveCacheHits2(batch) {
      if (batch.cacheHits) {
        for (var i = 0; i < batch.cacheHits.length; i++) {
          batch.cacheHits[i]();
        }
      }
    }
    function getValidMaxBatchSize2(options) {
      var shouldBatch = !options || options.batch !== false;
      if (!shouldBatch) {
        return 1;
      }
      var maxBatchSize = options && options.maxBatchSize;
      if (maxBatchSize === void 0) {
        return Infinity;
      }
      if (typeof maxBatchSize !== "number" || maxBatchSize < 1) {
        throw new TypeError("maxBatchSize must be a positive number: " + maxBatchSize);
      }
      return maxBatchSize;
    }
    function getValidBatchScheduleFn2(options) {
      var batchScheduleFn = options && options.batchScheduleFn;
      if (batchScheduleFn === void 0) {
        return enqueuePostPromiseJob2;
      }
      if (typeof batchScheduleFn !== "function") {
        throw new TypeError("batchScheduleFn must be a function: " + batchScheduleFn);
      }
      return batchScheduleFn;
    }
    function getValidCacheKeyFn2(options) {
      var cacheKeyFn = options && options.cacheKeyFn;
      if (cacheKeyFn === void 0) {
        return function(key) {
          return key;
        };
      }
      if (typeof cacheKeyFn !== "function") {
        throw new TypeError("cacheKeyFn must be a function: " + cacheKeyFn);
      }
      return cacheKeyFn;
    }
    function getValidCacheMap2(options) {
      var shouldCache = !options || options.cache !== false;
      if (!shouldCache) {
        return null;
      }
      var cacheMap = options && options.cacheMap;
      if (cacheMap === void 0) {
        return /* @__PURE__ */ new Map();
      }
      if (cacheMap !== null) {
        var cacheFunctions = ["get", "set", "delete", "clear"];
        var missingFunctions = cacheFunctions.filter(function(fnName) {
          return cacheMap && typeof cacheMap[fnName] !== "function";
        });
        if (missingFunctions.length !== 0) {
          throw new TypeError("Custom cacheMap missing methods: " + missingFunctions.join(", "));
        }
      }
      return cacheMap;
    }
    function getValidName2(options) {
      if (options && options.name) {
        return options.name;
      }
      return null;
    }
    function isArrayLike2(x) {
      return typeof x === "object" && x !== null && typeof x.length === "number" && (x.length === 0 || x.length > 0 && Object.prototype.hasOwnProperty.call(x, x.length - 1));
    }
    module2.exports = DataLoader3;
  }
});

// dapp/node_modules/.pnpm/@mysten+walrus-wasm@0.3.1/node_modules/@mysten/walrus-wasm/nodejs/walrus_wasm.js
var require_walrus_wasm = __commonJS({
  "dapp/node_modules/.pnpm/@mysten+walrus-wasm@0.3.1/node_modules/@mysten/walrus-wasm/nodejs/walrus_wasm.js"(exports2, module2) {
    var imports = {};
    imports["__wbindgen_placeholder__"] = module2.exports;
    var cachedUint8ArrayMemory0 = null;
    function getUint8ArrayMemory0() {
      if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
      }
      return cachedUint8ArrayMemory0;
    }
    var cachedTextDecoder = new TextDecoder("utf-8", { ignoreBOM: true, fatal: true });
    cachedTextDecoder.decode();
    function decodeText(ptr, len) {
      return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
    }
    function getStringFromWasm0(ptr, len) {
      ptr = ptr >>> 0;
      return decodeText(ptr, len);
    }
    var WASM_VECTOR_LEN = 0;
    var cachedTextEncoder = new TextEncoder();
    if (!("encodeInto" in cachedTextEncoder)) {
      cachedTextEncoder.encodeInto = function(arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
          read: arg.length,
          written: buf.length
        };
      };
    }
    function passStringToWasm0(arg, malloc, realloc) {
      if (realloc === void 0) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr2 = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr2, ptr2 + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr2;
      }
      let len = arg.length;
      let ptr = malloc(len, 1) >>> 0;
      const mem = getUint8ArrayMemory0();
      let offset = 0;
      for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 127) break;
        mem[ptr + offset] = code;
      }
      if (offset !== len) {
        if (offset !== 0) {
          arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);
        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
      }
      WASM_VECTOR_LEN = offset;
      return ptr;
    }
    var cachedDataViewMemory0 = null;
    function getDataViewMemory0() {
      if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || cachedDataViewMemory0.buffer.detached === void 0 && cachedDataViewMemory0.buffer !== wasm.memory.buffer) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
      }
      return cachedDataViewMemory0;
    }
    function isLikeNone(x) {
      return x === void 0 || x === null;
    }
    function debugString(val) {
      const type = typeof val;
      if (type == "number" || type == "boolean" || val == null) {
        return `${val}`;
      }
      if (type == "string") {
        return `"${val}"`;
      }
      if (type == "symbol") {
        const description = val.description;
        if (description == null) {
          return "Symbol";
        } else {
          return `Symbol(${description})`;
        }
      }
      if (type == "function") {
        const name = val.name;
        if (typeof name == "string" && name.length > 0) {
          return `Function(${name})`;
        } else {
          return "Function";
        }
      }
      if (Array.isArray(val)) {
        const length = val.length;
        let debug = "[";
        if (length > 0) {
          debug += debugString(val[0]);
        }
        for (let i = 1; i < length; i++) {
          debug += ", " + debugString(val[i]);
        }
        debug += "]";
        return debug;
      }
      const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
      let className;
      if (builtInMatches && builtInMatches.length > 1) {
        className = builtInMatches[1];
      } else {
        return toString.call(val);
      }
      if (className == "Object") {
        try {
          return "Object(" + JSON.stringify(val) + ")";
        } catch (_) {
          return "Object";
        }
      }
      if (val instanceof Error) {
        return `${val.name}: ${val.message}
${val.stack}`;
      }
      return className;
    }
    function addToExternrefTable0(obj) {
      const idx = wasm.__externref_table_alloc();
      wasm.__wbindgen_externrefs.set(idx, obj);
      return idx;
    }
    function handleError(f, args) {
      try {
        return f.apply(this, args);
      } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
      }
    }
    function getArrayU8FromWasm0(ptr, len) {
      ptr = ptr >>> 0;
      return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
    }
    function takeFromExternrefTable0(idx) {
      const value = wasm.__wbindgen_externrefs.get(idx);
      wasm.__externref_table_dealloc(idx);
      return value;
    }
    function passArrayJsValueToWasm0(array2, malloc) {
      const ptr = malloc(array2.length * 4, 4) >>> 0;
      for (let i = 0; i < array2.length; i++) {
        const add2 = addToExternrefTable0(array2[i]);
        getDataViewMemory0().setUint32(ptr + 4 * i, add2, true);
      }
      WASM_VECTOR_LEN = array2.length;
      return ptr;
    }
    exports2.bls12381_min_pk_aggregate = function(signatures) {
      const ret = wasm.bls12381_min_pk_aggregate(signatures);
      if (ret[3]) {
        throw takeFromExternrefTable0(ret[2]);
      }
      var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
      wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
      return v1;
    };
    function passArray8ToWasm0(arg, malloc) {
      const ptr = malloc(arg.length * 1, 1) >>> 0;
      getUint8ArrayMemory0().set(arg, ptr / 1);
      WASM_VECTOR_LEN = arg.length;
      return ptr;
    }
    exports2.bls12381_min_pk_verify = function(signature, public_key, msg) {
      const ptr0 = passArray8ToWasm0(signature, wasm.__wbindgen_malloc);
      const len0 = WASM_VECTOR_LEN;
      const ptr1 = passArray8ToWasm0(public_key, wasm.__wbindgen_malloc);
      const len1 = WASM_VECTOR_LEN;
      const ptr2 = passArray8ToWasm0(msg, wasm.__wbindgen_malloc);
      const len2 = WASM_VECTOR_LEN;
      const ret = wasm.bls12381_min_pk_verify(ptr0, len0, ptr1, len1, ptr2, len2);
      if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
      }
      return ret[0] !== 0;
    };
    exports2.bls12381_min_pk_verify_aggregate = function(public_keys, msg, signature) {
      const ptr0 = passArray8ToWasm0(msg, wasm.__wbindgen_malloc);
      const len0 = WASM_VECTOR_LEN;
      const ptr1 = passArray8ToWasm0(signature, wasm.__wbindgen_malloc);
      const len1 = WASM_VECTOR_LEN;
      const ret = wasm.bls12381_min_pk_verify_aggregate(public_keys, ptr0, len0, ptr1, len1);
      if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
      }
      return ret[0] !== 0;
    };
    var BlobEncoderFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
    }, unregister: () => {
    } } : new FinalizationRegistry((ptr) => wasm.__wbg_blobencoder_free(ptr >>> 0, 1));
    var BlobEncoder2 = class {
      __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        BlobEncoderFinalization.unregister(this);
        return ptr;
      }
      free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_blobencoder_free(ptr, 0);
      }
      /**
       * Compute metadata for data without encoding it.
       * Returns only the essential fields needed for blob registration:
       * (blob_id, root_hash, unencoded_length, encoding_type)
       *
       * This avoids serializing all 2k sliver hashes across the JS/WASM boundary.
       * @param {Uint8Array} data
       * @returns {any}
       */
      compute_metadata(data) {
        const ret = wasm.blobencoder_compute_metadata(this.__wbg_ptr, data);
        if (ret[2]) {
          throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
      }
      /**
       * @param {number} n_shards
       */
      constructor(n_shards) {
        const ret = wasm.blobencoder_new(n_shards);
        if (ret[2]) {
          throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0] >>> 0;
        BlobEncoderFinalization.register(this, this.__wbg_ptr, this);
        return this;
      }
      /**
       * Decode blob from BCS-encoded SliverData buffers.
       *
       * Arguments:
       * - blob_id: The blob identifier
       * - blob_size: The original unencoded blob size in bytes
       * - bcs_buffers: Vec<Uint8Array>, each containing BCS-encoded SliverData<Primary>
       * - output_buffer: Uint8Array to write decoded data into (must be exactly blob_size bytes)
       * @param {any} blob_id
       * @param {bigint} blob_size
       * @param {Uint8Array[]} bcs_buffers
       * @param {Uint8Array} output_buffer
       */
      decode(blob_id, blob_size, bcs_buffers, output_buffer) {
        const ptr0 = passArrayJsValueToWasm0(bcs_buffers, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.blobencoder_decode(this.__wbg_ptr, blob_id, blob_size, ptr0, len0, output_buffer);
        if (ret[1]) {
          throw takeFromExternrefTable0(ret[0]);
        }
      }
      /**
       * Encode data and write BCS-encoded SliverData directly into pre-allocated buffers.
       *
       * Arguments:
       * - data: Input data to encode
       * - primary_buffers: Array of Uint8Array buffers (one per shard) for primary slivers
       * - secondary_buffers: Array of Uint8Array buffers (one per shard) for secondary slivers
       *
       * Each buffer will be written with BCS-encoded SliverData.
       *
       * Returns: JsValue with (metadata, root_hash)
       * @param {Uint8Array} data
       * @param {Array<any>} primary_buffers
       * @param {Array<any>} secondary_buffers
       * @returns {any}
       */
      encode(data, primary_buffers, secondary_buffers) {
        const ret = wasm.blobencoder_encode(this.__wbg_ptr, data, primary_buffers, secondary_buffers);
        if (ret[2]) {
          throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
      }
    };
    if (Symbol.dispose) BlobEncoder2.prototype[Symbol.dispose] = BlobEncoder2.prototype.free;
    exports2.BlobEncoder = BlobEncoder2;
    exports2.__wbg_Error_e83987f665cf5504 = function(arg0, arg1) {
      const ret = Error(getStringFromWasm0(arg0, arg1));
      return ret;
    };
    exports2.__wbg_String_fed4d24b68977888 = function(arg0, arg1) {
      const ret = String(arg1);
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    };
    exports2.__wbg___wbindgen_boolean_get_6d5a1ee65bab5f68 = function(arg0) {
      const v = arg0;
      const ret = typeof v === "boolean" ? v : void 0;
      return isLikeNone(ret) ? 16777215 : ret ? 1 : 0;
    };
    exports2.__wbg___wbindgen_debug_string_df47ffb5e35e6763 = function(arg0, arg1) {
      const ret = debugString(arg1);
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    };
    exports2.__wbg___wbindgen_is_function_ee8a6c5833c90377 = function(arg0) {
      const ret = typeof arg0 === "function";
      return ret;
    };
    exports2.__wbg___wbindgen_is_object_c818261d21f283a4 = function(arg0) {
      const val = arg0;
      const ret = typeof val === "object" && val !== null;
      return ret;
    };
    exports2.__wbg___wbindgen_jsval_loose_eq_b664b38a2f582147 = function(arg0, arg1) {
      const ret = arg0 == arg1;
      return ret;
    };
    exports2.__wbg___wbindgen_number_get_a20bf9b85341449d = function(arg0, arg1) {
      const obj = arg1;
      const ret = typeof obj === "number" ? obj : void 0;
      getDataViewMemory0().setFloat64(arg0 + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
    };
    exports2.__wbg___wbindgen_string_get_e4f06c90489ad01b = function(arg0, arg1) {
      const obj = arg1;
      const ret = typeof obj === "string" ? obj : void 0;
      var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      var len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    };
    exports2.__wbg___wbindgen_throw_b855445ff6a94295 = function(arg0, arg1) {
      throw new Error(getStringFromWasm0(arg0, arg1));
    };
    exports2.__wbg_call_e762c39fa8ea36bf = function() {
      return handleError(function(arg0, arg1) {
        const ret = arg0.call(arg1);
        return ret;
      }, arguments);
    };
    exports2.__wbg_done_2042aa2670fb1db1 = function(arg0) {
      const ret = arg0.done;
      return ret;
    };
    exports2.__wbg_get_7bed016f185add81 = function(arg0, arg1) {
      const ret = arg0[arg1 >>> 0];
      return ret;
    };
    exports2.__wbg_get_efcb449f58ec27c2 = function() {
      return handleError(function(arg0, arg1) {
        const ret = Reflect.get(arg0, arg1);
        return ret;
      }, arguments);
    };
    exports2.__wbg_instanceof_ArrayBuffer_70beb1189ca63b38 = function(arg0) {
      let result;
      try {
        result = arg0 instanceof ArrayBuffer;
      } catch (_) {
        result = false;
      }
      const ret = result;
      return ret;
    };
    exports2.__wbg_instanceof_Uint8Array_20c8e73002f7af98 = function(arg0) {
      let result;
      try {
        result = arg0 instanceof Uint8Array;
      } catch (_) {
        result = false;
      }
      const ret = result;
      return ret;
    };
    exports2.__wbg_isArray_96e0af9891d0945d = function(arg0) {
      const ret = Array.isArray(arg0);
      return ret;
    };
    exports2.__wbg_isSafeInteger_d216eda7911dde36 = function(arg0) {
      const ret = Number.isSafeInteger(arg0);
      return ret;
    };
    exports2.__wbg_iterator_e5822695327a3c39 = function() {
      const ret = Symbol.iterator;
      return ret;
    };
    exports2.__wbg_length_69bca3cb64fc8748 = function(arg0) {
      const ret = arg0.length;
      return ret;
    };
    exports2.__wbg_length_cdd215e10d9dd507 = function(arg0) {
      const ret = arg0.length;
      return ret;
    };
    exports2.__wbg_new_1acc0b6eea89d040 = function() {
      const ret = new Object();
      return ret;
    };
    exports2.__wbg_new_5a79be3ab53b8aa5 = function(arg0) {
      const ret = new Uint8Array(arg0);
      return ret;
    };
    exports2.__wbg_new_e17d9f43105b08be = function() {
      const ret = new Array();
      return ret;
    };
    exports2.__wbg_next_020810e0ae8ebcb0 = function() {
      return handleError(function(arg0) {
        const ret = arg0.next();
        return ret;
      }, arguments);
    };
    exports2.__wbg_next_2c826fe5dfec6b6a = function(arg0) {
      const ret = arg0.next;
      return ret;
    };
    exports2.__wbg_prototypesetcall_2a6620b6922694b2 = function(arg0, arg1, arg2) {
      Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), arg2);
    };
    exports2.__wbg_set_3fda3bac07393de4 = function(arg0, arg1, arg2) {
      arg0[arg1] = arg2;
    };
    exports2.__wbg_set_9e6516df7b7d0f19 = function(arg0, arg1, arg2) {
      arg0.set(getArrayU8FromWasm0(arg1, arg2));
    };
    exports2.__wbg_set_c213c871859d6500 = function(arg0, arg1, arg2) {
      arg0[arg1 >>> 0] = arg2;
    };
    exports2.__wbg_value_692627309814bb8c = function(arg0) {
      const ret = arg0.value;
      return ret;
    };
    exports2.__wbindgen_cast_2241b6af4c4b2941 = function(arg0, arg1) {
      const ret = getStringFromWasm0(arg0, arg1);
      return ret;
    };
    exports2.__wbindgen_cast_4625c577ab2ec9ee = function(arg0) {
      const ret = BigInt.asUintN(64, arg0);
      return ret;
    };
    exports2.__wbindgen_cast_d6cd19b81560fd6e = function(arg0) {
      const ret = arg0;
      return ret;
    };
    exports2.__wbindgen_init_externref_table = function() {
      const table = wasm.__wbindgen_externrefs;
      const offset = table.grow(4);
      table.set(0, void 0);
      table.set(offset + 0, void 0);
      table.set(offset + 1, null);
      table.set(offset + 2, true);
      table.set(offset + 3, false);
      ;
    };
    var wasmPath = `${__dirname}/walrus_wasm_bg.wasm`;
    var wasmBytes = require("fs").readFileSync(wasmPath);
    var wasmModule = new WebAssembly.Module(wasmBytes);
    var wasm = exports2.__wasm = new WebAssembly.Instance(wasmModule, imports).exports;
    wasm.__wbindgen_start();
  }
});

// dapp/scripts/walrus-node-writes.mjs
async function writeBounded(storage, encoded, objectId, concurrency = 8) {
  if (!Number.isInteger(concurrency) || concurrency < 1 || concurrency > 16) throw Error("Invalid node concurrency");
  const results = Array(encoded.sliversByNode.length).fill(null);
  for (let attempt = 0; attempt < 2; attempt++) {
    let next = 0;
    await Promise.all(Array.from({ length: Math.min(concurrency, results.length) }, async () => {
      while (next < results.length) {
        const nodeIndex = next++;
        if (results[nodeIndex]) continue;
        try {
          results[nodeIndex] = await storage.writeEncodedBlobToNode({
            nodeIndex,
            blobId: encoded.blobId,
            metadata: encoded.metadata,
            slivers: encoded.sliversByNode[nodeIndex],
            deletable: false,
            objectId,
            signal: AbortSignal.timeout(1e4)
          });
        } catch {
        }
      }
    }));
  }
  return results;
}
function requireWeightedQuorum(committee, signers) {
  if (!committee || !Array.isArray(committee.members) || !Number.isSafeInteger(committee.n_shards) || committee.n_shards <= 0) throw Error("Invalid Walrus committee");
  const weights = committee.members.map((m) => m.weight);
  if (!weights.every((w) => Number.isSafeInteger(w) && w >= 0) || weights.reduce((a, b) => a + b, 0) !== committee.n_shards) throw Error("Invalid Walrus committee weights");
  if (!Array.isArray(signers) || new Set(signers).size !== signers.length || !signers.every((i) => Number.isInteger(i) && i >= 0 && i < weights.length)) throw Error("Invalid Walrus certificate signers");
  const weight = signers.reduce((sum, i) => sum + weights[i], 0);
  if (3 * weight < 2 * committee.n_shards + 1) throw Error("Insufficient Walrus shard-weight quorum");
  return weight;
}

// dapp/scripts/walrus-device-codec.mjs
var import_node_readline = require("node:readline");

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/client/protocol-version.mjs
var CLIENT_PROTOCOL_VERSION_HEADER = "x-sui-client-protocol-version";
var MAX_PROTOCOL_VERSION = 138;

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/transport.mjs
var import_runtime_rpc = __toESM(require_commonjs2(), 1);
var import_grpcweb_transport = __toESM(require_commonjs3(), 1);
var MESSAGE_DECODED = /* @__PURE__ */ Symbol.for("@mysten/sui/grpc/decoded-status-message");
function decodeGrpcStatusMessage(message) {
  if (!message.includes("%")) return message;
  try {
    return decodeURIComponent(message);
  } catch {
    return message;
  }
}
function markStatusMessageRead(error) {
  if (MESSAGE_DECODED in error) return false;
  Object.defineProperty(error, MESSAGE_DECODED, {
    value: true,
    configurable: true
  });
  return true;
}
function decodeStatusMessageOnce(error) {
  if (markStatusMessageRead(error)) error.message = decodeGrpcStatusMessage(error.message);
}
function hasDecodedStatusMessage(error) {
  return MESSAGE_DECODED in error;
}
function readProperty(value, key) {
  if (typeof value !== "object" || value === null) return void 0;
  try {
    return value[key];
  } catch {
    return;
  }
}
function abortStatus(reason) {
  const code = readProperty(reason, "code");
  if (typeof code === "string" && typeof import_grpcweb_transport.GrpcStatusCode[code] === "number") return code;
  return readProperty(reason, "name") === "TimeoutError" ? import_grpcweb_transport.GrpcStatusCode[import_grpcweb_transport.GrpcStatusCode.DEADLINE_EXCEEDED] : import_grpcweb_transport.GrpcStatusCode[import_grpcweb_transport.GrpcStatusCode.CANCELLED];
}
function isAbortReasonText(message, reason) {
  if (typeof reason === "string") return message === reason;
  const reasonMessage = readProperty(reason, "message");
  return typeof reasonMessage === "string" && message === reasonMessage;
}
function normalizeGrpcError(error, signal) {
  try {
    normalize(error, signal);
  } catch {
  }
}
function normalize(error, signal) {
  if (!(error instanceof import_runtime_rpc.RpcError)) return;
  if (signal?.aborted && (error.code === import_grpcweb_transport.GrpcStatusCode[import_grpcweb_transport.GrpcStatusCode.INTERNAL] || error.code === import_grpcweb_transport.GrpcStatusCode[import_grpcweb_transport.GrpcStatusCode.CANCELLED])) {
    error.code = abortStatus(signal.reason);
    if (isAbortReasonText(error.message, signal.reason)) markStatusMessageRead(error);
    else decodeStatusMessageOnce(error);
    return;
  }
  decodeStatusMessageOnce(error);
}
function normalizeRejections(promises, signal) {
  for (const promise of promises) promise.then(void 0, (error) => normalizeGrpcError(error, signal));
}
var GrpcWebFetchTransport$1 = class extends import_grpcweb_transport.GrpcWebFetchTransport {
  constructor(options) {
    super({
      ...options,
      meta: {
        [CLIENT_PROTOCOL_VERSION_HEADER]: String(MAX_PROTOCOL_VERSION),
        ...options.meta
      }
    });
  }
  unary(method, input, options) {
    const call = super.unary(method, input, options);
    normalizeRejections([
      call.headers,
      call.response,
      call.status,
      call.trailers
    ], options.abort);
    return call;
  }
  serverStreaming(method, input, options) {
    const call = super.serverStreaming(method, input, options);
    call.responses.onError((error) => normalizeGrpcError(error, options.abort));
    normalizeRejections([
      call.headers,
      call.status,
      call.trailers
    ], options.abort);
    return call;
  }
};
function withClientProtocolVersion(transport) {
  return {
    mergeOptions(options) {
      const merged = transport.mergeOptions(options);
      return {
        ...merged,
        meta: {
          [CLIENT_PROTOCOL_VERSION_HEADER]: String(MAX_PROTOCOL_VERSION),
          ...merged.meta
        }
      };
    },
    unary: transport.unary.bind(transport),
    serverStreaming: transport.serverStreaming.bind(transport),
    clientStreaming: transport.clientStreaming.bind(transport),
    duplex: transport.duplex.bind(transport)
  };
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/utils/suins.mjs
var SUI_NS_NAME_REGEX = /^(?!.*(^(?!@)|[-.@])($|[-.@]))(?:[a-z0-9-]{0,63}(?:\.[a-z0-9-]{0,63})*)?@[a-z0-9-]{0,63}$/i;
var SUI_NS_DOMAIN_REGEX = /^(?!.*(^|[-.])($|[-.]))(?:[a-z0-9-]{0,63}\.)+sui$/i;
var MAX_SUI_NS_NAME_LENGTH = 235;
function isValidSuiNSName(name) {
  if (name.length > MAX_SUI_NS_NAME_LENGTH) return false;
  if (name.includes("@")) return SUI_NS_NAME_REGEX.test(name);
  return SUI_NS_DOMAIN_REGEX.test(name);
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/utils/named-packages.mjs
var NAME_PATTERN = /^([a-z0-9]+(?:-[a-z0-9]+)*)$/;
var VERSION_REGEX = /^\d+$/;
var MAX_APP_SIZE = 64;
var NAME_SEPARATOR = "/";
var isValidNamedPackage = (name) => {
  const parts = name.split(NAME_SEPARATOR);
  if (parts.length < 2 || parts.length > 3) return false;
  const [org, app, version] = parts;
  if (version !== void 0 && !VERSION_REGEX.test(version)) return false;
  if (!isValidSuiNSName(org)) return false;
  return NAME_PATTERN.test(app) && app.length < MAX_APP_SIZE;
};

// dapp/node_modules/.pnpm/@mysten+bcs@2.1.2/node_modules/@mysten/bcs/dist/uleb.mjs
function ulebEncode(num) {
  let bigNum = BigInt(num);
  const arr = [];
  let len = 0;
  if (bigNum === 0n) return [0];
  while (bigNum > 0) {
    arr[len] = Number(bigNum & 127n);
    bigNum >>= 7n;
    if (bigNum > 0n) arr[len] |= 128;
    len += 1;
  }
  return arr;
}
function ulebDecode(arr) {
  let total = 0n;
  let shift = 0n;
  let len = 0;
  while (true) {
    if (len >= arr.length) throw new Error("ULEB decode error: buffer overflow");
    const byte = arr[len];
    len += 1;
    total += BigInt(byte & 127) << shift;
    if ((byte & 128) === 0) {
      if (byte === 0 && len > 1) throw new Error("ULEB decode error: non-canonical encoding");
      break;
    }
    shift += 7n;
  }
  if (total > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error("ULEB decode error: value exceeds MAX_SAFE_INTEGER");
  return {
    value: Number(total),
    length: len
  };
}

// dapp/node_modules/.pnpm/@mysten+bcs@2.1.2/node_modules/@mysten/bcs/dist/reader.mjs
var BcsReader = class {
  /**
  * @param {Uint8Array} data Data to use as a buffer.
  */
  constructor(data) {
    this.bytePosition = 0;
    this.dataView = new DataView(data.buffer, data.byteOffset, data.byteLength);
  }
  /**
  * Shift current cursor position by `bytes`.
  *
  * @param {Number} bytes Number of bytes to
  * @returns {this} Self for possible chaining.
  */
  shift(bytes) {
    this.bytePosition += bytes;
    return this;
  }
  /**
  * Read U8 value from the buffer and shift cursor by 1.
  * @returns
  */
  read8() {
    const value = this.dataView.getUint8(this.bytePosition);
    this.shift(1);
    return value;
  }
  /**
  * Read U16 value from the buffer and shift cursor by 2.
  * @returns
  */
  read16() {
    const value = this.dataView.getUint16(this.bytePosition, true);
    this.shift(2);
    return value;
  }
  /**
  * Read U32 value from the buffer and shift cursor by 4.
  * @returns
  */
  read32() {
    const value = this.dataView.getUint32(this.bytePosition, true);
    this.shift(4);
    return value;
  }
  /**
  * Read U64 value from the buffer and shift cursor by 8.
  * @returns
  */
  read64() {
    const value1 = this.read32();
    const result = this.read32().toString(16) + value1.toString(16).padStart(8, "0");
    return BigInt("0x" + result).toString(10);
  }
  /**
  * Read U128 value from the buffer and shift cursor by 16.
  */
  read128() {
    const value1 = BigInt(this.read64());
    const result = BigInt(this.read64()).toString(16) + value1.toString(16).padStart(16, "0");
    return BigInt("0x" + result).toString(10);
  }
  /**
  * Read U128 value from the buffer and shift cursor by 32.
  * @returns
  */
  read256() {
    const value1 = BigInt(this.read128());
    const result = BigInt(this.read128()).toString(16) + value1.toString(16).padStart(32, "0");
    return BigInt("0x" + result).toString(10);
  }
  /**
  * Read `num` number of bytes from the buffer and shift cursor by `num`.
  * @param num Number of bytes to read.
  */
  readBytes(num) {
    const start = this.bytePosition + this.dataView.byteOffset;
    const value = new Uint8Array(this.dataView.buffer, start, num);
    this.shift(num);
    return value;
  }
  /**
  * Read ULEB value - an integer of varying size. Used for enum indexes and
  * vector lengths.
  * @returns {Number} The ULEB value.
  */
  readULEB() {
    const start = this.bytePosition + this.dataView.byteOffset;
    const { value, length } = ulebDecode(new Uint8Array(this.dataView.buffer, start));
    this.shift(length);
    return value;
  }
  /**
  * Read a BCS vector: read a length and then apply function `cb` X times
  * where X is the length of the vector, defined as ULEB in BCS bytes.
  * @param cb Callback to process elements of vector.
  * @returns {Array<Any>} Array of the resulting values, returned by callback.
  */
  readVec(cb) {
    const length = this.readULEB();
    const result = [];
    for (let i = 0; i < length; i++) result.push(cb(this, i, length));
    return result;
  }
};

// dapp/node_modules/.pnpm/@scure+base@2.4.0/node_modules/@scure/base/index.js
var freeze = (fn) => Object.freeze(fn());
function isBytes(a) {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in a && a.BYTES_PER_ELEMENT === 1;
}
function abytes(b) {
  if (!isBytes(b))
    throw new TypeError("Uint8Array expected");
}
function astr(label, input) {
  if (typeof input !== "string")
    throw new TypeError(`${label}: string expected`);
  return true;
}
var asciiDecoder = /* @__PURE__ */ (() => {
  try {
    const decoder = new TextDecoder();
    return decoder.decode(Uint8Array.of(65, 48, 43, 127)) === "A0+\x7F" ? decoder : void 0;
  } catch (e) {
    return void 0;
  }
})();
var B2S_CHUNK = 8192;
function charcodesToString(codes) {
  const len = codes.length;
  if (asciiDecoder !== void 0 && len >= 12)
    return asciiDecoder.decode(codes);
  if (len <= B2S_CHUNK)
    return String.fromCharCode.apply(null, codes);
  let res = "";
  for (let i = 0; i < len; i += B2S_CHUNK)
    res += String.fromCharCode.apply(null, codes.subarray(i, i + B2S_CHUNK));
  return res;
}
function alphabet(letters, aliases) {
  const len = letters.length;
  if (len > 128)
    throw new Error("alphabet: max 128 letters");
  const encTable = new Uint8Array(len);
  const decTable = new Int8Array(128).fill(-1);
  for (let i = 0; i < len; i++) {
    const code = letters.charCodeAt(i);
    if (letters.codePointAt(i) !== code || code > 127)
      throw new Error("alphabet: single-char ASCII letters only");
    encTable[i] = code;
    decTable[code] = i;
  }
  if (aliases !== void 0) {
    for (const alias of Object.keys(aliases)) {
      const code = alias.charCodeAt(0);
      const target = decTable[aliases[alias].charCodeAt(0)];
      if (alias.length !== 1 || code > 127 || target === void 0 || target === -1)
        throw new Error(`alphabet: invalid alias ${alias}`);
      decTable[code] = target;
    }
  }
  return {
    encode: (digits) => {
      const codes = new Uint8Array(digits.length);
      for (let i = 0; i < digits.length; i++) {
        const d = digits[i];
        const code = encTable[d];
        if (code === void 0)
          throw new Error(`alphabet.encode: invalid digit ${d}`);
        codes[i] = code;
      }
      return charcodesToString(codes);
    },
    decode: (input) => {
      astr("decode", input);
      const slen = input.length;
      const digits = new Uint8Array(slen);
      for (let i = 0; i < slen; i++) {
        const code = input.charCodeAt(i);
        const digit = code < 128 ? decTable[code] : -1;
        if (digit === -1)
          throw new Error(`Unknown letter "${input[i]}". Allowed: ${letters}`);
        digits[i] = digit;
      }
      return digits;
    }
  };
}
var B58_GROUP = 656356768;
var RADIX_BASE_N_MAX_LENGTH = 65536;
var BASE_N_MAX_BYTES = 2048;
var BASE_N_MAX_CHARS = 4096;
var radixBaseN = (BASE, GROUP) => ({
  encode: (bytes) => {
    abytes(bytes);
    const blen = bytes.length;
    if (blen === 0)
      return new Uint8Array(0);
    if (blen >= RADIX_BASE_N_MAX_LENGTH)
      throw new Error("invalid length");
    let zeros = 0;
    while (zeros < blen - 1 && bytes[zeros] === 0)
      zeros++;
    const nlimbs = Math.ceil(blen / 2);
    const limbs = new Uint16Array(nlimbs);
    const odd = blen & 1;
    if (odd)
      limbs[0] = bytes[0];
    for (let i = odd, j2 = odd; i < blen; i += 2, j2++)
      limbs[j2] = bytes[i] << 8 | bytes[i + 1];
    const groups = [];
    let pos = 0;
    while (pos < nlimbs) {
      let carry = 0;
      for (let i = pos; i < nlimbs; i++) {
        const cur = carry * 65536 + limbs[i];
        const q = Math.floor(cur / GROUP);
        carry = cur - q * GROUP;
        limbs[i] = q;
        if (q === 0 && i === pos)
          pos++;
      }
      groups.push(carry);
    }
    const top = groups.length - 1;
    let sig = top * 5;
    for (let v = groups[top]; ; v = Math.floor(v / BASE)) {
      sig++;
      if (v < BASE)
        break;
    }
    const res = new Uint8Array(zeros + sig);
    let j = res.length - 1;
    for (let g = 0; g < top; g++) {
      let v = groups[g];
      for (let k = 0; k < 5; k++) {
        res[j--] = v % BASE;
        v = Math.floor(v / BASE);
      }
    }
    for (let v = groups[top]; j >= zeros; v = Math.floor(v / BASE))
      res[j--] = v % BASE;
    return res;
  },
  decode: (digits) => {
    abytes(digits);
    const dlen = digits.length;
    if (dlen === 0)
      return new Uint8Array(0);
    if (dlen >= RADIX_BASE_N_MAX_LENGTH)
      throw new Error("invalid length");
    let zeros = 0;
    while (zeros < dlen - 1 && digits[zeros] === 0)
      zeros++;
    const limbs = new Uint16Array(Math.ceil(dlen * 6 / 16) + 1);
    let used = 0;
    let i = 0;
    let group = dlen % 5 || 5;
    while (i < dlen) {
      let gval = 0;
      let factor = 1;
      for (const end = i + group; i < end; i++) {
        const d = digits[i];
        if (d >= BASE)
          throw new Error(`invalid integer: ${d}`);
        gval = gval * BASE + d;
        factor *= BASE;
      }
      group = 5;
      let carry = gval;
      for (let k = 0; k < used; k++) {
        const cur = limbs[k] * factor + carry;
        carry = Math.floor(cur / 65536);
        limbs[k] = cur - carry * 65536;
      }
      for (; carry > 0; carry = Math.floor(carry / 65536))
        limbs[used++] = carry % 65536;
    }
    const valueBytes = used === 0 ? 1 : used * 2 - (limbs[used - 1] < 256 ? 1 : 0);
    const res = new Uint8Array(zeros + valueBytes);
    let j = res.length - 1;
    for (let k = 0; k < used; k++) {
      const limb = limbs[k];
      res[j--] = limb & 255;
      if (j >= zeros)
        res[j--] = limb >> 8;
    }
    return res;
  }
});
var genBaseN = (radix, abc) => {
  const letters = alphabet(abc);
  return {
    encode(bytes) {
      abytes(bytes);
      if (bytes.length > BASE_N_MAX_BYTES)
        throw new Error("invalid length");
      return letters.encode(radix.encode(bytes));
    },
    decode(str) {
      astr("baseN.decode", str);
      if (str.length > BASE_N_MAX_CHARS)
        throw new Error("invalid length");
      return radix.decode(letters.decode(str));
    }
  };
};
var radix58 = /* @__PURE__ */ radixBaseN(58, B58_GROUP);
var genBase58 = (abc) => genBaseN(radix58, abc);
var base58 = /* @__PURE__ */ freeze(() => genBase58("123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"));

// dapp/node_modules/.pnpm/@mysten+utils@0.4.1/node_modules/@mysten/utils/dist/b58.mjs
var toBase58 = (buffer) => base58.encode(buffer);
var fromBase58 = (str) => base58.decode(str);

// dapp/node_modules/.pnpm/@mysten+utils@0.4.1/node_modules/@mysten/utils/dist/b64.mjs
function fromBase64(base64String2) {
  return Uint8Array.from(atob(base64String2), (char) => char.charCodeAt(0));
}
var CHUNK_SIZE = 8192;
function toBase64(bytes) {
  if (bytes.length < CHUNK_SIZE) return btoa(String.fromCharCode(...bytes));
  let output = "";
  for (var i = 0; i < bytes.length; i += CHUNK_SIZE) {
    const chunk3 = bytes.slice(i, i + CHUNK_SIZE);
    output += String.fromCharCode(...chunk3);
  }
  return btoa(output);
}

// dapp/node_modules/.pnpm/@mysten+utils@0.4.1/node_modules/@mysten/utils/dist/hex.mjs
function fromHex(hexStr) {
  const normalized = hexStr.startsWith("0x") ? hexStr.slice(2) : hexStr;
  const padded = normalized.length % 2 === 0 ? normalized : `0${normalized}`;
  const intArr = padded.match(/[0-9a-fA-F]{2}/g)?.map((byte) => parseInt(byte, 16)) ?? [];
  if (intArr.length !== padded.length / 2) throw new Error(`Invalid hex string ${hexStr}`);
  return Uint8Array.from(intArr);
}
function toHex(bytes) {
  return bytes.reduce((str, byte) => str + byte.toString(16).padStart(2, "0"), "");
}

// dapp/node_modules/.pnpm/@mysten+utils@0.4.1/node_modules/@mysten/utils/dist/chunk.mjs
function chunk(array2, size) {
  return Array.from({ length: Math.ceil(array2.length / size) }, (_, i) => {
    return array2.slice(i * size, (i + 1) * size);
  });
}

// dapp/node_modules/.pnpm/@mysten+utils@0.4.1/node_modules/@mysten/utils/dist/dataloader.mjs
var DataLoader = class {
  constructor(batchLoadFn, options) {
    if (typeof batchLoadFn !== "function") throw new TypeError(`DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but got: ${batchLoadFn}.`);
    this._batchLoadFn = batchLoadFn;
    this._maxBatchSize = getValidMaxBatchSize(options);
    this._batchScheduleFn = getValidBatchScheduleFn(options);
    this._cacheKeyFn = getValidCacheKeyFn(options);
    this._cacheMap = getValidCacheMap(options);
    this._batch = null;
    this.name = getValidName(options);
  }
  /**
  * Loads a key, returning a `Promise` for the value represented by that key.
  */
  load(key) {
    if (key === null || key === void 0) throw new TypeError(`The loader.load() function must be called with a value, but got: ${String(key)}.`);
    const batch = getCurrentBatch(this);
    const cacheMap = this._cacheMap;
    let cacheKey;
    if (cacheMap) {
      cacheKey = this._cacheKeyFn(key);
      const cachedPromise = cacheMap.get(cacheKey);
      if (cachedPromise) {
        const cacheHits = batch.cacheHits || (batch.cacheHits = []);
        return new Promise((resolve) => {
          cacheHits.push(() => {
            resolve(cachedPromise);
          });
        });
      }
    }
    batch.keys.push(key);
    const promise = new Promise((resolve, reject) => {
      batch.callbacks.push({
        resolve,
        reject
      });
    });
    if (cacheMap) cacheMap.set(cacheKey, promise);
    return promise;
  }
  /**
  * Loads multiple keys, promising an array of values:
  *
  *     var [ a, b ] = await myLoader.loadMany([ 'a', 'b' ]);
  *
  * This is similar to the more verbose:
  *
  *     var [ a, b ] = await Promise.all([
  *       myLoader.load('a'),
  *       myLoader.load('b')
  *     ]);
  *
  * However it is different in the case where any load fails. Where
  * Promise.all() would reject, loadMany() always resolves, however each result
  * is either a value or an Error instance.
  *
  *     var [ a, b, c ] = await myLoader.loadMany([ 'a', 'b', 'badkey' ]);
  *     // c instanceof Error
  *
  */
  loadMany(keys) {
    if (!isArrayLike(keys)) throw new TypeError(`The loader.loadMany() function must be called with Array<key>, but got: ${keys}.`);
    const loadPromises = [];
    for (let i = 0; i < keys.length; i++) loadPromises.push(this.load(keys[i]).catch((error) => error));
    return Promise.all(loadPromises);
  }
  /**
  * Clears the value at `key` from the cache, if it exists. Returns itself for
  * method chaining.
  */
  clear(key) {
    const cacheMap = this._cacheMap;
    if (cacheMap) {
      const cacheKey = this._cacheKeyFn(key);
      cacheMap.delete(cacheKey);
    }
    return this;
  }
  /**
  * Clears the entire cache. To be used when some event results in unknown
  * invalidations across this particular `DataLoader`. Returns itself for
  * method chaining.
  */
  clearAll() {
    const cacheMap = this._cacheMap;
    if (cacheMap) cacheMap.clear();
    return this;
  }
  /**
  * Adds the provided key and value to the cache. If the key already
  * exists, no change is made. Returns itself for method chaining.
  *
  * To prime the cache with an error at a key, provide an Error instance.
  */
  prime(key, value) {
    const cacheMap = this._cacheMap;
    if (cacheMap) {
      const cacheKey = this._cacheKeyFn(key);
      if (cacheMap.get(cacheKey) === void 0) {
        let promise;
        if (value instanceof Error) {
          promise = Promise.reject(value);
          promise.catch(() => {
          });
        } else promise = Promise.resolve(value);
        cacheMap.set(cacheKey, promise);
      }
    }
    return this;
  }
};
var enqueuePostPromiseJob = typeof process === "object" && typeof process.nextTick === "function" ? function(fn) {
  if (!resolvedPromise) resolvedPromise = Promise.resolve();
  resolvedPromise.then(() => {
    process.nextTick(fn);
  });
} : typeof setImmediate === "function" ? function(fn) {
  setImmediate(fn);
} : function(fn) {
  setTimeout(fn);
};
var resolvedPromise;
function getCurrentBatch(loader) {
  const existingBatch = loader._batch;
  if (existingBatch !== null && !existingBatch.hasDispatched && existingBatch.keys.length < loader._maxBatchSize) return existingBatch;
  const newBatch = {
    hasDispatched: false,
    keys: [],
    callbacks: []
  };
  loader._batch = newBatch;
  loader._batchScheduleFn(() => {
    dispatchBatch(loader, newBatch);
  });
  return newBatch;
}
function dispatchBatch(loader, batch) {
  batch.hasDispatched = true;
  if (batch.keys.length === 0) {
    resolveCacheHits(batch);
    return;
  }
  let batchPromise;
  try {
    batchPromise = loader._batchLoadFn(batch.keys);
  } catch (e) {
    return failedDispatch(loader, batch, /* @__PURE__ */ new TypeError(`DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function errored synchronously: ${String(e)}.`));
  }
  if (!batchPromise || typeof batchPromise.then !== "function") return failedDispatch(loader, batch, /* @__PURE__ */ new TypeError(`DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise: ${String(batchPromise)}.`));
  Promise.resolve(batchPromise).then((values) => {
    if (!isArrayLike(values)) throw new TypeError(`DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise of an Array: ${String(values)}.`);
    if (values.length !== batch.keys.length) throw new TypeError(`DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise of an Array of the same length as the Array of keys.

Keys:
${String(batch.keys)}

Values:
${String(values)}`);
    resolveCacheHits(batch);
    for (let i = 0; i < batch.callbacks.length; i++) {
      const value = values[i];
      if (value instanceof Error) batch.callbacks[i].reject(value);
      else batch.callbacks[i].resolve(value);
    }
  }).catch((error) => {
    failedDispatch(loader, batch, error);
  });
}
function failedDispatch(loader, batch, error) {
  resolveCacheHits(batch);
  for (let i = 0; i < batch.keys.length; i++) {
    loader.clear(batch.keys[i]);
    batch.callbacks[i].reject(error);
  }
}
function resolveCacheHits(batch) {
  if (batch.cacheHits) for (let i = 0; i < batch.cacheHits.length; i++) batch.cacheHits[i]();
}
function getValidMaxBatchSize(options) {
  if (!(!options || options.batch !== false)) return 1;
  const maxBatchSize = options && options.maxBatchSize;
  if (maxBatchSize === void 0) return Infinity;
  if (typeof maxBatchSize !== "number" || maxBatchSize < 1) throw new TypeError(`maxBatchSize must be a positive number: ${maxBatchSize}`);
  return maxBatchSize;
}
function getValidBatchScheduleFn(options) {
  const batchScheduleFn = options && options.batchScheduleFn;
  if (batchScheduleFn === void 0) return enqueuePostPromiseJob;
  if (typeof batchScheduleFn !== "function") throw new TypeError(`batchScheduleFn must be a function: ${batchScheduleFn}`);
  return batchScheduleFn;
}
function getValidCacheKeyFn(options) {
  const cacheKeyFn = options && options.cacheKeyFn;
  if (cacheKeyFn === void 0) return (key) => key;
  if (typeof cacheKeyFn !== "function") throw new TypeError(`cacheKeyFn must be a function: ${cacheKeyFn}`);
  return cacheKeyFn;
}
function getValidCacheMap(options) {
  if (!(!options || options.cache !== false)) return null;
  const cacheMap = options && options.cacheMap;
  if (cacheMap === void 0) return /* @__PURE__ */ new Map();
  if (cacheMap !== null) {
    const missingFunctions = [
      "get",
      "set",
      "delete",
      "clear"
    ].filter((fnName) => cacheMap && typeof cacheMap[fnName] !== "function");
    if (missingFunctions.length !== 0) throw new TypeError("Custom cacheMap missing methods: " + missingFunctions.join(", "));
  }
  return cacheMap;
}
function getValidName(options) {
  if (options && options.name) return options.name;
  return null;
}
function isArrayLike(x) {
  return typeof x === "object" && x !== null && "length" in x && typeof x.length === "number" && (x.length === 0 || x.length > 0 && Object.prototype.hasOwnProperty.call(x, x.length - 1));
}

// dapp/node_modules/.pnpm/@mysten+bcs@2.1.2/node_modules/@mysten/bcs/dist/utils.mjs
function encodeStr(data, encoding) {
  switch (encoding) {
    case "base58":
      return toBase58(data);
    case "base64":
      return toBase64(data);
    case "hex":
      return toHex(data);
    default:
      throw new Error("Unsupported encoding, supported values are: base64, hex");
  }
}
function splitGenericParameters(str, genericSeparators = ["<", ">"]) {
  const [left, right] = genericSeparators;
  const tok = [];
  let word = "";
  let nestedAngleBrackets = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str[i];
    if (char === left) nestedAngleBrackets++;
    if (char === right) nestedAngleBrackets--;
    if (nestedAngleBrackets === 0 && char === ",") {
      tok.push(word.trim());
      word = "";
      continue;
    }
    word += char;
  }
  tok.push(word.trim());
  return tok;
}

// dapp/node_modules/.pnpm/@mysten+bcs@2.1.2/node_modules/@mysten/bcs/dist/writer.mjs
var BcsWriter = class {
  constructor({ initialSize = 1024, maxSize = Infinity, allocateSize = 1024 } = {}) {
    this.bytePosition = 0;
    this.size = initialSize;
    this.maxSize = maxSize;
    this.allocateSize = allocateSize;
    this.dataView = new DataView(new ArrayBuffer(initialSize));
  }
  ensureSizeOrGrow(bytes) {
    const requiredSize = this.bytePosition + bytes;
    if (requiredSize > this.size) {
      const nextSize = Math.min(this.maxSize, Math.max(this.size + requiredSize, this.size + this.allocateSize));
      if (requiredSize > nextSize) throw new Error(`Attempting to serialize to BCS, but buffer does not have enough size. Allocated size: ${this.size}, Max size: ${this.maxSize}, Required size: ${requiredSize}`);
      this.size = nextSize;
      const nextBuffer = new ArrayBuffer(this.size);
      new Uint8Array(nextBuffer).set(new Uint8Array(this.dataView.buffer));
      this.dataView = new DataView(nextBuffer);
    }
  }
  /**
  * Shift current cursor position by `bytes`.
  *
  * @param {Number} bytes Number of bytes to
  * @returns {this} Self for possible chaining.
  */
  shift(bytes) {
    this.bytePosition += bytes;
    return this;
  }
  /**
  * Write a U8 value into a buffer and shift cursor position by 1.
  * @param {Number} value Value to write.
  * @returns {this}
  */
  write8(value) {
    this.ensureSizeOrGrow(1);
    this.dataView.setUint8(this.bytePosition, Number(value));
    return this.shift(1);
  }
  /**
  * Write a U8 value into a buffer and shift cursor position by 1.
  * @param {Number} value Value to write.
  * @returns {this}
  */
  writeBytes(bytes) {
    this.ensureSizeOrGrow(bytes.length);
    for (let i = 0; i < bytes.length; i++) this.dataView.setUint8(this.bytePosition + i, bytes[i]);
    return this.shift(bytes.length);
  }
  /**
  * Write a U16 value into a buffer and shift cursor position by 2.
  * @param {Number} value Value to write.
  * @returns {this}
  */
  write16(value) {
    this.ensureSizeOrGrow(2);
    this.dataView.setUint16(this.bytePosition, Number(value), true);
    return this.shift(2);
  }
  /**
  * Write a U32 value into a buffer and shift cursor position by 4.
  * @param {Number} value Value to write.
  * @returns {this}
  */
  write32(value) {
    this.ensureSizeOrGrow(4);
    this.dataView.setUint32(this.bytePosition, Number(value), true);
    return this.shift(4);
  }
  /**
  * Write a U64 value into a buffer and shift cursor position by 8.
  * @param {bigint} value Value to write.
  * @returns {this}
  */
  write64(value) {
    toLittleEndian(BigInt(value), 8).forEach((el) => this.write8(el));
    return this;
  }
  /**
  * Write a U128 value into a buffer and shift cursor position by 16.
  *
  * @param {bigint} value Value to write.
  * @returns {this}
  */
  write128(value) {
    toLittleEndian(BigInt(value), 16).forEach((el) => this.write8(el));
    return this;
  }
  /**
  * Write a U256 value into a buffer and shift cursor position by 16.
  *
  * @param {bigint} value Value to write.
  * @returns {this}
  */
  write256(value) {
    toLittleEndian(BigInt(value), 32).forEach((el) => this.write8(el));
    return this;
  }
  /**
  * Write a ULEB value into a buffer and shift cursor position by number of bytes
  * written.
  * @param {Number} value Value to write.
  * @returns {this}
  */
  writeULEB(value) {
    ulebEncode(value).forEach((el) => this.write8(el));
    return this;
  }
  /**
  * Write a vector into a buffer by first writing the vector length and then calling
  * a callback on each passed value.
  *
  * @param {Array<Any>} vector Array of elements to write.
  * @param {WriteVecCb} cb Callback to call on each element of the vector.
  * @returns {this}
  */
  writeVec(vector2, cb) {
    this.writeULEB(vector2.length);
    Array.from(vector2).forEach((el, i) => cb(this, el, i, vector2.length));
    return this;
  }
  /**
  * Adds support for iterations over the object.
  * @returns {Uint8Array}
  */
  *[Symbol.iterator]() {
    for (let i = 0; i < this.bytePosition; i++) yield this.dataView.getUint8(i);
    return this.toBytes();
  }
  /**
  * Get underlying buffer taking only value bytes (in case initial buffer size was bigger).
  * @returns {Uint8Array} Resulting bcs.
  */
  toBytes() {
    return new Uint8Array(this.dataView.buffer.slice(0, this.bytePosition));
  }
  /**
  * Represent data as 'hex' or 'base64'
  * @param encoding Encoding to use: 'base64' or 'hex'
  */
  toString(encoding) {
    return encodeStr(this.toBytes(), encoding);
  }
};
function toLittleEndian(bigint2, size) {
  const result = new Uint8Array(size);
  let i = 0;
  while (bigint2 > 0) {
    result[i] = Number(bigint2 % BigInt(256));
    bigint2 = bigint2 / BigInt(256);
    i += 1;
  }
  return result;
}

// dapp/node_modules/.pnpm/@mysten+bcs@2.1.2/node_modules/@mysten/bcs/dist/bcs-type.mjs
var BcsType = class BcsType2 {
  #write;
  #serialize;
  constructor(options) {
    this.name = options.name;
    this.read = options.read;
    this.serializedSize = options.serializedSize ?? (() => null);
    this.#write = options.write;
    this.#serialize = options.serialize ?? ((value, options$1) => {
      const writer = new BcsWriter({
        initialSize: this.serializedSize(value) ?? void 0,
        ...options$1
      });
      this.#write(value, writer);
      return writer.toBytes();
    });
    this.validate = options.validate ?? (() => {
    });
  }
  write(value, writer) {
    this.validate(value);
    this.#write(value, writer);
  }
  serialize(value, options) {
    this.validate(value);
    return new SerializedBcs(this, this.#serialize(value, options));
  }
  parse(bytes) {
    const reader = new BcsReader(bytes);
    return this.read(reader);
  }
  fromHex(hex) {
    return this.parse(fromHex(hex));
  }
  fromBase58(b64) {
    return this.parse(fromBase58(b64));
  }
  fromBase64(b64) {
    return this.parse(fromBase64(b64));
  }
  transform({ name, input, output, validate: validate2 }) {
    return new BcsType2({
      name: name ?? this.name,
      read: (reader) => output ? output(this.read(reader)) : this.read(reader),
      write: (value, writer) => this.#write(input ? input(value) : value, writer),
      serializedSize: (value) => this.serializedSize(input ? input(value) : value),
      serialize: (value, options) => this.#serialize(input ? input(value) : value, options),
      validate: (value) => {
        validate2?.(value);
        this.validate(input ? input(value) : value);
      }
    });
  }
};
var SERIALIZED_BCS_BRAND = /* @__PURE__ */ Symbol.for("@mysten/serialized-bcs");
function isSerializedBcs(obj) {
  return !!obj && typeof obj === "object" && obj[SERIALIZED_BCS_BRAND] === true;
}
var SerializedBcs = class {
  #schema;
  #bytes;
  get [SERIALIZED_BCS_BRAND]() {
    return true;
  }
  constructor(schema, bytes) {
    this.#schema = schema;
    this.#bytes = bytes;
  }
  toBytes() {
    return this.#bytes;
  }
  toHex() {
    return toHex(this.#bytes);
  }
  toBase64() {
    return toBase64(this.#bytes);
  }
  toBase58() {
    return toBase58(this.#bytes);
  }
  parse() {
    return this.#schema.parse(this.#bytes);
  }
};
function fixedSizeBcsType({ size, ...options }) {
  return new BcsType({
    ...options,
    serializedSize: () => size
  });
}
function uIntBcsType({ readMethod, writeMethod, ...options }) {
  return fixedSizeBcsType({
    ...options,
    read: (reader) => reader[readMethod](),
    write: (value, writer) => writer[writeMethod](value),
    validate: (value) => {
      if (value < 0 || value > options.maxValue) throw new TypeError(`Invalid ${options.name} value: ${value}. Expected value in range 0-${options.maxValue}`);
      options.validate?.(value);
    }
  });
}
function bigUIntBcsType({ readMethod, writeMethod, ...options }) {
  return fixedSizeBcsType({
    ...options,
    read: (reader) => reader[readMethod](),
    write: (value, writer) => writer[writeMethod](BigInt(value)),
    validate: (val) => {
      const value = BigInt(val);
      if (value < 0 || value > options.maxValue) throw new TypeError(`Invalid ${options.name} value: ${value}. Expected value in range 0-${options.maxValue}`);
      options.validate?.(value);
    }
  });
}
function dynamicSizeBcsType({ serialize, ...options }) {
  const type = new BcsType({
    ...options,
    serialize,
    write: (value, writer) => {
      for (const byte of type.serialize(value).toBytes()) writer.write8(byte);
    }
  });
  return type;
}
function stringLikeBcsType({ toBytes, fromBytes, ...options }) {
  return new BcsType({
    ...options,
    read: (reader) => {
      const length = reader.readULEB();
      return fromBytes(reader.readBytes(length));
    },
    write: (hex, writer) => {
      const bytes = toBytes(hex);
      writer.writeULEB(bytes.length);
      for (let i = 0; i < bytes.length; i++) writer.write8(bytes[i]);
    },
    serialize: (value) => {
      const bytes = toBytes(value);
      const size = ulebEncode(bytes.length);
      const result = new Uint8Array(size.length + bytes.length);
      result.set(size, 0);
      result.set(bytes, size.length);
      return result;
    },
    validate: (value) => {
      if (typeof value !== "string") throw new TypeError(`Invalid ${options.name} value: ${value}. Expected string`);
      options.validate?.(value);
    }
  });
}
function lazyBcsType(cb) {
  let lazyType = null;
  function getType() {
    if (!lazyType) lazyType = cb();
    return lazyType;
  }
  return new BcsType({
    name: "lazy",
    read: (data) => getType().read(data),
    serializedSize: (value) => getType().serializedSize(value),
    write: (value, writer) => getType().write(value, writer),
    serialize: (value, options) => getType().serialize(value, options).toBytes()
  });
}
var BcsStruct = class extends BcsType {
  constructor({ name, fields, ...options }) {
    const canonicalOrder = Object.entries(fields);
    super({
      name,
      serializedSize: (values) => {
        let total = 0;
        for (const [field, type] of canonicalOrder) {
          const size = type.serializedSize(values[field]);
          if (size == null) return null;
          total += size;
        }
        return total;
      },
      read: (reader) => {
        const result = {};
        for (const [field, type] of canonicalOrder) result[field] = type.read(reader);
        return result;
      },
      write: (value, writer) => {
        for (const [field, type] of canonicalOrder) type.write(value[field], writer);
      },
      ...options,
      validate: (value) => {
        options?.validate?.(value);
        if (typeof value !== "object" || value == null) throw new TypeError(`Expected object, found ${typeof value}`);
      }
    });
  }
};
var BcsEnum = class extends BcsType {
  constructor({ fields, ...options }) {
    const canonicalOrder = Object.entries(fields);
    super({
      read: (reader) => {
        const index = reader.readULEB();
        const enumEntry = canonicalOrder[index];
        if (!enumEntry) throw new TypeError(`Unknown value ${index} for enum ${options.name}`);
        const [kind, type] = enumEntry;
        return {
          [kind]: type?.read(reader) ?? true,
          $kind: kind
        };
      },
      write: (value, writer) => {
        const [name, val] = Object.entries(value).filter(([name$1]) => Object.hasOwn(fields, name$1))[0];
        for (let i = 0; i < canonicalOrder.length; i++) {
          const [optionName, optionType] = canonicalOrder[i];
          if (optionName === name) {
            writer.writeULEB(i);
            optionType?.write(val, writer);
            return;
          }
        }
      },
      ...options,
      validate: (value) => {
        options?.validate?.(value);
        if (typeof value !== "object" || value == null) throw new TypeError(`Expected object, found ${typeof value}`);
        const keys = Object.keys(value).filter((k) => value[k] !== void 0 && Object.hasOwn(fields, k));
        if (keys.length !== 1) throw new TypeError(`Expected object with one key, but found ${keys.length} for type ${options.name}}`);
        const [variant2] = keys;
        if (!Object.hasOwn(fields, variant2)) throw new TypeError(`Invalid enum variant ${variant2}`);
      }
    });
  }
};
var BcsTuple = class extends BcsType {
  constructor({ fields, name, ...options }) {
    super({
      name: name ?? `(${fields.map((t) => t.name).join(", ")})`,
      serializedSize: (values) => {
        let total = 0;
        for (let i = 0; i < fields.length; i++) {
          const size = fields[i].serializedSize(values[i]);
          if (size == null) return null;
          total += size;
        }
        return total;
      },
      read: (reader) => {
        const result = [];
        for (const field of fields) result.push(field.read(reader));
        return result;
      },
      write: (value, writer) => {
        for (let i = 0; i < fields.length; i++) fields[i].write(value[i], writer);
      },
      ...options,
      validate: (value) => {
        options?.validate?.(value);
        if (!Array.isArray(value)) throw new TypeError(`Expected array, found ${typeof value}`);
        if (value.length !== fields.length) throw new TypeError(`Expected array of length ${fields.length}, found ${value.length}`);
      }
    });
  }
};

// dapp/node_modules/.pnpm/@mysten+bcs@2.1.2/node_modules/@mysten/bcs/dist/bcs.mjs
function fixedArray(size, type, options) {
  return new BcsType({
    read: (reader) => {
      const result = new Array(size);
      for (let i = 0; i < size; i++) result[i] = type.read(reader);
      return result;
    },
    write: (value, writer) => {
      for (const item of value) type.write(item, writer);
    },
    ...options,
    name: options?.name ?? `${type.name}[${size}]`,
    validate: (value) => {
      options?.validate?.(value);
      if (!value || typeof value !== "object" || !("length" in value)) throw new TypeError(`Expected array, found ${typeof value}`);
      if (value.length !== size) throw new TypeError(`Expected array of length ${size}, found ${value.length}`);
    }
  });
}
function option(type) {
  return bcs.enum(`Option<${type.name}>`, {
    None: null,
    Some: type
  }).transform({
    input: (value) => {
      if (value == null) return { None: true };
      return { Some: value };
    },
    output: (value) => {
      if (value.$kind === "Some") return value.Some;
      return null;
    }
  });
}
function vector(type, options) {
  return new BcsType({
    read: (reader) => {
      const length = reader.readULEB();
      const result = new Array(length);
      for (let i = 0; i < length; i++) result[i] = type.read(reader);
      return result;
    },
    write: (value, writer) => {
      writer.writeULEB(value.length);
      for (const item of value) type.write(item, writer);
    },
    ...options,
    name: options?.name ?? `vector<${type.name}>`,
    validate: (value) => {
      options?.validate?.(value);
      if (!value || typeof value !== "object" || !("length" in value)) throw new TypeError(`Expected array, found ${typeof value}`);
    }
  });
}
function compareBcsBytes(a, b) {
  for (let i = 0; i < Math.min(a.length, b.length); i++) if (a[i] !== b[i]) return a[i] - b[i];
  return a.length - b.length;
}
function map(keyType, valueType) {
  return new BcsType({
    name: `Map<${keyType.name}, ${valueType.name}>`,
    read: (reader) => {
      const length = reader.readULEB();
      const result = /* @__PURE__ */ new Map();
      for (let i = 0; i < length; i++) result.set(keyType.read(reader), valueType.read(reader));
      return result;
    },
    write: (value, writer) => {
      const entries = [...value.entries()].map(([key, val]) => [keyType.serialize(key).toBytes(), val]);
      entries.sort(([a], [b]) => compareBcsBytes(a, b));
      writer.writeULEB(entries.length);
      for (const [keyBytes, val] of entries) {
        writer.writeBytes(keyBytes);
        valueType.write(val, writer);
      }
    }
  });
}
var bcs = {
  u8(options) {
    return uIntBcsType({
      readMethod: "read8",
      writeMethod: "write8",
      size: 1,
      maxValue: 2 ** 8 - 1,
      ...options,
      name: options?.name ?? "u8"
    });
  },
  u16(options) {
    return uIntBcsType({
      readMethod: "read16",
      writeMethod: "write16",
      size: 2,
      maxValue: 2 ** 16 - 1,
      ...options,
      name: options?.name ?? "u16"
    });
  },
  u32(options) {
    return uIntBcsType({
      readMethod: "read32",
      writeMethod: "write32",
      size: 4,
      maxValue: 2 ** 32 - 1,
      ...options,
      name: options?.name ?? "u32"
    });
  },
  u64(options) {
    return bigUIntBcsType({
      readMethod: "read64",
      writeMethod: "write64",
      size: 8,
      maxValue: 2n ** 64n - 1n,
      ...options,
      name: options?.name ?? "u64"
    });
  },
  u128(options) {
    return bigUIntBcsType({
      readMethod: "read128",
      writeMethod: "write128",
      size: 16,
      maxValue: 2n ** 128n - 1n,
      ...options,
      name: options?.name ?? "u128"
    });
  },
  u256(options) {
    return bigUIntBcsType({
      readMethod: "read256",
      writeMethod: "write256",
      size: 32,
      maxValue: 2n ** 256n - 1n,
      ...options,
      name: options?.name ?? "u256"
    });
  },
  bool(options) {
    return fixedSizeBcsType({
      size: 1,
      read: (reader) => {
        const value = reader.read8();
        if (value > 1) throw new TypeError(`Invalid bool value: expected 0 or 1, found ${value}`);
        return value === 1;
      },
      write: (value, writer) => writer.write8(value ? 1 : 0),
      ...options,
      name: options?.name ?? "bool",
      validate: (value) => {
        options?.validate?.(value);
        if (typeof value !== "boolean") throw new TypeError(`Expected boolean, found ${typeof value}`);
      }
    });
  },
  uleb128(options) {
    return dynamicSizeBcsType({
      read: (reader) => reader.readULEB(),
      serialize: (value) => {
        return Uint8Array.from(ulebEncode(value));
      },
      ...options,
      name: options?.name ?? "uleb128"
    });
  },
  bytes(size, options) {
    return fixedSizeBcsType({
      size,
      read: (reader) => reader.readBytes(size),
      write: (value, writer) => {
        writer.writeBytes(new Uint8Array(value));
      },
      ...options,
      name: options?.name ?? `bytes[${size}]`,
      validate: (value) => {
        options?.validate?.(value);
        if (!value || typeof value !== "object" || !("length" in value)) throw new TypeError(`Expected array, found ${typeof value}`);
        if (value.length !== size) throw new TypeError(`Expected array of length ${size}, found ${value.length}`);
      }
    });
  },
  byteVector(options) {
    return new BcsType({
      read: (reader) => {
        const length = reader.readULEB();
        return reader.readBytes(length);
      },
      write: (value, writer) => {
        const array2 = new Uint8Array(value);
        writer.writeULEB(array2.length);
        writer.writeBytes(array2);
      },
      ...options,
      name: options?.name ?? "vector<u8>",
      serializedSize: (value) => {
        const length = "length" in value ? value.length : null;
        return length == null ? null : ulebEncode(length).length + length;
      },
      validate: (value) => {
        options?.validate?.(value);
        if (!value || typeof value !== "object" || !("length" in value)) throw new TypeError(`Expected array, found ${typeof value}`);
      }
    });
  },
  string(options) {
    return stringLikeBcsType({
      toBytes: (value) => new TextEncoder().encode(value),
      fromBytes: (bytes) => new TextDecoder("utf-8", {
        fatal: true,
        ignoreBOM: true
      }).decode(bytes),
      ...options,
      name: options?.name ?? "string"
    });
  },
  fixedArray,
  option,
  vector,
  tuple(fields, options) {
    return new BcsTuple({
      fields,
      ...options
    });
  },
  struct(name, fields, options) {
    return new BcsStruct({
      name,
      fields,
      ...options
    });
  },
  enum(name, fields, options) {
    return new BcsEnum({
      name,
      fields,
      ...options
    });
  },
  map,
  lazy(cb) {
    return lazyBcsType(cb);
  }
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/utils/sui-types.mjs
var SUI_ADDRESS_LENGTH = 32;
function isValidSuiAddress(value) {
  return isHex(value) && getHexByteLength(value) === SUI_ADDRESS_LENGTH;
}
var MOVE_IDENTIFIER_REGEX = /^[a-zA-Z][a-zA-Z0-9_]*$/;
function isValidMoveIdentifier(name) {
  return MOVE_IDENTIFIER_REGEX.test(name);
}
var PRIMITIVE_TYPE_TAGS = [
  "bool",
  "u8",
  "u16",
  "u32",
  "u64",
  "u128",
  "u256",
  "address",
  "signer"
];
var VECTOR_TYPE_REGEX = /^vector<(.+)>$/;
function isValidTypeTag(type) {
  if (PRIMITIVE_TYPE_TAGS.includes(type)) return true;
  const vectorMatch = type.match(VECTOR_TYPE_REGEX);
  if (vectorMatch) return isValidTypeTag(vectorMatch[1]);
  if (type.includes("::")) return isValidStructTag(type);
  return false;
}
function isValidParsedStructTag(tag) {
  if (!isValidSuiAddress(tag.address) && !isValidNamedPackage(tag.address)) return false;
  if (!isValidMoveIdentifier(tag.module) || !isValidMoveIdentifier(tag.name)) return false;
  return tag.typeParams.every((param) => {
    if (typeof param === "string") return isValidTypeTag(param);
    return isValidParsedStructTag(param);
  });
}
function isValidStructTag(type) {
  try {
    return isValidParsedStructTag(parseStructTag(type));
  } catch {
    return false;
  }
}
function parseTypeTag(type) {
  if (type.startsWith("vector<")) {
    if (!type.endsWith(">")) throw new Error(`Invalid type tag: ${type}`);
    const inner = type.slice(7, -1);
    if (!inner) throw new Error(`Invalid type tag: ${type}`);
    const parsed = parseTypeTag(inner);
    if (typeof parsed === "string") return `vector<${parsed}>`;
    return `vector<${normalizeStructTag(parsed)}>`;
  }
  if (!type.includes("::")) return type;
  return parseStructTag(type);
}
function parseStructTag(type) {
  const parts = type.split("::");
  if (parts.length < 3) throw new Error(`Invalid struct tag: ${type}`);
  const [address, module2] = parts;
  if (!address || !module2) throw new Error(`Invalid struct tag: ${type}`);
  const isMvrPackage = isValidNamedPackage(address);
  const rest = type.slice(address.length + module2.length + 4);
  const name = rest.includes("<") ? rest.slice(0, rest.indexOf("<")) : rest;
  if (!name || rest.includes("<") && !rest.endsWith(">")) throw new Error(`Invalid struct tag: ${type}`);
  const typeParams = rest.includes("<") ? splitGenericParameters(rest.slice(rest.indexOf("<") + 1, rest.lastIndexOf(">"))).map((typeParam) => parseTypeTag(typeParam.trim())) : [];
  return {
    address: isMvrPackage ? address : normalizeSuiAddress(address),
    module: module2,
    name,
    typeParams
  };
}
function normalizeStructTag(type) {
  if (typeof type === "string" && type.startsWith("vector<")) throw new Error("normalizeStructTag does not support vector types. Use normalizeTypeTag instead.");
  const { address, module: module2, name, typeParams } = typeof type === "string" ? parseStructTag(type) : type;
  return `${address}::${module2}::${name}${typeParams?.length > 0 ? `<${typeParams.map((typeParam) => typeof typeParam === "string" ? typeParam : normalizeStructTag(typeParam)).join(",")}>` : ""}`;
}
function normalizeSuiAddress(value, forceAdd0x = false) {
  let address = value.toLowerCase();
  if (!forceAdd0x && address.startsWith("0x")) address = address.slice(2);
  return `0x${address.padStart(SUI_ADDRESS_LENGTH * 2, "0")}`;
}
function normalizeSuiObjectId(value, forceAdd0x = false) {
  return normalizeSuiAddress(value, forceAdd0x);
}
function isHex(value) {
  return /^(0x|0X)?[a-fA-F0-9]+$/.test(value) && value.length % 2 === 0;
}
function getHexByteLength(value) {
  return /^(0x|0X)/.test(value) ? (value.length - 2) / 2 : value.length / 2;
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/bcs/type-tag-serializer.mjs
var VECTOR_REGEX = /^vector<(.+)>$/;
var STRUCT_REGEX = /^([^:]+)::([^:]+)::([^<]+)(<(.+)>)?/;
var TypeTagSerializer = class TypeTagSerializer2 {
  static parseFromStr(str, normalizeAddress = false) {
    if (str === "address") return { address: null };
    else if (str === "bool") return { bool: null };
    else if (str === "u8") return { u8: null };
    else if (str === "u16") return { u16: null };
    else if (str === "u32") return { u32: null };
    else if (str === "u64") return { u64: null };
    else if (str === "u128") return { u128: null };
    else if (str === "u256") return { u256: null };
    else if (str === "signer") return { signer: null };
    const vectorMatch = str.match(VECTOR_REGEX);
    if (vectorMatch) return { vector: TypeTagSerializer2.parseFromStr(vectorMatch[1], normalizeAddress) };
    const structMatch = str.match(STRUCT_REGEX);
    if (structMatch) return { struct: {
      address: normalizeAddress ? normalizeSuiAddress(structMatch[1]) : structMatch[1],
      module: structMatch[2],
      name: structMatch[3],
      typeParams: structMatch[5] === void 0 ? [] : TypeTagSerializer2.parseStructTypeArgs(structMatch[5], normalizeAddress)
    } };
    throw new Error(`Encountered unexpected token when parsing type args for ${str}`);
  }
  static parseStructTypeArgs(str, normalizeAddress = false) {
    return splitGenericParameters(str).map((tok) => TypeTagSerializer2.parseFromStr(tok, normalizeAddress));
  }
  static tagToString(tag) {
    if ("bool" in tag) return "bool";
    if ("u8" in tag) return "u8";
    if ("u16" in tag) return "u16";
    if ("u32" in tag) return "u32";
    if ("u64" in tag) return "u64";
    if ("u128" in tag) return "u128";
    if ("u256" in tag) return "u256";
    if ("address" in tag) return "address";
    if ("signer" in tag) return "signer";
    if ("vector" in tag) return `vector<${TypeTagSerializer2.tagToString(tag.vector)}>`;
    if ("struct" in tag) {
      const struct = tag.struct;
      const typeParams = struct.typeParams.map(TypeTagSerializer2.tagToString).join(", ");
      return `${struct.address}::${struct.module}::${struct.name}${typeParams ? `<${typeParams}>` : ""}`;
    }
    throw new Error("Invalid TypeTag");
  }
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/bcs/bcs.mjs
function unsafe_u64(options) {
  return bcs.u64({
    name: "unsafe_u64",
    ...options
  }).transform({
    input: (val) => val,
    output: (val) => Number(val)
  });
}
function optionEnum(type) {
  return bcs.enum("Option", {
    None: null,
    Some: type
  });
}
var Address = bcs.bytes(SUI_ADDRESS_LENGTH).transform({
  validate: (val) => {
    const address = typeof val === "string" ? val : toHex(val);
    if (!address || !isValidSuiAddress(normalizeSuiAddress(address))) throw new Error(`Invalid Sui address ${address}`);
  },
  input: (val) => typeof val === "string" ? fromHex(normalizeSuiAddress(val)) : val,
  output: (val) => normalizeSuiAddress(toHex(val))
});
var ObjectDigest = bcs.byteVector().transform({
  name: "ObjectDigest",
  input: (value) => fromBase58(value),
  output: (value) => toBase58(new Uint8Array(value)),
  validate: (value) => {
    if (fromBase58(value).length !== 32) throw new Error("ObjectDigest must be 32 bytes");
  }
});
var SuiObjectRef = bcs.struct("SuiObjectRef", {
  objectId: Address,
  version: bcs.u64(),
  digest: ObjectDigest
});
var SharedObjectRef = bcs.struct("SharedObjectRef", {
  objectId: Address,
  initialSharedVersion: bcs.u64(),
  mutable: bcs.bool()
});
var ObjectArg = bcs.enum("ObjectArg", {
  ImmOrOwnedObject: SuiObjectRef,
  SharedObject: SharedObjectRef,
  Receiving: SuiObjectRef
});
var Owner = bcs.enum("Owner", {
  AddressOwner: Address,
  ObjectOwner: Address,
  Shared: bcs.struct("Shared", { initialSharedVersion: bcs.u64() }),
  Immutable: null,
  ConsensusAddressOwner: bcs.struct("ConsensusAddressOwner", {
    startVersion: bcs.u64(),
    owner: Address
  })
});
var Reservation = bcs.enum("Reservation", { MaxAmountU64: bcs.u64() });
var WithdrawalType = bcs.enum("WithdrawalType", { Balance: bcs.lazy(() => TypeTag) });
var WithdrawFrom = bcs.enum("WithdrawFrom", {
  Sender: null,
  Sponsor: null,
  SenderAllowance: bcs.struct("SenderAllowance", {
    funder: Address,
    allowance: Address
  })
});
var FundsWithdrawal = bcs.struct("FundsWithdrawal", {
  reservation: Reservation,
  typeArg: WithdrawalType,
  withdrawFrom: WithdrawFrom
});
var CallArg = bcs.enum("CallArg", {
  Pure: bcs.struct("Pure", { bytes: bcs.byteVector().transform({
    input: (val) => typeof val === "string" ? fromBase64(val) : val,
    output: (val) => toBase64(new Uint8Array(val))
  }) }),
  Object: ObjectArg,
  FundsWithdrawal
});
var InnerTypeTag = bcs.enum("TypeTag", {
  bool: null,
  u8: null,
  u64: null,
  u128: null,
  address: null,
  signer: null,
  vector: bcs.lazy(() => InnerTypeTag),
  struct: bcs.lazy(() => StructTag),
  u16: null,
  u32: null,
  u256: null
});
var TypeTag = InnerTypeTag.transform({
  input: (typeTag) => typeof typeTag === "string" ? TypeTagSerializer.parseFromStr(typeTag, true) : typeTag,
  output: (typeTag) => TypeTagSerializer.tagToString(typeTag)
});
var Argument = bcs.enum("Argument", {
  GasCoin: null,
  Input: bcs.u16(),
  Result: bcs.u16(),
  NestedResult: bcs.tuple([bcs.u16(), bcs.u16()])
});
var ProgrammableMoveCall = bcs.struct("ProgrammableMoveCall", {
  package: Address,
  module: bcs.string(),
  function: bcs.string(),
  typeArguments: bcs.vector(TypeTag),
  arguments: bcs.vector(Argument)
});
var Command = bcs.enum("Command", {
  MoveCall: ProgrammableMoveCall,
  TransferObjects: bcs.struct("TransferObjects", {
    objects: bcs.vector(Argument),
    address: Argument
  }),
  SplitCoins: bcs.struct("SplitCoins", {
    coin: Argument,
    amounts: bcs.vector(Argument)
  }),
  MergeCoins: bcs.struct("MergeCoins", {
    destination: Argument,
    sources: bcs.vector(Argument)
  }),
  Publish: bcs.struct("Publish", {
    modules: bcs.vector(bcs.byteVector().transform({
      input: (val) => typeof val === "string" ? fromBase64(val) : val,
      output: (val) => toBase64(new Uint8Array(val))
    })),
    dependencies: bcs.vector(Address)
  }),
  MakeMoveVec: bcs.struct("MakeMoveVec", {
    type: optionEnum(TypeTag).transform({
      input: (val) => val === null ? { None: true } : { Some: val },
      output: (val) => val.Some ?? null
    }),
    elements: bcs.vector(Argument)
  }),
  Upgrade: bcs.struct("Upgrade", {
    modules: bcs.vector(bcs.byteVector().transform({
      input: (val) => typeof val === "string" ? fromBase64(val) : val,
      output: (val) => toBase64(new Uint8Array(val))
    })),
    dependencies: bcs.vector(Address),
    package: Address,
    ticket: Argument
  })
});
var ProgrammableTransaction = bcs.struct("ProgrammableTransaction", {
  inputs: bcs.vector(CallArg),
  commands: bcs.vector(Command)
});
var ValidDuring = bcs.struct("ValidDuring", {
  minEpoch: bcs.option(bcs.u64()),
  maxEpoch: bcs.option(bcs.u64()),
  minTimestamp: bcs.option(bcs.u64()),
  maxTimestamp: bcs.option(bcs.u64()),
  chain: ObjectDigest,
  nonce: bcs.u32()
});
function assertAllowedProposersNotEmpty(proposers) {
  if (proposers.length === 0) throw new Error("Allowed proposers must not be empty");
  return proposers;
}
function assertAllowedProposersStrictlyIncreasing(proposers) {
  assertAllowedProposersNotEmpty(proposers);
  for (let i = 1; i < proposers.length; i++) if (proposers[i] <= proposers[i - 1]) throw new Error("Allowed proposers must be strictly increasing");
  return proposers;
}
var AllowedProposerIndices = bcs.vector(bcs.u32()).transform({
  input: assertAllowedProposersStrictlyIncreasing,
  output: assertAllowedProposersNotEmpty
});
var AllowedProposers = bcs.struct("AllowedProposers", {
  epoch: bcs.u64(),
  proposers: AllowedProposerIndices
});
var Validity = bcs.struct("Validity", {
  minEpoch: bcs.option(bcs.u64()),
  maxEpoch: bcs.option(bcs.u64()),
  minTimestamp: bcs.option(bcs.u64()),
  maxTimestamp: bcs.option(bcs.u64()),
  chain: ObjectDigest,
  nonce: bcs.u32(),
  allowedProposers: bcs.option(AllowedProposers)
});
var TransactionExpiration = bcs.enum("TransactionExpiration", {
  None: null,
  Epoch: unsafe_u64(),
  ValidDuring,
  Validity
});
var StructTag = bcs.struct("StructTag", {
  address: Address,
  module: bcs.string(),
  name: bcs.string(),
  typeParams: bcs.vector(InnerTypeTag)
});
var GasData = bcs.struct("GasData", {
  payment: bcs.vector(SuiObjectRef),
  owner: Address,
  price: bcs.u64(),
  budget: bcs.u64()
});
var IntentScope = bcs.enum("IntentScope", {
  TransactionData: null,
  TransactionEffects: null,
  CheckpointSummary: null,
  PersonalMessage: null
});
var IntentVersion = bcs.enum("IntentVersion", { V0: null });
var AppId = bcs.enum("AppId", { Sui: null });
var Intent = bcs.struct("Intent", {
  scope: IntentScope,
  version: IntentVersion,
  appId: AppId
});
function IntentMessage(T) {
  return bcs.struct(`IntentMessage<${T.name}>`, {
    intent: Intent,
    value: T
  });
}
var CompressedSignature = bcs.enum("CompressedSignature", {
  ED25519: bcs.bytes(64),
  Secp256k1: bcs.bytes(64),
  Secp256r1: bcs.bytes(64),
  ZkLogin: bcs.byteVector(),
  Passkey: bcs.byteVector(),
  MLDSA65: bcs.bytes(3309)
});
var PublicKey = bcs.enum("PublicKey", {
  ED25519: bcs.bytes(32),
  Secp256k1: bcs.bytes(33),
  Secp256r1: bcs.bytes(33),
  ZkLogin: bcs.byteVector(),
  Passkey: bcs.bytes(33),
  MLDSA65: bcs.bytes(1952)
});
var MultiSigPkMap = bcs.struct("MultiSigPkMap", {
  pubKey: PublicKey,
  weight: bcs.u8()
});
var MultiSigPublicKey = bcs.struct("MultiSigPublicKey", {
  pk_map: bcs.vector(MultiSigPkMap),
  threshold: bcs.u16()
});
var MultiSig = bcs.struct("MultiSig", {
  sigs: bcs.vector(CompressedSignature),
  bitmap: bcs.u16(),
  multisig_pk: MultiSigPublicKey
});
var base64String = bcs.byteVector().transform({
  input: (val) => typeof val === "string" ? fromBase64(val) : val,
  output: (val) => toBase64(new Uint8Array(val))
});
var PasskeyAuthenticator = bcs.struct("PasskeyAuthenticator", {
  authenticatorData: bcs.byteVector(),
  clientDataJson: bcs.string(),
  userSignature: bcs.byteVector()
});
var MoveObjectType = bcs.enum("MoveObjectType", {
  Other: StructTag,
  GasCoin: null,
  StakedSui: null,
  Coin: TypeTag,
  AccumulatorBalanceWrapper: null
});
var TypeOrigin = bcs.struct("TypeOrigin", {
  moduleName: bcs.string(),
  datatypeName: bcs.string(),
  package: Address
});
var UpgradeInfo = bcs.struct("UpgradeInfo", {
  upgradedId: Address,
  upgradedVersion: bcs.u64()
});
var MovePackage = bcs.struct("MovePackage", {
  id: Address,
  version: bcs.u64(),
  moduleMap: bcs.map(bcs.string(), bcs.byteVector()),
  typeOriginTable: bcs.vector(TypeOrigin),
  linkageTable: bcs.map(Address, UpgradeInfo)
});
var MoveObject = bcs.struct("MoveObject", {
  type: MoveObjectType,
  hasPublicTransfer: bcs.bool(),
  version: bcs.u64(),
  contents: bcs.byteVector()
});
var Data = bcs.enum("Data", {
  Move: MoveObject,
  Package: MovePackage
});
var ObjectInner = bcs.struct("ObjectInner", {
  data: Data,
  owner: Owner,
  previousTransaction: ObjectDigest,
  storageRebate: bcs.u64()
});

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/bcs/transactions.mjs
var ChangeEpoch = bcs.struct("ChangeEpoch", {
  epoch: bcs.u64(),
  protocolVersion: bcs.u64(),
  storageCharge: bcs.u64(),
  computationCharge: bcs.u64(),
  storageRebate: bcs.u64(),
  nonRefundableStorageFee: bcs.u64(),
  epochStartTimestampMs: bcs.u64(),
  systemPackages: bcs.vector(bcs.tuple([
    bcs.u64(),
    bcs.vector(bcs.byteVector()),
    bcs.vector(Address)
  ]))
});
var GenesisObject = bcs.enum("GenesisObject", { RawObject: bcs.struct("RawObject", {
  data: Data,
  owner: Owner
}) });
var GenesisTransaction = bcs.struct("GenesisTransaction", { objects: bcs.vector(GenesisObject) });
var ConsensusCommitPrologue = bcs.struct("ConsensusCommitPrologue", {
  epoch: bcs.u64(),
  round: bcs.u64(),
  commitTimestampMs: bcs.u64()
});
var ConsensusCommitPrologueV2 = bcs.struct("ConsensusCommitPrologueV2", {
  epoch: bcs.u64(),
  round: bcs.u64(),
  commitTimestampMs: bcs.u64(),
  consensusCommitDigest: ObjectDigest
});
var ConsensusDeterminedVersionAssignments = bcs.enum("ConsensusDeterminedVersionAssignments", {
  CancelledTransactions: bcs.vector(bcs.tuple([ObjectDigest, bcs.vector(bcs.tuple([Address, bcs.u64()]))])),
  CancelledTransactionsV2: bcs.vector(bcs.tuple([ObjectDigest, bcs.vector(bcs.tuple([bcs.tuple([Address, bcs.u64()]), bcs.u64()]))]))
});
var ConsensusCommitPrologueV3 = bcs.struct("ConsensusCommitPrologueV3", {
  epoch: bcs.u64(),
  round: bcs.u64(),
  subDagIndex: bcs.option(bcs.u64()),
  commitTimestampMs: bcs.u64(),
  consensusCommitDigest: ObjectDigest,
  consensusDeterminedVersionAssignments: ConsensusDeterminedVersionAssignments
});
var ConsensusCommitPrologueV4 = bcs.struct("ConsensusCommitPrologueV4", {
  epoch: bcs.u64(),
  round: bcs.u64(),
  subDagIndex: bcs.option(bcs.u64()),
  commitTimestampMs: bcs.u64(),
  consensusCommitDigest: ObjectDigest,
  consensusDeterminedVersionAssignments: ConsensusDeterminedVersionAssignments,
  additionalStateDigest: ObjectDigest
});
var ActiveJwk = bcs.struct("ActiveJwk", {
  jwkId: bcs.struct("JwkId", {
    iss: bcs.string(),
    kid: bcs.string()
  }),
  jwk: bcs.struct("JWK", {
    kty: bcs.string(),
    e: bcs.string(),
    n: bcs.string(),
    alg: bcs.string()
  }),
  epoch: bcs.u64()
});
var AuthenticatorStateUpdate = bcs.struct("AuthenticatorStateUpdate", {
  epoch: bcs.u64(),
  round: bcs.u64(),
  newActiveJwks: bcs.vector(ActiveJwk),
  authenticatorObjInitialSharedVersion: bcs.u64()
});
var RandomnessStateUpdate = bcs.struct("RandomnessStateUpdate", {
  epoch: bcs.u64(),
  randomnessRound: bcs.u64(),
  randomBytes: bcs.byteVector(),
  randomnessObjInitialSharedVersion: bcs.u64()
});
var AuthenticatorStateExpire = bcs.struct("AuthenticatorStateExpire", {
  minEpoch: bcs.u64(),
  authenticatorObjInitialSharedVersion: bcs.u64()
});
var ExecutionTimeObservationKey = bcs.enum("ExecutionTimeObservationKey", {
  MoveEntryPoint: bcs.struct("MoveEntryPoint", {
    package: Address,
    module: bcs.string(),
    function: bcs.string(),
    typeArguments: bcs.vector(TypeTag)
  }),
  TransferObjects: null,
  SplitCoins: null,
  MergeCoins: null,
  Publish: null,
  MakeMoveVec: null,
  Upgrade: null
});
var StoredExecutionTimeObservations = bcs.enum("StoredExecutionTimeObservations", { V1: bcs.vector(bcs.tuple([ExecutionTimeObservationKey, bcs.vector(bcs.tuple([bcs.byteVector(), bcs.struct("Duration", {
  secs: bcs.u64(),
  nanos: bcs.u32()
})]))])) });
var WriteAccumulatorStorageCost = bcs.struct("WriteAccumulatorStorageCost", { storageCost: bcs.u64() });
var EndOfEpochTransactionKind = bcs.enum("EndOfEpochTransactionKind", {
  ChangeEpoch,
  AuthenticatorStateCreate: null,
  AuthenticatorStateExpire,
  RandomnessStateCreate: null,
  DenyListStateCreate: null,
  BridgeStateCreate: ObjectDigest,
  BridgeCommitteeInit: bcs.u64(),
  StoreExecutionTimeObservations: StoredExecutionTimeObservations,
  AccumulatorRootCreate: null,
  CoinRegistryCreate: null,
  DisplayRegistryCreate: null,
  AddressAliasStateCreate: null,
  WriteAccumulatorStorageCost,
  ForwardingAddressRegistryCreate: null
});
var TransactionKind = bcs.enum("TransactionKind", {
  ProgrammableTransaction,
  ChangeEpoch,
  Genesis: GenesisTransaction,
  ConsensusCommitPrologue,
  AuthenticatorStateUpdate,
  EndOfEpochTransaction: bcs.vector(EndOfEpochTransactionKind),
  RandomnessStateUpdate,
  ConsensusCommitPrologueV2,
  ConsensusCommitPrologueV3,
  ConsensusCommitPrologueV4,
  ProgrammableSystemTransaction: ProgrammableTransaction
});
var TransactionDataV1 = bcs.struct("TransactionDataV1", {
  kind: TransactionKind,
  sender: Address,
  gasData: GasData,
  expiration: TransactionExpiration
});
var TransactionData = bcs.enum("TransactionData", { V1: TransactionDataV1 });
var SenderSignedTransaction = bcs.struct("SenderSignedTransaction", {
  intentMessage: IntentMessage(TransactionData),
  txSignatures: bcs.vector(base64String)
});
var SenderSignedData = bcs.vector(SenderSignedTransaction, { name: "SenderSignedData" });

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/bcs/effects.mjs
var PackageUpgradeError = bcs.enum("PackageUpgradeError", {
  UnableToFetchPackage: bcs.struct("UnableToFetchPackage", { packageId: Address }),
  NotAPackage: bcs.struct("NotAPackage", { objectId: Address }),
  IncompatibleUpgrade: null,
  DigestDoesNotMatch: bcs.struct("DigestDoesNotMatch", { digest: bcs.byteVector() }),
  UnknownUpgradePolicy: bcs.struct("UnknownUpgradePolicy", { policy: bcs.u8() }),
  PackageIDDoesNotMatch: bcs.struct("PackageIDDoesNotMatch", {
    packageId: Address,
    ticketId: Address
  })
});
var ModuleId = bcs.struct("ModuleId", {
  address: Address,
  name: bcs.string()
});
var MoveLocation = bcs.struct("MoveLocation", {
  module: ModuleId,
  function: bcs.u16(),
  instruction: bcs.u16(),
  functionName: bcs.option(bcs.string())
});
var CommandArgumentError = bcs.enum("CommandArgumentError", {
  TypeMismatch: null,
  InvalidBCSBytes: null,
  InvalidUsageOfPureArg: null,
  InvalidArgumentToPrivateEntryFunction: null,
  IndexOutOfBounds: bcs.struct("IndexOutOfBounds", { idx: bcs.u16() }),
  SecondaryIndexOutOfBounds: bcs.struct("SecondaryIndexOutOfBounds", {
    resultIdx: bcs.u16(),
    secondaryIdx: bcs.u16()
  }),
  InvalidResultArity: bcs.struct("InvalidResultArity", { resultIdx: bcs.u16() }),
  InvalidGasCoinUsage: null,
  InvalidValueUsage: null,
  InvalidObjectByValue: null,
  InvalidObjectByMutRef: null,
  SharedObjectOperationNotAllowed: null,
  InvalidArgumentArity: null,
  InvalidTransferObject: null,
  InvalidMakeMoveVecNonObjectArgument: null,
  ArgumentWithoutValue: null,
  CannotMoveBorrowedValue: null,
  CannotWriteToExtendedReference: null,
  InvalidReferenceArgument: null,
  InvalidTxContext: null
});
var TypeArgumentError = bcs.enum("TypeArgumentError", {
  TypeNotFound: null,
  ConstraintNotSatisfied: null
});
var ExecutionFailureStatus = bcs.enum("ExecutionFailureStatus", {
  InsufficientGas: null,
  InvalidGasObject: null,
  InvariantViolation: null,
  FeatureNotYetSupported: null,
  MoveObjectTooBig: bcs.struct("MoveObjectTooBig", {
    objectSize: bcs.u64(),
    maxObjectSize: bcs.u64()
  }),
  MovePackageTooBig: bcs.struct("MovePackageTooBig", {
    objectSize: bcs.u64(),
    maxObjectSize: bcs.u64()
  }),
  CircularObjectOwnership: bcs.struct("CircularObjectOwnership", { object: Address }),
  InsufficientCoinBalance: null,
  CoinBalanceOverflow: null,
  PublishErrorNonZeroAddress: null,
  SuiMoveVerificationError: null,
  MovePrimitiveRuntimeError: bcs.option(MoveLocation),
  MoveAbort: bcs.tuple([MoveLocation, bcs.u64()]),
  VMVerificationOrDeserializationError: null,
  VMInvariantViolation: null,
  FunctionNotFound: null,
  ArityMismatch: null,
  TypeArityMismatch: null,
  NonEntryFunctionInvoked: null,
  CommandArgumentError: bcs.struct("CommandArgumentError", {
    argIdx: bcs.u16(),
    kind: CommandArgumentError
  }),
  TypeArgumentError: bcs.struct("TypeArgumentError", {
    argumentIdx: bcs.u16(),
    kind: TypeArgumentError
  }),
  UnusedValueWithoutDrop: bcs.struct("UnusedValueWithoutDrop", {
    resultIdx: bcs.u16(),
    secondaryIdx: bcs.u16()
  }),
  InvalidPublicFunctionReturnType: bcs.struct("InvalidPublicFunctionReturnType", { idx: bcs.u16() }),
  InvalidTransferObject: null,
  EffectsTooLarge: bcs.struct("EffectsTooLarge", {
    currentSize: bcs.u64(),
    maxSize: bcs.u64()
  }),
  PublishUpgradeMissingDependency: null,
  PublishUpgradeDependencyDowngrade: null,
  PackageUpgradeError: bcs.struct("PackageUpgradeError", { upgradeError: PackageUpgradeError }),
  WrittenObjectsTooLarge: bcs.struct("WrittenObjectsTooLarge", {
    currentSize: bcs.u64(),
    maxSize: bcs.u64()
  }),
  CertificateDenied: null,
  SuiMoveVerificationTimedout: null,
  SharedObjectOperationNotAllowed: null,
  InputObjectDeleted: null,
  ExecutionCancelledDueToSharedObjectCongestion: bcs.struct("ExecutionCancelledDueToSharedObjectCongestion", { congested_objects: bcs.vector(Address) }),
  AddressDeniedForCoin: bcs.struct("AddressDeniedForCoin", {
    address: Address,
    coinType: bcs.string()
  }),
  CoinTypeGlobalPause: bcs.struct("CoinTypeGlobalPause", { coinType: bcs.string() }),
  ExecutionCancelledDueToRandomnessUnavailable: null,
  MoveVectorElemTooBig: bcs.struct("MoveVectorElemTooBig", {
    valueSize: bcs.u64(),
    maxScaledSize: bcs.u64()
  }),
  MoveRawValueTooBig: bcs.struct("MoveRawValueTooBig", {
    valueSize: bcs.u64(),
    maxScaledSize: bcs.u64()
  }),
  InvalidLinkage: null,
  InsufficientBalanceForWithdraw: null,
  NonExclusiveWriteInputObjectModified: bcs.struct("NonExclusiveWriteInputObjectModified", { id: Address })
});
var ExecutionStatus = bcs.enum("ExecutionStatus", {
  Success: null,
  Failure: bcs.struct("Failure", {
    error: ExecutionFailureStatus,
    command: bcs.option(bcs.u64())
  })
});
var GasCostSummary = bcs.struct("GasCostSummary", {
  computationCost: bcs.u64(),
  storageCost: bcs.u64(),
  storageRebate: bcs.u64(),
  nonRefundableStorageFee: bcs.u64()
});
var TransactionEffectsV1 = bcs.struct("TransactionEffectsV1", {
  status: ExecutionStatus,
  executedEpoch: bcs.u64(),
  gasUsed: GasCostSummary,
  modifiedAtVersions: bcs.vector(bcs.tuple([Address, bcs.u64()])),
  sharedObjects: bcs.vector(SuiObjectRef),
  transactionDigest: ObjectDigest,
  created: bcs.vector(bcs.tuple([SuiObjectRef, Owner])),
  mutated: bcs.vector(bcs.tuple([SuiObjectRef, Owner])),
  unwrapped: bcs.vector(bcs.tuple([SuiObjectRef, Owner])),
  deleted: bcs.vector(SuiObjectRef),
  unwrappedThenDeleted: bcs.vector(SuiObjectRef),
  wrapped: bcs.vector(SuiObjectRef),
  gasObject: bcs.tuple([SuiObjectRef, Owner]),
  eventsDigest: bcs.option(ObjectDigest),
  dependencies: bcs.vector(ObjectDigest)
});
var VersionDigest = bcs.tuple([bcs.u64(), ObjectDigest]);
var ObjectIn = bcs.enum("ObjectIn", {
  NotExist: null,
  Exist: bcs.tuple([VersionDigest, Owner])
});
var AccumulatorAddress = bcs.struct("AccumulatorAddress", {
  address: Address,
  ty: TypeTag
});
var AccumulatorOperation = bcs.enum("AccumulatorOperation", {
  Merge: null,
  Split: null
});
var AccumulatorValue = bcs.enum("AccumulatorValue", {
  Integer: bcs.u64(),
  IntegerTuple: bcs.tuple([bcs.u64(), bcs.u64()]),
  EventDigest: bcs.vector(bcs.tuple([bcs.u64(), ObjectDigest]))
});
var AccumulatorWriteV1 = bcs.struct("AccumulatorWriteV1", {
  address: AccumulatorAddress,
  operation: AccumulatorOperation,
  value: AccumulatorValue
});
var ObjectOut = bcs.enum("ObjectOut", {
  NotExist: null,
  ObjectWrite: bcs.tuple([ObjectDigest, Owner]),
  PackageWrite: VersionDigest,
  AccumulatorWriteV1
});
var IDOperation = bcs.enum("IDOperation", {
  None: null,
  Created: null,
  Deleted: null
});
var EffectsObjectChange = bcs.struct("EffectsObjectChange", {
  inputState: ObjectIn,
  outputState: ObjectOut,
  idOperation: IDOperation
});
var UnchangedConsensusKind = bcs.enum("UnchangedConsensusKind", {
  ReadOnlyRoot: VersionDigest,
  MutateConsensusStreamEnded: bcs.u64(),
  ReadConsensusStreamEnded: bcs.u64(),
  Cancelled: bcs.u64(),
  PerEpochConfig: null
});
var TransactionEffectsV2 = bcs.struct("TransactionEffectsV2", {
  status: ExecutionStatus,
  executedEpoch: bcs.u64(),
  gasUsed: GasCostSummary,
  transactionDigest: ObjectDigest,
  gasObjectIndex: bcs.option(bcs.u32()),
  eventsDigest: bcs.option(ObjectDigest),
  dependencies: bcs.vector(ObjectDigest),
  lamportVersion: bcs.u64(),
  changedObjects: bcs.vector(bcs.tuple([Address, EffectsObjectChange])),
  unchangedConsensusObjects: bcs.vector(bcs.tuple([Address, UnchangedConsensusKind])),
  auxDataDigest: bcs.option(ObjectDigest)
});
var TransactionEffects = bcs.enum("TransactionEffects", {
  V1: TransactionEffectsV1,
  V2: TransactionEffectsV2
});

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/bcs/pure.mjs
function pureBcsSchemaFromTypeName(name) {
  switch (name) {
    case "u8":
      return bcs.u8();
    case "u16":
      return bcs.u16();
    case "u32":
      return bcs.u32();
    case "u64":
      return bcs.u64();
    case "u128":
      return bcs.u128();
    case "u256":
      return bcs.u256();
    case "bool":
      return bcs.bool();
    case "string":
      return bcs.string();
    case "id":
    case "address":
      return Address;
  }
  const generic = name.match(/^(vector|option)<(.+)>$/);
  if (generic) {
    const [kind, inner] = generic.slice(1);
    if (kind === "vector") return bcs.vector(pureBcsSchemaFromTypeName(inner));
    else return bcs.option(pureBcsSchemaFromTypeName(inner));
  }
  throw new Error(`Invalid Pure type name: ${name}`);
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/bcs/index.mjs
var suiBcs = {
  ...bcs,
  U8: bcs.u8(),
  U16: bcs.u16(),
  U32: bcs.u32(),
  U64: bcs.u64(),
  U128: bcs.u128(),
  U256: bcs.u256(),
  ULEB128: bcs.uleb128(),
  Bool: bcs.bool(),
  String: bcs.string(),
  Address,
  AppId,
  Argument,
  CallArg,
  Command,
  CompressedSignature,
  Data,
  GasData,
  Intent,
  IntentMessage,
  IntentScope,
  IntentVersion,
  MoveObject,
  MoveObjectType,
  MovePackage,
  MultiSig,
  MultiSigPkMap,
  MultiSigPublicKey,
  Object: ObjectInner,
  ObjectArg,
  ObjectDigest,
  Owner,
  PasskeyAuthenticator,
  ProgrammableMoveCall,
  ProgrammableTransaction,
  PublicKey,
  SenderSignedData,
  SenderSignedTransaction,
  SharedObjectRef,
  StructTag,
  SuiObjectRef,
  TransactionData,
  TransactionDataV1,
  TransactionEffects,
  TransactionExpiration,
  TransactionKind,
  TypeOrigin,
  TypeTag,
  UpgradeInfo
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/utils/move-registry.mjs
var isValidNamedType = (type) => {
  const splitType = type.split(/::|<|>|,/);
  for (const t of splitType) if (t.includes(NAME_SEPARATOR) && !isValidNamedPackage(t)) return false;
  return isValidStructTag(type);
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/version.mjs
var PACKAGE_VERSION = "2.36.0";

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/client/mvr.mjs
var NAME_SEPARATOR2 = "/";
var MVR_API_HEADER = { "Mvr-Source": `@mysten/sui@${PACKAGE_VERSION}` };
var MvrClient = class {
  #cache;
  #url;
  #pageSize;
  #overrides;
  constructor({ cache, url, pageSize = 50, overrides }) {
    this.#cache = cache;
    this.#url = url;
    this.#pageSize = pageSize;
    this.#overrides = {
      packages: overrides?.packages,
      types: overrides?.types
    };
    validateOverrides(this.#overrides);
  }
  get #mvrPackageDataLoader() {
    return this.#cache.readSync(["#mvrPackageDataLoader", this.#url ?? ""], () => {
      const loader = new DataLoader(async (packages) => {
        if (!this.#url) throw new Error(`MVR Api URL is not set for the current client (resolving ${packages.join(", ")})`);
        const resolved = await this.#resolvePackages(packages);
        return packages.map((pkg) => resolved[pkg] ?? /* @__PURE__ */ new Error(`Failed to resolve package: ${pkg}`));
      });
      const overrides = this.#overrides?.packages;
      if (overrides) for (const [pkg, id] of Object.entries(overrides)) loader.prime(pkg, id);
      return loader;
    });
  }
  get #mvrTypeDataLoader() {
    return this.#cache.readSync(["#mvrTypeDataLoader", this.#url ?? ""], () => {
      const loader = new DataLoader(async (types) => {
        if (!this.#url) throw new Error(`MVR Api URL is not set for the current client (resolving ${types.join(", ")})`);
        const resolved = await this.#resolveTypes(types);
        return types.map((type) => resolved[type] ?? /* @__PURE__ */ new Error(`Failed to resolve type: ${type}`));
      });
      const overrides = this.#overrides?.types;
      if (overrides) for (const [type, id] of Object.entries(overrides)) loader.prime(type, id);
      return loader;
    });
  }
  async #resolvePackages(packages) {
    if (packages.length === 0) return {};
    const batches = chunk(packages, this.#pageSize);
    const results = {};
    await Promise.all(batches.map(async (batch) => {
      const data = await this.#fetch("/v1/resolution/bulk", { names: batch });
      if (!data?.resolution) return;
      for (const pkg of Object.keys(data?.resolution)) {
        const pkgData = data.resolution[pkg]?.package_id;
        if (!pkgData) continue;
        results[pkg] = pkgData;
      }
    }));
    return results;
  }
  async #resolveTypes(types) {
    if (types.length === 0) return {};
    const batches = chunk(types, this.#pageSize);
    const results = {};
    await Promise.all(batches.map(async (batch) => {
      const data = await this.#fetch("/v1/struct-definition/bulk", { types: batch });
      if (!data?.resolution) return;
      for (const type of Object.keys(data?.resolution)) {
        const typeData = data.resolution[type]?.type_tag;
        if (!typeData) continue;
        results[type] = typeData;
      }
    }));
    return results;
  }
  async #fetch(url, body) {
    if (!this.#url) throw new Error("MVR Api URL is not set for the current client");
    const response = await fetch(`${this.#url}${url}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...MVR_API_HEADER
      },
      body: JSON.stringify(body)
    });
    if (!response.ok) {
      const errorBody = await response.json().catch(() => ({}));
      throw new Error(`Failed to resolve types: ${errorBody?.message}`);
    }
    return response.json();
  }
  async resolvePackage({ package: name, signal }) {
    signal?.throwIfAborted();
    if (!hasMvrName(name)) return { package: name };
    return { package: await raceSignal(this.#mvrPackageDataLoader.load(name), signal) };
  }
  async resolveType({ type, signal }) {
    signal?.throwIfAborted();
    if (!hasMvrName(type)) return { type };
    const mvrTypes = [...extractMvrTypes(type)];
    const resolvedTypes = await raceSignal(this.#mvrTypeDataLoader.loadMany(mvrTypes), signal);
    const typeMap = {};
    for (let i = 0; i < mvrTypes.length; i++) {
      const resolvedType = resolvedTypes[i];
      if (resolvedType instanceof Error) throw resolvedType;
      typeMap[mvrTypes[i]] = resolvedType;
    }
    return { type: replaceMvrNames(type, typeMap) };
  }
  async resolve({ types = [], packages = [], signal }) {
    signal?.throwIfAborted();
    const mvrTypes = /* @__PURE__ */ new Set();
    for (const type of types ?? []) extractMvrTypes(type, mvrTypes);
    const typesArray = [...mvrTypes];
    const [resolvedTypes, resolvedPackages] = await raceSignal(Promise.all([typesArray.length > 0 ? this.#mvrTypeDataLoader.loadMany(typesArray) : [], packages.length > 0 ? this.#mvrPackageDataLoader.loadMany(packages) : []]), signal);
    const typeMap = { ...this.#overrides?.types };
    for (const [i, type] of typesArray.entries()) {
      const resolvedType = resolvedTypes[i];
      if (resolvedType instanceof Error) throw resolvedType;
      typeMap[type] = resolvedType;
    }
    const replacedTypes = {};
    for (const type of types ?? []) replacedTypes[type] = { type: replaceMvrNames(type, typeMap) };
    const replacedPackages = {};
    for (const [i, pkg] of (packages ?? []).entries()) {
      const resolvedPkg = this.#overrides?.packages?.[pkg] ?? resolvedPackages[i];
      if (resolvedPkg instanceof Error) throw resolvedPkg;
      replacedPackages[pkg] = { package: resolvedPkg };
    }
    return {
      types: replacedTypes,
      packages: replacedPackages
    };
  }
};
function validateOverrides(overrides) {
  if (overrides?.packages) for (const [pkg, id] of Object.entries(overrides.packages)) {
    if (!isValidNamedPackage(pkg)) throw new Error(`Invalid package name: ${pkg}`);
    if (!isValidSuiAddress(normalizeSuiAddress(id))) throw new Error(`Invalid package ID: ${id}`);
  }
  if (overrides?.types) for (const [type, val] of Object.entries(overrides.types)) {
    if (parseStructTag(type).typeParams.length > 0) throw new Error("Type overrides must be first-level only. If you want to supply generic types, just pass each type individually.");
    if (!isValidSuiAddress(parseStructTag(val).address)) throw new Error(`Invalid type: ${val}`);
  }
}
function extractMvrTypes(type, types = /* @__PURE__ */ new Set()) {
  if (typeof type === "string" && !hasMvrName(type)) return types;
  if (typeof type === "string" && type.startsWith("vector<") && type.endsWith(">")) return extractMvrTypes(type.slice(7, -1), types);
  const tag = isStructTag(type) ? type : parseStructTag(type);
  if (hasMvrName(tag.address)) types.add(`${tag.address}::${tag.module}::${tag.name}`);
  for (const param of tag.typeParams) extractMvrTypes(param, types);
  return types;
}
function replaceMvrNames(tag, typeCache) {
  if (typeof tag === "string" && !tag.includes("::")) return tag;
  if (typeof tag === "string" && tag.startsWith("vector<") && tag.endsWith(">")) return `vector<${replaceMvrNames(tag.slice(7, -1), typeCache)}>`;
  const type = isStructTag(tag) ? tag : parseStructTag(tag);
  const cacheHit = typeCache[`${type.address}::${type.module}::${type.name}`];
  return normalizeStructTag({
    ...type,
    address: cacheHit ? cacheHit.split("::")[0] : type.address,
    typeParams: type.typeParams.map((param) => replaceMvrNames(param, typeCache))
  });
}
function hasMvrName(nameOrType) {
  return nameOrType.includes(NAME_SEPARATOR2) || nameOrType.includes("@") || nameOrType.includes(".sui");
}
function raceSignal(promise, signal) {
  if (!signal) return promise;
  if (signal.aborted) return Promise.reject(signal.reason);
  return new Promise((resolve, reject) => {
    const onAbort = () => reject(signal.reason);
    signal.addEventListener("abort", onAbort, { once: true });
    promise.then(resolve, reject).finally(() => {
      signal.removeEventListener("abort", onAbort);
    });
  });
}
function isStructTag(type) {
  return typeof type === "object" && "address" in type && "module" in type && "name" in type && "typeParams" in type;
}
function findNamesInTransaction(builder) {
  const packages = /* @__PURE__ */ new Set();
  const types = /* @__PURE__ */ new Set();
  for (const command of builder.commands) switch (command.$kind) {
    case "MakeMoveVec":
      if (command.MakeMoveVec.type) getNamesFromTypeList([command.MakeMoveVec.type]).forEach((type) => {
        types.add(type);
      });
      break;
    case "MoveCall":
      const moveCall = command.MoveCall;
      const pkg = moveCall.package.split("::")[0];
      if (hasMvrName(pkg)) {
        if (!isValidNamedPackage(pkg)) throw new Error(`Invalid package name: ${pkg}`);
        packages.add(pkg);
      }
      getNamesFromTypeList(moveCall.typeArguments ?? []).forEach((type) => {
        types.add(type);
      });
      break;
    default:
      break;
  }
  return {
    packages: [...packages],
    types: [...types]
  };
}
function replaceNames(builder, resolved) {
  for (const command of builder.commands) {
    if (command.MakeMoveVec?.type) {
      if (!hasMvrName(command.MakeMoveVec.type)) continue;
      if (!resolved.types[command.MakeMoveVec.type]) throw new Error(`No resolution found for type: ${command.MakeMoveVec.type}`);
      command.MakeMoveVec.type = resolved.types[command.MakeMoveVec.type].type;
    }
    const tx = command.MoveCall;
    if (!tx) continue;
    const nameParts = tx.package.split("::");
    const name = nameParts[0];
    if (hasMvrName(name) && !resolved.packages[name]) throw new Error(`No address found for package: ${name}`);
    if (hasMvrName(name)) {
      nameParts[0] = resolved.packages[name].package;
      tx.package = nameParts.join("::");
    }
    const types = tx.typeArguments;
    if (!types) continue;
    for (let i = 0; i < types.length; i++) {
      if (!hasMvrName(types[i])) continue;
      if (!resolved.types[types[i]]) throw new Error(`No resolution found for type: ${types[i]}`);
      types[i] = resolved.types[types[i]].type;
    }
    tx.typeArguments = types;
  }
}
function getNamesFromTypeList(types) {
  const names = /* @__PURE__ */ new Set();
  for (const type of types) if (hasMvrName(type)) {
    if (!isValidNamedType(type)) throw new Error(`Invalid type with names: ${type}`);
    names.add(type);
  }
  return names;
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/client/cache.mjs
var ClientCache = class ClientCache2 {
  #prefix;
  #cache;
  constructor({ prefix, cache } = {}) {
    this.#prefix = prefix ?? [];
    this.#cache = cache ?? /* @__PURE__ */ new Map();
  }
  read(key, load) {
    const cacheKey = [this.#prefix, ...key].join(":");
    if (this.#cache.has(cacheKey)) return this.#cache.get(cacheKey);
    const result = load();
    this.#cache.set(cacheKey, result);
    if (typeof result === "object" && result !== null && "then" in result) return Promise.resolve(result).then((v) => {
      this.#cache.set(cacheKey, v);
      return v;
    }).catch((err) => {
      this.#cache.delete(cacheKey);
      throw err;
    });
    return result;
  }
  readSync(key, load) {
    const cacheKey = [this.#prefix, ...key].join(":");
    if (this.#cache.has(cacheKey)) return this.#cache.get(cacheKey);
    const result = load();
    this.#cache.set(cacheKey, result);
    return result;
  }
  clear(prefix) {
    const prefixKey = [...this.#prefix, ...prefix ?? []].join(":");
    if (!prefixKey) {
      this.#cache.clear();
      return;
    }
    for (const key of this.#cache.keys()) if (key.startsWith(prefixKey)) this.#cache.delete(key);
  }
  scope(prefix) {
    return new ClientCache2({
      prefix: [...this.#prefix, ...Array.isArray(prefix) ? prefix : [prefix]],
      cache: this.#cache
    });
  }
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/client/client.mjs
var BaseClient = class {
  constructor({ network, base, cache = base?.cache ?? new ClientCache() }) {
    this.network = network;
    this.base = base ?? this;
    this.cache = cache;
  }
  $extend(...registrations) {
    const extensions = Object.fromEntries(registrations.map((registration) => {
      return [registration.name, registration.register(this)];
    }));
    const methodCache = /* @__PURE__ */ new Map();
    return new Proxy(this, { get(target, prop, receiver) {
      if (typeof prop === "string" && prop in extensions) return extensions[prop];
      const value = Reflect.get(target, prop, receiver);
      if (typeof value === "function") {
        if (prop === "$extend") return value.bind(receiver);
        if (!methodCache.has(prop)) methodCache.set(prop, value.bind(target));
        return methodCache.get(prop);
      }
      return value;
    } });
  }
};

// dapp/node_modules/.pnpm/@noble+hashes@2.4.0/node_modules/@noble/hashes/utils.js
function isBytes2(a) {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in a && a.BYTES_PER_ELEMENT === 1;
}
var atitle = (title) => title ? `"${title}" ` : "";
function anumber(n, title = "") {
  if (typeof n !== "number")
    throw new TypeError(atitle(title) + "expected number, got " + typeof n);
  if (!Number.isSafeInteger(n) || n < 0)
    throw new RangeError(atitle(title) + "expected integer >= 0, got " + n);
  return n;
}
function abytes2(value, length, title = "") {
  if (isBytes2(value) && (length === void 0 || value.length === length))
    return value;
  if (length !== void 0)
    anumber(length, "length");
  const bytes = isBytes2(value);
  const ofLen = length !== void 0 ? ` of length ${length}` : "";
  const got = bytes ? `length=${value.length}` : `type=${typeof value}`;
  const message = atitle(title) + "expected Uint8Array" + ofLen + ", got " + got;
  if (!bytes)
    throw new TypeError(message);
  throw new RangeError(message);
}
function copyBytes(bytes) {
  return Uint8Array.from(abytes2(bytes));
}
var aobject = (value, label) => {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    throw new TypeError((label === "object" ? "" : `"${label}" `) + "expected object, got type=" + typeof value);
};
var aopts = (value, label) => {
  aobject(value, label);
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null)
    throw new TypeError(`"${label}" expected plain object`);
  if (Object.hasOwn(value, "__proto__"))
    throw new TypeError(`"${label}.__proto__" is not allowed`);
};
function aexists(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("hash was destroyed");
  if (checkFinished && instance.finished)
    throw new Error("digest() was already called");
}
function aoutput(out, instance) {
  abytes2(out, void 0, "output");
  const min = instance.outputLen;
  if (!(out.length >= min)) {
    throw new RangeError('"output" expected length >= ' + min);
  }
}
function u32(arr) {
  return new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
}
function clean(...arrays) {
  for (let i = 0; i < arrays.length; i++) {
    arrays[i].fill(0);
  }
}
var isLE = /* @__PURE__ */ (() => new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68)();
function byteSwap(word) {
  return word << 24 & 4278190080 | word << 8 & 16711680 | word >>> 8 & 65280 | word >>> 24 & 255;
}
var swap8IfBE = isLE ? (n) => n : (n) => byteSwap(n) >>> 0;
function byteSwap32(arr) {
  for (let i = 0; i < arr.length; i++) {
    arr[i] = byteSwap(arr[i]);
  }
  return arr;
}
var swap32IfBE = isLE ? (u) => u : byteSwap32;
function checkOpts(defaults, opts, title = "opts") {
  aopts(defaults, "defaults");
  if (opts !== void 0)
    aopts(opts, title);
  const merged = Object.assign(/* @__PURE__ */ Object.create(null), defaults, opts);
  return merged;
}
function createHasher(hashCons, info = {}) {
  if (typeof hashCons !== "function")
    throw new TypeError('"hashCons" expected function, got type=' + typeof hashCons);
  info = checkOpts({}, info, "info");
  const hashC = (msg, opts) => hashCons(opts).update(msg).digest();
  const tmp = hashCons(void 0);
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.canXOF = tmp.canXOF;
  hashC.create = (opts) => hashCons(opts);
  Object.assign(hashC, info);
  return Object.freeze(hashC);
}

// dapp/node_modules/.pnpm/@noble+hashes@2.4.0/node_modules/@noble/hashes/_blake.js
var BSIGMA = /* @__PURE__ */ Uint8Array.from([
  0,
  1,
  2,
  3,
  4,
  5,
  6,
  7,
  8,
  9,
  10,
  11,
  12,
  13,
  14,
  15,
  14,
  10,
  4,
  8,
  9,
  15,
  13,
  6,
  1,
  12,
  0,
  2,
  11,
  7,
  5,
  3,
  11,
  8,
  12,
  0,
  5,
  2,
  15,
  13,
  10,
  14,
  3,
  6,
  7,
  1,
  9,
  4,
  7,
  9,
  3,
  1,
  13,
  12,
  11,
  14,
  2,
  6,
  5,
  10,
  4,
  0,
  15,
  8,
  9,
  0,
  5,
  7,
  2,
  4,
  10,
  15,
  14,
  1,
  11,
  12,
  6,
  8,
  3,
  13,
  2,
  12,
  6,
  10,
  0,
  11,
  8,
  3,
  4,
  13,
  7,
  5,
  15,
  14,
  1,
  9,
  12,
  5,
  1,
  15,
  14,
  13,
  4,
  10,
  0,
  7,
  6,
  3,
  9,
  2,
  8,
  11,
  13,
  11,
  7,
  14,
  12,
  1,
  3,
  9,
  5,
  0,
  15,
  4,
  8,
  6,
  2,
  10,
  6,
  15,
  14,
  9,
  11,
  3,
  0,
  8,
  12,
  2,
  13,
  7,
  1,
  4,
  10,
  5,
  10,
  2,
  8,
  4,
  7,
  6,
  1,
  5,
  15,
  11,
  9,
  14,
  3,
  12,
  13,
  0,
  0,
  1,
  2,
  3,
  4,
  5,
  6,
  7,
  8,
  9,
  10,
  11,
  12,
  13,
  14,
  15,
  14,
  10,
  4,
  8,
  9,
  15,
  13,
  6,
  1,
  12,
  0,
  2,
  11,
  7,
  5,
  3,
  // Blake1, unused in others
  11,
  8,
  12,
  0,
  5,
  2,
  15,
  13,
  10,
  14,
  3,
  6,
  7,
  1,
  9,
  4,
  7,
  9,
  3,
  1,
  13,
  12,
  11,
  14,
  2,
  6,
  5,
  10,
  4,
  0,
  15,
  8,
  9,
  0,
  5,
  7,
  2,
  4,
  10,
  15,
  14,
  1,
  11,
  12,
  6,
  8,
  3,
  13,
  2,
  12,
  6,
  10,
  0,
  11,
  8,
  3,
  4,
  13,
  7,
  5,
  15,
  14,
  1,
  9
]);

// dapp/node_modules/.pnpm/@noble+hashes@2.4.0/node_modules/@noble/hashes/_u64.js
var fromNumH = (n) => n / 2 ** 32 | 0;
var fromNumL = (n) => n >>> 0;
var rotrSH = (h, l, s) => h >>> s | l << 32 - s;
var rotrSL = (h, l, s) => h << 32 - s | l >>> s;
var rotrBH = (h, l, s) => h << 64 - s | l >>> s - 32;
var rotrBL = (h, l, s) => h >>> s - 32 | l << 64 - s;
var rotr32H = (_h, l) => l;
var rotr32L = (h, _l) => h;
function add(Ah, Al, Bh, Bl) {
  const l = (Al >>> 0) + (Bl >>> 0);
  return { h: Ah + Bh + (l / 2 ** 32 | 0) | 0, l: l | 0 };
}
var add3L = (Al, Bl, Cl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0);
var add3H = (low, Ah, Bh, Ch) => Ah + Bh + Ch + (low / 2 ** 32 | 0) | 0;

// dapp/node_modules/.pnpm/@noble+hashes@2.4.0/node_modules/@noble/hashes/blake2.js
var B2B_IV = /* @__PURE__ */ Uint32Array.from([
  4089235720,
  1779033703,
  2227873595,
  3144134277,
  4271175723,
  1013904242,
  1595750129,
  2773480762,
  2917565137,
  1359893119,
  725511199,
  2600822924,
  4215389547,
  528734635,
  327033209,
  1541459225
]);
var BBUF = /* @__PURE__ */ new Uint32Array(32);
function G1b(a, b, c, d, msg, x) {
  const Xl = msg[x], Xh = msg[x + 1];
  let Al = BBUF[2 * a], Ah = BBUF[2 * a + 1];
  let Bl = BBUF[2 * b], Bh = BBUF[2 * b + 1];
  let Cl = BBUF[2 * c], Ch = BBUF[2 * c + 1];
  let Dl = BBUF[2 * d], Dh = BBUF[2 * d + 1];
  const ll = add3L(Al, Bl, Xl);
  Ah = add3H(ll, Ah, Bh, Xh);
  Al = ll | 0;
  let xh = Dh ^ Ah, xl = Dl ^ Al;
  Dh = rotr32H(xh, xl);
  Dl = rotr32L(xh, xl);
  ({ h: Ch, l: Cl } = add(Ch, Cl, Dh, Dl));
  xh = Bh ^ Ch;
  xl = Bl ^ Cl;
  Bh = rotrSH(xh, xl, 24);
  Bl = rotrSL(xh, xl, 24);
  BBUF[2 * a] = Al;
  BBUF[2 * a + 1] = Ah;
  BBUF[2 * b] = Bl;
  BBUF[2 * b + 1] = Bh;
  BBUF[2 * c] = Cl;
  BBUF[2 * c + 1] = Ch;
  BBUF[2 * d] = Dl;
  BBUF[2 * d + 1] = Dh;
}
function G2b(a, b, c, d, msg, x) {
  const Xl = msg[x], Xh = msg[x + 1];
  let Al = BBUF[2 * a], Ah = BBUF[2 * a + 1];
  let Bl = BBUF[2 * b], Bh = BBUF[2 * b + 1];
  let Cl = BBUF[2 * c], Ch = BBUF[2 * c + 1];
  let Dl = BBUF[2 * d], Dh = BBUF[2 * d + 1];
  const ll = add3L(Al, Bl, Xl);
  Ah = add3H(ll, Ah, Bh, Xh);
  Al = ll | 0;
  let xh = Dh ^ Ah, xl = Dl ^ Al;
  Dh = rotrSH(xh, xl, 16);
  Dl = rotrSL(xh, xl, 16);
  ({ h: Ch, l: Cl } = add(Ch, Cl, Dh, Dl));
  xh = Bh ^ Ch;
  xl = Bl ^ Cl;
  Bh = rotrBH(xh, xl, 63);
  Bl = rotrBL(xh, xl, 63);
  BBUF[2 * a] = Al;
  BBUF[2 * a + 1] = Ah;
  BBUF[2 * b] = Bl;
  BBUF[2 * b + 1] = Bh;
  BBUF[2 * c] = Cl;
  BBUF[2 * c + 1] = Ch;
  BBUF[2 * d] = Dl;
  BBUF[2 * d + 1] = Dh;
}
function checkBlake2Opts(outputLen, opts = {}, keyLen, saltLen, persLen) {
  anumber(keyLen);
  if (outputLen <= 0 || outputLen > keyLen)
    throw new Error('"dkLen" must be 1..' + keyLen + ", got " + outputLen);
  const { key, salt, personalization } = opts;
  if (key !== void 0 && (key.length < 1 || key.length > keyLen))
    throw new Error('"key" expected to be undefined or of length=1..' + keyLen);
  if (salt !== void 0)
    abytes2(salt, saltLen, "salt");
  if (personalization !== void 0)
    abytes2(personalization, persLen, "personalization");
}
var _BLAKE2 = class {
  buffer;
  buffer32;
  finished = false;
  destroyed = false;
  length = 0;
  pos = 0;
  blockLen;
  outputLen;
  canXOF = false;
  constructor(blockLen, outputLen) {
    anumber(blockLen);
    anumber(outputLen);
    this.blockLen = blockLen;
    this.outputLen = outputLen;
    this.buffer = new Uint8Array(blockLen);
    this.buffer32 = u32(this.buffer);
  }
  update(data) {
    aexists(this);
    abytes2(data);
    const { blockLen, buffer, buffer32 } = this;
    const len = data.length;
    const offset = data.byteOffset;
    const buf = data.buffer;
    for (let pos = 0; pos < len; ) {
      if (this.pos === blockLen) {
        swap32IfBE(buffer32);
        this.compress(buffer32, 0, false);
        swap32IfBE(buffer32);
        this.pos = 0;
      }
      const take = Math.min(blockLen - this.pos, len - pos);
      const dataOffset = offset + pos;
      if (take === blockLen && !(dataOffset % 4) && pos + take < len) {
        const data32 = new Uint32Array(buf, dataOffset, Math.floor((len - pos) / 4));
        swap32IfBE(data32);
        for (let pos32 = 0; pos + blockLen < len; pos32 += buffer32.length, pos += blockLen) {
          this.length += blockLen;
          this.compress(data32, pos32, false);
        }
        swap32IfBE(data32);
        continue;
      }
      buffer.set(pos === 0 && take === len ? data : data.subarray(pos, pos + take), this.pos);
      this.pos += take;
      this.length += take;
      pos += take;
    }
    return this;
  }
  digestInto(out) {
    aexists(this);
    aoutput(out, this);
    if (out.byteOffset & 3)
      throw new RangeError('"output" expected 4-byte aligned byteOffset, got ' + out.byteOffset);
    const { pos, buffer32 } = this;
    this.finished = true;
    this.buffer.fill(0, pos);
    swap32IfBE(buffer32);
    this.compress(buffer32, 0, true);
    swap32IfBE(buffer32);
    const state = this.get();
    const out32 = out === this.buffer ? buffer32 : u32(out);
    const full = Math.floor(this.outputLen / 4);
    for (let i = 0; i < full; i++)
      out32[i] = swap8IfBE(state[i]);
    const tail = this.outputLen % 4;
    if (!tail)
      return;
    const off = full * 4;
    const word = state[full];
    for (let i = 0; i < tail; i++)
      out[off + i] = word >>> 8 * i;
  }
  digest() {
    const { buffer, outputLen } = this;
    this.digestInto(buffer);
    const res = buffer.slice(0, outputLen);
    this.destroy();
    return res;
  }
  _cloneInto(to) {
    const { buffer, length, finished, destroyed, outputLen, pos } = this;
    to ||= new this.constructor({ dkLen: outputLen });
    to.set(...this.get());
    to.buffer.set(buffer);
    to.destroyed = destroyed;
    to.finished = finished;
    to.length = length;
    to.pos = pos;
    to.outputLen = outputLen;
    return to;
  }
  clone() {
    return this._cloneInto();
  }
};
var _BLAKE2b = class extends _BLAKE2 {
  // Same IV words as SHA-512 / BLAKE2b, encoded as LE u32 low/high halves.
  v0l = B2B_IV[0] | 0;
  v0h = B2B_IV[1] | 0;
  v1l = B2B_IV[2] | 0;
  v1h = B2B_IV[3] | 0;
  v2l = B2B_IV[4] | 0;
  v2h = B2B_IV[5] | 0;
  v3l = B2B_IV[6] | 0;
  v3h = B2B_IV[7] | 0;
  v4l = B2B_IV[8] | 0;
  v4h = B2B_IV[9] | 0;
  v5l = B2B_IV[10] | 0;
  v5h = B2B_IV[11] | 0;
  v6l = B2B_IV[12] | 0;
  v6h = B2B_IV[13] | 0;
  v7l = B2B_IV[14] | 0;
  v7h = B2B_IV[15] | 0;
  constructor(opts = {}) {
    opts = checkOpts({}, opts);
    const olen = opts.dkLen === void 0 ? 64 : opts.dkLen;
    super(128, olen);
    checkBlake2Opts(olen, opts, 64, 16, 16);
    let { key, personalization, salt } = opts;
    let keyLength = 0;
    if (key !== void 0) {
      abytes2(key, void 0, "key");
      keyLength = key.length;
    }
    this.v0l ^= this.outputLen | keyLength << 8 | 1 << 16 | 1 << 24;
    if (salt !== void 0) {
      abytes2(salt, void 0, "salt");
      const slt = u32(copyBytes(salt));
      this.v4l ^= swap8IfBE(slt[0]);
      this.v4h ^= swap8IfBE(slt[1]);
      this.v5l ^= swap8IfBE(slt[2]);
      this.v5h ^= swap8IfBE(slt[3]);
    }
    if (personalization !== void 0) {
      abytes2(personalization, void 0, "personalization");
      const pers = u32(copyBytes(personalization));
      this.v6l ^= swap8IfBE(pers[0]);
      this.v6h ^= swap8IfBE(pers[1]);
      this.v7l ^= swap8IfBE(pers[2]);
      this.v7h ^= swap8IfBE(pers[3]);
    }
    if (key !== void 0) {
      const tmp = new Uint8Array(this.blockLen);
      tmp.set(key);
      this.update(tmp);
      clean(tmp);
    }
  }
  // prettier-ignore
  get() {
    let { v0l, v0h, v1l, v1h, v2l, v2h, v3l, v3h, v4l, v4h, v5l, v5h, v6l, v6h, v7l, v7h } = this;
    return [v0l, v0h, v1l, v1h, v2l, v2h, v3l, v3h, v4l, v4h, v5l, v5h, v6l, v6h, v7l, v7h];
  }
  // prettier-ignore
  set(v0l, v0h, v1l, v1h, v2l, v2h, v3l, v3h, v4l, v4h, v5l, v5h, v6l, v6h, v7l, v7h) {
    this.v0l = v0l | 0;
    this.v0h = v0h | 0;
    this.v1l = v1l | 0;
    this.v1h = v1h | 0;
    this.v2l = v2l | 0;
    this.v2h = v2h | 0;
    this.v3l = v3l | 0;
    this.v3h = v3h | 0;
    this.v4l = v4l | 0;
    this.v4h = v4h | 0;
    this.v5l = v5l | 0;
    this.v5h = v5h | 0;
    this.v6l = v6l | 0;
    this.v6h = v6h | 0;
    this.v7l = v7l | 0;
    this.v7h = v7h | 0;
  }
  compress(msg, offset, isLast) {
    const { v0l, v0h, v1l, v1h, v2l, v2h, v3l, v3h, v4l, v4h, v5l, v5h, v6l, v6h, v7l, v7h } = this;
    {
      BBUF[0] = v0l;
      BBUF[1] = v0h;
      BBUF[2] = v1l;
      BBUF[3] = v1h;
      BBUF[4] = v2l;
      BBUF[5] = v2h;
      BBUF[6] = v3l;
      BBUF[7] = v3h;
      BBUF[8] = v4l;
      BBUF[9] = v4h;
      BBUF[10] = v5l;
      BBUF[11] = v5h;
      BBUF[12] = v6l;
      BBUF[13] = v6h;
      BBUF[14] = v7l;
      BBUF[15] = v7h;
    }
    BBUF.set(B2B_IV, 16);
    const l = fromNumL(this.length);
    const h = fromNumH(this.length);
    BBUF[24] = B2B_IV[8] ^ l;
    BBUF[25] = B2B_IV[9] ^ h;
    if (isLast) {
      BBUF[28] = ~BBUF[28];
      BBUF[29] = ~BBUF[29];
    }
    let j = 0;
    const s = BSIGMA;
    for (let i = 0; i < 12; i++) {
      G1b(0, 4, 8, 12, msg, offset + 2 * s[j++]);
      G2b(0, 4, 8, 12, msg, offset + 2 * s[j++]);
      G1b(1, 5, 9, 13, msg, offset + 2 * s[j++]);
      G2b(1, 5, 9, 13, msg, offset + 2 * s[j++]);
      G1b(2, 6, 10, 14, msg, offset + 2 * s[j++]);
      G2b(2, 6, 10, 14, msg, offset + 2 * s[j++]);
      G1b(3, 7, 11, 15, msg, offset + 2 * s[j++]);
      G2b(3, 7, 11, 15, msg, offset + 2 * s[j++]);
      G1b(0, 5, 10, 15, msg, offset + 2 * s[j++]);
      G2b(0, 5, 10, 15, msg, offset + 2 * s[j++]);
      G1b(1, 6, 11, 12, msg, offset + 2 * s[j++]);
      G2b(1, 6, 11, 12, msg, offset + 2 * s[j++]);
      G1b(2, 7, 8, 13, msg, offset + 2 * s[j++]);
      G2b(2, 7, 8, 13, msg, offset + 2 * s[j++]);
      G1b(3, 4, 9, 14, msg, offset + 2 * s[j++]);
      G2b(3, 4, 9, 14, msg, offset + 2 * s[j++]);
    }
    this.v0l ^= BBUF[0] ^ BBUF[16];
    this.v0h ^= BBUF[1] ^ BBUF[17];
    this.v1l ^= BBUF[2] ^ BBUF[18];
    this.v1h ^= BBUF[3] ^ BBUF[19];
    this.v2l ^= BBUF[4] ^ BBUF[20];
    this.v2h ^= BBUF[5] ^ BBUF[21];
    this.v3l ^= BBUF[6] ^ BBUF[22];
    this.v3h ^= BBUF[7] ^ BBUF[23];
    this.v4l ^= BBUF[8] ^ BBUF[24];
    this.v4h ^= BBUF[9] ^ BBUF[25];
    this.v5l ^= BBUF[10] ^ BBUF[26];
    this.v5h ^= BBUF[11] ^ BBUF[27];
    this.v6l ^= BBUF[12] ^ BBUF[28];
    this.v6h ^= BBUF[13] ^ BBUF[29];
    this.v7l ^= BBUF[14] ^ BBUF[30];
    this.v7h ^= BBUF[15] ^ BBUF[31];
    clean(BBUF);
  }
  destroy() {
    this.destroyed = true;
    clean(this.buffer32);
    this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
  }
};
var blake2b = /* @__PURE__ */ createHasher((opts) => new _BLAKE2b(opts));

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/utils/dynamic-fields.mjs
function deriveDynamicFieldID(parentId, typeTag, key) {
  const address = suiBcs.Address.serialize(parentId).toBytes();
  const tag = suiBcs.TypeTag.serialize(typeTag).toBytes();
  const keyLength = suiBcs.u64().serialize(key.length).toBytes();
  const hash = blake2b.create({ dkLen: 32 });
  hash.update(new Uint8Array([240]));
  hash.update(address);
  hash.update(keyLength);
  hash.update(key);
  hash.update(tag);
  return `0x${toHex(hash.digest().slice(0, 32))}`;
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/client/core.mjs
var DEFAULT_MVR_URLS = {
  mainnet: "https://mainnet.mvr.mystenlabs.com",
  testnet: "https://testnet.mvr.mystenlabs.com"
};
var CoreClient = class extends BaseClient {
  constructor(options) {
    super(options);
    this.core = this;
    this.mvr = new MvrClient({
      cache: this.cache.scope("core.mvr"),
      url: options.mvr?.url ?? DEFAULT_MVR_URLS[this.network],
      pageSize: options.mvr?.pageSize,
      overrides: options.mvr?.overrides
    });
  }
  async getObject(options) {
    const { objectId } = options;
    const { objects: [result] } = await this.getObjects({
      objectIds: [objectId],
      signal: options.signal,
      include: options.include
    });
    if (result instanceof Error) throw result;
    return { object: result };
  }
  async getDynamicField(options) {
    const normalizedNameType = TypeTagSerializer.parseFromStr((await this.core.mvr.resolveType({
      type: options.name.type,
      signal: options.signal
    })).type);
    const fieldId = deriveDynamicFieldID(options.parentId, normalizedNameType, options.name.bcs);
    const { objects: [fieldObject] } = await this.getObjects({
      objectIds: [fieldId],
      signal: options.signal,
      include: {
        previousTransaction: true,
        content: true
      }
    });
    if (fieldObject instanceof Error) throw fieldObject;
    const fieldType = parseStructTag(fieldObject.type);
    const content = await fieldObject.content;
    const nameTypeParam = fieldType.typeParams[0];
    const isDynamicObject = typeof nameTypeParam !== "string" && nameTypeParam.module === "dynamic_object_field" && nameTypeParam.name === "Wrapper";
    const valueBcs = content.slice(SUI_ADDRESS_LENGTH + options.name.bcs.length);
    const valueType = typeof fieldType.typeParams[1] === "string" ? fieldType.typeParams[1] : normalizeStructTag(fieldType.typeParams[1]);
    return { dynamicField: {
      $kind: isDynamicObject ? "DynamicObject" : "DynamicField",
      fieldId: fieldObject.objectId,
      digest: fieldObject.digest,
      version: fieldObject.version,
      type: fieldObject.type,
      previousTransaction: fieldObject.previousTransaction,
      name: {
        type: typeof nameTypeParam === "string" ? nameTypeParam : normalizeStructTag(nameTypeParam),
        bcs: options.name.bcs
      },
      value: {
        type: valueType,
        bcs: valueBcs
      },
      childId: isDynamicObject ? suiBcs.Address.parse(valueBcs) : void 0
    } };
  }
  async getDynamicObjectField(options) {
    const wrappedType = `0x2::dynamic_object_field::Wrapper<${(await this.core.mvr.resolveType({
      type: options.name.type,
      signal: options.signal
    })).type}>`;
    const { dynamicField } = await this.getDynamicField({
      parentId: options.parentId,
      name: {
        type: wrappedType,
        bcs: options.name.bcs
      },
      signal: options.signal
    });
    const { object: object2 } = await this.getObject({
      objectId: dynamicField.childId,
      signal: options.signal,
      include: options.include
    });
    return { object: object2 };
  }
  async waitForTransaction(options) {
    const { signal, timeout = 60 * 1e3, pollSchedule, include } = options;
    const digest2 = "result" in options && options.result ? (options.result.Transaction ?? options.result.FailedTransaction).digest : options.digest;
    const abortSignal = signal ? AbortSignal.any([AbortSignal.timeout(timeout), signal]) : AbortSignal.timeout(timeout);
    const abortPromise = new Promise((_, reject) => {
      abortSignal.addEventListener("abort", () => reject(abortSignal.reason));
    });
    abortPromise.catch(() => {
    });
    const schedule = pollSchedule ?? [
      0,
      300,
      600,
      1500,
      3500
    ];
    const t0 = Date.now();
    let scheduleIndex = 0;
    const lastInterval = schedule.length > 0 ? schedule[schedule.length - 1] - (schedule[schedule.length - 2] ?? 0) : 2e3;
    while (true) {
      if (scheduleIndex < schedule.length) {
        const remaining = t0 + schedule[scheduleIndex] - Date.now();
        scheduleIndex++;
        if (remaining > 0) await Promise.race([new Promise((resolve) => setTimeout(resolve, remaining)), abortPromise]);
      } else await Promise.race([new Promise((resolve) => setTimeout(resolve, lastInterval)), abortPromise]);
      abortSignal.throwIfAborted();
      try {
        return await this.getTransaction({
          digest: digest2,
          include,
          signal: abortSignal
        });
      } catch {
      }
    }
  }
  async signAndExecuteTransaction({ transaction, signer, additionalSignatures = [], ...input }) {
    let transactionBytes;
    if (transaction instanceof Uint8Array) transactionBytes = transaction;
    else {
      transaction.setSenderIfNotSet(signer.toSuiAddress());
      transactionBytes = await transaction.build({ client: this });
    }
    const { signature } = await signer.signTransaction(transactionBytes);
    return this.executeTransaction({
      transaction: transactionBytes,
      signatures: [signature, ...additionalSignatures],
      ...input
    });
  }
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/utils/constants.mjs
var MIST_PER_SUI = BigInt(1e9);
var MOVE_STDLIB_ADDRESS = "0x0000000000000000000000000000000000000000000000000000000000000001";
var SUI_FRAMEWORK_ADDRESS = "0x0000000000000000000000000000000000000000000000000000000000000002";
var SUI_CLOCK_OBJECT_ID = "0x0000000000000000000000000000000000000000000000000000000000000006";
var SUI_TYPE_ARG = `${SUI_FRAMEWORK_ADDRESS}::sui::SUI`;
var SUI_SYSTEM_STATE_OBJECT_ID = "0x0000000000000000000000000000000000000000000000000000000000000005";
var SUI_RANDOM_OBJECT_ID = "0x0000000000000000000000000000000000000000000000000000000000000008";
var SUI_DENY_LIST_OBJECT_ID = "0x0000000000000000000000000000000000000000000000000000000000000403";
var MOCKED_GAS_OBJECT_ID = "0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff";

// dapp/node_modules/.pnpm/valibot@1.5.0_typescript@5.9.3/node_modules/valibot/dist/index.mjs
var store$4;
var DEFAULT_CONFIG = {
  lang: void 0,
  message: void 0,
  abortEarly: void 0,
  abortPipeEarly: void 0
};
// @__NO_SIDE_EFFECTS__
function getGlobalConfig(config$1) {
  if (!config$1 && !store$4) return DEFAULT_CONFIG;
  return {
    lang: config$1?.lang ?? store$4?.lang,
    message: config$1?.message,
    abortEarly: config$1?.abortEarly ?? store$4?.abortEarly,
    abortPipeEarly: config$1?.abortPipeEarly ?? store$4?.abortPipeEarly
  };
}
var store$3;
// @__NO_SIDE_EFFECTS__
function getGlobalMessage(lang) {
  return store$3?.get(lang);
}
var store$2;
// @__NO_SIDE_EFFECTS__
function getSchemaMessage(lang) {
  return store$2?.get(lang);
}
var store$1;
// @__NO_SIDE_EFFECTS__
function getSpecificMessage(reference, lang) {
  return store$1?.get(reference)?.get(lang);
}
// @__NO_SIDE_EFFECTS__
function _stringify(input) {
  const type = typeof input;
  if (type === "string") return `"${input}"`;
  if (type === "number" || type === "bigint" || type === "boolean") return `${input}`;
  if (type === "object" || type === "function") return (input && Object.getPrototypeOf(input)?.constructor?.name) ?? "null";
  return type;
}
function _addIssue(context, label, dataset, config$1, other) {
  const input = other && "input" in other ? other.input : dataset.value;
  const expected = other?.expected ?? context.expects ?? null;
  const received = other?.received ?? /* @__PURE__ */ _stringify(input);
  const issue = {
    kind: context.kind,
    type: context.type,
    input,
    expected,
    received,
    message: `Invalid ${label}: ${expected ? `Expected ${expected} but r` : "R"}eceived ${received}`,
    requirement: context.requirement,
    path: other?.path,
    issues: other?.issues,
    lang: config$1.lang,
    abortEarly: config$1.abortEarly,
    abortPipeEarly: config$1.abortPipeEarly
  };
  const isSchema = context.kind === "schema";
  const message$1 = other?.message ?? context.message ?? /* @__PURE__ */ getSpecificMessage(context.reference, issue.lang) ?? (isSchema ? /* @__PURE__ */ getSchemaMessage(issue.lang) : null) ?? config$1.message ?? /* @__PURE__ */ getGlobalMessage(issue.lang);
  if (message$1 !== void 0) issue.message = typeof message$1 === "function" ? message$1(issue) : message$1;
  if (isSchema) dataset.typed = false;
  if (dataset.issues) dataset.issues.push(issue);
  else dataset.issues = [issue];
}
// @__NO_SIDE_EFFECTS__
function _isSameValueZero(value1, value2) {
  return value1 === value2 || Number.isNaN(value1) && Number.isNaN(value2);
}
// @__NO_SIDE_EFFECTS__
function _isValidObjectKey(object$1, key) {
  return Object.prototype.hasOwnProperty.call(object$1, key) && key !== "__proto__" && key !== "prototype" && key !== "constructor";
}
// @__NO_SIDE_EFFECTS__
function _joinExpects(values$1, separator) {
  const list = [...new Set(values$1)];
  if (list.length > 1) return `(${list.join(` ${separator} `)})`;
  return list[0] ?? "never";
}
function _standardSchema(schema) {
  schema["~standard"] = {
    version: 1,
    vendor: "valibot",
    validate: (value$1) => schema["~run"]({ value: value$1 }, /* @__PURE__ */ getGlobalConfig())
  };
  return schema;
}
var ValiError = class extends Error {
  /**
  * Creates a Valibot error with useful information.
  *
  * @param issues The error issues.
  */
  constructor(issues) {
    super(issues[0].message);
    this.name = "ValiError";
    this.issues = issues;
  }
};
var EMOJI_REGEX = new RegExp("^(?:[\\u{1F1E6}-\\u{1F1FF}]{2}|\\u{1F3F4}[\\u{E0061}-\\u{E007A}]{2}[\\u{E0030}-\\u{E0039}\\u{E0061}-\\u{E007A}]{1,3}\\u{E007F}|(?:\\p{Emoji}\\uFE0F\\u20E3?|\\p{Emoji_Modifier_Base}\\p{Emoji_Modifier}?|(?![\\p{Emoji_Modifier_Base}\\u{1F1E6}-\\u{1F1FF}])\\p{Emoji_Presentation})(?:\\u200D(?:\\p{Emoji}\\uFE0F\\u20E3?|\\p{Emoji_Modifier_Base}\\p{Emoji_Modifier}?|(?![\\p{Emoji_Modifier_Base}\\u{1F1E6}-\\u{1F1FF}])\\p{Emoji_Presentation}))*)+$", "u");
// @__NO_SIDE_EFFECTS__
function check(requirement, message$1) {
  return {
    kind: "validation",
    type: "check",
    reference: check,
    async: false,
    expects: null,
    requirement,
    message: message$1,
    "~run"(dataset, config$1) {
      if (dataset.typed && !this.requirement(dataset.value)) _addIssue(this, "input", dataset, config$1);
      return dataset;
    }
  };
}
// @__NO_SIDE_EFFECTS__
function integer(message$1) {
  return {
    kind: "validation",
    type: "integer",
    reference: integer,
    async: false,
    expects: null,
    requirement: Number.isInteger,
    message: message$1,
    "~run"(dataset, config$1) {
      if (dataset.typed && !this.requirement(dataset.value)) _addIssue(this, "integer", dataset, config$1);
      return dataset;
    }
  };
}
// @__NO_SIDE_EFFECTS__
function transform(operation) {
  return {
    kind: "transformation",
    type: "transform",
    reference: transform,
    async: false,
    operation,
    "~run"(dataset) {
      dataset.value = this.operation(dataset.value);
      return dataset;
    }
  };
}
var ABORT_EARLY_CONFIG = { abortEarly: true };
// @__NO_SIDE_EFFECTS__
function getFallback(schema, dataset, config$1) {
  return typeof schema.fallback === "function" ? schema.fallback(dataset, config$1) : schema.fallback;
}
// @__NO_SIDE_EFFECTS__
function getDefault(schema, dataset, config$1) {
  return typeof schema.default === "function" ? schema.default(dataset, config$1) : schema.default;
}
// @__NO_SIDE_EFFECTS__
function is(schema, input) {
  return !schema["~run"]({ value: input }, ABORT_EARLY_CONFIG).issues;
}
// @__NO_SIDE_EFFECTS__
function array(item, message$1) {
  return _standardSchema({
    kind: "schema",
    type: "array",
    reference: array,
    expects: "Array",
    async: false,
    item,
    message: message$1,
    "~run"(dataset, config$1) {
      const input = dataset.value;
      if (Array.isArray(input)) {
        dataset.typed = true;
        dataset.value = [];
        for (let key = 0; key < input.length; key++) {
          const value$1 = input[key];
          const itemDataset = this.item["~run"]({ value: value$1 }, config$1);
          if (itemDataset.issues) {
            const pathItem = {
              type: "array",
              origin: "value",
              input,
              key,
              value: value$1
            };
            for (const issue of itemDataset.issues) {
              if (issue.path) issue.path.unshift(pathItem);
              else issue.path = [pathItem];
              dataset.issues?.push(issue);
            }
            if (!dataset.issues) dataset.issues = itemDataset.issues;
            if (config$1.abortEarly) {
              dataset.typed = false;
              break;
            }
          }
          if (!itemDataset.typed) dataset.typed = false;
          dataset.value.push(itemDataset.value);
        }
      } else _addIssue(this, "type", dataset, config$1);
      return dataset;
    }
  });
}
// @__NO_SIDE_EFFECTS__
function bigint(message$1) {
  return _standardSchema({
    kind: "schema",
    type: "bigint",
    reference: bigint,
    expects: "bigint",
    async: false,
    message: message$1,
    "~run"(dataset, config$1) {
      if (typeof dataset.value === "bigint") dataset.typed = true;
      else _addIssue(this, "type", dataset, config$1);
      return dataset;
    }
  });
}
// @__NO_SIDE_EFFECTS__
function boolean(message$1) {
  return _standardSchema({
    kind: "schema",
    type: "boolean",
    reference: boolean,
    expects: "boolean",
    async: false,
    message: message$1,
    "~run"(dataset, config$1) {
      if (typeof dataset.value === "boolean") dataset.typed = true;
      else _addIssue(this, "type", dataset, config$1);
      return dataset;
    }
  });
}
// @__NO_SIDE_EFFECTS__
function lazy(getter) {
  return _standardSchema({
    kind: "schema",
    type: "lazy",
    reference: lazy,
    expects: "unknown",
    async: false,
    getter,
    "~run"(dataset, config$1) {
      return this.getter(dataset.value)["~run"](dataset, config$1);
    }
  });
}
// @__NO_SIDE_EFFECTS__
function literal(literal_, message$1) {
  return _standardSchema({
    kind: "schema",
    type: "literal",
    reference: literal,
    expects: /* @__PURE__ */ _stringify(literal_),
    async: false,
    literal: literal_,
    message: message$1,
    "~run"(dataset, config$1) {
      if (/* @__PURE__ */ _isSameValueZero(dataset.value, this.literal)) dataset.typed = true;
      else _addIssue(this, "type", dataset, config$1);
      return dataset;
    }
  });
}
// @__NO_SIDE_EFFECTS__
function nullable(wrapped, default_) {
  return _standardSchema({
    kind: "schema",
    type: "nullable",
    reference: nullable,
    expects: `(${wrapped.expects} | null)`,
    async: false,
    wrapped,
    default: default_,
    "~run"(dataset, config$1) {
      if (dataset.value === null) {
        if (this.default !== void 0) dataset.value = /* @__PURE__ */ getDefault(this, dataset, config$1);
        if (dataset.value === null) {
          dataset.typed = true;
          return dataset;
        }
      }
      return this.wrapped["~run"](dataset, config$1);
    }
  });
}
// @__NO_SIDE_EFFECTS__
function nullish(wrapped, default_) {
  return _standardSchema({
    kind: "schema",
    type: "nullish",
    reference: nullish,
    expects: `(${wrapped.expects} | null | undefined)`,
    async: false,
    wrapped,
    default: default_,
    "~run"(dataset, config$1) {
      if (dataset.value === null || dataset.value === void 0) {
        if (this.default !== void 0) dataset.value = /* @__PURE__ */ getDefault(this, dataset, config$1);
        if (dataset.value === null || dataset.value === void 0) {
          dataset.typed = true;
          return dataset;
        }
      }
      return this.wrapped["~run"](dataset, config$1);
    }
  });
}
// @__NO_SIDE_EFFECTS__
function number(message$1) {
  return _standardSchema({
    kind: "schema",
    type: "number",
    reference: number,
    expects: "number",
    async: false,
    message: message$1,
    "~run"(dataset, config$1) {
      if (typeof dataset.value === "number" && !isNaN(dataset.value)) dataset.typed = true;
      else _addIssue(this, "type", dataset, config$1);
      return dataset;
    }
  });
}
// @__NO_SIDE_EFFECTS__
function object(entries$1, message$1) {
  return _standardSchema({
    kind: "schema",
    type: "object",
    reference: object,
    expects: "Object",
    async: false,
    entries: entries$1,
    message: message$1,
    "~run"(dataset, config$1) {
      const input = dataset.value;
      if (input && typeof input === "object") {
        dataset.typed = true;
        dataset.value = {};
        for (const key in this.entries) {
          const valueSchema = this.entries[key];
          if (key in input || (valueSchema.type === "exact_optional" || valueSchema.type === "optional" || valueSchema.type === "nullish") && valueSchema.default !== void 0) {
            const value$1 = key in input ? input[key] : /* @__PURE__ */ getDefault(valueSchema);
            const valueDataset = valueSchema["~run"]({ value: value$1 }, config$1);
            if (valueDataset.issues) {
              const pathItem = {
                type: "object",
                origin: "value",
                input,
                key,
                value: value$1
              };
              for (const issue of valueDataset.issues) {
                if (issue.path) issue.path.unshift(pathItem);
                else issue.path = [pathItem];
                dataset.issues?.push(issue);
              }
              if (!dataset.issues) dataset.issues = valueDataset.issues;
              if (config$1.abortEarly) {
                dataset.typed = false;
                break;
              }
            }
            if (!valueDataset.typed) dataset.typed = false;
            dataset.value[key] = valueDataset.value;
          } else if (valueSchema.fallback !== void 0) dataset.value[key] = /* @__PURE__ */ getFallback(valueSchema);
          else if (valueSchema.type !== "exact_optional" && valueSchema.type !== "optional" && valueSchema.type !== "nullish") {
            _addIssue(this, "key", dataset, config$1, {
              input: void 0,
              expected: `"${key}"`,
              path: [{
                type: "object",
                origin: "key",
                input,
                key,
                value: input[key]
              }]
            });
            if (config$1.abortEarly) break;
          }
        }
      } else _addIssue(this, "type", dataset, config$1);
      return dataset;
    }
  });
}
// @__NO_SIDE_EFFECTS__
function optional(wrapped, default_) {
  return _standardSchema({
    kind: "schema",
    type: "optional",
    reference: optional,
    expects: `(${wrapped.expects} | undefined)`,
    async: false,
    wrapped,
    default: default_,
    "~run"(dataset, config$1) {
      if (dataset.value === void 0) {
        if (this.default !== void 0) dataset.value = /* @__PURE__ */ getDefault(this, dataset, config$1);
        if (dataset.value === void 0) {
          dataset.typed = true;
          return dataset;
        }
      }
      return this.wrapped["~run"](dataset, config$1);
    }
  });
}
// @__NO_SIDE_EFFECTS__
function picklist(options, message$1) {
  return _standardSchema({
    kind: "schema",
    type: "picklist",
    reference: picklist,
    expects: /* @__PURE__ */ _joinExpects(options.map(_stringify), "|"),
    async: false,
    options,
    message: message$1,
    "~run"(dataset, config$1) {
      if (this.options.includes(dataset.value)) dataset.typed = true;
      else _addIssue(this, "type", dataset, config$1);
      return dataset;
    }
  });
}
// @__NO_SIDE_EFFECTS__
function record(key, value$1, message$1) {
  return _standardSchema({
    kind: "schema",
    type: "record",
    reference: record,
    expects: "Object",
    async: false,
    key,
    value: value$1,
    message: message$1,
    "~run"(dataset, config$1) {
      const input = dataset.value;
      if (input && typeof input === "object") {
        dataset.typed = true;
        dataset.value = {};
        for (const entryKey in input) if (/* @__PURE__ */ _isValidObjectKey(input, entryKey)) {
          const entryValue = input[entryKey];
          const keyDataset = this.key["~run"]({ value: entryKey }, config$1);
          if (keyDataset.issues) {
            const pathItem = {
              type: "object",
              origin: "key",
              input,
              key: entryKey,
              value: entryValue
            };
            for (const issue of keyDataset.issues) {
              issue.path = [pathItem];
              dataset.issues?.push(issue);
            }
            if (!dataset.issues) dataset.issues = keyDataset.issues;
            if (config$1.abortEarly) {
              dataset.typed = false;
              break;
            }
          }
          const valueDataset = this.value["~run"]({ value: entryValue }, config$1);
          if (valueDataset.issues) {
            const pathItem = {
              type: "object",
              origin: "value",
              input,
              key: entryKey,
              value: entryValue
            };
            for (const issue of valueDataset.issues) {
              if (issue.path) issue.path.unshift(pathItem);
              else issue.path = [pathItem];
              dataset.issues?.push(issue);
            }
            if (!dataset.issues) dataset.issues = valueDataset.issues;
            if (config$1.abortEarly) {
              dataset.typed = false;
              break;
            }
          }
          if (!keyDataset.typed || !valueDataset.typed) dataset.typed = false;
          if (keyDataset.typed) dataset.value[keyDataset.value] = valueDataset.value;
        }
      } else _addIssue(this, "type", dataset, config$1);
      return dataset;
    }
  });
}
// @__NO_SIDE_EFFECTS__
function string(message$1) {
  return _standardSchema({
    kind: "schema",
    type: "string",
    reference: string,
    expects: "string",
    async: false,
    message: message$1,
    "~run"(dataset, config$1) {
      if (typeof dataset.value === "string") dataset.typed = true;
      else _addIssue(this, "type", dataset, config$1);
      return dataset;
    }
  });
}
// @__NO_SIDE_EFFECTS__
function tuple(items, message$1) {
  return _standardSchema({
    kind: "schema",
    type: "tuple",
    reference: tuple,
    expects: "Array",
    async: false,
    items,
    message: message$1,
    "~run"(dataset, config$1) {
      const input = dataset.value;
      if (Array.isArray(input)) {
        dataset.typed = true;
        dataset.value = [];
        for (let key = 0; key < this.items.length; key++) {
          const value$1 = input[key];
          const itemDataset = this.items[key]["~run"]({ value: value$1 }, config$1);
          if (itemDataset.issues) {
            const pathItem = {
              type: "array",
              origin: "value",
              input,
              key,
              value: value$1
            };
            for (const issue of itemDataset.issues) {
              if (issue.path) issue.path.unshift(pathItem);
              else issue.path = [pathItem];
              dataset.issues?.push(issue);
            }
            if (!dataset.issues) dataset.issues = itemDataset.issues;
            if (config$1.abortEarly) {
              dataset.typed = false;
              break;
            }
          }
          if (!itemDataset.typed) dataset.typed = false;
          dataset.value.push(itemDataset.value);
        }
      } else _addIssue(this, "type", dataset, config$1);
      return dataset;
    }
  });
}
// @__NO_SIDE_EFFECTS__
function _subIssues(datasets) {
  let issues;
  if (datasets) for (const dataset of datasets) if (issues) for (const issue of dataset.issues) issues.push(issue);
  else issues = dataset.issues;
  return issues;
}
// @__NO_SIDE_EFFECTS__
function union(options, message$1) {
  return _standardSchema({
    kind: "schema",
    type: "union",
    reference: union,
    expects: /* @__PURE__ */ _joinExpects(options.map((option2) => option2.expects), "|"),
    async: false,
    options,
    message: message$1,
    "~run"(dataset, config$1) {
      let validDataset;
      let typedDatasets;
      let untypedDatasets;
      for (const schema of this.options) {
        const optionDataset = schema["~run"]({ value: dataset.value }, config$1);
        if (optionDataset.typed) if (optionDataset.issues) if (typedDatasets) typedDatasets.push(optionDataset);
        else typedDatasets = [optionDataset];
        else {
          validDataset = optionDataset;
          break;
        }
        else if (untypedDatasets) untypedDatasets.push(optionDataset);
        else untypedDatasets = [optionDataset];
      }
      if (validDataset) return validDataset;
      if (typedDatasets) {
        if (typedDatasets.length === 1) return typedDatasets[0];
        _addIssue(this, "type", dataset, config$1, { issues: /* @__PURE__ */ _subIssues(typedDatasets) });
        dataset.typed = true;
      } else if (untypedDatasets?.length === 1) return untypedDatasets[0];
      else _addIssue(this, "type", dataset, config$1, { issues: /* @__PURE__ */ _subIssues(untypedDatasets) });
      return dataset;
    }
  });
}
// @__NO_SIDE_EFFECTS__
function unknown() {
  return _standardSchema({
    kind: "schema",
    type: "unknown",
    reference: unknown,
    expects: "unknown",
    async: false,
    "~run"(dataset) {
      dataset.typed = true;
      return dataset;
    }
  });
}
// @__NO_SIDE_EFFECTS__
function variant(key, options, message$1) {
  return _standardSchema({
    kind: "schema",
    type: "variant",
    reference: variant,
    expects: "Object",
    async: false,
    key,
    options,
    message: message$1,
    "~run"(dataset, config$1) {
      const input = dataset.value;
      if (input && typeof input === "object") {
        let outputDataset;
        let maxDiscriminatorPriority = 0;
        let invalidDiscriminatorKey = this.key;
        let expectedDiscriminators = [];
        const parseOptions = (variant$1, allKeys) => {
          for (const schema of variant$1.options) {
            if (schema.type === "variant") parseOptions(schema, new Set(allKeys).add(schema.key));
            else {
              let keysAreValid = true;
              let currentPriority = 0;
              for (const currentKey of allKeys) {
                const discriminatorSchema = schema.entries[currentKey];
                if (currentKey in input ? discriminatorSchema["~run"]({
                  typed: false,
                  value: input[currentKey]
                }, ABORT_EARLY_CONFIG).issues : discriminatorSchema.type !== "exact_optional" && discriminatorSchema.type !== "optional" && discriminatorSchema.type !== "nullish") {
                  keysAreValid = false;
                  if (invalidDiscriminatorKey !== currentKey && (maxDiscriminatorPriority < currentPriority || maxDiscriminatorPriority === currentPriority && currentKey in input && !(invalidDiscriminatorKey in input))) {
                    maxDiscriminatorPriority = currentPriority;
                    invalidDiscriminatorKey = currentKey;
                    expectedDiscriminators = [];
                  }
                  if (invalidDiscriminatorKey === currentKey) expectedDiscriminators.push(schema.entries[currentKey].expects);
                  break;
                }
                currentPriority++;
              }
              if (keysAreValid) {
                const optionDataset = schema["~run"]({ value: input }, config$1);
                if (!outputDataset || !outputDataset.typed && optionDataset.typed) outputDataset = optionDataset;
              }
            }
            if (outputDataset && !outputDataset.issues) break;
          }
        };
        parseOptions(this, /* @__PURE__ */ new Set([this.key]));
        if (outputDataset) return outputDataset;
        _addIssue(this, "type", dataset, config$1, {
          input: input[invalidDiscriminatorKey],
          expected: /* @__PURE__ */ _joinExpects(expectedDiscriminators, "|"),
          path: [{
            type: "object",
            origin: "value",
            input,
            key: invalidDiscriminatorKey,
            value: input[invalidDiscriminatorKey]
          }]
        });
      } else _addIssue(this, "type", dataset, config$1);
      return dataset;
    }
  });
}
function parse(schema, input, config$1) {
  const dataset = schema["~run"]({ value: input }, /* @__PURE__ */ getGlobalConfig(config$1));
  if (dataset.issues) throw new ValiError(dataset.issues);
  return dataset.value;
}
// @__NO_SIDE_EFFECTS__
function pipe(...pipe$1) {
  return _standardSchema({
    ...pipe$1[0],
    pipe: pipe$1,
    "~run"(dataset, config$1) {
      for (const item of pipe$1) if (item.kind !== "metadata") {
        if (dataset.issues && (item.kind === "schema" || item.kind === "transformation")) {
          dataset.typed = false;
          break;
        }
        if (!dataset.issues || !config$1.abortEarly && !config$1.abortPipeEarly) dataset = item["~run"](dataset, config$1);
      }
      return dataset;
    }
  });
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/data/internal.mjs
function safeEnum(options) {
  const schemas = Object.keys(options).map((key) => object({
    [key]: options[key],
    $kind: literal(key)
  }));
  return pipe(unknown(), check((input) => unsupportedEnumVariantMessage(input, options) === void 0, ({ input, message }) => unsupportedEnumVariantMessage(input, options) ?? message), transform(addMissingEnumKind), variant("$kind", schemas));
}
function getEnumKind(input) {
  if (typeof input !== "object" || input === null) return null;
  if ("$kind" in input && typeof input.$kind === "string") return input.$kind;
  return Object.keys(input).find((key) => key !== "$kind") ?? null;
}
function addMissingEnumKind(input) {
  if (typeof input !== "object" || input === null || "$kind" in input) return input;
  const kind = getEnumKind(input);
  return kind === null ? input : {
    ...input,
    $kind: kind
  };
}
function unsupportedEnumVariantMessage(input, options) {
  const kind = getEnumKind(input);
  if (kind === null || Object.hasOwn(options, kind)) return void 0;
  return `Unsupported enum variant "${kind}". Expected one of: ${Object.keys(options).map((key) => `"${key}"`).join(", ")}.`;
}
function withKind(key, schema) {
  return pipe(object({
    ...schema.entries,
    $kind: optional(literal(key))
  }), transform((value) => ({
    ...value,
    $kind: key
  })));
}
var SuiAddress = pipe(string(), transform((value) => normalizeSuiAddress(value)), check(isValidSuiAddress));
var ObjectID = SuiAddress;
var BCSBytes = string();
var JsonU64 = pipe(union([string(), pipe(number(), integer())]), check((val) => {
  try {
    BigInt(val);
    return BigInt(val) >= 0 && BigInt(val) <= 18446744073709551615n;
  } catch {
    return false;
  }
}, "Invalid u64"));
var U32 = pipe(number(), integer(), check((val) => val >= 0 && val < 2 ** 32, "Invalid u32"));
var ObjectRefSchema = object({
  objectId: SuiAddress,
  version: JsonU64,
  digest: string()
});
var ArgumentSchema = union([
  withKind("GasCoin", object({ GasCoin: literal(true) })),
  withKind("Input", object({
    Input: pipe(number(), integer()),
    type: optional(union([
      literal("pure"),
      literal("object"),
      literal("withdrawal")
    ]))
  })),
  withKind("Result", object({ Result: pipe(number(), integer()) })),
  withKind("NestedResult", object({ NestedResult: tuple([pipe(number(), integer()), pipe(number(), integer())]) }))
]);
var GasDataSchema = object({
  budget: nullable(JsonU64),
  price: nullable(JsonU64),
  owner: nullable(SuiAddress),
  payment: nullable(array(ObjectRefSchema))
});
var StructTagSchema = object({
  address: string(),
  module: string(),
  name: string(),
  typeParams: array(string())
});
var OpenSignatureBodySchema = union([
  object({ $kind: literal("address") }),
  object({ $kind: literal("bool") }),
  object({ $kind: literal("u8") }),
  object({ $kind: literal("u16") }),
  object({ $kind: literal("u32") }),
  object({ $kind: literal("u64") }),
  object({ $kind: literal("u128") }),
  object({ $kind: literal("u256") }),
  object({ $kind: literal("unknown") }),
  object({
    $kind: literal("vector"),
    vector: lazy(() => OpenSignatureBodySchema)
  }),
  object({
    $kind: literal("datatype"),
    datatype: object({
      typeName: string(),
      typeParameters: array(lazy(() => OpenSignatureBodySchema))
    })
  }),
  object({
    $kind: literal("typeParameter"),
    index: pipe(number(), integer())
  })
]);
var OpenSignatureSchema = object({
  reference: nullable(union([
    literal("mutable"),
    literal("immutable"),
    literal("unknown")
  ])),
  body: OpenSignatureBodySchema
});
var ProgrammableMoveCallSchema = object({
  package: ObjectID,
  module: string(),
  function: string(),
  typeArguments: array(string()),
  arguments: array(ArgumentSchema),
  _argumentTypes: optional(nullable(array(OpenSignatureSchema)))
});
var $Intent = object({
  name: string(),
  inputs: record(string(), union([ArgumentSchema, array(ArgumentSchema)])),
  data: record(string(), unknown())
});
var CommandSchema = safeEnum({
  MoveCall: ProgrammableMoveCallSchema,
  TransferObjects: object({
    objects: array(ArgumentSchema),
    address: ArgumentSchema
  }),
  SplitCoins: object({
    coin: ArgumentSchema,
    amounts: array(ArgumentSchema)
  }),
  MergeCoins: object({
    destination: ArgumentSchema,
    sources: array(ArgumentSchema)
  }),
  Publish: object({
    modules: array(BCSBytes),
    dependencies: array(ObjectID)
  }),
  MakeMoveVec: object({
    type: nullable(string()),
    elements: array(ArgumentSchema)
  }),
  Upgrade: object({
    modules: array(BCSBytes),
    dependencies: array(ObjectID),
    package: ObjectID,
    ticket: ArgumentSchema
  }),
  $Intent
});
var ObjectArgSchema = safeEnum({
  ImmOrOwnedObject: ObjectRefSchema,
  SharedObject: object({
    objectId: ObjectID,
    initialSharedVersion: JsonU64,
    mutable: boolean()
  }),
  Receiving: ObjectRefSchema
});
var ReservationSchema = safeEnum({ MaxAmountU64: JsonU64 });
var WithdrawalTypeArgSchema = safeEnum({ Balance: string() });
var WithdrawFromSchema = safeEnum({
  Sender: literal(true),
  Sponsor: literal(true),
  SenderAllowance: object({
    funder: SuiAddress,
    allowance: ObjectID
  })
});
var FundsWithdrawalArgSchema = object({
  reservation: ReservationSchema,
  typeArg: WithdrawalTypeArgSchema,
  withdrawFrom: WithdrawFromSchema
});
var CallArgSchema = safeEnum({
  Object: ObjectArgSchema,
  Pure: object({ bytes: BCSBytes }),
  UnresolvedPure: object({ value: unknown() }),
  UnresolvedObject: object({
    objectId: ObjectID,
    version: optional(nullable(JsonU64)),
    digest: optional(nullable(string())),
    initialSharedVersion: optional(nullable(JsonU64)),
    mutable: optional(nullable(boolean()))
  }),
  FundsWithdrawal: FundsWithdrawalArgSchema
});
var NormalizedCallArg = safeEnum({
  Object: ObjectArgSchema,
  Pure: object({ bytes: BCSBytes })
});
var ValidDuringSchema = object({
  minEpoch: nullable(JsonU64),
  maxEpoch: nullable(JsonU64),
  minTimestamp: nullable(JsonU64),
  maxTimestamp: nullable(JsonU64),
  chain: string(),
  nonce: U32
});
var AllowedProposersSchema = object({
  epoch: JsonU64,
  proposers: pipe(array(U32), check((proposers) => proposers.length > 0, "Allowed proposers must not be empty"))
});
var ValiditySchema = object({
  ...ValidDuringSchema.entries,
  allowedProposers: nullable(AllowedProposersSchema)
});
var TransactionExpiration2 = safeEnum({
  None: literal(true),
  Epoch: JsonU64,
  ValidDuring: ValidDuringSchema,
  Validity: ValiditySchema
});
var TransactionDataSchema = object({
  version: literal(2),
  sender: nullish(SuiAddress),
  expiration: nullish(TransactionExpiration2),
  gasData: GasDataSchema,
  inputs: array(CallArgSchema),
  commands: array(CommandSchema)
});

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/data/v1.mjs
var ObjectRef = object({
  digest: string(),
  objectId: string(),
  version: union([
    pipe(number(), integer()),
    string(),
    bigint()
  ])
});
var ObjectArg2 = safeEnum({
  ImmOrOwned: ObjectRef,
  Shared: object({
    objectId: ObjectID,
    initialSharedVersion: JsonU64,
    mutable: boolean()
  }),
  Receiving: ObjectRef
});
var NormalizedCallArg2 = safeEnum({
  Object: ObjectArg2,
  Pure: array(pipe(number(), integer()))
});
var TransactionInput = union([object({
  kind: literal("Input"),
  index: pipe(number(), integer()),
  value: unknown(),
  type: optional(literal("object"))
}), object({
  kind: literal("Input"),
  index: pipe(number(), integer()),
  value: unknown(),
  type: literal("pure")
})]);
var TransactionExpiration3 = union([
  object({ Epoch: pipe(number(), integer()) }),
  object({ None: nullable(literal(true)) }),
  object({ ValidDuring: ValidDuringSchema }),
  object({ Validity: ValiditySchema })
]);
function expirationToV1(expiration) {
  if (!expiration) return null;
  switch (expiration.$kind) {
    case "Epoch":
      return { Epoch: Number(expiration.Epoch) };
    case "ValidDuring":
      return { ValidDuring: expiration.ValidDuring };
    case "Validity":
      return { Validity: expiration.Validity };
    case "None":
      return { None: true };
    default:
      throw new Error(`Unknown transaction expiration: ${JSON.stringify(expiration)}`);
  }
}
function expirationFromV1(expiration) {
  if (!expiration) return null;
  if ("Epoch" in expiration) return { Epoch: expiration.Epoch };
  if ("ValidDuring" in expiration) return { ValidDuring: expiration.ValidDuring };
  if ("Validity" in expiration) return { Validity: expiration.Validity };
  if ("None" in expiration) return { None: true };
  throw new Error(`Unknown transaction expiration in v1 transaction data: ${Object.keys(expiration).join(", ")}`);
}
var StringEncodedBigint = pipe(union([
  number(),
  string(),
  bigint()
]), check((val) => {
  if (![
    "string",
    "number",
    "bigint"
  ].includes(typeof val)) return false;
  try {
    BigInt(val);
    return true;
  } catch {
    return false;
  }
}));
var TypeTag2 = union([
  object({ bool: nullable(literal(true)) }),
  object({ u8: nullable(literal(true)) }),
  object({ u64: nullable(literal(true)) }),
  object({ u128: nullable(literal(true)) }),
  object({ address: nullable(literal(true)) }),
  object({ signer: nullable(literal(true)) }),
  object({ vector: lazy(() => TypeTag2) }),
  object({ struct: lazy(() => StructTag2) }),
  object({ u16: nullable(literal(true)) }),
  object({ u32: nullable(literal(true)) }),
  object({ u256: nullable(literal(true)) })
]);
var StructTag2 = object({
  address: string(),
  module: string(),
  name: string(),
  typeParams: array(TypeTag2)
});
var GasConfig = object({
  budget: optional(StringEncodedBigint),
  price: optional(StringEncodedBigint),
  payment: optional(array(ObjectRef)),
  owner: optional(string())
});
var TransactionArgumentTypes = [
  TransactionInput,
  object({ kind: literal("GasCoin") }),
  object({
    kind: literal("Result"),
    index: pipe(number(), integer())
  }),
  object({
    kind: literal("NestedResult"),
    index: pipe(number(), integer()),
    resultIndex: pipe(number(), integer())
  })
];
var TransactionArgument = union([...TransactionArgumentTypes]);
var MoveCallTransaction = object({
  kind: literal("MoveCall"),
  target: pipe(string(), check((target) => target.split("::").length === 3)),
  typeArguments: array(string()),
  arguments: array(TransactionArgument)
});
var TransferObjectsTransaction = object({
  kind: literal("TransferObjects"),
  objects: array(TransactionArgument),
  address: TransactionArgument
});
var SplitCoinsTransaction = object({
  kind: literal("SplitCoins"),
  coin: TransactionArgument,
  amounts: array(TransactionArgument)
});
var MergeCoinsTransaction = object({
  kind: literal("MergeCoins"),
  destination: TransactionArgument,
  sources: array(TransactionArgument)
});
var MakeMoveVecTransaction = object({
  kind: literal("MakeMoveVec"),
  type: union([object({ Some: TypeTag2 }), object({ None: nullable(literal(true)) })]),
  objects: array(TransactionArgument)
});
var TransactionType = union([...[
  MoveCallTransaction,
  TransferObjectsTransaction,
  SplitCoinsTransaction,
  MergeCoinsTransaction,
  object({
    kind: literal("Publish"),
    modules: array(array(pipe(number(), integer()))),
    dependencies: array(string())
  }),
  object({
    kind: literal("Upgrade"),
    modules: array(array(pipe(number(), integer()))),
    dependencies: array(string()),
    packageId: string(),
    ticket: TransactionArgument
  }),
  MakeMoveVecTransaction
]]);
var SerializedTransactionDataV1 = object({
  version: literal(1),
  sender: optional(string()),
  expiration: nullish(TransactionExpiration3),
  gasConfig: GasConfig,
  inputs: array(TransactionInput),
  transactions: array(TransactionType)
});
function serializeV1TransactionData(transactionData) {
  const inputs = transactionData.inputs.map((input, index) => {
    if (input.Object) return {
      kind: "Input",
      index,
      value: { Object: input.Object.ImmOrOwnedObject ? { ImmOrOwned: input.Object.ImmOrOwnedObject } : input.Object.Receiving ? { Receiving: {
        digest: input.Object.Receiving.digest,
        version: input.Object.Receiving.version,
        objectId: input.Object.Receiving.objectId
      } } : { Shared: {
        mutable: input.Object.SharedObject.mutable,
        initialSharedVersion: input.Object.SharedObject.initialSharedVersion,
        objectId: input.Object.SharedObject.objectId
      } } },
      type: "object"
    };
    if (input.Pure) return {
      kind: "Input",
      index,
      value: { Pure: Array.from(fromBase64(input.Pure.bytes)) },
      type: "pure"
    };
    if (input.UnresolvedPure) return {
      kind: "Input",
      type: "pure",
      index,
      value: input.UnresolvedPure.value
    };
    if (input.UnresolvedObject) return {
      kind: "Input",
      type: "object",
      index,
      value: input.UnresolvedObject.objectId
    };
    throw new Error("Invalid input");
  });
  return {
    version: 1,
    sender: transactionData.sender ?? void 0,
    expiration: expirationToV1(transactionData.expiration),
    gasConfig: {
      owner: transactionData.gasData.owner ?? void 0,
      budget: transactionData.gasData.budget ?? void 0,
      price: transactionData.gasData.price ?? void 0,
      payment: transactionData.gasData.payment ?? void 0
    },
    inputs,
    transactions: transactionData.commands.map((command) => {
      if (command.MakeMoveVec) return {
        kind: "MakeMoveVec",
        type: command.MakeMoveVec.type === null ? { None: true } : { Some: TypeTagSerializer.parseFromStr(command.MakeMoveVec.type) },
        objects: command.MakeMoveVec.elements.map((arg) => convertTransactionArgument(arg, inputs))
      };
      if (command.MergeCoins) return {
        kind: "MergeCoins",
        destination: convertTransactionArgument(command.MergeCoins.destination, inputs),
        sources: command.MergeCoins.sources.map((arg) => convertTransactionArgument(arg, inputs))
      };
      if (command.MoveCall) return {
        kind: "MoveCall",
        target: `${command.MoveCall.package}::${command.MoveCall.module}::${command.MoveCall.function}`,
        typeArguments: command.MoveCall.typeArguments,
        arguments: command.MoveCall.arguments.map((arg) => convertTransactionArgument(arg, inputs))
      };
      if (command.Publish) return {
        kind: "Publish",
        modules: command.Publish.modules.map((mod) => Array.from(fromBase64(mod))),
        dependencies: command.Publish.dependencies
      };
      if (command.SplitCoins) return {
        kind: "SplitCoins",
        coin: convertTransactionArgument(command.SplitCoins.coin, inputs),
        amounts: command.SplitCoins.amounts.map((arg) => convertTransactionArgument(arg, inputs))
      };
      if (command.TransferObjects) return {
        kind: "TransferObjects",
        objects: command.TransferObjects.objects.map((arg) => convertTransactionArgument(arg, inputs)),
        address: convertTransactionArgument(command.TransferObjects.address, inputs)
      };
      if (command.Upgrade) return {
        kind: "Upgrade",
        modules: command.Upgrade.modules.map((mod) => Array.from(fromBase64(mod))),
        dependencies: command.Upgrade.dependencies,
        packageId: command.Upgrade.package,
        ticket: convertTransactionArgument(command.Upgrade.ticket, inputs)
      };
      throw new Error(`Unknown transaction ${Object.keys(command)}`);
    })
  };
}
function convertTransactionArgument(arg, inputs) {
  if (arg.$kind === "GasCoin") return { kind: "GasCoin" };
  if (arg.$kind === "Result") return {
    kind: "Result",
    index: arg.Result
  };
  if (arg.$kind === "NestedResult") return {
    kind: "NestedResult",
    index: arg.NestedResult[0],
    resultIndex: arg.NestedResult[1]
  };
  if (arg.$kind === "Input") return inputs[arg.Input];
  throw new Error(`Invalid argument ${Object.keys(arg)}`);
}
function transactionDataFromV1(data) {
  return parse(TransactionDataSchema, {
    version: 2,
    sender: data.sender ?? null,
    expiration: expirationFromV1(data.expiration),
    gasData: {
      owner: data.gasConfig.owner ?? null,
      budget: data.gasConfig.budget?.toString() ?? null,
      price: data.gasConfig.price?.toString() ?? null,
      payment: data.gasConfig.payment?.map((ref) => ({
        digest: ref.digest,
        objectId: ref.objectId,
        version: ref.version.toString()
      })) ?? null
    },
    inputs: data.inputs.map((input) => {
      if (input.kind === "Input") {
        if (is(NormalizedCallArg2, input.value)) {
          const value = parse(NormalizedCallArg2, input.value);
          if (value.Object) {
            if (value.Object.ImmOrOwned) return { Object: { ImmOrOwnedObject: {
              objectId: value.Object.ImmOrOwned.objectId,
              version: String(value.Object.ImmOrOwned.version),
              digest: value.Object.ImmOrOwned.digest
            } } };
            if (value.Object.Shared) return { Object: { SharedObject: {
              mutable: value.Object.Shared.mutable ?? null,
              initialSharedVersion: value.Object.Shared.initialSharedVersion,
              objectId: value.Object.Shared.objectId
            } } };
            if (value.Object.Receiving) return { Object: { Receiving: {
              digest: value.Object.Receiving.digest,
              version: String(value.Object.Receiving.version),
              objectId: value.Object.Receiving.objectId
            } } };
            throw new Error("Invalid object input");
          }
          return { Pure: { bytes: toBase64(new Uint8Array(value.Pure)) } };
        }
        if (input.type === "object") return { UnresolvedObject: { objectId: input.value } };
        return { UnresolvedPure: { value: input.value } };
      }
      throw new Error("Invalid input");
    }),
    commands: data.transactions.map((transaction) => {
      switch (transaction.kind) {
        case "MakeMoveVec":
          return { MakeMoveVec: {
            type: "Some" in transaction.type ? TypeTagSerializer.tagToString(transaction.type.Some) : null,
            elements: transaction.objects.map((arg) => parseV1TransactionArgument(arg))
          } };
        case "MergeCoins":
          return { MergeCoins: {
            destination: parseV1TransactionArgument(transaction.destination),
            sources: transaction.sources.map((arg) => parseV1TransactionArgument(arg))
          } };
        case "MoveCall": {
          const [pkg, mod, fn] = transaction.target.split("::");
          return { MoveCall: {
            package: pkg,
            module: mod,
            function: fn,
            typeArguments: transaction.typeArguments,
            arguments: transaction.arguments.map((arg) => parseV1TransactionArgument(arg))
          } };
        }
        case "Publish":
          return { Publish: {
            modules: transaction.modules.map((mod) => toBase64(Uint8Array.from(mod))),
            dependencies: transaction.dependencies
          } };
        case "SplitCoins":
          return { SplitCoins: {
            coin: parseV1TransactionArgument(transaction.coin),
            amounts: transaction.amounts.map((arg) => parseV1TransactionArgument(arg))
          } };
        case "TransferObjects":
          return { TransferObjects: {
            objects: transaction.objects.map((arg) => parseV1TransactionArgument(arg)),
            address: parseV1TransactionArgument(transaction.address)
          } };
        case "Upgrade":
          return { Upgrade: {
            modules: transaction.modules.map((mod) => toBase64(Uint8Array.from(mod))),
            dependencies: transaction.dependencies,
            package: transaction.packageId,
            ticket: parseV1TransactionArgument(transaction.ticket)
          } };
      }
      throw new Error(`Unknown transaction ${Object.keys(transaction)}`);
    })
  });
}
function parseV1TransactionArgument(arg) {
  switch (arg.kind) {
    case "GasCoin":
      return { GasCoin: true };
    case "Result":
      return { Result: arg.index };
    case "NestedResult":
      return { NestedResult: [arg.index, arg.resultIndex] };
    case "Input":
      return { Input: arg.index };
  }
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/hash.mjs
function hashTypedData(typeTag, data) {
  const typeTagBytes = Array.from(`${typeTag}::`).map((e) => e.charCodeAt(0));
  const dataWithTag = new Uint8Array(typeTagBytes.length + data.length);
  dataWithTag.set(typeTagBytes);
  dataWithTag.set(data, typeTagBytes.length);
  return blake2b(dataWithTag, { dkLen: 32 });
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/utils.mjs
function getIdFromCallArg(arg) {
  if (typeof arg === "string") return normalizeSuiAddress(arg);
  if (arg.Object) {
    if (arg.Object.ImmOrOwnedObject) return normalizeSuiAddress(arg.Object.ImmOrOwnedObject.objectId);
    if (arg.Object.Receiving) return normalizeSuiAddress(arg.Object.Receiving.objectId);
    return normalizeSuiAddress(arg.Object.SharedObject.objectId);
  }
  if (arg.UnresolvedObject) return normalizeSuiAddress(arg.UnresolvedObject.objectId);
}
function isArgument(value) {
  return is(ArgumentSchema, value);
}
function remapCommandArguments(command, inputMapping, commandMapping) {
  const remapArg = (arg) => {
    switch (arg.$kind) {
      case "Input": {
        const newInputIndex = inputMapping.get(arg.Input);
        if (newInputIndex === void 0) throw new Error(`Input ${arg.Input} not found in input mapping`);
        return {
          ...arg,
          Input: newInputIndex
        };
      }
      case "Result": {
        const newCommandIndex = commandMapping.get(arg.Result);
        if (newCommandIndex !== void 0) return {
          ...arg,
          Result: newCommandIndex
        };
        return arg;
      }
      case "NestedResult": {
        const newCommandIndex = commandMapping.get(arg.NestedResult[0]);
        if (newCommandIndex !== void 0) return {
          ...arg,
          NestedResult: [newCommandIndex, arg.NestedResult[1]]
        };
        return arg;
      }
      default:
        return arg;
    }
  };
  switch (command.$kind) {
    case "MoveCall":
      command.MoveCall.arguments = command.MoveCall.arguments.map(remapArg);
      break;
    case "TransferObjects":
      command.TransferObjects.objects = command.TransferObjects.objects.map(remapArg);
      command.TransferObjects.address = remapArg(command.TransferObjects.address);
      break;
    case "SplitCoins":
      command.SplitCoins.coin = remapArg(command.SplitCoins.coin);
      command.SplitCoins.amounts = command.SplitCoins.amounts.map(remapArg);
      break;
    case "MergeCoins":
      command.MergeCoins.destination = remapArg(command.MergeCoins.destination);
      command.MergeCoins.sources = command.MergeCoins.sources.map(remapArg);
      break;
    case "MakeMoveVec":
      command.MakeMoveVec.elements = command.MakeMoveVec.elements.map(remapArg);
      break;
    case "Upgrade":
      command.Upgrade.ticket = remapArg(command.Upgrade.ticket);
      break;
    case "$Intent": {
      const inputs = command.$Intent.inputs;
      command.$Intent.inputs = {};
      for (const [key, value] of Object.entries(inputs)) command.$Intent.inputs[key] = Array.isArray(value) ? value.map(remapArg) : remapArg(value);
      break;
    }
    case "Publish":
      break;
  }
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/TransactionData.mjs
function prepareSuiAddress(address) {
  return normalizeSuiAddress(address).replace("0x", "");
}
var TransactionDataBuilder = class TransactionDataBuilder2 {
  static fromKindBytes(bytes) {
    const programmableTx = suiBcs.TransactionKind.parse(bytes).ProgrammableTransaction;
    if (!programmableTx) throw new Error("Unable to deserialize from bytes.");
    return TransactionDataBuilder2.restore({
      version: 2,
      sender: null,
      expiration: null,
      gasData: {
        budget: null,
        owner: null,
        payment: null,
        price: null
      },
      inputs: programmableTx.inputs,
      commands: programmableTx.commands
    });
  }
  static fromBytes(bytes) {
    const data = suiBcs.TransactionData.parse(bytes)?.V1;
    const programmableTx = data.kind.ProgrammableTransaction;
    if (!data || !programmableTx) throw new Error("Unable to deserialize from bytes.");
    return TransactionDataBuilder2.restore({
      version: 2,
      sender: data.sender,
      expiration: data.expiration,
      gasData: data.gasData,
      inputs: programmableTx.inputs,
      commands: programmableTx.commands
    });
  }
  static restore(data) {
    if (data.version === 2) return new TransactionDataBuilder2(parse(TransactionDataSchema, data));
    else return new TransactionDataBuilder2(parse(TransactionDataSchema, transactionDataFromV1(data)));
  }
  /**
  * Generate transaction digest.
  *
  * @param bytes BCS serialized transaction data
  * @returns transaction digest.
  */
  static getDigestFromBytes(bytes) {
    return toBase58(hashTypedData("TransactionData", bytes));
  }
  constructor(clone) {
    this.version = 2;
    this.sender = clone?.sender ?? null;
    this.expiration = clone?.expiration ?? null;
    this.inputs = clone?.inputs ?? [];
    this.commands = clone?.commands ?? [];
    this.gasData = clone?.gasData ?? {
      budget: null,
      price: null,
      owner: null,
      payment: null
    };
  }
  build({ maxSizeBytes = Infinity, overrides, onlyTransactionKind } = {}) {
    const inputs = this.inputs;
    const commands = this.commands;
    const kind = { ProgrammableTransaction: {
      inputs,
      commands
    } };
    if (onlyTransactionKind) return suiBcs.TransactionKind.serialize(kind, { maxSize: maxSizeBytes }).toBytes();
    const expiration = overrides?.expiration ?? this.expiration;
    const sender = overrides?.sender ?? this.sender;
    const gasData = {
      ...this.gasData,
      ...overrides?.gasData
    };
    if (!sender) throw new Error("Missing transaction sender");
    if (!gasData.budget) throw new Error("Missing gas budget");
    if (!gasData.payment) throw new Error("Missing gas payment");
    if (!gasData.price) throw new Error("Missing gas price");
    const transactionData = {
      sender: prepareSuiAddress(sender),
      expiration: expiration ? expiration : { None: true },
      gasData: {
        payment: gasData.payment,
        owner: prepareSuiAddress(this.gasData.owner ?? sender),
        price: BigInt(gasData.price),
        budget: BigInt(gasData.budget)
      },
      kind: { ProgrammableTransaction: {
        inputs,
        commands
      } }
    };
    return suiBcs.TransactionData.serialize({ V1: transactionData }, { maxSize: maxSizeBytes }).toBytes();
  }
  addInput(type, arg) {
    const index = this.inputs.length;
    this.inputs.push(arg);
    return {
      Input: index,
      type,
      $kind: "Input"
    };
  }
  getInputUses(index, fn) {
    this.mapArguments((arg, command) => {
      if (arg.$kind === "Input" && arg.Input === index) fn(arg, command);
      return arg;
    });
  }
  mapCommandArguments(index, fn) {
    const command = this.commands[index];
    switch (command.$kind) {
      case "MoveCall":
        command.MoveCall.arguments = command.MoveCall.arguments.map((arg) => fn(arg, command, index));
        break;
      case "TransferObjects":
        command.TransferObjects.objects = command.TransferObjects.objects.map((arg) => fn(arg, command, index));
        command.TransferObjects.address = fn(command.TransferObjects.address, command, index);
        break;
      case "SplitCoins":
        command.SplitCoins.coin = fn(command.SplitCoins.coin, command, index);
        command.SplitCoins.amounts = command.SplitCoins.amounts.map((arg) => fn(arg, command, index));
        break;
      case "MergeCoins":
        command.MergeCoins.destination = fn(command.MergeCoins.destination, command, index);
        command.MergeCoins.sources = command.MergeCoins.sources.map((arg) => fn(arg, command, index));
        break;
      case "MakeMoveVec":
        command.MakeMoveVec.elements = command.MakeMoveVec.elements.map((arg) => fn(arg, command, index));
        break;
      case "Upgrade":
        command.Upgrade.ticket = fn(command.Upgrade.ticket, command, index);
        break;
      case "$Intent":
        const inputs = command.$Intent.inputs;
        command.$Intent.inputs = {};
        for (const [key, value] of Object.entries(inputs)) command.$Intent.inputs[key] = Array.isArray(value) ? value.map((arg) => fn(arg, command, index)) : fn(value, command, index);
        break;
      case "Publish":
        break;
      default:
        throw new Error(`Unexpected transaction kind: ${command.$kind}`);
    }
  }
  mapArguments(fn) {
    for (const commandIndex of this.commands.keys()) this.mapCommandArguments(commandIndex, fn);
  }
  replaceCommand(index, replacement, resultIndex = index) {
    if (!Array.isArray(replacement)) {
      this.commands[index] = replacement;
      return;
    }
    const sizeDiff = replacement.length - 1;
    this.commands.splice(index, 1, ...structuredClone(replacement));
    this.mapArguments((arg, _command, commandIndex) => {
      if (commandIndex < index + replacement.length) return arg;
      if (typeof resultIndex !== "number") {
        if (arg.$kind === "Result" && arg.Result === index || arg.$kind === "NestedResult" && arg.NestedResult[0] === index) if (!("NestedResult" in arg) || arg.NestedResult[1] === 0) return parse(ArgumentSchema, structuredClone(resultIndex));
        else throw new Error(`Cannot replace command ${index} with a specific result type: NestedResult[${index}, ${arg.NestedResult[1]}] references a nested element that cannot be mapped to the replacement result`);
      }
      switch (arg.$kind) {
        case "Result":
          if (arg.Result === index && typeof resultIndex === "number") arg.Result = resultIndex;
          if (arg.Result > index) arg.Result += sizeDiff;
          break;
        case "NestedResult":
          if (arg.NestedResult[0] === index && typeof resultIndex === "number") return {
            $kind: "NestedResult",
            NestedResult: [resultIndex, arg.NestedResult[1]]
          };
          if (arg.NestedResult[0] > index) arg.NestedResult[0] += sizeDiff;
          break;
      }
      return arg;
    });
  }
  replaceCommandWithTransaction(index, otherTransaction, result) {
    if (result.$kind !== "Result" && result.$kind !== "NestedResult") throw new Error("Result must be of kind Result or NestedResult");
    this.insertTransaction(index, otherTransaction);
    this.replaceCommand(index + otherTransaction.commands.length, [], "Result" in result ? { NestedResult: [result.Result + index, 0] } : { NestedResult: [result.NestedResult[0] + index, result.NestedResult[1]] });
  }
  insertTransaction(atCommandIndex, otherTransaction) {
    const inputMapping = /* @__PURE__ */ new Map();
    const commandMapping = /* @__PURE__ */ new Map();
    for (let i = 0; i < otherTransaction.inputs.length; i++) {
      const otherInput = otherTransaction.inputs[i];
      const id = getIdFromCallArg(otherInput);
      let existingIndex = -1;
      if (id !== void 0) {
        existingIndex = this.inputs.findIndex((input) => getIdFromCallArg(input) === id);
        if (existingIndex !== -1 && this.inputs[existingIndex].Object?.SharedObject && otherInput.Object?.SharedObject) this.inputs[existingIndex].Object.SharedObject.mutable = this.inputs[existingIndex].Object.SharedObject.mutable || otherInput.Object.SharedObject.mutable;
      }
      if (existingIndex !== -1) inputMapping.set(i, existingIndex);
      else {
        const newIndex = this.inputs.length;
        this.inputs.push(otherInput);
        inputMapping.set(i, newIndex);
      }
    }
    for (let i = 0; i < otherTransaction.commands.length; i++) commandMapping.set(i, atCommandIndex + i);
    const remappedCommands = [];
    for (let i = 0; i < otherTransaction.commands.length; i++) {
      const command = structuredClone(otherTransaction.commands[i]);
      remapCommandArguments(command, inputMapping, commandMapping);
      remappedCommands.push(command);
    }
    this.commands.splice(atCommandIndex, 0, ...remappedCommands);
    const sizeDiff = remappedCommands.length;
    if (sizeDiff > 0) this.mapArguments((arg, _command, commandIndex) => {
      if (commandIndex >= atCommandIndex && commandIndex < atCommandIndex + remappedCommands.length) return arg;
      switch (arg.$kind) {
        case "Result":
          if (arg.Result >= atCommandIndex) arg.Result += sizeDiff;
          break;
        case "NestedResult":
          if (arg.NestedResult[0] >= atCommandIndex) arg.NestedResult[0] += sizeDiff;
          break;
      }
      return arg;
    });
  }
  getDigest() {
    const bytes = this.build({ onlyTransactionKind: false });
    return TransactionDataBuilder2.getDigestFromBytes(bytes);
  }
  snapshot() {
    return parse(TransactionDataSchema, this);
  }
  getData() {
    return this.snapshot();
  }
  shallowClone() {
    return new TransactionDataBuilder2({
      version: this.version,
      sender: this.sender,
      expiration: this.expiration,
      gasData: { ...this.gasData },
      inputs: [...this.inputs],
      commands: [...this.commands]
    });
  }
  applyResolvedData(resolved) {
    if (!this.sender) this.sender = resolved.sender ?? null;
    if (!this.expiration) this.expiration = resolved.expiration ?? null;
    if (!this.gasData.budget) this.gasData.budget = resolved.gasData.budget;
    if (!this.gasData.owner) this.gasData.owner = resolved.gasData.owner ?? null;
    if (!this.gasData.payment) this.gasData.payment = resolved.gasData.payment;
    if (!this.gasData.price) this.gasData.price = resolved.gasData.price;
    for (let i = 0; i < this.inputs.length; i++) {
      const input = this.inputs[i];
      const resolvedInput = resolved.inputs[i];
      switch (input.$kind) {
        case "UnresolvedPure":
          if (resolvedInput.$kind !== "Pure") throw new Error(`Expected input at index ${i} to resolve to a Pure argument, but got ${JSON.stringify(resolvedInput)}`);
          this.inputs[i] = resolvedInput;
          break;
        case "UnresolvedObject":
          if (resolvedInput.$kind !== "Object") throw new Error(`Expected input at index ${i} to resolve to an Object argument, but got ${JSON.stringify(resolvedInput)}`);
          if (resolvedInput.Object.$kind === "ImmOrOwnedObject" || resolvedInput.Object.$kind === "Receiving") {
            const original = input.UnresolvedObject;
            const resolved$1 = resolvedInput.Object.ImmOrOwnedObject ?? resolvedInput.Object.Receiving;
            if (normalizeSuiAddress(original.objectId) !== normalizeSuiAddress(resolved$1.objectId) || original.version != null && original.version !== resolved$1.version || original.digest != null && original.digest !== resolved$1.digest || original.mutable != null || original.initialSharedVersion != null) throw new Error(`Input at index ${i} did not match unresolved object. ${JSON.stringify(original)} is not compatible with ${JSON.stringify(resolved$1)}`);
          } else if (resolvedInput.Object.$kind === "SharedObject") {
            const original = input.UnresolvedObject;
            const resolved$1 = resolvedInput.Object.SharedObject;
            if (normalizeSuiAddress(original.objectId) !== normalizeSuiAddress(resolved$1.objectId) || original.initialSharedVersion != null && original.initialSharedVersion !== resolved$1.initialSharedVersion || original.mutable != null && original.mutable !== resolved$1.mutable || original.version != null || original.digest != null) throw new Error(`Input at index ${i} did not match unresolved object. ${JSON.stringify(original)} is not compatible with ${JSON.stringify(resolved$1)}`);
          } else throw new Error(`Input at index ${i} resolved to an unexpected Object kind: ${JSON.stringify(resolvedInput.Object)}`);
          this.inputs[i] = resolvedInput;
          break;
      }
    }
  }
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/client/utils.mjs
var ordinalRules = new Intl.PluralRules("en-US", { type: "ordinal" });
var ordinalSuffixes = /* @__PURE__ */ new Map([
  ["one", "st"],
  ["two", "nd"],
  ["few", "rd"],
  ["other", "th"]
]);
function formatOrdinal(n) {
  return `${n}${ordinalSuffixes.get(ordinalRules.select(n))}`;
}
function formatMoveAbortMessage(options) {
  const { command, location, abortCode, cleverError } = options;
  const parts = [];
  if (command != null) parts.push(`MoveAbort in ${formatOrdinal(command + 1)} command`);
  else parts.push("MoveAbort");
  if (cleverError?.constantName) {
    const errorStr = cleverError.value ? `'${cleverError.constantName}': ${cleverError.value}` : `'${cleverError.constantName}'`;
    parts.push(errorStr);
  } else parts.push(`abort code: ${abortCode}`);
  if (location?.package && location?.module) {
    const locationStr = [`in '${[
      location.package.startsWith("0x") ? location.package : `0x${location.package}`,
      location.module,
      location.functionName
    ].filter(Boolean).join("::")}'`];
    if (cleverError?.lineNumber != null) locationStr.push(`(line ${cleverError.lineNumber})`);
    else if (location.instruction != null) locationStr.push(`(instruction ${location.instruction})`);
    parts.push(locationStr.join(" "));
  }
  return parts.join(", ");
}
var MinimalEffectsWithError = suiBcs.struct("MinimalEffectsWithError", { status: ExecutionStatus });
var MinimalTransactionEffectsWithError = suiBcs.enum("MinimalTransactionEffectsWithError", {
  V1: MinimalEffectsWithError,
  V2: MinimalEffectsWithError
});
var MinimalExecutionStatusNoError = suiBcs.enum("MinimalExecutionStatusNoError", {
  Success: null,
  Failed: null
});
var MinimalEffectsNoError = suiBcs.struct("MinimalEffectsNoError", { status: MinimalExecutionStatusNoError });
var MinimalTransactionEffectsNoError = suiBcs.enum("MinimalTransactionEffectsNoError", {
  V1: MinimalEffectsNoError,
  V2: MinimalEffectsNoError
});
function transactionBytesHaveEmptyGasPayment(bytes) {
  try {
    return suiBcs.TransactionData.parse(bytes).V1?.gasData.payment?.length === 0;
  } catch {
    return false;
  }
}
function isMockedGasObjectId(objectId) {
  return objectId != null && normalizeSuiAddress(objectId) === MOCKED_GAS_OBJECT_ID;
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/client/errors.mjs
var SuiClientError = class extends Error {
};
var SimulationError = class extends SuiClientError {
  constructor(message, options) {
    super(message, { cause: options?.cause });
    this.executionError = options?.executionError;
  }
};
var ObjectError = class extends SuiClientError {
  constructor(code, message, options) {
    super(message, { cause: options?.cause });
    this.code = code;
    this.reason = options?.reason ?? "unknown";
    this.objectId = options?.objectId;
  }
};
var TRANSACTION_ERROR_MESSAGES = { notFound: (digest2) => `Transaction ${digest2} not found` };
var TransactionError = class extends SuiClientError {
  constructor(reason, digest2, options) {
    super(TRANSACTION_ERROR_MESSAGES[reason](digest2), options);
    this.reason = reason;
    this.digest = digest2;
  }
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/google/protobuf/struct.mjs
var import_runtime = __toESM(require_commonjs(), 1);
var NullValue = /* @__PURE__ */ (function(NullValue$1) {
  NullValue$1[NullValue$1["NULL_VALUE"] = 0] = "NULL_VALUE";
  return NullValue$1;
})({});
var Struct$Type = class extends import_runtime.MessageType {
  constructor() {
    super("google.protobuf.Struct", [{
      no: 1,
      name: "fields",
      kind: "map",
      K: 9,
      V: {
        kind: "message",
        T: () => Value
      }
    }]);
  }
  /**
  * Encode `Struct` to JSON object.
  */
  internalJsonWrite(message, options) {
    let json = {};
    for (let [k, v] of Object.entries(message.fields)) json[k] = Value.toJson(v);
    return json;
  }
  /**
  * Decode `Struct` from JSON object.
  */
  internalJsonRead(json, options, target) {
    if (!(0, import_runtime.isJsonObject)(json)) throw new globalThis.Error("Unable to parse message " + this.typeName + " from JSON " + (0, import_runtime.typeofJsonValue)(json) + ".");
    if (!target) target = this.create();
    for (let [k, v] of globalThis.Object.entries(json)) target.fields[k] = Value.fromJson(v);
    return target;
  }
};
var Struct = new Struct$Type();
var Value$Type = class extends import_runtime.MessageType {
  constructor() {
    super("google.protobuf.Value", [
      {
        no: 1,
        name: "null_value",
        kind: "enum",
        oneof: "kind",
        T: () => ["google.protobuf.NullValue", NullValue]
      },
      {
        no: 2,
        name: "number_value",
        kind: "scalar",
        oneof: "kind",
        T: 1
      },
      {
        no: 3,
        name: "string_value",
        kind: "scalar",
        oneof: "kind",
        T: 9
      },
      {
        no: 4,
        name: "bool_value",
        kind: "scalar",
        oneof: "kind",
        T: 8
      },
      {
        no: 5,
        name: "struct_value",
        kind: "message",
        oneof: "kind",
        T: () => Struct
      },
      {
        no: 6,
        name: "list_value",
        kind: "message",
        oneof: "kind",
        T: () => ListValue
      }
    ]);
  }
  /**
  * Encode `Value` to JSON value.
  */
  internalJsonWrite(message, options) {
    if (message.kind.oneofKind === void 0) throw new globalThis.Error();
    switch (message.kind.oneofKind) {
      case void 0:
        throw new globalThis.Error();
      case "boolValue":
        return message.kind.boolValue;
      case "nullValue":
        return null;
      case "numberValue":
        let numberValue = message.kind.numberValue;
        if (typeof numberValue == "number" && !Number.isFinite(numberValue)) throw new globalThis.Error();
        return numberValue;
      case "stringValue":
        return message.kind.stringValue;
      case "listValue":
        let listValueField = this.fields.find((f) => f.no === 6);
        if (listValueField?.kind !== "message") throw new globalThis.Error();
        return listValueField.T().toJson(message.kind.listValue);
      case "structValue":
        let structValueField = this.fields.find((f) => f.no === 5);
        if (structValueField?.kind !== "message") throw new globalThis.Error();
        return structValueField.T().toJson(message.kind.structValue);
    }
  }
  /**
  * Decode `Value` from JSON value.
  */
  internalJsonRead(json, options, target) {
    if (!target) target = this.create();
    switch (typeof json) {
      case "number":
        target.kind = {
          oneofKind: "numberValue",
          numberValue: json
        };
        break;
      case "string":
        target.kind = {
          oneofKind: "stringValue",
          stringValue: json
        };
        break;
      case "boolean":
        target.kind = {
          oneofKind: "boolValue",
          boolValue: json
        };
        break;
      case "object":
        if (json === null) target.kind = {
          oneofKind: "nullValue",
          nullValue: NullValue.NULL_VALUE
        };
        else if (globalThis.Array.isArray(json)) target.kind = {
          oneofKind: "listValue",
          listValue: ListValue.fromJson(json)
        };
        else target.kind = {
          oneofKind: "structValue",
          structValue: Struct.fromJson(json)
        };
        break;
      default:
        throw new globalThis.Error("Unable to parse " + this.typeName + " from JSON " + (0, import_runtime.typeofJsonValue)(json));
    }
    return target;
  }
};
var Value = new Value$Type();
var ListValue$Type = class extends import_runtime.MessageType {
  constructor() {
    super("google.protobuf.ListValue", [{
      no: 1,
      name: "values",
      kind: "message",
      repeat: 2,
      T: () => Value
    }]);
  }
  /**
  * Encode `ListValue` to JSON array.
  */
  internalJsonWrite(message, options) {
    return message.values.map((v) => Value.toJson(v));
  }
  /**
  * Decode `ListValue` from JSON array.
  */
  internalJsonRead(json, options, target) {
    if (!globalThis.Array.isArray(json)) throw new globalThis.Error("Unable to parse " + this.typeName + " from JSON " + (0, import_runtime.typeofJsonValue)(json));
    if (!target) target = this.create();
    let values = json.map((v) => Value.fromJson(v));
    target.values.push(...values);
    return target;
  }
};
var ListValue = new ListValue$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/move_package.mjs
var import_runtime2 = __toESM(require_commonjs(), 1);
var DatatypeDescriptor_DatatypeKind = /* @__PURE__ */ (function(DatatypeDescriptor_DatatypeKind$1) {
  DatatypeDescriptor_DatatypeKind$1[DatatypeDescriptor_DatatypeKind$1["DATATYPE_KIND_UNKNOWN"] = 0] = "DATATYPE_KIND_UNKNOWN";
  DatatypeDescriptor_DatatypeKind$1[DatatypeDescriptor_DatatypeKind$1["STRUCT"] = 1] = "STRUCT";
  DatatypeDescriptor_DatatypeKind$1[DatatypeDescriptor_DatatypeKind$1["ENUM"] = 2] = "ENUM";
  return DatatypeDescriptor_DatatypeKind$1;
})({});
var OpenSignatureBody_Type = /* @__PURE__ */ (function(OpenSignatureBody_Type$1) {
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["TYPE_UNKNOWN"] = 0] = "TYPE_UNKNOWN";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["ADDRESS"] = 1] = "ADDRESS";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["BOOL"] = 2] = "BOOL";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["U8"] = 3] = "U8";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["U16"] = 4] = "U16";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["U32"] = 5] = "U32";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["U64"] = 6] = "U64";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["U128"] = 7] = "U128";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["U256"] = 8] = "U256";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["VECTOR"] = 9] = "VECTOR";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["DATATYPE"] = 10] = "DATATYPE";
  OpenSignatureBody_Type$1[OpenSignatureBody_Type$1["TYPE_PARAMETER"] = 11] = "TYPE_PARAMETER";
  return OpenSignatureBody_Type$1;
})({});
var FunctionDescriptor_Visibility = /* @__PURE__ */ (function(FunctionDescriptor_Visibility$1) {
  FunctionDescriptor_Visibility$1[FunctionDescriptor_Visibility$1["VISIBILITY_UNKNOWN"] = 0] = "VISIBILITY_UNKNOWN";
  FunctionDescriptor_Visibility$1[FunctionDescriptor_Visibility$1["PRIVATE"] = 1] = "PRIVATE";
  FunctionDescriptor_Visibility$1[FunctionDescriptor_Visibility$1["PUBLIC"] = 2] = "PUBLIC";
  FunctionDescriptor_Visibility$1[FunctionDescriptor_Visibility$1["FRIEND"] = 3] = "FRIEND";
  return FunctionDescriptor_Visibility$1;
})({});
var OpenSignature_Reference = /* @__PURE__ */ (function(OpenSignature_Reference$1) {
  OpenSignature_Reference$1[OpenSignature_Reference$1["REFERENCE_UNKNOWN"] = 0] = "REFERENCE_UNKNOWN";
  OpenSignature_Reference$1[OpenSignature_Reference$1["IMMUTABLE"] = 1] = "IMMUTABLE";
  OpenSignature_Reference$1[OpenSignature_Reference$1["MUTABLE"] = 2] = "MUTABLE";
  return OpenSignature_Reference$1;
})({});
var Ability = /* @__PURE__ */ (function(Ability$1) {
  Ability$1[Ability$1["ABILITY_UNKNOWN"] = 0] = "ABILITY_UNKNOWN";
  Ability$1[Ability$1["COPY"] = 1] = "COPY";
  Ability$1[Ability$1["DROP"] = 2] = "DROP";
  Ability$1[Ability$1["STORE"] = 3] = "STORE";
  Ability$1[Ability$1["KEY"] = 4] = "KEY";
  return Ability$1;
})({});
var Package$Type = class extends import_runtime2.MessageType {
  constructor() {
    super("sui.rpc.v2.Package", [
      {
        no: 1,
        name: "storage_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "original_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "modules",
        kind: "message",
        repeat: 2,
        T: () => Module
      },
      {
        no: 5,
        name: "type_origins",
        kind: "message",
        repeat: 2,
        T: () => TypeOrigin2
      },
      {
        no: 6,
        name: "linkage",
        kind: "message",
        repeat: 2,
        T: () => Linkage
      }
    ]);
  }
};
var Package = new Package$Type();
var Module$Type = class extends import_runtime2.MessageType {
  constructor() {
    super("sui.rpc.v2.Module", [
      {
        no: 1,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "contents",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "datatypes",
        kind: "message",
        repeat: 2,
        T: () => DatatypeDescriptor
      },
      {
        no: 4,
        name: "functions",
        kind: "message",
        repeat: 2,
        T: () => FunctionDescriptor
      }
    ]);
  }
};
var Module = new Module$Type();
var DatatypeDescriptor$Type = class extends import_runtime2.MessageType {
  constructor() {
    super("sui.rpc.v2.DatatypeDescriptor", [
      {
        no: 1,
        name: "type_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "defining_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "module",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "abilities",
        kind: "enum",
        repeat: 1,
        T: () => ["sui.rpc.v2.Ability", Ability]
      },
      {
        no: 6,
        name: "type_parameters",
        kind: "message",
        repeat: 2,
        T: () => TypeParameter
      },
      {
        no: 7,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.DatatypeDescriptor.DatatypeKind", DatatypeDescriptor_DatatypeKind]
      },
      {
        no: 8,
        name: "fields",
        kind: "message",
        repeat: 2,
        T: () => FieldDescriptor
      },
      {
        no: 9,
        name: "variants",
        kind: "message",
        repeat: 2,
        T: () => VariantDescriptor
      }
    ]);
  }
};
var DatatypeDescriptor = new DatatypeDescriptor$Type();
var TypeParameter$Type = class extends import_runtime2.MessageType {
  constructor() {
    super("sui.rpc.v2.TypeParameter", [{
      no: 1,
      name: "constraints",
      kind: "enum",
      repeat: 1,
      T: () => ["sui.rpc.v2.Ability", Ability]
    }, {
      no: 2,
      name: "is_phantom",
      kind: "scalar",
      opt: true,
      T: 8
    }]);
  }
};
var TypeParameter = new TypeParameter$Type();
var FieldDescriptor$Type = class extends import_runtime2.MessageType {
  constructor() {
    super("sui.rpc.v2.FieldDescriptor", [
      {
        no: 1,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "position",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "type",
        kind: "message",
        T: () => OpenSignatureBody
      }
    ]);
  }
};
var FieldDescriptor = new FieldDescriptor$Type();
var VariantDescriptor$Type = class extends import_runtime2.MessageType {
  constructor() {
    super("sui.rpc.v2.VariantDescriptor", [
      {
        no: 1,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "position",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "fields",
        kind: "message",
        repeat: 2,
        T: () => FieldDescriptor
      }
    ]);
  }
};
var VariantDescriptor = new VariantDescriptor$Type();
var OpenSignatureBody$Type = class extends import_runtime2.MessageType {
  constructor() {
    super("sui.rpc.v2.OpenSignatureBody", [
      {
        no: 1,
        name: "type",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.OpenSignatureBody.Type", OpenSignatureBody_Type]
      },
      {
        no: 2,
        name: "type_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "type_parameter_instantiation",
        kind: "message",
        repeat: 2,
        T: () => OpenSignatureBody
      },
      {
        no: 4,
        name: "type_parameter",
        kind: "scalar",
        opt: true,
        T: 13
      }
    ]);
  }
};
var OpenSignatureBody = new OpenSignatureBody$Type();
var FunctionDescriptor$Type = class extends import_runtime2.MessageType {
  constructor() {
    super("sui.rpc.v2.FunctionDescriptor", [
      {
        no: 1,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "visibility",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.FunctionDescriptor.Visibility", FunctionDescriptor_Visibility]
      },
      {
        no: 6,
        name: "is_entry",
        kind: "scalar",
        opt: true,
        T: 8
      },
      {
        no: 7,
        name: "type_parameters",
        kind: "message",
        repeat: 2,
        T: () => TypeParameter
      },
      {
        no: 8,
        name: "parameters",
        kind: "message",
        repeat: 2,
        T: () => OpenSignature
      },
      {
        no: 9,
        name: "returns",
        kind: "message",
        repeat: 2,
        T: () => OpenSignature
      }
    ]);
  }
};
var FunctionDescriptor = new FunctionDescriptor$Type();
var OpenSignature$Type = class extends import_runtime2.MessageType {
  constructor() {
    super("sui.rpc.v2.OpenSignature", [{
      no: 1,
      name: "reference",
      kind: "enum",
      opt: true,
      T: () => ["sui.rpc.v2.OpenSignature.Reference", OpenSignature_Reference]
    }, {
      no: 2,
      name: "body",
      kind: "message",
      T: () => OpenSignatureBody
    }]);
  }
};
var OpenSignature = new OpenSignature$Type();
var TypeOrigin$Type = class extends import_runtime2.MessageType {
  constructor() {
    super("sui.rpc.v2.TypeOrigin", [
      {
        no: 1,
        name: "module_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "datatype_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "package_id",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var TypeOrigin2 = new TypeOrigin$Type();
var Linkage$Type = class extends import_runtime2.MessageType {
  constructor() {
    super("sui.rpc.v2.Linkage", [
      {
        no: 1,
        name: "original_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "upgraded_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "upgraded_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var Linkage = new Linkage$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/owner.mjs
var import_runtime3 = __toESM(require_commonjs(), 1);
var Owner_OwnerKind = /* @__PURE__ */ (function(Owner_OwnerKind$1) {
  Owner_OwnerKind$1[Owner_OwnerKind$1["OWNER_KIND_UNKNOWN"] = 0] = "OWNER_KIND_UNKNOWN";
  Owner_OwnerKind$1[Owner_OwnerKind$1["ADDRESS"] = 1] = "ADDRESS";
  Owner_OwnerKind$1[Owner_OwnerKind$1["OBJECT"] = 2] = "OBJECT";
  Owner_OwnerKind$1[Owner_OwnerKind$1["SHARED"] = 3] = "SHARED";
  Owner_OwnerKind$1[Owner_OwnerKind$1["IMMUTABLE"] = 4] = "IMMUTABLE";
  Owner_OwnerKind$1[Owner_OwnerKind$1["CONSENSUS_ADDRESS"] = 5] = "CONSENSUS_ADDRESS";
  return Owner_OwnerKind$1;
})({});
var Owner$Type = class extends import_runtime3.MessageType {
  constructor() {
    super("sui.rpc.v2.Owner", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.Owner.OwnerKind", Owner_OwnerKind]
      },
      {
        no: 2,
        name: "address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var Owner2 = new Owner$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/argument.mjs
var import_runtime4 = __toESM(require_commonjs(), 1);
var Argument_ArgumentKind = /* @__PURE__ */ (function(Argument_ArgumentKind$1) {
  Argument_ArgumentKind$1[Argument_ArgumentKind$1["ARGUMENT_KIND_UNKNOWN"] = 0] = "ARGUMENT_KIND_UNKNOWN";
  Argument_ArgumentKind$1[Argument_ArgumentKind$1["GAS"] = 1] = "GAS";
  Argument_ArgumentKind$1[Argument_ArgumentKind$1["INPUT"] = 2] = "INPUT";
  Argument_ArgumentKind$1[Argument_ArgumentKind$1["RESULT"] = 3] = "RESULT";
  return Argument_ArgumentKind$1;
})({});
var Argument$Type = class extends import_runtime4.MessageType {
  constructor() {
    super("sui.rpc.v2.Argument", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.Argument.ArgumentKind", Argument_ArgumentKind]
      },
      {
        no: 2,
        name: "input",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "result",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 4,
        name: "subresult",
        kind: "scalar",
        opt: true,
        T: 13
      }
    ]);
  }
};
var Argument2 = new Argument$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/input.mjs
var import_runtime5 = __toESM(require_commonjs(), 1);
var Input_InputKind = /* @__PURE__ */ (function(Input_InputKind$1) {
  Input_InputKind$1[Input_InputKind$1["INPUT_KIND_UNKNOWN"] = 0] = "INPUT_KIND_UNKNOWN";
  Input_InputKind$1[Input_InputKind$1["PURE"] = 1] = "PURE";
  Input_InputKind$1[Input_InputKind$1["IMMUTABLE_OR_OWNED"] = 2] = "IMMUTABLE_OR_OWNED";
  Input_InputKind$1[Input_InputKind$1["SHARED"] = 3] = "SHARED";
  Input_InputKind$1[Input_InputKind$1["RECEIVING"] = 4] = "RECEIVING";
  Input_InputKind$1[Input_InputKind$1["FUNDS_WITHDRAWAL"] = 5] = "FUNDS_WITHDRAWAL";
  return Input_InputKind$1;
})({});
var Input_Mutability = /* @__PURE__ */ (function(Input_Mutability$1) {
  Input_Mutability$1[Input_Mutability$1["MUTABILITY_UNKNOWN"] = 0] = "MUTABILITY_UNKNOWN";
  Input_Mutability$1[Input_Mutability$1["IMMUTABLE"] = 1] = "IMMUTABLE";
  Input_Mutability$1[Input_Mutability$1["MUTABLE"] = 2] = "MUTABLE";
  Input_Mutability$1[Input_Mutability$1["NON_EXCLUSIVE_WRITE"] = 3] = "NON_EXCLUSIVE_WRITE";
  return Input_Mutability$1;
})({});
var FundsWithdrawal_Source = /* @__PURE__ */ (function(FundsWithdrawal_Source$1) {
  FundsWithdrawal_Source$1[FundsWithdrawal_Source$1["SOURCE_UNKNOWN"] = 0] = "SOURCE_UNKNOWN";
  FundsWithdrawal_Source$1[FundsWithdrawal_Source$1["SENDER"] = 1] = "SENDER";
  FundsWithdrawal_Source$1[FundsWithdrawal_Source$1["SPONSOR"] = 2] = "SPONSOR";
  FundsWithdrawal_Source$1[FundsWithdrawal_Source$1["SENDER_ALLOWANCE"] = 3] = "SENDER_ALLOWANCE";
  return FundsWithdrawal_Source$1;
})({});
var Input$Type = class extends import_runtime5.MessageType {
  constructor() {
    super("sui.rpc.v2.Input", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.Input.InputKind", Input_InputKind]
      },
      {
        no: 2,
        name: "pure",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 6,
        name: "mutable",
        kind: "scalar",
        opt: true,
        T: 8
      },
      {
        no: 7,
        name: "mutability",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.Input.Mutability", Input_Mutability]
      },
      {
        no: 8,
        name: "funds_withdrawal",
        kind: "message",
        T: () => FundsWithdrawal2
      },
      {
        no: 1e3,
        name: "literal",
        kind: "message",
        T: () => Value
      }
    ]);
  }
};
var Input = new Input$Type();
var FundsWithdrawal$Type = class extends import_runtime5.MessageType {
  constructor() {
    super("sui.rpc.v2.FundsWithdrawal", [
      {
        no: 1,
        name: "amount",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "coin_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "source",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.FundsWithdrawal.Source", FundsWithdrawal_Source]
      },
      {
        no: 4,
        name: "funder",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "allowance",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var FundsWithdrawal2 = new FundsWithdrawal$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/google/protobuf/duration.mjs
var import_runtime6 = __toESM(require_commonjs(), 1);
var Duration$Type = class extends import_runtime6.MessageType {
  constructor() {
    super("google.protobuf.Duration", [{
      no: 1,
      name: "seconds",
      kind: "scalar",
      T: 3,
      L: 0
    }, {
      no: 2,
      name: "nanos",
      kind: "scalar",
      T: 5
    }]);
  }
  /**
  * Encode `Duration` to JSON string like "3.000001s".
  */
  internalJsonWrite(message, options) {
    let s = import_runtime6.PbLong.from(message.seconds).toNumber();
    if (s > 315576e6 || s < -315576e6) throw new Error("Duration value out of range.");
    let text = message.seconds.toString();
    if (s === 0 && message.nanos < 0) text = "-" + text;
    if (message.nanos !== 0) {
      let nanosStr = Math.abs(message.nanos).toString();
      nanosStr = "0".repeat(9 - nanosStr.length) + nanosStr;
      if (nanosStr.substring(3) === "000000") nanosStr = nanosStr.substring(0, 3);
      else if (nanosStr.substring(6) === "000") nanosStr = nanosStr.substring(0, 6);
      text += "." + nanosStr;
    }
    return text + "s";
  }
  /**
  * Decode `Duration` from JSON string like "3.000001s"
  */
  internalJsonRead(json, options, target) {
    if (typeof json !== "string") throw new Error("Unable to parse Duration from JSON " + (0, import_runtime6.typeofJsonValue)(json) + ". Expected string.");
    let match = json.match(/^(-?)([0-9]+)(?:\.([0-9]+))?s/);
    if (match === null) throw new Error("Unable to parse Duration from JSON string. Invalid format.");
    if (!target) target = this.create();
    let [, sign, secs, nanos] = match;
    let longSeconds = import_runtime6.PbLong.from(sign + secs);
    if (longSeconds.toNumber() > 315576e6 || longSeconds.toNumber() < -315576e6) throw new Error("Unable to parse Duration from JSON string. Value out of range.");
    target.seconds = longSeconds.toBigInt();
    if (typeof nanos == "string") {
      let nanosStr = sign + nanos + "0".repeat(9 - nanos.length);
      target.nanos = parseInt(nanosStr);
    }
    return target;
  }
};
var Duration = new Duration$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/jwk.mjs
var import_runtime7 = __toESM(require_commonjs(), 1);
var JwkId$Type = class extends import_runtime7.MessageType {
  constructor() {
    super("sui.rpc.v2.JwkId", [{
      no: 1,
      name: "iss",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "kid",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var JwkId = new JwkId$Type();
var Jwk$Type = class extends import_runtime7.MessageType {
  constructor() {
    super("sui.rpc.v2.Jwk", [
      {
        no: 1,
        name: "kty",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "e",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "n",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "alg",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var Jwk = new Jwk$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/bcs.mjs
var import_runtime8 = __toESM(require_commonjs(), 1);
var Bcs$Type = class extends import_runtime8.MessageType {
  constructor() {
    super("sui.rpc.v2.Bcs", [{
      no: 1,
      name: "name",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "value",
      kind: "scalar",
      opt: true,
      T: 12
    }]);
  }
};
var Bcs = new Bcs$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/object.mjs
var import_runtime9 = __toESM(require_commonjs(), 1);
var Object$Type = class extends import_runtime9.MessageType {
  constructor() {
    super("sui.rpc.v2.Object", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "owner",
        kind: "message",
        T: () => Owner2
      },
      {
        no: 6,
        name: "object_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 7,
        name: "has_public_transfer",
        kind: "scalar",
        opt: true,
        T: 8
      },
      {
        no: 8,
        name: "contents",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 9,
        name: "package",
        kind: "message",
        T: () => Package
      },
      {
        no: 10,
        name: "previous_transaction",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 11,
        name: "storage_rebate",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 100,
        name: "json",
        kind: "message",
        T: () => Value
      },
      {
        no: 101,
        name: "balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 102,
        name: "display",
        kind: "message",
        T: () => Display
      }
    ]);
  }
};
var Object$1 = new Object$Type();
var ObjectSet$Type = class extends import_runtime9.MessageType {
  constructor() {
    super("sui.rpc.v2.ObjectSet", [{
      no: 1,
      name: "objects",
      kind: "message",
      repeat: 2,
      T: () => Object$1
    }]);
  }
};
var ObjectSet = new ObjectSet$Type();
var Display$Type = class extends import_runtime9.MessageType {
  constructor() {
    super("sui.rpc.v2.Display", [{
      no: 1,
      name: "output",
      kind: "message",
      T: () => Value
    }, {
      no: 2,
      name: "errors",
      kind: "message",
      T: () => Value
    }]);
  }
};
var Display = new Display$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/google/protobuf/timestamp.mjs
var import_runtime10 = __toESM(require_commonjs(), 1);
var Timestamp$Type = class extends import_runtime10.MessageType {
  constructor() {
    super("google.protobuf.Timestamp", [{
      no: 1,
      name: "seconds",
      kind: "scalar",
      T: 3,
      L: 0
    }, {
      no: 2,
      name: "nanos",
      kind: "scalar",
      T: 5
    }]);
  }
  /**
  * Creates a new `Timestamp` for the current time.
  */
  now() {
    const msg = this.create();
    const ms = Date.now();
    msg.seconds = import_runtime10.PbLong.from(Math.floor(ms / 1e3)).toBigInt();
    msg.nanos = ms % 1e3 * 1e6;
    return msg;
  }
  /**
  * Converts a `Timestamp` to a JavaScript Date.
  */
  toDate(message) {
    return new Date(import_runtime10.PbLong.from(message.seconds).toNumber() * 1e3 + Math.ceil(message.nanos / 1e6));
  }
  /**
  * Converts a JavaScript Date to a `Timestamp`.
  */
  fromDate(date) {
    const msg = this.create();
    const ms = date.getTime();
    msg.seconds = import_runtime10.PbLong.from(Math.floor(ms / 1e3)).toBigInt();
    msg.nanos = (ms % 1e3 + (ms < 0 && ms % 1e3 !== 0 ? 1e3 : 0)) * 1e6;
    return msg;
  }
  /**
  * In JSON format, the `Timestamp` type is encoded as a string
  * in the RFC 3339 format.
  */
  internalJsonWrite(message, options) {
    let ms = import_runtime10.PbLong.from(message.seconds).toNumber() * 1e3;
    if (ms < Date.parse("0001-01-01T00:00:00Z") || ms > Date.parse("9999-12-31T23:59:59Z")) throw new Error("Unable to encode Timestamp to JSON. Must be from 0001-01-01T00:00:00Z to 9999-12-31T23:59:59Z inclusive.");
    if (message.nanos < 0) throw new Error("Unable to encode invalid Timestamp to JSON. Nanos must not be negative.");
    let z = "Z";
    if (message.nanos > 0) {
      let nanosStr = (message.nanos + 1e9).toString().substring(1);
      if (nanosStr.substring(3) === "000000") z = "." + nanosStr.substring(0, 3) + "Z";
      else if (nanosStr.substring(6) === "000") z = "." + nanosStr.substring(0, 6) + "Z";
      else z = "." + nanosStr + "Z";
    }
    return new Date(ms).toISOString().replace(".000Z", z);
  }
  /**
  * In JSON format, the `Timestamp` type is encoded as a string
  * in the RFC 3339 format.
  */
  internalJsonRead(json, options, target) {
    if (typeof json !== "string") throw new Error("Unable to parse Timestamp from JSON " + (0, import_runtime10.typeofJsonValue)(json) + ".");
    let matches = json.match(/^([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})(?:Z|\.([0-9]{3,9})Z|([+-][0-9][0-9]:[0-9][0-9]))$/);
    if (!matches) throw new Error("Unable to parse Timestamp from JSON. Invalid format.");
    let ms = Date.parse(matches[1] + "-" + matches[2] + "-" + matches[3] + "T" + matches[4] + ":" + matches[5] + ":" + matches[6] + (matches[8] ? matches[8] : "Z"));
    if (Number.isNaN(ms)) throw new Error("Unable to parse Timestamp from JSON. Invalid value.");
    if (ms < Date.parse("0001-01-01T00:00:00Z") || ms > Date.parse("9999-12-31T23:59:59Z")) throw new globalThis.Error("Unable to parse Timestamp from JSON. Must be from 0001-01-01T00:00:00Z to 9999-12-31T23:59:59Z inclusive.");
    if (!target) target = this.create();
    target.seconds = import_runtime10.PbLong.from(ms / 1e3).toBigInt();
    target.nanos = 0;
    if (matches[7]) target.nanos = parseInt("1" + matches[7] + "0".repeat(9 - matches[7].length)) - 1e9;
    return target;
  }
};
var Timestamp = new Timestamp$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/object_reference.mjs
var import_runtime11 = __toESM(require_commonjs(), 1);
var ObjectReference$Type = class extends import_runtime11.MessageType {
  constructor() {
    super("sui.rpc.v2.ObjectReference", [
      {
        no: 1,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var ObjectReference = new ObjectReference$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/transaction.mjs
var import_runtime12 = __toESM(require_commonjs(), 1);
var TransactionExpiration_TransactionExpirationKind = /* @__PURE__ */ (function(TransactionExpiration_TransactionExpirationKind$1) {
  TransactionExpiration_TransactionExpirationKind$1[TransactionExpiration_TransactionExpirationKind$1["TRANSACTION_EXPIRATION_KIND_UNKNOWN"] = 0] = "TRANSACTION_EXPIRATION_KIND_UNKNOWN";
  TransactionExpiration_TransactionExpirationKind$1[TransactionExpiration_TransactionExpirationKind$1["NONE"] = 1] = "NONE";
  TransactionExpiration_TransactionExpirationKind$1[TransactionExpiration_TransactionExpirationKind$1["EPOCH"] = 2] = "EPOCH";
  TransactionExpiration_TransactionExpirationKind$1[TransactionExpiration_TransactionExpirationKind$1["VALID_DURING"] = 3] = "VALID_DURING";
  TransactionExpiration_TransactionExpirationKind$1[TransactionExpiration_TransactionExpirationKind$1["VALIDITY"] = 4] = "VALIDITY";
  return TransactionExpiration_TransactionExpirationKind$1;
})({});
var TransactionKind_Kind = /* @__PURE__ */ (function(TransactionKind_Kind$1) {
  TransactionKind_Kind$1[TransactionKind_Kind$1["KIND_UNKNOWN"] = 0] = "KIND_UNKNOWN";
  TransactionKind_Kind$1[TransactionKind_Kind$1["PROGRAMMABLE_TRANSACTION"] = 1] = "PROGRAMMABLE_TRANSACTION";
  TransactionKind_Kind$1[TransactionKind_Kind$1["CHANGE_EPOCH"] = 2] = "CHANGE_EPOCH";
  TransactionKind_Kind$1[TransactionKind_Kind$1["GENESIS"] = 3] = "GENESIS";
  TransactionKind_Kind$1[TransactionKind_Kind$1["CONSENSUS_COMMIT_PROLOGUE_V1"] = 4] = "CONSENSUS_COMMIT_PROLOGUE_V1";
  TransactionKind_Kind$1[TransactionKind_Kind$1["AUTHENTICATOR_STATE_UPDATE"] = 5] = "AUTHENTICATOR_STATE_UPDATE";
  TransactionKind_Kind$1[TransactionKind_Kind$1["END_OF_EPOCH"] = 6] = "END_OF_EPOCH";
  TransactionKind_Kind$1[TransactionKind_Kind$1["RANDOMNESS_STATE_UPDATE"] = 7] = "RANDOMNESS_STATE_UPDATE";
  TransactionKind_Kind$1[TransactionKind_Kind$1["CONSENSUS_COMMIT_PROLOGUE_V2"] = 8] = "CONSENSUS_COMMIT_PROLOGUE_V2";
  TransactionKind_Kind$1[TransactionKind_Kind$1["CONSENSUS_COMMIT_PROLOGUE_V3"] = 9] = "CONSENSUS_COMMIT_PROLOGUE_V3";
  TransactionKind_Kind$1[TransactionKind_Kind$1["CONSENSUS_COMMIT_PROLOGUE_V4"] = 10] = "CONSENSUS_COMMIT_PROLOGUE_V4";
  TransactionKind_Kind$1[TransactionKind_Kind$1["PROGRAMMABLE_SYSTEM_TRANSACTION"] = 11] = "PROGRAMMABLE_SYSTEM_TRANSACTION";
  return TransactionKind_Kind$1;
})({});
var EndOfEpochTransactionKind_Kind = /* @__PURE__ */ (function(EndOfEpochTransactionKind_Kind$1) {
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["KIND_UNKNOWN"] = 0] = "KIND_UNKNOWN";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["CHANGE_EPOCH"] = 1] = "CHANGE_EPOCH";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["AUTHENTICATOR_STATE_CREATE"] = 2] = "AUTHENTICATOR_STATE_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["AUTHENTICATOR_STATE_EXPIRE"] = 3] = "AUTHENTICATOR_STATE_EXPIRE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["RANDOMNESS_STATE_CREATE"] = 4] = "RANDOMNESS_STATE_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["DENY_LIST_STATE_CREATE"] = 5] = "DENY_LIST_STATE_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["BRIDGE_STATE_CREATE"] = 6] = "BRIDGE_STATE_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["BRIDGE_COMMITTEE_INIT"] = 7] = "BRIDGE_COMMITTEE_INIT";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["STORE_EXECUTION_TIME_OBSERVATIONS"] = 8] = "STORE_EXECUTION_TIME_OBSERVATIONS";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["ACCUMULATOR_ROOT_CREATE"] = 9] = "ACCUMULATOR_ROOT_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["COIN_REGISTRY_CREATE"] = 10] = "COIN_REGISTRY_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["DISPLAY_REGISTRY_CREATE"] = 11] = "DISPLAY_REGISTRY_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["ADDRESS_ALIAS_STATE_CREATE"] = 12] = "ADDRESS_ALIAS_STATE_CREATE";
  EndOfEpochTransactionKind_Kind$1[EndOfEpochTransactionKind_Kind$1["WRITE_ACCUMULATOR_STORAGE_COST"] = 13] = "WRITE_ACCUMULATOR_STORAGE_COST";
  return EndOfEpochTransactionKind_Kind$1;
})({});
var ExecutionTimeObservation_ExecutionTimeObservationKind = /* @__PURE__ */ (function(ExecutionTimeObservation_ExecutionTimeObservationKind$1) {
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["EXECUTION_TIME_OBSERVATION_KIND_UNKNOWN"] = 0] = "EXECUTION_TIME_OBSERVATION_KIND_UNKNOWN";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["MOVE_ENTRY_POINT"] = 1] = "MOVE_ENTRY_POINT";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["TRANSFER_OBJECTS"] = 2] = "TRANSFER_OBJECTS";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["SPLIT_COINS"] = 3] = "SPLIT_COINS";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["MERGE_COINS"] = 4] = "MERGE_COINS";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["PUBLISH"] = 5] = "PUBLISH";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["MAKE_MOVE_VECTOR"] = 6] = "MAKE_MOVE_VECTOR";
  ExecutionTimeObservation_ExecutionTimeObservationKind$1[ExecutionTimeObservation_ExecutionTimeObservationKind$1["UPGRADE"] = 7] = "UPGRADE";
  return ExecutionTimeObservation_ExecutionTimeObservationKind$1;
})({});
var Transaction$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.Transaction", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 5
      },
      {
        no: 4,
        name: "kind",
        kind: "message",
        T: () => TransactionKind2
      },
      {
        no: 5,
        name: "sender",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 6,
        name: "gas_payment",
        kind: "message",
        T: () => GasPayment
      },
      {
        no: 7,
        name: "expiration",
        kind: "message",
        T: () => TransactionExpiration4
      }
    ]);
  }
};
var Transaction = new Transaction$Type();
var GasPayment$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.GasPayment", [
      {
        no: 1,
        name: "objects",
        kind: "message",
        repeat: 2,
        T: () => ObjectReference
      },
      {
        no: 2,
        name: "owner",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "price",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "budget",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var GasPayment = new GasPayment$Type();
var TransactionExpiration$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.TransactionExpiration", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.TransactionExpiration.TransactionExpirationKind", TransactionExpiration_TransactionExpirationKind]
      },
      {
        no: 2,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "min_epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "min_timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 5,
        name: "max_timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 6,
        name: "chain",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 7,
        name: "nonce",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 8,
        name: "allowed_proposers",
        kind: "message",
        T: () => AllowedProposers2
      }
    ]);
  }
};
var TransactionExpiration4 = new TransactionExpiration$Type();
var AllowedProposers$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.AllowedProposers", [{
      no: 1,
      name: "epoch",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "proposers",
      kind: "scalar",
      repeat: 1,
      T: 13
    }]);
  }
};
var AllowedProposers2 = new AllowedProposers$Type();
var TransactionKind$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.TransactionKind", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.TransactionKind.Kind", TransactionKind_Kind]
      },
      {
        no: 2,
        name: "programmable_transaction",
        kind: "message",
        oneof: "data",
        T: () => ProgrammableTransaction2
      },
      {
        no: 3,
        name: "change_epoch",
        kind: "message",
        oneof: "data",
        T: () => ChangeEpoch2
      },
      {
        no: 4,
        name: "genesis",
        kind: "message",
        oneof: "data",
        T: () => GenesisTransaction2
      },
      {
        no: 5,
        name: "consensus_commit_prologue",
        kind: "message",
        oneof: "data",
        T: () => ConsensusCommitPrologue2
      },
      {
        no: 6,
        name: "authenticator_state_update",
        kind: "message",
        oneof: "data",
        T: () => AuthenticatorStateUpdate2
      },
      {
        no: 7,
        name: "end_of_epoch",
        kind: "message",
        oneof: "data",
        T: () => EndOfEpochTransaction
      },
      {
        no: 8,
        name: "randomness_state_update",
        kind: "message",
        oneof: "data",
        T: () => RandomnessStateUpdate2
      }
    ]);
  }
};
var TransactionKind2 = new TransactionKind$Type();
var ProgrammableTransaction$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.ProgrammableTransaction", [{
      no: 1,
      name: "inputs",
      kind: "message",
      repeat: 2,
      T: () => Input
    }, {
      no: 2,
      name: "commands",
      kind: "message",
      repeat: 2,
      T: () => Command2
    }]);
  }
};
var ProgrammableTransaction2 = new ProgrammableTransaction$Type();
var Command$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.Command", [
      {
        no: 1,
        name: "move_call",
        kind: "message",
        oneof: "command",
        T: () => MoveCall
      },
      {
        no: 2,
        name: "transfer_objects",
        kind: "message",
        oneof: "command",
        T: () => TransferObjects
      },
      {
        no: 3,
        name: "split_coins",
        kind: "message",
        oneof: "command",
        T: () => SplitCoins
      },
      {
        no: 4,
        name: "merge_coins",
        kind: "message",
        oneof: "command",
        T: () => MergeCoins
      },
      {
        no: 5,
        name: "publish",
        kind: "message",
        oneof: "command",
        T: () => Publish
      },
      {
        no: 6,
        name: "make_move_vector",
        kind: "message",
        oneof: "command",
        T: () => MakeMoveVector
      },
      {
        no: 7,
        name: "upgrade",
        kind: "message",
        oneof: "command",
        T: () => Upgrade
      }
    ]);
  }
};
var Command2 = new Command$Type();
var MoveCall$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.MoveCall", [
      {
        no: 1,
        name: "package",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "module",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "function",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "type_arguments",
        kind: "scalar",
        repeat: 2,
        T: 9
      },
      {
        no: 5,
        name: "arguments",
        kind: "message",
        repeat: 2,
        T: () => Argument2
      }
    ]);
  }
};
var MoveCall = new MoveCall$Type();
var TransferObjects$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.TransferObjects", [{
      no: 1,
      name: "objects",
      kind: "message",
      repeat: 2,
      T: () => Argument2
    }, {
      no: 2,
      name: "address",
      kind: "message",
      T: () => Argument2
    }]);
  }
};
var TransferObjects = new TransferObjects$Type();
var SplitCoins$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.SplitCoins", [{
      no: 1,
      name: "coin",
      kind: "message",
      T: () => Argument2
    }, {
      no: 2,
      name: "amounts",
      kind: "message",
      repeat: 2,
      T: () => Argument2
    }]);
  }
};
var SplitCoins = new SplitCoins$Type();
var MergeCoins$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.MergeCoins", [{
      no: 1,
      name: "coin",
      kind: "message",
      T: () => Argument2
    }, {
      no: 2,
      name: "coins_to_merge",
      kind: "message",
      repeat: 2,
      T: () => Argument2
    }]);
  }
};
var MergeCoins = new MergeCoins$Type();
var Publish$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.Publish", [{
      no: 1,
      name: "modules",
      kind: "scalar",
      repeat: 2,
      T: 12
    }, {
      no: 2,
      name: "dependencies",
      kind: "scalar",
      repeat: 2,
      T: 9
    }]);
  }
};
var Publish = new Publish$Type();
var MakeMoveVector$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.MakeMoveVector", [{
      no: 1,
      name: "element_type",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "elements",
      kind: "message",
      repeat: 2,
      T: () => Argument2
    }]);
  }
};
var MakeMoveVector = new MakeMoveVector$Type();
var Upgrade$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.Upgrade", [
      {
        no: 1,
        name: "modules",
        kind: "scalar",
        repeat: 2,
        T: 12
      },
      {
        no: 2,
        name: "dependencies",
        kind: "scalar",
        repeat: 2,
        T: 9
      },
      {
        no: 3,
        name: "package",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "ticket",
        kind: "message",
        T: () => Argument2
      }
    ]);
  }
};
var Upgrade = new Upgrade$Type();
var RandomnessStateUpdate$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.RandomnessStateUpdate", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "randomness_round",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "random_bytes",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 4,
        name: "randomness_object_initial_shared_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var RandomnessStateUpdate2 = new RandomnessStateUpdate$Type();
var ChangeEpoch$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.ChangeEpoch", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "protocol_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "storage_charge",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "computation_charge",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "storage_rebate",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "non_refundable_storage_fee",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "epoch_start_timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 8,
        name: "system_packages",
        kind: "message",
        repeat: 2,
        T: () => SystemPackage
      }
    ]);
  }
};
var ChangeEpoch2 = new ChangeEpoch$Type();
var SystemPackage$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.SystemPackage", [
      {
        no: 1,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "modules",
        kind: "scalar",
        repeat: 2,
        T: 12
      },
      {
        no: 3,
        name: "dependencies",
        kind: "scalar",
        repeat: 2,
        T: 9
      }
    ]);
  }
};
var SystemPackage = new SystemPackage$Type();
var GenesisTransaction$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.GenesisTransaction", [{
      no: 1,
      name: "objects",
      kind: "message",
      repeat: 2,
      T: () => Object$1
    }]);
  }
};
var GenesisTransaction2 = new GenesisTransaction$Type();
var ConsensusCommitPrologue$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.ConsensusCommitPrologue", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "round",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "commit_timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 4,
        name: "consensus_commit_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "sub_dag_index",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "consensus_determined_version_assignments",
        kind: "message",
        T: () => ConsensusDeterminedVersionAssignments2
      },
      {
        no: 7,
        name: "additional_state_digest",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var ConsensusCommitPrologue2 = new ConsensusCommitPrologue$Type();
var VersionAssignment$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.VersionAssignment", [
      {
        no: 1,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "start_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var VersionAssignment = new VersionAssignment$Type();
var CanceledTransaction$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.CanceledTransaction", [{
      no: 1,
      name: "digest",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "version_assignments",
      kind: "message",
      repeat: 2,
      T: () => VersionAssignment
    }]);
  }
};
var CanceledTransaction = new CanceledTransaction$Type();
var ConsensusDeterminedVersionAssignments$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.ConsensusDeterminedVersionAssignments", [{
      no: 1,
      name: "version",
      kind: "scalar",
      opt: true,
      T: 5
    }, {
      no: 3,
      name: "canceled_transactions",
      kind: "message",
      repeat: 2,
      T: () => CanceledTransaction
    }]);
  }
};
var ConsensusDeterminedVersionAssignments2 = new ConsensusDeterminedVersionAssignments$Type();
var AuthenticatorStateUpdate$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.AuthenticatorStateUpdate", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "round",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "new_active_jwks",
        kind: "message",
        repeat: 2,
        T: () => ActiveJwk2
      },
      {
        no: 4,
        name: "authenticator_object_initial_shared_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var AuthenticatorStateUpdate2 = new AuthenticatorStateUpdate$Type();
var ActiveJwk$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.ActiveJwk", [
      {
        no: 1,
        name: "id",
        kind: "message",
        T: () => JwkId
      },
      {
        no: 2,
        name: "jwk",
        kind: "message",
        T: () => Jwk
      },
      {
        no: 3,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var ActiveJwk2 = new ActiveJwk$Type();
var EndOfEpochTransaction$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.EndOfEpochTransaction", [{
      no: 1,
      name: "transactions",
      kind: "message",
      repeat: 2,
      T: () => EndOfEpochTransactionKind2
    }]);
  }
};
var EndOfEpochTransaction = new EndOfEpochTransaction$Type();
var EndOfEpochTransactionKind$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.EndOfEpochTransactionKind", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.EndOfEpochTransactionKind.Kind", EndOfEpochTransactionKind_Kind]
      },
      {
        no: 2,
        name: "change_epoch",
        kind: "message",
        oneof: "data",
        T: () => ChangeEpoch2
      },
      {
        no: 3,
        name: "authenticator_state_expire",
        kind: "message",
        oneof: "data",
        T: () => AuthenticatorStateExpire2
      },
      {
        no: 4,
        name: "execution_time_observations",
        kind: "message",
        oneof: "data",
        T: () => ExecutionTimeObservations
      },
      {
        no: 5,
        name: "bridge_chain_id",
        kind: "scalar",
        oneof: "data",
        T: 9
      },
      {
        no: 6,
        name: "bridge_object_version",
        kind: "scalar",
        oneof: "data",
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "storage_cost",
        kind: "scalar",
        oneof: "data",
        T: 4,
        L: 0
      }
    ]);
  }
};
var EndOfEpochTransactionKind2 = new EndOfEpochTransactionKind$Type();
var AuthenticatorStateExpire$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.AuthenticatorStateExpire", [{
      no: 1,
      name: "min_epoch",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "authenticator_object_initial_shared_version",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var AuthenticatorStateExpire2 = new AuthenticatorStateExpire$Type();
var ExecutionTimeObservations$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.ExecutionTimeObservations", [{
      no: 1,
      name: "version",
      kind: "scalar",
      opt: true,
      T: 5
    }, {
      no: 2,
      name: "observations",
      kind: "message",
      repeat: 2,
      T: () => ExecutionTimeObservation
    }]);
  }
};
var ExecutionTimeObservations = new ExecutionTimeObservations$Type();
var ExecutionTimeObservation$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.ExecutionTimeObservation", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.ExecutionTimeObservation.ExecutionTimeObservationKind", ExecutionTimeObservation_ExecutionTimeObservationKind]
      },
      {
        no: 2,
        name: "move_entry_point",
        kind: "message",
        T: () => MoveCall
      },
      {
        no: 3,
        name: "validator_observations",
        kind: "message",
        repeat: 2,
        T: () => ValidatorExecutionTimeObservation
      }
    ]);
  }
};
var ExecutionTimeObservation = new ExecutionTimeObservation$Type();
var ValidatorExecutionTimeObservation$Type = class extends import_runtime12.MessageType {
  constructor() {
    super("sui.rpc.v2.ValidatorExecutionTimeObservation", [{
      no: 1,
      name: "validator",
      kind: "scalar",
      opt: true,
      T: 12
    }, {
      no: 2,
      name: "duration",
      kind: "message",
      T: () => Duration
    }]);
  }
};
var ValidatorExecutionTimeObservation = new ValidatorExecutionTimeObservation$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/client/transaction-resolver.mjs
function millisecondsToGrpcTimestamp(value) {
  const milliseconds = BigInt(value);
  return {
    seconds: milliseconds / 1000n,
    nanos: Number(milliseconds % 1000n) * 1e6
  };
}
function grpcTimestampToMilliseconds(timestamp) {
  return (timestamp.seconds * 1000n + BigInt(Math.floor(timestamp.nanos / 1e6))).toString();
}
function callArgToGrpcInput(arg) {
  switch (arg.$kind) {
    case "Pure":
      return {
        kind: Input_InputKind.PURE,
        pure: fromBase64(arg.Pure.bytes)
      };
    case "Object":
      if (arg.Object.$kind === "ImmOrOwnedObject") return {
        kind: Input_InputKind.IMMUTABLE_OR_OWNED,
        objectId: arg.Object.ImmOrOwnedObject.objectId,
        version: BigInt(arg.Object.ImmOrOwnedObject.version),
        digest: arg.Object.ImmOrOwnedObject.digest
      };
      else if (arg.Object.$kind === "SharedObject") return {
        kind: Input_InputKind.SHARED,
        objectId: arg.Object.SharedObject.objectId,
        version: BigInt(arg.Object.SharedObject.initialSharedVersion),
        mutable: arg.Object.SharedObject.mutable
      };
      else if (arg.Object.$kind === "Receiving") return {
        kind: Input_InputKind.RECEIVING,
        objectId: arg.Object.Receiving.objectId,
        version: BigInt(arg.Object.Receiving.version),
        digest: arg.Object.Receiving.digest
      };
      throw new Error(`Unknown Object kind: ${JSON.stringify(arg.Object)}`);
    case "UnresolvedObject":
      const unresolved = arg.UnresolvedObject;
      return {
        objectId: unresolved.objectId,
        version: unresolved.version ? BigInt(unresolved.version) : unresolved.initialSharedVersion ? BigInt(unresolved.initialSharedVersion) : void 0,
        digest: unresolved.digest ?? void 0,
        mutable: unresolved.mutable ?? void 0
      };
    case "UnresolvedPure":
      throw new Error("UnresolvedPure arguments must be resolved before converting to gRPC format");
    case "FundsWithdrawal": {
      const withdrawal = arg.FundsWithdrawal;
      return {
        kind: Input_InputKind.FUNDS_WITHDRAWAL,
        fundsWithdrawal: {
          amount: withdrawal.reservation.$kind === "MaxAmountU64" ? BigInt(withdrawal.reservation.MaxAmountU64) : void 0,
          coinType: withdrawal.typeArg.$kind === "Balance" ? withdrawal.typeArg.Balance : void 0,
          ...tsWithdrawFromToGrpc(withdrawal.withdrawFrom)
        }
      };
    }
    default:
      throw new Error(`Unknown CallArg kind: ${JSON.stringify(arg)}`);
  }
}
function tsWithdrawFromToGrpc(withdrawFrom) {
  switch (withdrawFrom.$kind) {
    case "Sender":
      return { source: FundsWithdrawal_Source.SENDER };
    case "Sponsor":
      return { source: FundsWithdrawal_Source.SPONSOR };
    case "SenderAllowance":
      return {
        source: FundsWithdrawal_Source.SENDER_ALLOWANCE,
        funder: withdrawFrom.SenderAllowance.funder,
        allowance: withdrawFrom.SenderAllowance.allowance
      };
    default:
      throw new Error(`Unknown WithdrawFrom kind: ${JSON.stringify(withdrawFrom)}`);
  }
}
function grpcWithdrawFromToTs(withdrawal) {
  switch (withdrawal?.source) {
    case FundsWithdrawal_Source.SPONSOR:
      return {
        $kind: "Sponsor",
        Sponsor: true
      };
    case FundsWithdrawal_Source.SENDER_ALLOWANCE:
      if (!withdrawal.funder || !withdrawal.allowance) throw new Error(`SENDER_ALLOWANCE withdrawal is missing funder or allowance: ${JSON.stringify(withdrawal)}`);
      return {
        $kind: "SenderAllowance",
        SenderAllowance: {
          funder: withdrawal.funder,
          allowance: withdrawal.allowance
        }
      };
    default:
      return {
        $kind: "Sender",
        Sender: true
      };
  }
}
function tsArgumentToGrpcArgument(arg) {
  if ("GasCoin" in arg) return { kind: Argument_ArgumentKind.GAS };
  else if ("Input" in arg) return {
    kind: Argument_ArgumentKind.INPUT,
    input: arg.Input
  };
  else if ("Result" in arg) return {
    kind: Argument_ArgumentKind.RESULT,
    result: arg.Result
  };
  else if ("NestedResult" in arg) return {
    kind: Argument_ArgumentKind.RESULT,
    result: arg.NestedResult[0],
    subresult: arg.NestedResult[1]
  };
  throw new Error(`Unknown Argument: ${JSON.stringify(arg)}`);
}
function tsCommandToGrpcCommand(cmd) {
  switch (cmd.$kind) {
    case "MoveCall":
      return { command: {
        oneofKind: "moveCall",
        moveCall: {
          package: cmd.MoveCall.package,
          module: cmd.MoveCall.module,
          function: cmd.MoveCall.function,
          typeArguments: cmd.MoveCall.typeArguments,
          arguments: cmd.MoveCall.arguments.map(tsArgumentToGrpcArgument)
        }
      } };
    case "TransferObjects":
      return { command: {
        oneofKind: "transferObjects",
        transferObjects: {
          objects: cmd.TransferObjects.objects.map(tsArgumentToGrpcArgument),
          address: tsArgumentToGrpcArgument(cmd.TransferObjects.address)
        }
      } };
    case "SplitCoins":
      return { command: {
        oneofKind: "splitCoins",
        splitCoins: {
          coin: tsArgumentToGrpcArgument(cmd.SplitCoins.coin),
          amounts: cmd.SplitCoins.amounts.map(tsArgumentToGrpcArgument)
        }
      } };
    case "MergeCoins":
      return { command: {
        oneofKind: "mergeCoins",
        mergeCoins: {
          coin: tsArgumentToGrpcArgument(cmd.MergeCoins.destination),
          coinsToMerge: cmd.MergeCoins.sources.map(tsArgumentToGrpcArgument)
        }
      } };
    case "Publish":
      return { command: {
        oneofKind: "publish",
        publish: {
          modules: cmd.Publish.modules.map((m) => fromBase64(m)),
          dependencies: cmd.Publish.dependencies
        }
      } };
    case "MakeMoveVec":
      return { command: {
        oneofKind: "makeMoveVector",
        makeMoveVector: {
          elementType: cmd.MakeMoveVec.type ?? void 0,
          elements: cmd.MakeMoveVec.elements.map(tsArgumentToGrpcArgument)
        }
      } };
    case "Upgrade":
      return { command: {
        oneofKind: "upgrade",
        upgrade: {
          modules: cmd.Upgrade.modules.map((m) => fromBase64(m)),
          dependencies: cmd.Upgrade.dependencies,
          package: cmd.Upgrade.package,
          ticket: tsArgumentToGrpcArgument(cmd.Upgrade.ticket)
        }
      } };
    default:
      throw new Error(`Unknown Command kind: ${JSON.stringify(cmd)}`);
  }
}
function transactionDataToGrpcTransaction(data) {
  const transaction = {
    version: 1,
    kind: { data: {
      oneofKind: "programmableTransaction",
      programmableTransaction: {
        inputs: data.inputs.map(callArgToGrpcInput),
        commands: data.commands.map(tsCommandToGrpcCommand)
      }
    } }
  };
  if (data.sender) transaction.sender = data.sender;
  const gasOwner = data.gasData.owner ?? data.sender;
  transaction.gasPayment = {
    objects: data.gasData.payment ? data.gasData.payment.map((ref) => ({
      objectId: ref.objectId,
      version: BigInt(ref.version),
      digest: ref.digest
    })) : [],
    price: data.gasData.price ? BigInt(data.gasData.price) : void 0,
    budget: data.gasData.budget ? BigInt(data.gasData.budget) : void 0
  };
  if (gasOwner) transaction.gasPayment.owner = gasOwner;
  if (data.expiration) {
    if ("None" in data.expiration) transaction.expiration = { kind: TransactionExpiration_TransactionExpirationKind.NONE };
    else if (data.expiration.$kind === "Epoch") transaction.expiration = {
      kind: TransactionExpiration_TransactionExpirationKind.EPOCH,
      epoch: BigInt(data.expiration.Epoch)
    };
    else if (data.expiration.$kind === "ValidDuring" || data.expiration.$kind === "Validity") {
      const validity = data.expiration.$kind === "ValidDuring" ? data.expiration.ValidDuring : data.expiration.Validity;
      const allowedProposers = data.expiration.$kind === "Validity" ? data.expiration.Validity.allowedProposers : null;
      transaction.expiration = {
        kind: data.expiration.$kind === "ValidDuring" ? TransactionExpiration_TransactionExpirationKind.VALID_DURING : TransactionExpiration_TransactionExpirationKind.VALIDITY,
        minEpoch: validity.minEpoch != null ? BigInt(validity.minEpoch) : void 0,
        epoch: validity.maxEpoch != null ? BigInt(validity.maxEpoch) : void 0,
        minTimestamp: validity.minTimestamp != null ? millisecondsToGrpcTimestamp(validity.minTimestamp) : void 0,
        maxTimestamp: validity.maxTimestamp != null ? millisecondsToGrpcTimestamp(validity.maxTimestamp) : void 0,
        chain: validity.chain,
        nonce: validity.nonce,
        allowedProposers: allowedProposers ? {
          epoch: BigInt(allowedProposers.epoch),
          proposers: assertAllowedProposersStrictlyIncreasing(allowedProposers.proposers)
        } : void 0
      };
    }
  }
  return transaction;
}
function applyGrpcResolvedTransaction(transactionData, resolvedTransaction, options) {
  const resolved = grpcTransactionToTransactionData(resolvedTransaction);
  if (options?.onlyTransactionKind) transactionData.applyResolvedData({
    ...resolved,
    sender: null,
    gasData: {
      budget: null,
      owner: null,
      payment: null,
      price: null
    },
    expiration: null
  });
  else transactionData.applyResolvedData(resolved);
}
function transactionToGrpcTransaction(transaction) {
  const snapshot = transaction.getData();
  if (!snapshot.sender) snapshot.sender = "0x0000000000000000000000000000000000000000000000000000000000000000";
  return transactionDataToGrpcTransaction(snapshot);
}
function grpcInputToCallArg(input) {
  switch (input.kind) {
    case Input_InputKind.PURE:
      return {
        $kind: "Pure",
        Pure: { bytes: toBase64(input.pure) }
      };
    case Input_InputKind.IMMUTABLE_OR_OWNED:
      return {
        $kind: "Object",
        Object: {
          $kind: "ImmOrOwnedObject",
          ImmOrOwnedObject: {
            objectId: input.objectId,
            version: input.version.toString(),
            digest: input.digest
          }
        }
      };
    case Input_InputKind.SHARED:
      return {
        $kind: "Object",
        Object: {
          $kind: "SharedObject",
          SharedObject: {
            objectId: input.objectId,
            initialSharedVersion: input.version.toString(),
            mutable: input.mutable ?? false
          }
        }
      };
    case Input_InputKind.RECEIVING:
      return {
        $kind: "Object",
        Object: {
          $kind: "Receiving",
          Receiving: {
            objectId: input.objectId,
            version: input.version.toString(),
            digest: input.digest
          }
        }
      };
    case Input_InputKind.FUNDS_WITHDRAWAL:
      return {
        $kind: "FundsWithdrawal",
        FundsWithdrawal: {
          reservation: {
            $kind: "MaxAmountU64",
            MaxAmountU64: input.fundsWithdrawal?.amount?.toString() ?? "0"
          },
          typeArg: {
            $kind: "Balance",
            Balance: input.fundsWithdrawal?.coinType ?? "0x2::sui::SUI"
          },
          withdrawFrom: grpcWithdrawFromToTs(input.fundsWithdrawal)
        }
      };
    default:
      throw new Error(`Unknown Input kind: ${JSON.stringify(input)}`);
  }
}
function grpcArgumentToTsArgument(arg) {
  switch (arg.kind) {
    case Argument_ArgumentKind.GAS:
      return {
        $kind: "GasCoin",
        GasCoin: true
      };
    case Argument_ArgumentKind.INPUT:
      return {
        $kind: "Input",
        Input: arg.input
      };
    case Argument_ArgumentKind.RESULT:
      if (arg.subresult != null) return {
        $kind: "NestedResult",
        NestedResult: [arg.result, arg.subresult]
      };
      return {
        $kind: "Result",
        Result: arg.result
      };
    default:
      throw new Error(`Unknown Argument kind: ${JSON.stringify(arg)}`);
  }
}
function grpcCommandToTsCommand(cmd) {
  const command = cmd.command;
  if (!command) throw new Error("Command is missing");
  switch (command.oneofKind) {
    case "moveCall":
      return {
        $kind: "MoveCall",
        MoveCall: {
          package: command.moveCall.package,
          module: command.moveCall.module,
          function: command.moveCall.function,
          typeArguments: command.moveCall.typeArguments ?? [],
          arguments: command.moveCall.arguments.map(grpcArgumentToTsArgument)
        }
      };
    case "transferObjects":
      return {
        $kind: "TransferObjects",
        TransferObjects: {
          objects: command.transferObjects.objects.map(grpcArgumentToTsArgument),
          address: grpcArgumentToTsArgument(command.transferObjects.address)
        }
      };
    case "splitCoins":
      return {
        $kind: "SplitCoins",
        SplitCoins: {
          coin: grpcArgumentToTsArgument(command.splitCoins.coin),
          amounts: command.splitCoins.amounts.map(grpcArgumentToTsArgument)
        }
      };
    case "mergeCoins":
      return {
        $kind: "MergeCoins",
        MergeCoins: {
          destination: grpcArgumentToTsArgument(command.mergeCoins.coin),
          sources: command.mergeCoins.coinsToMerge.map(grpcArgumentToTsArgument)
        }
      };
    case "publish":
      return {
        $kind: "Publish",
        Publish: {
          modules: command.publish.modules.map((m) => toBase64(m)),
          dependencies: command.publish.dependencies ?? []
        }
      };
    case "makeMoveVector":
      return {
        $kind: "MakeMoveVec",
        MakeMoveVec: {
          type: command.makeMoveVector.elementType ?? null,
          elements: command.makeMoveVector.elements.map(grpcArgumentToTsArgument)
        }
      };
    case "upgrade":
      return {
        $kind: "Upgrade",
        Upgrade: {
          modules: command.upgrade.modules.map((m) => toBase64(m)),
          dependencies: command.upgrade.dependencies ?? [],
          package: command.upgrade.package,
          ticket: grpcArgumentToTsArgument(command.upgrade.ticket)
        }
      };
    default:
      throw new Error(`Unknown Command kind: ${JSON.stringify(command)}`);
  }
}
function grpcTransactionToTransactionData(grpcTx) {
  const programmableTx = grpcTx.kind?.data;
  if (programmableTx?.oneofKind !== "programmableTransaction") throw new Error("Only programmable transactions are supported");
  const inputs = programmableTx.programmableTransaction.inputs.map(grpcInputToCallArg);
  const commands = programmableTx.programmableTransaction.commands.map(grpcCommandToTsCommand);
  let expiration = null;
  if (grpcTx.expiration) switch (grpcTx.expiration.kind) {
    case TransactionExpiration_TransactionExpirationKind.NONE:
      expiration = {
        $kind: "None",
        None: true
      };
      break;
    case TransactionExpiration_TransactionExpirationKind.EPOCH:
      expiration = {
        $kind: "Epoch",
        Epoch: grpcTx.expiration.epoch.toString()
      };
      break;
    case TransactionExpiration_TransactionExpirationKind.VALID_DURING:
      expiration = {
        $kind: "ValidDuring",
        ValidDuring: {
          minEpoch: grpcTx.expiration.minEpoch?.toString() ?? null,
          maxEpoch: grpcTx.expiration.epoch?.toString() ?? null,
          minTimestamp: grpcTx.expiration.minTimestamp ? grpcTimestampToMilliseconds(grpcTx.expiration.minTimestamp) : null,
          maxTimestamp: grpcTx.expiration.maxTimestamp ? grpcTimestampToMilliseconds(grpcTx.expiration.maxTimestamp) : null,
          chain: grpcTx.expiration.chain ?? "",
          nonce: grpcTx.expiration.nonce ?? 0
        }
      };
      break;
    case TransactionExpiration_TransactionExpirationKind.VALIDITY:
      expiration = {
        $kind: "Validity",
        Validity: {
          minEpoch: grpcTx.expiration.minEpoch?.toString() ?? null,
          maxEpoch: grpcTx.expiration.epoch?.toString() ?? null,
          minTimestamp: grpcTx.expiration.minTimestamp ? grpcTimestampToMilliseconds(grpcTx.expiration.minTimestamp) : null,
          maxTimestamp: grpcTx.expiration.maxTimestamp ? grpcTimestampToMilliseconds(grpcTx.expiration.maxTimestamp) : null,
          chain: grpcTx.expiration.chain ?? "",
          nonce: grpcTx.expiration.nonce ?? 0,
          allowedProposers: grpcTx.expiration.allowedProposers ? {
            epoch: grpcTx.expiration.allowedProposers.epoch?.toString() ?? "0",
            proposers: assertAllowedProposersNotEmpty(grpcTx.expiration.allowedProposers.proposers)
          } : null
        }
      };
      break;
    default:
      throw new Error(`Unknown transaction expiration kind: ${grpcTx.expiration.kind}`);
  }
  return {
    version: 2,
    sender: grpcTx.sender ?? null,
    expiration,
    gasData: {
      budget: grpcTx.gasPayment?.budget?.toString() ?? null,
      owner: grpcTx.gasPayment?.owner ?? null,
      payment: grpcTx.gasPayment?.objects?.map((obj) => ({
        objectId: obj.objectId,
        version: obj.version.toString(),
        digest: obj.digest
      })) ?? null,
      price: grpcTx.gasPayment?.price?.toString() ?? null
    },
    inputs,
    commands
  };
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/client/address-balance-transaction-expiration.mjs
async function setAddressBalanceTransactionExpirationFromSimulatedEpoch({ transactionData, client, epoch, originalTransactionData, isTransactionKindOnly, doGasSelection }) {
  if (isTransactionKindOnly || doGasSelection || originalTransactionData.expiration || originalTransactionData.gasData.payment?.length !== 0) return;
  if (transactionData.expiration && transactionData.expiration.$kind !== "None") return;
  const [{ chainIdentifier }, systemStateResult] = await Promise.all([client.core.getChainIdentifier(), epoch == null ? client.core.getCurrentSystemState() : null]);
  const currentEpoch = BigInt(epoch ?? systemStateResult.systemState.epoch);
  transactionData.expiration = {
    $kind: "ValidDuring",
    ValidDuring: {
      minEpoch: String(currentEpoch),
      maxEpoch: String(currentEpoch + 1n),
      minTimestamp: null,
      maxTimestamp: null,
      chain: chainIdentifier,
      nonce: Math.random() * 4294967296 >>> 0
    }
  };
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/execution_status.mjs
var import_runtime13 = __toESM(require_commonjs(), 1);
var ExecutionError_ExecutionErrorKind = /* @__PURE__ */ (function(ExecutionError_ExecutionErrorKind$1) {
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["EXECUTION_ERROR_KIND_UNKNOWN"] = 0] = "EXECUTION_ERROR_KIND_UNKNOWN";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INSUFFICIENT_GAS"] = 1] = "INSUFFICIENT_GAS";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INVALID_GAS_OBJECT"] = 2] = "INVALID_GAS_OBJECT";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INVARIANT_VIOLATION"] = 3] = "INVARIANT_VIOLATION";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["FEATURE_NOT_YET_SUPPORTED"] = 4] = "FEATURE_NOT_YET_SUPPORTED";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["OBJECT_TOO_BIG"] = 5] = "OBJECT_TOO_BIG";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["PACKAGE_TOO_BIG"] = 6] = "PACKAGE_TOO_BIG";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["CIRCULAR_OBJECT_OWNERSHIP"] = 7] = "CIRCULAR_OBJECT_OWNERSHIP";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INSUFFICIENT_COIN_BALANCE"] = 8] = "INSUFFICIENT_COIN_BALANCE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["COIN_BALANCE_OVERFLOW"] = 9] = "COIN_BALANCE_OVERFLOW";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["PUBLISH_ERROR_NON_ZERO_ADDRESS"] = 10] = "PUBLISH_ERROR_NON_ZERO_ADDRESS";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["SUI_MOVE_VERIFICATION_ERROR"] = 11] = "SUI_MOVE_VERIFICATION_ERROR";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["MOVE_PRIMITIVE_RUNTIME_ERROR"] = 12] = "MOVE_PRIMITIVE_RUNTIME_ERROR";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["MOVE_ABORT"] = 13] = "MOVE_ABORT";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["VM_VERIFICATION_OR_DESERIALIZATION_ERROR"] = 14] = "VM_VERIFICATION_OR_DESERIALIZATION_ERROR";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["VM_INVARIANT_VIOLATION"] = 15] = "VM_INVARIANT_VIOLATION";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["FUNCTION_NOT_FOUND"] = 16] = "FUNCTION_NOT_FOUND";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["ARITY_MISMATCH"] = 17] = "ARITY_MISMATCH";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["TYPE_ARITY_MISMATCH"] = 18] = "TYPE_ARITY_MISMATCH";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["NON_ENTRY_FUNCTION_INVOKED"] = 19] = "NON_ENTRY_FUNCTION_INVOKED";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["COMMAND_ARGUMENT_ERROR"] = 20] = "COMMAND_ARGUMENT_ERROR";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["TYPE_ARGUMENT_ERROR"] = 21] = "TYPE_ARGUMENT_ERROR";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["UNUSED_VALUE_WITHOUT_DROP"] = 22] = "UNUSED_VALUE_WITHOUT_DROP";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INVALID_PUBLIC_FUNCTION_RETURN_TYPE"] = 23] = "INVALID_PUBLIC_FUNCTION_RETURN_TYPE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INVALID_TRANSFER_OBJECT"] = 24] = "INVALID_TRANSFER_OBJECT";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["EFFECTS_TOO_LARGE"] = 25] = "EFFECTS_TOO_LARGE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["PUBLISH_UPGRADE_MISSING_DEPENDENCY"] = 26] = "PUBLISH_UPGRADE_MISSING_DEPENDENCY";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["PUBLISH_UPGRADE_DEPENDENCY_DOWNGRADE"] = 27] = "PUBLISH_UPGRADE_DEPENDENCY_DOWNGRADE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["PACKAGE_UPGRADE_ERROR"] = 28] = "PACKAGE_UPGRADE_ERROR";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["WRITTEN_OBJECTS_TOO_LARGE"] = 29] = "WRITTEN_OBJECTS_TOO_LARGE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["CERTIFICATE_DENIED"] = 30] = "CERTIFICATE_DENIED";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["SUI_MOVE_VERIFICATION_TIMEDOUT"] = 31] = "SUI_MOVE_VERIFICATION_TIMEDOUT";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["CONSENSUS_OBJECT_OPERATION_NOT_ALLOWED"] = 32] = "CONSENSUS_OBJECT_OPERATION_NOT_ALLOWED";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INPUT_OBJECT_DELETED"] = 33] = "INPUT_OBJECT_DELETED";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["EXECUTION_CANCELED_DUE_TO_CONSENSUS_OBJECT_CONGESTION"] = 34] = "EXECUTION_CANCELED_DUE_TO_CONSENSUS_OBJECT_CONGESTION";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["ADDRESS_DENIED_FOR_COIN"] = 35] = "ADDRESS_DENIED_FOR_COIN";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["COIN_TYPE_GLOBAL_PAUSE"] = 36] = "COIN_TYPE_GLOBAL_PAUSE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["EXECUTION_CANCELED_DUE_TO_RANDOMNESS_UNAVAILABLE"] = 37] = "EXECUTION_CANCELED_DUE_TO_RANDOMNESS_UNAVAILABLE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["MOVE_VECTOR_ELEM_TOO_BIG"] = 38] = "MOVE_VECTOR_ELEM_TOO_BIG";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["MOVE_RAW_VALUE_TOO_BIG"] = 39] = "MOVE_RAW_VALUE_TOO_BIG";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INVALID_LINKAGE"] = 40] = "INVALID_LINKAGE";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["INSUFFICIENT_FUNDS_FOR_WITHDRAW"] = 41] = "INSUFFICIENT_FUNDS_FOR_WITHDRAW";
  ExecutionError_ExecutionErrorKind$1[ExecutionError_ExecutionErrorKind$1["NON_EXCLUSIVE_WRITE_INPUT_OBJECT_MODIFIED"] = 42] = "NON_EXCLUSIVE_WRITE_INPUT_OBJECT_MODIFIED";
  return ExecutionError_ExecutionErrorKind$1;
})({});
var CommandArgumentError_CommandArgumentErrorKind = /* @__PURE__ */ (function(CommandArgumentError_CommandArgumentErrorKind$1) {
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["COMMAND_ARGUMENT_ERROR_KIND_UNKNOWN"] = 0] = "COMMAND_ARGUMENT_ERROR_KIND_UNKNOWN";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["TYPE_MISMATCH"] = 1] = "TYPE_MISMATCH";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_BCS_BYTES"] = 2] = "INVALID_BCS_BYTES";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_USAGE_OF_PURE_ARGUMENT"] = 3] = "INVALID_USAGE_OF_PURE_ARGUMENT";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_ARGUMENT_TO_PRIVATE_ENTRY_FUNCTION"] = 4] = "INVALID_ARGUMENT_TO_PRIVATE_ENTRY_FUNCTION";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INDEX_OUT_OF_BOUNDS"] = 5] = "INDEX_OUT_OF_BOUNDS";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["SECONDARY_INDEX_OUT_OF_BOUNDS"] = 6] = "SECONDARY_INDEX_OUT_OF_BOUNDS";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_RESULT_ARITY"] = 7] = "INVALID_RESULT_ARITY";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_GAS_COIN_USAGE"] = 8] = "INVALID_GAS_COIN_USAGE";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_VALUE_USAGE"] = 9] = "INVALID_VALUE_USAGE";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_OBJECT_BY_VALUE"] = 10] = "INVALID_OBJECT_BY_VALUE";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_OBJECT_BY_MUT_REF"] = 11] = "INVALID_OBJECT_BY_MUT_REF";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["CONSENSUS_OBJECT_OPERATION_NOT_ALLOWED"] = 12] = "CONSENSUS_OBJECT_OPERATION_NOT_ALLOWED";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_ARGUMENT_ARITY"] = 13] = "INVALID_ARGUMENT_ARITY";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_TRANSFER_OBJECT"] = 14] = "INVALID_TRANSFER_OBJECT";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_MAKE_MOVE_VEC_NON_OBJECT_ARGUMENT"] = 15] = "INVALID_MAKE_MOVE_VEC_NON_OBJECT_ARGUMENT";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["ARGUMENT_WITHOUT_VALUE"] = 16] = "ARGUMENT_WITHOUT_VALUE";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["CANNOT_MOVE_BORROWED_VALUE"] = 17] = "CANNOT_MOVE_BORROWED_VALUE";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["CANNOT_WRITE_TO_EXTENDED_REFERENCE"] = 18] = "CANNOT_WRITE_TO_EXTENDED_REFERENCE";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_REFERENCE_ARGUMENT"] = 19] = "INVALID_REFERENCE_ARGUMENT";
  CommandArgumentError_CommandArgumentErrorKind$1[CommandArgumentError_CommandArgumentErrorKind$1["INVALID_TX_CONTEXT"] = 20] = "INVALID_TX_CONTEXT";
  return CommandArgumentError_CommandArgumentErrorKind$1;
})({});
var PackageUpgradeError_PackageUpgradeErrorKind = /* @__PURE__ */ (function(PackageUpgradeError_PackageUpgradeErrorKind$1) {
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["PACKAGE_UPGRADE_ERROR_KIND_UNKNOWN"] = 0] = "PACKAGE_UPGRADE_ERROR_KIND_UNKNOWN";
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["UNABLE_TO_FETCH_PACKAGE"] = 1] = "UNABLE_TO_FETCH_PACKAGE";
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["NOT_A_PACKAGE"] = 2] = "NOT_A_PACKAGE";
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["INCOMPATIBLE_UPGRADE"] = 3] = "INCOMPATIBLE_UPGRADE";
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["DIGEST_DOES_NOT_MATCH"] = 4] = "DIGEST_DOES_NOT_MATCH";
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["UNKNOWN_UPGRADE_POLICY"] = 5] = "UNKNOWN_UPGRADE_POLICY";
  PackageUpgradeError_PackageUpgradeErrorKind$1[PackageUpgradeError_PackageUpgradeErrorKind$1["PACKAGE_ID_DOES_NOT_MATCH"] = 6] = "PACKAGE_ID_DOES_NOT_MATCH";
  return PackageUpgradeError_PackageUpgradeErrorKind$1;
})({});
var TypeArgumentError_TypeArgumentErrorKind = /* @__PURE__ */ (function(TypeArgumentError_TypeArgumentErrorKind$1) {
  TypeArgumentError_TypeArgumentErrorKind$1[TypeArgumentError_TypeArgumentErrorKind$1["TYPE_ARGUMENT_ERROR_KIND_UNKNOWN"] = 0] = "TYPE_ARGUMENT_ERROR_KIND_UNKNOWN";
  TypeArgumentError_TypeArgumentErrorKind$1[TypeArgumentError_TypeArgumentErrorKind$1["TYPE_NOT_FOUND"] = 1] = "TYPE_NOT_FOUND";
  TypeArgumentError_TypeArgumentErrorKind$1[TypeArgumentError_TypeArgumentErrorKind$1["CONSTRAINT_NOT_SATISFIED"] = 2] = "CONSTRAINT_NOT_SATISFIED";
  return TypeArgumentError_TypeArgumentErrorKind$1;
})({});
var ExecutionStatus$Type = class extends import_runtime13.MessageType {
  constructor() {
    super("sui.rpc.v2.ExecutionStatus", [{
      no: 1,
      name: "success",
      kind: "scalar",
      opt: true,
      T: 8
    }, {
      no: 2,
      name: "error",
      kind: "message",
      T: () => ExecutionError
    }]);
  }
};
var ExecutionStatus2 = new ExecutionStatus$Type();
var ExecutionError$Type = class extends import_runtime13.MessageType {
  constructor() {
    super("sui.rpc.v2.ExecutionError", [
      {
        no: 1,
        name: "description",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "command",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.ExecutionError.ExecutionErrorKind", ExecutionError_ExecutionErrorKind]
      },
      {
        no: 4,
        name: "abort",
        kind: "message",
        oneof: "errorDetails",
        T: () => MoveAbort
      },
      {
        no: 5,
        name: "size_error",
        kind: "message",
        oneof: "errorDetails",
        T: () => SizeError
      },
      {
        no: 6,
        name: "command_argument_error",
        kind: "message",
        oneof: "errorDetails",
        T: () => CommandArgumentError2
      },
      {
        no: 7,
        name: "type_argument_error",
        kind: "message",
        oneof: "errorDetails",
        T: () => TypeArgumentError2
      },
      {
        no: 8,
        name: "package_upgrade_error",
        kind: "message",
        oneof: "errorDetails",
        T: () => PackageUpgradeError2
      },
      {
        no: 9,
        name: "index_error",
        kind: "message",
        oneof: "errorDetails",
        T: () => IndexError
      },
      {
        no: 10,
        name: "object_id",
        kind: "scalar",
        oneof: "errorDetails",
        T: 9
      },
      {
        no: 11,
        name: "coin_deny_list_error",
        kind: "message",
        oneof: "errorDetails",
        T: () => CoinDenyListError
      },
      {
        no: 12,
        name: "congested_objects",
        kind: "message",
        oneof: "errorDetails",
        T: () => CongestedObjects
      }
    ]);
  }
};
var ExecutionError = new ExecutionError$Type();
var MoveAbort$Type = class extends import_runtime13.MessageType {
  constructor() {
    super("sui.rpc.v2.MoveAbort", [
      {
        no: 1,
        name: "abort_code",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "location",
        kind: "message",
        T: () => MoveLocation2
      },
      {
        no: 3,
        name: "clever_error",
        kind: "message",
        T: () => CleverError
      }
    ]);
  }
};
var MoveAbort = new MoveAbort$Type();
var MoveLocation$Type = class extends import_runtime13.MessageType {
  constructor() {
    super("sui.rpc.v2.MoveLocation", [
      {
        no: 1,
        name: "package",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "module",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "function",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 4,
        name: "instruction",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 5,
        name: "function_name",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var MoveLocation2 = new MoveLocation$Type();
var CleverError$Type = class extends import_runtime13.MessageType {
  constructor() {
    super("sui.rpc.v2.CleverError", [
      {
        no: 1,
        name: "error_code",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "line_number",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "constant_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "constant_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "rendered",
        kind: "scalar",
        oneof: "value",
        T: 9
      },
      {
        no: 6,
        name: "raw",
        kind: "scalar",
        oneof: "value",
        T: 12
      }
    ]);
  }
};
var CleverError = new CleverError$Type();
var SizeError$Type = class extends import_runtime13.MessageType {
  constructor() {
    super("sui.rpc.v2.SizeError", [{
      no: 1,
      name: "size",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "max_size",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var SizeError = new SizeError$Type();
var IndexError$Type = class extends import_runtime13.MessageType {
  constructor() {
    super("sui.rpc.v2.IndexError", [{
      no: 1,
      name: "index",
      kind: "scalar",
      opt: true,
      T: 13
    }, {
      no: 2,
      name: "subresult",
      kind: "scalar",
      opt: true,
      T: 13
    }]);
  }
};
var IndexError = new IndexError$Type();
var CoinDenyListError$Type = class extends import_runtime13.MessageType {
  constructor() {
    super("sui.rpc.v2.CoinDenyListError", [{
      no: 1,
      name: "address",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "coin_type",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var CoinDenyListError = new CoinDenyListError$Type();
var CongestedObjects$Type = class extends import_runtime13.MessageType {
  constructor() {
    super("sui.rpc.v2.CongestedObjects", [{
      no: 1,
      name: "objects",
      kind: "scalar",
      repeat: 2,
      T: 9
    }]);
  }
};
var CongestedObjects = new CongestedObjects$Type();
var CommandArgumentError$Type = class extends import_runtime13.MessageType {
  constructor() {
    super("sui.rpc.v2.CommandArgumentError", [
      {
        no: 1,
        name: "argument",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 2,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.CommandArgumentError.CommandArgumentErrorKind", CommandArgumentError_CommandArgumentErrorKind]
      },
      {
        no: 3,
        name: "index_error",
        kind: "message",
        T: () => IndexError
      }
    ]);
  }
};
var CommandArgumentError2 = new CommandArgumentError$Type();
var PackageUpgradeError$Type = class extends import_runtime13.MessageType {
  constructor() {
    super("sui.rpc.v2.PackageUpgradeError", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.PackageUpgradeError.PackageUpgradeErrorKind", PackageUpgradeError_PackageUpgradeErrorKind]
      },
      {
        no: 2,
        name: "package_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "policy",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 5,
        name: "ticket_id",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var PackageUpgradeError2 = new PackageUpgradeError$Type();
var TypeArgumentError$Type = class extends import_runtime13.MessageType {
  constructor() {
    super("sui.rpc.v2.TypeArgumentError", [{
      no: 1,
      name: "type_argument",
      kind: "scalar",
      opt: true,
      T: 13
    }, {
      no: 2,
      name: "kind",
      kind: "enum",
      opt: true,
      T: () => ["sui.rpc.v2.TypeArgumentError.TypeArgumentErrorKind", TypeArgumentError_TypeArgumentErrorKind]
    }]);
  }
};
var TypeArgumentError2 = new TypeArgumentError$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/gas_cost_summary.mjs
var import_runtime14 = __toESM(require_commonjs(), 1);
var GasCostSummary$Type = class extends import_runtime14.MessageType {
  constructor() {
    super("sui.rpc.v2.GasCostSummary", [
      {
        no: 1,
        name: "computation_cost",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "storage_cost",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "storage_rebate",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "non_refundable_storage_fee",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var GasCostSummary2 = new GasCostSummary$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/effects.mjs
var import_runtime15 = __toESM(require_commonjs(), 1);
var ChangedObject_InputObjectState = /* @__PURE__ */ (function(ChangedObject_InputObjectState$1) {
  ChangedObject_InputObjectState$1[ChangedObject_InputObjectState$1["UNKNOWN"] = 0] = "UNKNOWN";
  ChangedObject_InputObjectState$1[ChangedObject_InputObjectState$1["DOES_NOT_EXIST"] = 1] = "DOES_NOT_EXIST";
  ChangedObject_InputObjectState$1[ChangedObject_InputObjectState$1["EXISTS"] = 2] = "EXISTS";
  return ChangedObject_InputObjectState$1;
})({});
var ChangedObject_OutputObjectState = /* @__PURE__ */ (function(ChangedObject_OutputObjectState$1) {
  ChangedObject_OutputObjectState$1[ChangedObject_OutputObjectState$1["UNKNOWN"] = 0] = "UNKNOWN";
  ChangedObject_OutputObjectState$1[ChangedObject_OutputObjectState$1["DOES_NOT_EXIST"] = 1] = "DOES_NOT_EXIST";
  ChangedObject_OutputObjectState$1[ChangedObject_OutputObjectState$1["OBJECT_WRITE"] = 2] = "OBJECT_WRITE";
  ChangedObject_OutputObjectState$1[ChangedObject_OutputObjectState$1["PACKAGE_WRITE"] = 3] = "PACKAGE_WRITE";
  ChangedObject_OutputObjectState$1[ChangedObject_OutputObjectState$1["ACCUMULATOR_WRITE"] = 4] = "ACCUMULATOR_WRITE";
  return ChangedObject_OutputObjectState$1;
})({});
var ChangedObject_IdOperation = /* @__PURE__ */ (function(ChangedObject_IdOperation$1) {
  ChangedObject_IdOperation$1[ChangedObject_IdOperation$1["ID_OPERATION_UNKNOWN"] = 0] = "ID_OPERATION_UNKNOWN";
  ChangedObject_IdOperation$1[ChangedObject_IdOperation$1["NONE"] = 1] = "NONE";
  ChangedObject_IdOperation$1[ChangedObject_IdOperation$1["CREATED"] = 2] = "CREATED";
  ChangedObject_IdOperation$1[ChangedObject_IdOperation$1["DELETED"] = 3] = "DELETED";
  return ChangedObject_IdOperation$1;
})({});
var AccumulatorWrite_AccumulatorOperation = /* @__PURE__ */ (function(AccumulatorWrite_AccumulatorOperation$1) {
  AccumulatorWrite_AccumulatorOperation$1[AccumulatorWrite_AccumulatorOperation$1["ACCUMULATOR_OPERATION_UNKNOWN"] = 0] = "ACCUMULATOR_OPERATION_UNKNOWN";
  AccumulatorWrite_AccumulatorOperation$1[AccumulatorWrite_AccumulatorOperation$1["MERGE"] = 1] = "MERGE";
  AccumulatorWrite_AccumulatorOperation$1[AccumulatorWrite_AccumulatorOperation$1["SPLIT"] = 2] = "SPLIT";
  return AccumulatorWrite_AccumulatorOperation$1;
})({});
var AccumulatorWrite_AccumulatorValue = /* @__PURE__ */ (function(AccumulatorWrite_AccumulatorValue$1) {
  AccumulatorWrite_AccumulatorValue$1[AccumulatorWrite_AccumulatorValue$1["ACCUMULATOR_VALUE_UNKNOWN"] = 0] = "ACCUMULATOR_VALUE_UNKNOWN";
  AccumulatorWrite_AccumulatorValue$1[AccumulatorWrite_AccumulatorValue$1["INTEGER"] = 1] = "INTEGER";
  AccumulatorWrite_AccumulatorValue$1[AccumulatorWrite_AccumulatorValue$1["INTEGER_TUPLE"] = 2] = "INTEGER_TUPLE";
  AccumulatorWrite_AccumulatorValue$1[AccumulatorWrite_AccumulatorValue$1["EVENT_DIGEST"] = 3] = "EVENT_DIGEST";
  return AccumulatorWrite_AccumulatorValue$1;
})({});
var UnchangedConsensusObject_UnchangedConsensusObjectKind = /* @__PURE__ */ (function(UnchangedConsensusObject_UnchangedConsensusObjectKind$1) {
  UnchangedConsensusObject_UnchangedConsensusObjectKind$1[UnchangedConsensusObject_UnchangedConsensusObjectKind$1["UNCHANGED_CONSENSUS_OBJECT_KIND_UNKNOWN"] = 0] = "UNCHANGED_CONSENSUS_OBJECT_KIND_UNKNOWN";
  UnchangedConsensusObject_UnchangedConsensusObjectKind$1[UnchangedConsensusObject_UnchangedConsensusObjectKind$1["READ_ONLY_ROOT"] = 1] = "READ_ONLY_ROOT";
  UnchangedConsensusObject_UnchangedConsensusObjectKind$1[UnchangedConsensusObject_UnchangedConsensusObjectKind$1["MUTATE_CONSENSUS_STREAM_ENDED"] = 2] = "MUTATE_CONSENSUS_STREAM_ENDED";
  UnchangedConsensusObject_UnchangedConsensusObjectKind$1[UnchangedConsensusObject_UnchangedConsensusObjectKind$1["READ_CONSENSUS_STREAM_ENDED"] = 3] = "READ_CONSENSUS_STREAM_ENDED";
  UnchangedConsensusObject_UnchangedConsensusObjectKind$1[UnchangedConsensusObject_UnchangedConsensusObjectKind$1["CANCELED"] = 4] = "CANCELED";
  UnchangedConsensusObject_UnchangedConsensusObjectKind$1[UnchangedConsensusObject_UnchangedConsensusObjectKind$1["PER_EPOCH_CONFIG"] = 5] = "PER_EPOCH_CONFIG";
  return UnchangedConsensusObject_UnchangedConsensusObjectKind$1;
})({});
var TransactionEffects$Type = class extends import_runtime15.MessageType {
  constructor() {
    super("sui.rpc.v2.TransactionEffects", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 5
      },
      {
        no: 4,
        name: "status",
        kind: "message",
        T: () => ExecutionStatus2
      },
      {
        no: 5,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "gas_used",
        kind: "message",
        T: () => GasCostSummary2
      },
      {
        no: 7,
        name: "transaction_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 8,
        name: "gas_object",
        kind: "message",
        T: () => ChangedObject
      },
      {
        no: 9,
        name: "events_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 10,
        name: "dependencies",
        kind: "scalar",
        repeat: 2,
        T: 9
      },
      {
        no: 11,
        name: "lamport_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 12,
        name: "changed_objects",
        kind: "message",
        repeat: 2,
        T: () => ChangedObject
      },
      {
        no: 13,
        name: "unchanged_consensus_objects",
        kind: "message",
        repeat: 2,
        T: () => UnchangedConsensusObject
      },
      {
        no: 14,
        name: "auxiliary_data_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 15,
        name: "unchanged_loaded_runtime_objects",
        kind: "message",
        repeat: 2,
        T: () => ObjectReference
      }
    ]);
  }
};
var TransactionEffects2 = new TransactionEffects$Type();
var ChangedObject$Type = class extends import_runtime15.MessageType {
  constructor() {
    super("sui.rpc.v2.ChangedObject", [
      {
        no: 1,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "input_state",
        kind: "enum",
        opt: true,
        T: () => [
          "sui.rpc.v2.ChangedObject.InputObjectState",
          ChangedObject_InputObjectState,
          "INPUT_OBJECT_STATE_"
        ]
      },
      {
        no: 3,
        name: "input_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "input_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "input_owner",
        kind: "message",
        T: () => Owner2
      },
      {
        no: 6,
        name: "output_state",
        kind: "enum",
        opt: true,
        T: () => [
          "sui.rpc.v2.ChangedObject.OutputObjectState",
          ChangedObject_OutputObjectState,
          "OUTPUT_OBJECT_STATE_"
        ]
      },
      {
        no: 7,
        name: "output_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 8,
        name: "output_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 9,
        name: "output_owner",
        kind: "message",
        T: () => Owner2
      },
      {
        no: 12,
        name: "accumulator_write",
        kind: "message",
        T: () => AccumulatorWrite
      },
      {
        no: 10,
        name: "id_operation",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.ChangedObject.IdOperation", ChangedObject_IdOperation]
      },
      {
        no: 11,
        name: "object_type",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var ChangedObject = new ChangedObject$Type();
var EventDigestEntry$Type = class extends import_runtime15.MessageType {
  constructor() {
    super("sui.rpc.v2.EventDigestEntry", [{
      no: 1,
      name: "event_index",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "digest",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var EventDigestEntry = new EventDigestEntry$Type();
var AccumulatorWrite$Type = class extends import_runtime15.MessageType {
  constructor() {
    super("sui.rpc.v2.AccumulatorWrite", [
      {
        no: 1,
        name: "address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "accumulator_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "operation",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.AccumulatorWrite.AccumulatorOperation", AccumulatorWrite_AccumulatorOperation]
      },
      {
        no: 4,
        name: "value_kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.AccumulatorWrite.AccumulatorValue", AccumulatorWrite_AccumulatorValue]
      },
      {
        no: 5,
        name: "integer_value",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "integer_tuple",
        kind: "scalar",
        repeat: 1,
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "event_digest_value",
        kind: "message",
        repeat: 2,
        T: () => EventDigestEntry
      }
    ]);
  }
};
var AccumulatorWrite = new AccumulatorWrite$Type();
var UnchangedConsensusObject$Type = class extends import_runtime15.MessageType {
  constructor() {
    super("sui.rpc.v2.UnchangedConsensusObject", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.UnchangedConsensusObject.UnchangedConsensusObjectKind", UnchangedConsensusObject_UnchangedConsensusObjectKind]
      },
      {
        no: 2,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "object_type",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var UnchangedConsensusObject = new UnchangedConsensusObject$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/client/query-filters.mjs
var DEFAULT_PAGE_SIZE = 50;
function resolvePagination(options) {
  if (options.after != null && options.before != null) throw new Error("Only one of `after` or `before` may be provided");
  const descending = options.order ? options.order === "descending" : options.before != null;
  if (options.after != null && descending) throw new Error("`after` can not be combined with descending queries");
  if (options.before != null && !descending) throw new Error("`before` can not be combined with ascending queries");
  return {
    descending,
    after: options.after ?? void 0,
    before: options.before ?? void 0,
    limit: options.limit ?? DEFAULT_PAGE_SIZE
  };
}
function validateTransactionQuery(filter, pagination) {
  if (filter?.$kind === "function" && (pagination.after != null || pagination.before != null) && (!filter.module || !filter.function)) throw new Error("Paginating transactions filtered by function requires a fully qualified `package::module::function`");
}
async function resolveTransactionFilter(mvr, filter, signal) {
  assertSinglePredicate(filter, ["sender", "function"], "transaction");
  if (filter.sender != null) return {
    $kind: "sender",
    sender: normalizeSuiAddress(filter.sender)
  };
  const [pkg, module2, fn, ...rest] = filter.function.split("::");
  if (!pkg || rest.length > 0 || module2 === "" || fn === "") throw new Error(`Invalid function filter "${filter.function}": expected "package", "package::module", or "package::module::function"`);
  return {
    $kind: "function",
    package: normalizeSuiAddress((await mvr.resolvePackage({
      package: pkg,
      signal
    })).package),
    module: module2,
    function: fn
  };
}
async function resolveEventFilter(mvr, filter, signal) {
  assertSinglePredicate(filter, [
    "sender",
    "emitModule",
    "eventType"
  ], "event");
  if (filter.sender != null) return {
    $kind: "sender",
    sender: normalizeSuiAddress(filter.sender)
  };
  if (filter.emitModule != null) {
    const [pkg, module2, ...rest] = filter.emitModule.split("::");
    if (!pkg || !module2 || rest.length > 0) throw new Error(`Invalid emitModule filter "${filter.emitModule}": expected "package::module"`);
    return {
      $kind: "emitModule",
      package: normalizeSuiAddress((await mvr.resolvePackage({
        package: pkg,
        signal
      })).package),
      module: module2
    };
  }
  const eventType = filter.eventType;
  const segments = eventType.split("::");
  if (segments.length === 2 && segments.every((segment) => segment !== "")) return {
    $kind: "eventTypeModule",
    package: normalizeSuiAddress((await mvr.resolvePackage({
      package: segments[0],
      signal
    })).package),
    module: segments[1]
  };
  if (segments.length < 3 || segments.some((segment) => segment === "")) throw new Error(`Invalid eventType filter "${eventType}": expected "package::module" or a fully qualified type name`);
  return {
    $kind: "eventType",
    eventType: (await mvr.resolveType({
      type: eventType,
      signal
    })).type
  };
}
function assertSinglePredicate(filter, predicates, kind) {
  const present = predicates.filter((predicate) => filter[predicate] != null);
  if (present.length !== 1) throw new Error(`A ${kind} filter must specify exactly one of ${predicates.join(", ")}${present.length ? ` (got ${present.join(", ")})` : ""}`);
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/balance_change.mjs
var import_runtime16 = __toESM(require_commonjs(), 1);
var BalanceChange$Type = class extends import_runtime16.MessageType {
  constructor() {
    super("sui.rpc.v2.BalanceChange", [
      {
        no: 1,
        name: "address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "coin_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "amount",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var BalanceChange = new BalanceChange$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/event.mjs
var import_runtime17 = __toESM(require_commonjs(), 1);
var TransactionEvents$Type = class extends import_runtime17.MessageType {
  constructor() {
    super("sui.rpc.v2.TransactionEvents", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "events",
        kind: "message",
        repeat: 2,
        T: () => Event
      }
    ]);
  }
};
var TransactionEvents = new TransactionEvents$Type();
var Event$Type = class extends import_runtime17.MessageType {
  constructor() {
    super("sui.rpc.v2.Event", [
      {
        no: 1,
        name: "package_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "module",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "sender",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "event_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "contents",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 6,
        name: "json",
        kind: "message",
        T: () => Value
      },
      {
        no: 7,
        name: "checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 8,
        name: "transaction_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 9,
        name: "transaction_index",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 10,
        name: "event_index",
        kind: "scalar",
        opt: true,
        T: 13
      }
    ]);
  }
};
var Event = new Event$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/signature_scheme.mjs
var SignatureScheme = /* @__PURE__ */ (function(SignatureScheme$1) {
  SignatureScheme$1[SignatureScheme$1["ED25519"] = 0] = "ED25519";
  SignatureScheme$1[SignatureScheme$1["SECP256K1"] = 1] = "SECP256K1";
  SignatureScheme$1[SignatureScheme$1["SECP256R1"] = 2] = "SECP256R1";
  SignatureScheme$1[SignatureScheme$1["MULTISIG"] = 3] = "MULTISIG";
  SignatureScheme$1[SignatureScheme$1["BLS12381"] = 4] = "BLS12381";
  SignatureScheme$1[SignatureScheme$1["ZKLOGIN"] = 5] = "ZKLOGIN";
  SignatureScheme$1[SignatureScheme$1["PASSKEY"] = 6] = "PASSKEY";
  return SignatureScheme$1;
})({});

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/signature.mjs
var import_runtime18 = __toESM(require_commonjs(), 1);
var UserSignature$Type = class extends import_runtime18.MessageType {
  constructor() {
    super("sui.rpc.v2.UserSignature", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "scheme",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.SignatureScheme", SignatureScheme]
      },
      {
        no: 3,
        name: "simple",
        kind: "message",
        oneof: "signature",
        T: () => SimpleSignature
      },
      {
        no: 4,
        name: "multisig",
        kind: "message",
        oneof: "signature",
        T: () => MultisigAggregatedSignature
      },
      {
        no: 5,
        name: "zklogin",
        kind: "message",
        oneof: "signature",
        T: () => ZkLoginAuthenticator
      },
      {
        no: 6,
        name: "passkey",
        kind: "message",
        oneof: "signature",
        T: () => PasskeyAuthenticator2
      }
    ]);
  }
};
var UserSignature = new UserSignature$Type();
var SimpleSignature$Type = class extends import_runtime18.MessageType {
  constructor() {
    super("sui.rpc.v2.SimpleSignature", [
      {
        no: 1,
        name: "scheme",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.SignatureScheme", SignatureScheme]
      },
      {
        no: 2,
        name: "signature",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "public_key",
        kind: "scalar",
        opt: true,
        T: 12
      }
    ]);
  }
};
var SimpleSignature = new SimpleSignature$Type();
var ZkLoginPublicIdentifier$Type = class extends import_runtime18.MessageType {
  constructor() {
    super("sui.rpc.v2.ZkLoginPublicIdentifier", [{
      no: 1,
      name: "iss",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "address_seed",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var ZkLoginPublicIdentifier = new ZkLoginPublicIdentifier$Type();
var MultisigMemberPublicKey$Type = class extends import_runtime18.MessageType {
  constructor() {
    super("sui.rpc.v2.MultisigMemberPublicKey", [
      {
        no: 1,
        name: "scheme",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.SignatureScheme", SignatureScheme]
      },
      {
        no: 2,
        name: "public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "zklogin",
        kind: "message",
        T: () => ZkLoginPublicIdentifier
      }
    ]);
  }
};
var MultisigMemberPublicKey = new MultisigMemberPublicKey$Type();
var MultisigMember$Type = class extends import_runtime18.MessageType {
  constructor() {
    super("sui.rpc.v2.MultisigMember", [{
      no: 1,
      name: "public_key",
      kind: "message",
      T: () => MultisigMemberPublicKey
    }, {
      no: 2,
      name: "weight",
      kind: "scalar",
      opt: true,
      T: 13
    }]);
  }
};
var MultisigMember = new MultisigMember$Type();
var MultisigCommittee$Type = class extends import_runtime18.MessageType {
  constructor() {
    super("sui.rpc.v2.MultisigCommittee", [{
      no: 1,
      name: "members",
      kind: "message",
      repeat: 2,
      T: () => MultisigMember
    }, {
      no: 2,
      name: "threshold",
      kind: "scalar",
      opt: true,
      T: 13
    }]);
  }
};
var MultisigCommittee = new MultisigCommittee$Type();
var MultisigAggregatedSignature$Type = class extends import_runtime18.MessageType {
  constructor() {
    super("sui.rpc.v2.MultisigAggregatedSignature", [
      {
        no: 1,
        name: "signatures",
        kind: "message",
        repeat: 2,
        T: () => MultisigMemberSignature
      },
      {
        no: 2,
        name: "bitmap",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "legacy_bitmap",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 4,
        name: "committee",
        kind: "message",
        T: () => MultisigCommittee
      }
    ]);
  }
};
var MultisigAggregatedSignature = new MultisigAggregatedSignature$Type();
var MultisigMemberSignature$Type = class extends import_runtime18.MessageType {
  constructor() {
    super("sui.rpc.v2.MultisigMemberSignature", [
      {
        no: 1,
        name: "scheme",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.SignatureScheme", SignatureScheme]
      },
      {
        no: 2,
        name: "signature",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "zklogin",
        kind: "message",
        T: () => ZkLoginAuthenticator
      },
      {
        no: 4,
        name: "passkey",
        kind: "message",
        T: () => PasskeyAuthenticator2
      }
    ]);
  }
};
var MultisigMemberSignature = new MultisigMemberSignature$Type();
var ZkLoginAuthenticator$Type = class extends import_runtime18.MessageType {
  constructor() {
    super("sui.rpc.v2.ZkLoginAuthenticator", [
      {
        no: 1,
        name: "inputs",
        kind: "message",
        T: () => ZkLoginInputs
      },
      {
        no: 2,
        name: "max_epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "signature",
        kind: "message",
        T: () => SimpleSignature
      },
      {
        no: 4,
        name: "public_identifier",
        kind: "message",
        T: () => ZkLoginPublicIdentifier
      },
      {
        no: 5,
        name: "jwk_id",
        kind: "message",
        T: () => JwkId
      }
    ]);
  }
};
var ZkLoginAuthenticator = new ZkLoginAuthenticator$Type();
var ZkLoginInputs$Type = class extends import_runtime18.MessageType {
  constructor() {
    super("sui.rpc.v2.ZkLoginInputs", [
      {
        no: 1,
        name: "proof_points",
        kind: "message",
        T: () => ZkLoginProof
      },
      {
        no: 2,
        name: "iss_base64_details",
        kind: "message",
        T: () => ZkLoginClaim
      },
      {
        no: 3,
        name: "header_base64",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "address_seed",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var ZkLoginInputs = new ZkLoginInputs$Type();
var ZkLoginProof$Type = class extends import_runtime18.MessageType {
  constructor() {
    super("sui.rpc.v2.ZkLoginProof", [
      {
        no: 1,
        name: "a",
        kind: "message",
        T: () => CircomG1
      },
      {
        no: 2,
        name: "b",
        kind: "message",
        T: () => CircomG2
      },
      {
        no: 3,
        name: "c",
        kind: "message",
        T: () => CircomG1
      }
    ]);
  }
};
var ZkLoginProof = new ZkLoginProof$Type();
var ZkLoginClaim$Type = class extends import_runtime18.MessageType {
  constructor() {
    super("sui.rpc.v2.ZkLoginClaim", [{
      no: 1,
      name: "value",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "index_mod_4",
      kind: "scalar",
      opt: true,
      T: 13
    }]);
  }
};
var ZkLoginClaim = new ZkLoginClaim$Type();
var CircomG1$Type = class extends import_runtime18.MessageType {
  constructor() {
    super("sui.rpc.v2.CircomG1", [
      {
        no: 1,
        name: "e0",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "e1",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "e2",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var CircomG1 = new CircomG1$Type();
var CircomG2$Type = class extends import_runtime18.MessageType {
  constructor() {
    super("sui.rpc.v2.CircomG2", [
      {
        no: 1,
        name: "e00",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "e01",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "e10",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "e11",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "e20",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 6,
        name: "e21",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var CircomG2 = new CircomG2$Type();
var PasskeyAuthenticator$Type = class extends import_runtime18.MessageType {
  constructor() {
    super("sui.rpc.v2.PasskeyAuthenticator", [
      {
        no: 1,
        name: "authenticator_data",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 2,
        name: "client_data_json",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "signature",
        kind: "message",
        T: () => SimpleSignature
      }
    ]);
  }
};
var PasskeyAuthenticator2 = new PasskeyAuthenticator$Type();
var ValidatorCommittee$Type = class extends import_runtime18.MessageType {
  constructor() {
    super("sui.rpc.v2.ValidatorCommittee", [{
      no: 1,
      name: "epoch",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "members",
      kind: "message",
      repeat: 2,
      T: () => ValidatorCommitteeMember
    }]);
  }
};
var ValidatorCommittee = new ValidatorCommittee$Type();
var ValidatorCommitteeMember$Type = class extends import_runtime18.MessageType {
  constructor() {
    super("sui.rpc.v2.ValidatorCommitteeMember", [{
      no: 1,
      name: "public_key",
      kind: "scalar",
      opt: true,
      T: 12
    }, {
      no: 2,
      name: "weight",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var ValidatorCommitteeMember = new ValidatorCommitteeMember$Type();
var ValidatorAggregatedSignature$Type = class extends import_runtime18.MessageType {
  constructor() {
    super("sui.rpc.v2.ValidatorAggregatedSignature", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "signature",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "bitmap",
        kind: "scalar",
        opt: true,
        T: 12
      }
    ]);
  }
};
var ValidatorAggregatedSignature = new ValidatorAggregatedSignature$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/executed_transaction.mjs
var import_runtime19 = __toESM(require_commonjs(), 1);
var ExecutedTransaction$Type = class extends import_runtime19.MessageType {
  constructor() {
    super("sui.rpc.v2.ExecutedTransaction", [
      {
        no: 1,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "transaction",
        kind: "message",
        T: () => Transaction
      },
      {
        no: 3,
        name: "signatures",
        kind: "message",
        repeat: 2,
        T: () => UserSignature
      },
      {
        no: 4,
        name: "effects",
        kind: "message",
        T: () => TransactionEffects2
      },
      {
        no: 5,
        name: "events",
        kind: "message",
        T: () => TransactionEvents
      },
      {
        no: 6,
        name: "checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 8,
        name: "balance_changes",
        kind: "message",
        repeat: 2,
        T: () => BalanceChange
      },
      {
        no: 9,
        name: "objects",
        kind: "message",
        T: () => ObjectSet
      },
      {
        no: 10,
        name: "transaction_index",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var ExecutedTransaction = new ExecutedTransaction$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/google/protobuf/field_mask.mjs
var import_runtime20 = __toESM(require_commonjs(), 1);
var FieldMask$Type = class extends import_runtime20.MessageType {
  constructor() {
    super("google.protobuf.FieldMask", [{
      no: 1,
      name: "paths",
      kind: "scalar",
      repeat: 2,
      T: 9
    }]);
  }
  /**
  * Encode `FieldMask` to JSON object.
  */
  internalJsonWrite(message, options) {
    const invalidFieldMaskJsonRegex = /[A-Z]|(_([.0-9_]|$))/g;
    return message.paths.map((p) => {
      if (invalidFieldMaskJsonRegex.test(p)) throw new Error('Unable to encode FieldMask to JSON. lowerCamelCase of path name "' + p + '" is irreversible.');
      return (0, import_runtime20.lowerCamelCase)(p);
    }).join(",");
  }
  /**
  * Decode `FieldMask` from JSON object.
  */
  internalJsonRead(json, options, target) {
    if (typeof json !== "string") throw new Error("Unable to parse FieldMask from JSON " + (0, import_runtime20.typeofJsonValue)(json) + ". Expected string.");
    if (!target) target = this.create();
    if (json === "") return target;
    let camelToSnake = (str) => {
      if (str.includes("_")) throw new Error("Unable to parse FieldMask from JSON. Path names must be lowerCamelCase.");
      return str.replace(/[A-Z]/g, (letter) => "_" + letter.toLowerCase());
    };
    target.paths = json.split(",").map(camelToSnake);
    return target;
  }
};
var FieldMask = new FieldMask$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/transaction_execution_service.mjs
var import_runtime21 = __toESM(require_commonjs(), 1);
var import_runtime_rpc2 = __toESM(require_commonjs2(), 1);
var SimulateTransactionRequest_TransactionChecks = /* @__PURE__ */ (function(SimulateTransactionRequest_TransactionChecks$1) {
  SimulateTransactionRequest_TransactionChecks$1[SimulateTransactionRequest_TransactionChecks$1["ENABLED"] = 0] = "ENABLED";
  SimulateTransactionRequest_TransactionChecks$1[SimulateTransactionRequest_TransactionChecks$1["DISABLED"] = 1] = "DISABLED";
  return SimulateTransactionRequest_TransactionChecks$1;
})({});
var ExecuteTransactionRequest$Type = class extends import_runtime21.MessageType {
  constructor() {
    super("sui.rpc.v2.ExecuteTransactionRequest", [
      {
        no: 1,
        name: "transaction",
        kind: "message",
        T: () => Transaction
      },
      {
        no: 2,
        name: "signatures",
        kind: "message",
        repeat: 2,
        T: () => UserSignature
      },
      {
        no: 3,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      }
    ]);
  }
};
var ExecuteTransactionRequest = new ExecuteTransactionRequest$Type();
var ExecuteTransactionResponse$Type = class extends import_runtime21.MessageType {
  constructor() {
    super("sui.rpc.v2.ExecuteTransactionResponse", [{
      no: 1,
      name: "transaction",
      kind: "message",
      T: () => ExecutedTransaction
    }]);
  }
};
var ExecuteTransactionResponse = new ExecuteTransactionResponse$Type();
var SimulateTransactionRequest$Type = class extends import_runtime21.MessageType {
  constructor() {
    super("sui.rpc.v2.SimulateTransactionRequest", [
      {
        no: 1,
        name: "transaction",
        kind: "message",
        T: () => Transaction
      },
      {
        no: 2,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      },
      {
        no: 3,
        name: "checks",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.SimulateTransactionRequest.TransactionChecks", SimulateTransactionRequest_TransactionChecks]
      },
      {
        no: 4,
        name: "do_gas_selection",
        kind: "scalar",
        opt: true,
        T: 8
      }
    ]);
  }
};
var SimulateTransactionRequest = new SimulateTransactionRequest$Type();
var SimulateTransactionResponse$Type = class extends import_runtime21.MessageType {
  constructor() {
    super("sui.rpc.v2.SimulateTransactionResponse", [
      {
        no: 1,
        name: "transaction",
        kind: "message",
        T: () => ExecutedTransaction
      },
      {
        no: 2,
        name: "command_outputs",
        kind: "message",
        repeat: 2,
        T: () => CommandResult
      },
      {
        no: 3,
        name: "suggested_gas_price",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var SimulateTransactionResponse = new SimulateTransactionResponse$Type();
var CommandResult$Type = class extends import_runtime21.MessageType {
  constructor() {
    super("sui.rpc.v2.CommandResult", [{
      no: 1,
      name: "return_values",
      kind: "message",
      repeat: 2,
      T: () => CommandOutput
    }, {
      no: 2,
      name: "mutated_by_ref",
      kind: "message",
      repeat: 2,
      T: () => CommandOutput
    }]);
  }
};
var CommandResult = new CommandResult$Type();
var CommandOutput$Type = class extends import_runtime21.MessageType {
  constructor() {
    super("sui.rpc.v2.CommandOutput", [
      {
        no: 1,
        name: "argument",
        kind: "message",
        T: () => Argument2
      },
      {
        no: 2,
        name: "value",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 3,
        name: "json",
        kind: "message",
        T: () => Value
      }
    ]);
  }
};
var CommandOutput = new CommandOutput$Type();
var TransactionExecutionService = new import_runtime_rpc2.ServiceType("sui.rpc.v2.TransactionExecutionService", [{
  name: "ExecuteTransaction",
  options: {},
  I: ExecuteTransactionRequest,
  O: ExecuteTransactionResponse
}, {
  name: "SimulateTransaction",
  options: {},
  I: SimulateTransactionRequest,
  O: SimulateTransactionResponse
}]);

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/query_options.mjs
var import_runtime22 = __toESM(require_commonjs(), 1);
var Ordering = /* @__PURE__ */ (function(Ordering$1) {
  Ordering$1[Ordering$1["ASCENDING"] = 0] = "ASCENDING";
  Ordering$1[Ordering$1["DESCENDING"] = 1] = "DESCENDING";
  return Ordering$1;
})({});
var QueryEndReason = /* @__PURE__ */ (function(QueryEndReason$1) {
  QueryEndReason$1[QueryEndReason$1["UNKNOWN"] = 0] = "UNKNOWN";
  QueryEndReason$1[QueryEndReason$1["ITEM_LIMIT"] = 1] = "ITEM_LIMIT";
  QueryEndReason$1[QueryEndReason$1["SCAN_LIMIT"] = 2] = "SCAN_LIMIT";
  QueryEndReason$1[QueryEndReason$1["CHECKPOINT_BOUND"] = 3] = "CHECKPOINT_BOUND";
  QueryEndReason$1[QueryEndReason$1["CURSOR_BOUND"] = 4] = "CURSOR_BOUND";
  QueryEndReason$1[QueryEndReason$1["LEDGER_TIP"] = 5] = "LEDGER_TIP";
  return QueryEndReason$1;
})({});
var QueryOptions$Type = class extends import_runtime22.MessageType {
  constructor() {
    super("sui.rpc.v2.QueryOptions", [
      {
        no: 1,
        name: "limit",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 2,
        name: "after",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 3,
        name: "before",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 4,
        name: "ordering",
        kind: "enum",
        opt: true,
        T: () => [
          "sui.rpc.v2.Ordering",
          Ordering,
          "ORDERING_"
        ]
      }
    ]);
  }
};
var QueryOptions = new QueryOptions$Type();
var Watermark$Type = class extends import_runtime22.MessageType {
  constructor() {
    super("sui.rpc.v2.Watermark", [{
      no: 1,
      name: "cursor",
      kind: "scalar",
      opt: true,
      T: 12
    }, {
      no: 2,
      name: "checkpoint",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var Watermark = new Watermark$Type();
var QueryEnd$Type = class extends import_runtime22.MessageType {
  constructor() {
    super("sui.rpc.v2.QueryEnd", [{
      no: 1,
      name: "reason",
      kind: "enum",
      opt: true,
      T: () => [
        "sui.rpc.v2.QueryEndReason",
        QueryEndReason,
        "QUERY_END_REASON_"
      ]
    }]);
  }
};
var QueryEnd = new QueryEnd$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/filters.mjs
function toGrpcTransactionFilter(filter) {
  return { terms: [{ literals: [filter.$kind === "sender" ? {
    negated: false,
    predicate: {
      oneofKind: "sender",
      sender: { address: filter.sender }
    }
  } : {
    negated: false,
    predicate: {
      oneofKind: "moveCall",
      moveCall: { function: [
        filter.package,
        filter.module,
        filter.function
      ].filter(Boolean).join("::") }
    }
  }] }] };
}
function toGrpcEventFilter(filter) {
  return { terms: [{ literals: [filter.$kind === "sender" ? {
    negated: false,
    predicate: {
      oneofKind: "sender",
      sender: { address: filter.sender }
    }
  } : filter.$kind === "emitModule" ? {
    negated: false,
    predicate: {
      oneofKind: "emitModule",
      emitModule: { module: `${filter.package}::${filter.module}` }
    }
  } : {
    negated: false,
    predicate: {
      oneofKind: "eventType",
      eventType: { eventType: filter.$kind === "eventTypeModule" ? `${filter.package}::${filter.module}` : filter.eventType }
    }
  }] }] };
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/core.mjs
var import_runtime_rpc3 = __toESM(require_commonjs2(), 1);
var import_grpcweb_transport2 = __toESM(require_commonjs3(), 1);
function isNameServiceResolutionMiss(error) {
  if (typeof error !== "object" || error === null) return false;
  const { code, message } = error;
  if (typeof code !== "string" || typeof message !== "string") return false;
  if (code === import_grpcweb_transport2.GrpcStatusCode[import_grpcweb_transport2.GrpcStatusCode.NOT_FOUND]) return true;
  if (code !== import_grpcweb_transport2.GrpcStatusCode[import_grpcweb_transport2.GrpcStatusCode.RESOURCE_EXHAUSTED]) return false;
  if (message === "name has expired") return true;
  return !hasDecodedStatusMessage(error) && message === "name%20has%20expired";
}
var GrpcCoreClient = class extends CoreClient {
  #client;
  constructor({ client, ...options }) {
    super(options);
    this.#client = client;
  }
  async getObjects(options) {
    const batches = chunk(options.objectIds, 50);
    const results = [];
    const paths = [
      "owner",
      "object_type",
      "digest",
      "version",
      "object_id"
    ];
    if (options.include?.content) paths.push("contents");
    if (options.include?.previousTransaction) paths.push("previous_transaction");
    if (options.include?.objectBcs) paths.push("bcs");
    if (options.include?.json) paths.push("json");
    if (options.include?.display) paths.push("display");
    for (const batch of batches) {
      const response = await this.#client.ledgerService.batchGetObjects({
        requests: batch.map((id) => ({ objectId: id })),
        readMask: { paths }
      }, { abort: options.signal });
      results.push(...response.response.objects.map((object2, index) => {
        if (object2.result.oneofKind === "error") {
          const error = object2.result.error;
          if (error.code === import_grpcweb_transport2.GrpcStatusCode.NOT_FOUND) return new ObjectError("notExists", error.message, {
            cause: error,
            reason: "notFound",
            objectId: batch[index]
          });
          return new ObjectError(import_grpcweb_transport2.GrpcStatusCode[error.code] ?? "unknown", error.message, {
            cause: error,
            reason: "unknown",
            objectId: batch[index]
          });
        }
        if (object2.result.oneofKind !== "object") return new ObjectError("unknown", "Unexpected result type", {
          reason: "unknown",
          objectId: batch[index]
        });
        const bcsContent = object2.result.object.contents?.value ?? void 0;
        const objectBcs = object2.result.object.bcs?.value ?? void 0;
        const objectType = object2.result.object.objectType;
        const type = objectType && objectType.includes("::") ? normalizeStructTag(objectType) : objectType ?? "";
        const jsonContent = options.include?.json ? object2.result.object.json ? Value.toJson(object2.result.object.json) : null : void 0;
        const displayData = mapDisplayProto(options.include?.display, object2.result.object.display);
        return {
          objectId: object2.result.object.objectId,
          version: object2.result.object.version?.toString(),
          digest: object2.result.object.digest,
          content: bcsContent,
          owner: mapOwner(object2.result.object.owner),
          type,
          previousTransaction: object2.result.object.previousTransaction ?? void 0,
          objectBcs,
          json: jsonContent,
          display: displayData
        };
      }));
    }
    return { objects: results };
  }
  async listOwnedObjects(options) {
    const paths = [
      "owner",
      "object_type",
      "digest",
      "version",
      "object_id"
    ];
    if (options.include?.content) paths.push("contents");
    if (options.include?.previousTransaction) paths.push("previous_transaction");
    if (options.include?.objectBcs) paths.push("bcs");
    if (options.include?.json) paths.push("json");
    if (options.include?.display) paths.push("display");
    const response = await this.#client.stateService.listOwnedObjects({
      owner: options.owner,
      objectType: options.type ? (await this.mvr.resolveType({
        type: options.type,
        signal: options.signal
      })).type : void 0,
      pageToken: options.cursor ? fromBase64(options.cursor) : void 0,
      pageSize: options.limit,
      readMask: { paths }
    }, { abort: options.signal });
    return {
      objects: response.response.objects.map((object2) => ({
        objectId: object2.objectId,
        version: object2.version?.toString(),
        digest: object2.digest,
        content: object2.contents?.value,
        owner: mapOwner(object2.owner),
        type: object2.objectType,
        previousTransaction: object2.previousTransaction ?? void 0,
        objectBcs: object2.bcs?.value,
        json: options.include?.json ? object2.json ? Value.toJson(object2.json) : null : void 0,
        display: mapDisplayProto(options.include?.display, object2.display)
      })),
      cursor: response.response.nextPageToken ? toBase64(response.response.nextPageToken) : null,
      hasNextPage: response.response.nextPageToken !== void 0
    };
  }
  async listCoins(options) {
    const paths = [
      "owner",
      "object_type",
      "digest",
      "version",
      "object_id",
      "balance"
    ];
    const coinType = options.coinType ?? SUI_TYPE_ARG;
    const response = await this.#client.stateService.listOwnedObjects({
      owner: options.owner,
      objectType: `0x2::coin::Coin<${(await this.mvr.resolveType({
        type: coinType,
        signal: options.signal
      })).type}>`,
      pageToken: options.cursor ? fromBase64(options.cursor) : void 0,
      pageSize: options.limit,
      readMask: { paths }
    }, { abort: options.signal });
    return {
      objects: response.response.objects.map((object2) => ({
        objectId: object2.objectId,
        version: object2.version?.toString(),
        digest: object2.digest,
        owner: mapOwner(object2.owner),
        type: object2.objectType,
        balance: object2.balance?.toString()
      })),
      cursor: response.response.nextPageToken ? toBase64(response.response.nextPageToken) : null,
      hasNextPage: response.response.nextPageToken !== void 0
    };
  }
  async getBalance(options) {
    const coinType = options.coinType ?? SUI_TYPE_ARG;
    const result = await this.#client.stateService.getBalance({
      owner: options.owner,
      coinType: (await this.mvr.resolveType({
        type: coinType,
        signal: options.signal
      })).type
    }, { abort: options.signal });
    return { balance: {
      balance: result.response.balance?.balance?.toString() ?? "0",
      coinType: result.response.balance?.coinType ?? coinType,
      coinBalance: result.response.balance?.coinBalance?.toString() ?? "0",
      addressBalance: result.response.balance?.addressBalance?.toString() ?? "0"
    } };
  }
  async getCoinMetadata(options) {
    const coinType = (await this.mvr.resolveType({
      type: options.coinType,
      signal: options.signal
    })).type;
    let response;
    try {
      ({ response } = await this.#client.stateService.getCoinInfo({ coinType }, { abort: options.signal }));
    } catch (error) {
      if (options.signal?.aborted) throw error;
      return { coinMetadata: null };
    }
    if (!response.metadata) return { coinMetadata: null };
    return { coinMetadata: {
      id: response.metadata.id ?? null,
      decimals: response.metadata.decimals ?? 0,
      name: response.metadata.name ?? "",
      symbol: response.metadata.symbol ?? "",
      description: response.metadata.description ?? "",
      iconUrl: response.metadata.iconUrl ?? null
    } };
  }
  async listBalances(options) {
    const result = await this.#client.stateService.listBalances({
      owner: options.owner,
      pageToken: options.cursor ? fromBase64(options.cursor) : void 0,
      pageSize: options.limit
    }, { abort: options.signal });
    return {
      hasNextPage: !!result.response.nextPageToken,
      cursor: result.response.nextPageToken ? toBase64(result.response.nextPageToken) : null,
      balances: result.response.balances.map((balance) => ({
        balance: balance.balance?.toString() ?? "0",
        coinType: balance.coinType,
        coinBalance: balance.coinBalance?.toString() ?? "0",
        addressBalance: balance.addressBalance?.toString() ?? "0"
      }))
    };
  }
  async getTransaction(options) {
    try {
      const { response } = await this.#client.ledgerService.getTransaction({
        digest: options.digest,
        readMask: { paths: transactionReadMaskPaths(options.include) }
      }, { abort: options.signal });
      if (!response.transaction) throw new TransactionError("notFound", options.digest);
      return withProtoJson(parseGrpcTransactionResponse(response.transaction, { include: options.include }), options.include, () => ExecutedTransaction.toJson(response.transaction));
    } catch (error) {
      if (error instanceof import_runtime_rpc3.RpcError && error.code === import_grpcweb_transport2.GrpcStatusCode[import_grpcweb_transport2.GrpcStatusCode.NOT_FOUND]) throw new TransactionError("notFound", options.digest, { cause: error });
      throw error;
    }
  }
  async executeTransaction(options) {
    const { response } = await this.#client.transactionExecutionService.executeTransaction({
      transaction: { bcs: { value: options.transaction } },
      signatures: options.signatures.map((signature) => ({
        bcs: { value: fromBase64(signature) },
        signature: { oneofKind: void 0 }
      })),
      readMask: { paths: transactionReadMaskPaths(options.include) }
    }, { abort: options.signal });
    return withProtoJson(parseGrpcTransactionResponse(response.transaction, { include: options.include }), options.include, () => ExecutedTransaction.toJson(response.transaction));
  }
  async simulateTransaction(options) {
    const paths = transactionReadMaskPaths(options.include, "transaction.");
    if (options.include?.commandResults) paths.push("command_outputs");
    if (!options.include?.effects) paths.push("transaction.effects.gas_object.object_id");
    if (!(options.transaction instanceof Uint8Array)) await options.transaction.prepareForSerialization({ client: this });
    const doGasSelection = options.doGasSelection ?? (options.transaction instanceof Uint8Array ? transactionBytesHaveEmptyGasPayment(options.transaction) : options.transaction.getData().gasData.payment?.length === 0);
    const { response } = await this.#client.transactionExecutionService.simulateTransaction({
      transaction: options.transaction instanceof Uint8Array ? { bcs: { value: options.transaction } } : transactionToGrpcTransaction(options.transaction),
      readMask: { paths },
      doGasSelection,
      checks: options.checksEnabled === false ? SimulateTransactionRequest_TransactionChecks.DISABLED : SimulateTransactionRequest_TransactionChecks.ENABLED
    }, { abort: options.signal });
    return withProtoJson(parseGrpcSimulateTransactionResponse(response, { include: options.include }), options.include, () => SimulateTransactionResponse.toJson(response));
  }
  async getReferenceGasPrice(options) {
    return { referenceGasPrice: (await this.#client.ledgerService.getEpoch({ readMask: { paths: ["reference_gas_price"] } }, { abort: options?.signal })).response.epoch?.referenceGasPrice?.toString() ?? "" };
  }
  async getProtocolConfig(options) {
    const protocolConfig = (await this.#client.ledgerService.getEpoch({ readMask: { paths: ["protocol_config"] } }, { abort: options?.signal })).response.epoch?.protocolConfig;
    if (!protocolConfig) throw new Error("Protocol config not found in response");
    const featureFlags = { ...protocolConfig.featureFlags };
    const attributes = {};
    if (protocolConfig.attributes) for (const [key, value] of Object.entries(protocolConfig.attributes)) attributes[key] = value ?? null;
    return { protocolConfig: {
      protocolVersion: protocolConfig.protocolVersion?.toString() ?? null,
      featureFlags,
      attributes
    } };
  }
  async getCurrentSystemState(options) {
    const epoch = (await this.#client.ledgerService.getEpoch({ readMask: { paths: [
      "system_state.version",
      "system_state.epoch",
      "system_state.protocol_version",
      "system_state.reference_gas_price",
      "system_state.epoch_start_timestamp_ms",
      "system_state.safe_mode",
      "system_state.safe_mode_storage_rewards",
      "system_state.safe_mode_computation_rewards",
      "system_state.safe_mode_storage_rebates",
      "system_state.safe_mode_non_refundable_storage_fee",
      "system_state.parameters",
      "system_state.storage_fund",
      "system_state.stake_subsidy"
    ] } }, { abort: options?.signal })).response.epoch;
    const systemState = epoch?.systemState;
    if (!systemState) throw new Error("System state not found in response");
    const startMs = epoch?.start?.seconds ? Number(epoch.start.seconds) * 1e3 + Math.floor((epoch.start.nanos || 0) / 1e6) : systemState.epochStartTimestampMs ? Number(systemState.epochStartTimestampMs) : null;
    return { systemState: {
      systemStateVersion: systemState.version?.toString() ?? null,
      epoch: systemState.epoch?.toString() ?? null,
      protocolVersion: systemState.protocolVersion?.toString() ?? null,
      referenceGasPrice: systemState.referenceGasPrice?.toString() ?? null,
      epochStartTimestampMs: startMs.toString(),
      safeMode: systemState.safeMode ?? false,
      safeModeStorageRewards: systemState.safeModeStorageRewards?.toString() ?? null,
      safeModeComputationRewards: systemState.safeModeComputationRewards?.toString() ?? null,
      safeModeStorageRebates: systemState.safeModeStorageRebates?.toString() ?? null,
      safeModeNonRefundableStorageFee: systemState.safeModeNonRefundableStorageFee?.toString() ?? null,
      parameters: {
        epochDurationMs: systemState.parameters?.epochDurationMs?.toString() ?? null,
        stakeSubsidyStartEpoch: systemState.parameters?.stakeSubsidyStartEpoch?.toString() ?? null,
        maxValidatorCount: systemState.parameters?.maxValidatorCount?.toString() ?? null,
        minValidatorJoiningStake: systemState.parameters?.minValidatorJoiningStake?.toString() ?? null,
        validatorLowStakeThreshold: systemState.parameters?.validatorLowStakeThreshold?.toString() ?? null,
        validatorLowStakeGracePeriod: systemState.parameters?.validatorLowStakeGracePeriod?.toString() ?? null
      },
      storageFund: {
        totalObjectStorageRebates: systemState.storageFund?.totalObjectStorageRebates?.toString() ?? null,
        nonRefundableBalance: systemState.storageFund?.nonRefundableBalance?.toString() ?? null
      },
      stakeSubsidy: {
        balance: systemState.stakeSubsidy?.balance?.toString() ?? null,
        distributionCounter: systemState.stakeSubsidy?.distributionCounter?.toString() ?? null,
        currentDistributionAmount: systemState.stakeSubsidy?.currentDistributionAmount?.toString() ?? null,
        stakeSubsidyPeriodLength: systemState.stakeSubsidy?.stakeSubsidyPeriodLength?.toString() ?? null,
        stakeSubsidyDecreaseRate: systemState.stakeSubsidy?.stakeSubsidyDecreaseRate ?? null
      }
    } };
  }
  async listDynamicFields(options) {
    return this.#client.listDynamicFields(options);
  }
  async listTransactions(options) {
    const paths = transactionReadMaskPaths(options.include);
    const filter = options.filter ? await resolveTransactionFilter(this.mvr, options.filter, options.signal) : void 0;
    const pagination = resolvePagination(options);
    validateTransactionQuery(filter, pagination);
    const call = this.#client.ledgerService.listTransactions({
      readMask: { paths },
      filter: filter && toGrpcTransactionFilter(filter),
      options: toGrpcQueryOptions(pagination, pagination.limit + 1)
    }, { abort: options.signal });
    const transactions = [];
    let startCursor = null;
    let endCursor = null;
    let frontier = null;
    let end;
    let sawLookaheadItem = false;
    for await (const frame of call.responses) {
      if (frame.watermark?.cursor) frontier = toBase64(frame.watermark.cursor);
      if (frame.transaction) if (transactions.length >= pagination.limit) sawLookaheadItem = true;
      else {
        startCursor ??= frontier;
        endCursor = frontier;
        transactions.push(parseGrpcTransactionResponse(frame.transaction, { include: options.include }));
      }
      if (frame.end) end = frame.end;
    }
    const hasNextPage = sawLookaheadItem || end?.reason === QueryEndReason.SCAN_LIMIT || end?.reason === QueryEndReason.ITEM_LIMIT;
    return {
      transactions,
      hasNextPage,
      startCursor,
      endCursor: sawLookaheadItem ? endCursor : hasNextPage ? frontier ?? endCursor : endCursor
    };
  }
  async listEvents(options) {
    const pagination = resolvePagination(options);
    const call = this.#client.ledgerService.listEvents({
      readMask: { paths: [
        "package_id",
        "module",
        "sender",
        "event_type",
        "contents",
        "json",
        "checkpoint",
        "transaction_digest",
        "event_index"
      ] },
      filter: options.filter ? toGrpcEventFilter(await resolveEventFilter(this.mvr, options.filter, options.signal)) : void 0,
      options: toGrpcQueryOptions(pagination, pagination.limit + 1)
    }, { abort: options.signal });
    const events = [];
    let startCursor = null;
    let endCursor = null;
    let frontier = null;
    let end;
    let sawLookaheadItem = false;
    for await (const frame of call.responses) {
      if (frame.watermark?.cursor) frontier = toBase64(frame.watermark.cursor);
      if (frame.event) if (events.length >= pagination.limit) sawLookaheadItem = true;
      else {
        startCursor ??= frontier;
        endCursor = frontier;
        const event = frame.event;
        events.push({
          packageId: normalizeSuiAddress(event.packageId),
          module: event.module,
          sender: normalizeSuiAddress(event.sender),
          eventType: normalizeStructTag(event.eventType),
          bcs: event.contents?.value ?? new Uint8Array(),
          json: event.json ? Value.toJson(event.json) : null,
          checkpoint: event.checkpoint?.toString() ?? null,
          transactionDigest: event.transactionDigest,
          eventIndex: event.eventIndex
        });
      }
      if (frame.end) end = frame.end;
    }
    const hasNextPage = sawLookaheadItem || end?.reason === QueryEndReason.SCAN_LIMIT || end?.reason === QueryEndReason.ITEM_LIMIT;
    return {
      events,
      hasNextPage,
      startCursor,
      endCursor: sawLookaheadItem ? endCursor : hasNextPage ? frontier ?? endCursor : endCursor
    };
  }
  async verifyZkLoginSignature(options) {
    const messageBytes = fromBase64(options.bytes);
    const messageValue = options.intentScope === "PersonalMessage" ? suiBcs.byteVector().serialize(messageBytes).toBytes() : messageBytes;
    const { response } = await this.#client.signatureVerificationService.verifySignature({
      message: {
        name: options.intentScope,
        value: messageValue
      },
      signature: {
        bcs: { value: fromBase64(options.signature) },
        signature: { oneofKind: void 0 }
      },
      address: options.address,
      jwks: []
    }, { abort: options.signal });
    return {
      success: response.isValid ?? false,
      errors: response.reason ? [response.reason] : []
    };
  }
  async defaultNameServiceName(options) {
    try {
      const { response } = await this.#client.nameService.reverseLookupName({ address: options.address }, { abort: options.signal });
      return { data: { name: response.record?.name ?? null } };
    } catch (error) {
      if (isNameServiceResolutionMiss(error)) return { data: { name: null } };
      throw error;
    }
  }
  async resolveNameServiceAddress(options) {
    try {
      const { response } = await this.#client.nameService.lookupName({ name: options.name }, { abort: options.signal });
      return { address: response.record?.targetAddress ?? null };
    } catch (error) {
      if (isNameServiceResolutionMiss(error)) return { address: null };
      throw error;
    }
  }
  async getMoveFunction(options) {
    const resolvedPackageId = (await this.mvr.resolvePackage({
      package: options.packageId,
      signal: options.signal
    })).package;
    const { response } = await this.#client.movePackageService.getFunction({
      packageId: resolvedPackageId,
      moduleName: options.moduleName,
      name: options.name
    }, { abort: options.signal });
    let visibility = "unknown";
    switch (response.function?.visibility) {
      case FunctionDescriptor_Visibility.PUBLIC:
        visibility = "public";
        break;
      case FunctionDescriptor_Visibility.PRIVATE:
        visibility = "private";
        break;
      case FunctionDescriptor_Visibility.FRIEND:
        visibility = "friend";
        break;
    }
    return { function: {
      packageId: normalizeSuiAddress(resolvedPackageId),
      moduleName: options.moduleName,
      name: response.function?.name,
      visibility,
      isEntry: response.function?.isEntry ?? false,
      typeParameters: response.function?.typeParameters?.map(({ constraints }) => ({
        isPhantom: false,
        constraints: constraints.map((constraint) => {
          switch (constraint) {
            case Ability.COPY:
              return "copy";
            case Ability.DROP:
              return "drop";
            case Ability.STORE:
              return "store";
            case Ability.KEY:
              return "key";
            default:
              return "unknown";
          }
        }) ?? []
      })) ?? [],
      parameters: response.function?.parameters?.map((param) => parseNormalizedSuiMoveType(param)) ?? [],
      returns: response.function?.returns?.map((ret) => parseNormalizedSuiMoveType(ret)) ?? []
    } };
  }
  async getChainIdentifier(options) {
    return raceSignal(Promise.resolve(this.cache.read(["chainIdentifier"], async () => {
      const { response } = await this.#client.ledgerService.getServiceInfo({});
      if (!response.chainId) throw new Error("Chain identifier not found in service info");
      return { chainIdentifier: response.chainId };
    })), options?.signal);
  }
  resolveTransactionPlugin() {
    const client = this.#client;
    return async function resolveTransactionData(transactionData, options, next) {
      const snapshot = transactionData.snapshot();
      if (!snapshot.sender) snapshot.sender = "0x0000000000000000000000000000000000000000000000000000000000000000";
      const grpcTransaction = transactionDataToGrpcTransaction(snapshot);
      const doGasSelection = !options.onlyTransactionKind && (snapshot.gasData.budget == null || snapshot.gasData.payment == null);
      let response;
      try {
        response = (await client.transactionExecutionService.simulateTransaction({
          transaction: grpcTransaction,
          doGasSelection,
          checks: options.onlyTransactionKind ? SimulateTransactionRequest_TransactionChecks.DISABLED : SimulateTransactionRequest_TransactionChecks.ENABLED,
          readMask: { paths: [
            "transaction.transaction.sender",
            "transaction.transaction.gas_payment",
            "transaction.transaction.expiration",
            "transaction.transaction.kind",
            "transaction.effects.status",
            "transaction.effects.epoch"
          ] }
        })).response;
      } catch (error) {
        if (error instanceof Error && error.message) throw new SimulationError(error.message, { cause: error });
        throw error;
      }
      if (!options.onlyTransactionKind && response.transaction?.effects?.status && !response.transaction.effects.status.success) {
        const executionError = response.transaction.effects.status.error ? parseGrpcExecutionError(response.transaction.effects.status.error) : void 0;
        throw new SimulationError(`Transaction resolution failed: ${executionError?.message ?? "Transaction failed"}`, { executionError });
      }
      if (!response.transaction?.transaction) throw new Error("simulateTransaction did not return resolved transaction data");
      applyGrpcResolvedTransaction(transactionData, response.transaction.transaction, options);
      await setAddressBalanceTransactionExpirationFromSimulatedEpoch({
        transactionData,
        client,
        epoch: response.transaction.effects?.epoch,
        originalTransactionData: snapshot,
        isTransactionKindOnly: !!options.onlyTransactionKind,
        doGasSelection
      });
      return await next();
    };
  }
};
function toGrpcQueryOptions(pagination, limit) {
  return {
    limit,
    ordering: pagination.descending ? Ordering.DESCENDING : Ordering.ASCENDING,
    after: pagination.after ? fromBase64(pagination.after) : void 0,
    before: pagination.before ? fromBase64(pagination.before) : void 0
  };
}
function transactionReadMaskPaths(include, prefix = "") {
  const paths = [
    "digest",
    "transaction.digest",
    "signatures",
    "effects.status",
    "timestamp",
    "checkpoint"
  ];
  if (include?.transaction) paths.push("transaction.sender", "transaction.gas_payment", "transaction.expiration", "transaction.kind");
  if (include?.bcs) paths.push("transaction.bcs");
  if (include?.balanceChanges) paths.push("balance_changes");
  if (include?.effects) paths.push("effects");
  if (include?.events) paths.push("events");
  if (include?.objectTypes) {
    paths.push("effects.changed_objects.object_type");
    paths.push("effects.changed_objects.object_id");
  }
  return prefix ? paths.map((path) => prefix + path) : paths;
}
function withProtoJson(result, include, getProtoJson) {
  if (!include?.protoJson) return result;
  return {
    ...result,
    protoJson: getProtoJson()
  };
}
function mapDisplayProto(include, display) {
  if (!include) return void 0;
  if (display === void 0) return null;
  return {
    output: display.output !== void 0 ? Value.toJson(display.output) : null,
    errors: display.errors !== void 0 ? Value.toJson(display.errors) : null
  };
}
function mapOwner(owner) {
  if (!owner) return null;
  if (owner.kind === Owner_OwnerKind.IMMUTABLE) return {
    $kind: "Immutable",
    Immutable: true
  };
  if (owner.kind === Owner_OwnerKind.ADDRESS) return {
    AddressOwner: owner.address,
    $kind: "AddressOwner"
  };
  if (owner.kind === Owner_OwnerKind.OBJECT) return {
    $kind: "ObjectOwner",
    ObjectOwner: owner.address
  };
  if (owner.kind === Owner_OwnerKind.SHARED) return {
    $kind: "Shared",
    Shared: { initialSharedVersion: owner.version?.toString() }
  };
  if (owner.kind === Owner_OwnerKind.CONSENSUS_ADDRESS) return {
    $kind: "ConsensusAddressOwner",
    ConsensusAddressOwner: {
      startVersion: owner.version?.toString(),
      owner: owner.address
    }
  };
  throw new Error(`Unknown owner kind ${JSON.stringify(owner, (_k, v) => typeof v === "bigint" ? v.toString() : v)}`);
}
function parseGrpcExecutionError(error) {
  const message = error.description ?? "Unknown error";
  const command = error.command != null ? Number(error.command) : void 0;
  const details = error.errorDetails;
  switch (details?.oneofKind) {
    case "abort": {
      const abort = details.abort;
      const cleverError = abort.cleverError;
      return {
        $kind: "MoveAbort",
        message: formatMoveAbortMessage({
          command,
          location: abort.location,
          abortCode: String(abort.abortCode ?? 0n),
          cleverError: cleverError ? {
            lineNumber: cleverError.lineNumber != null ? Number(cleverError.lineNumber) : void 0,
            constantName: cleverError.constantName,
            value: cleverError.value?.oneofKind === "rendered" ? cleverError.value.rendered : void 0
          } : void 0
        }),
        command,
        MoveAbort: parseMoveAbort(abort)
      };
    }
    case "sizeError":
      return {
        $kind: "SizeError",
        message,
        command,
        SizeError: {
          name: mapErrorName(error.kind),
          size: Number(details.sizeError.size ?? 0n),
          maxSize: Number(details.sizeError.maxSize ?? 0n)
        }
      };
    case "commandArgumentError":
      return {
        $kind: "CommandArgumentError",
        message,
        command,
        CommandArgumentError: {
          argument: details.commandArgumentError.argument ?? 0,
          name: mapErrorName(details.commandArgumentError.kind)
        }
      };
    case "typeArgumentError":
      return {
        $kind: "TypeArgumentError",
        message,
        command,
        TypeArgumentError: {
          typeArgument: details.typeArgumentError.typeArgument ?? 0,
          name: mapErrorName(details.typeArgumentError.kind)
        }
      };
    case "packageUpgradeError":
      return {
        $kind: "PackageUpgradeError",
        message,
        command,
        PackageUpgradeError: {
          name: mapErrorName(details.packageUpgradeError.kind),
          packageId: details.packageUpgradeError.packageId,
          digest: details.packageUpgradeError.digest
        }
      };
    case "indexError":
      return {
        $kind: "IndexError",
        message,
        command,
        IndexError: {
          index: details.indexError.index,
          subresult: details.indexError.subresult
        }
      };
    case "coinDenyListError":
      return {
        $kind: "CoinDenyListError",
        message,
        command,
        CoinDenyListError: {
          name: mapErrorName(error.kind),
          coinType: details.coinDenyListError.coinType,
          address: details.coinDenyListError.address
        }
      };
    case "congestedObjects":
      return {
        $kind: "CongestedObjects",
        message,
        command,
        CongestedObjects: {
          name: mapErrorName(error.kind),
          objects: details.congestedObjects.objects
        }
      };
    case "objectId":
      return {
        $kind: "ObjectIdError",
        message,
        command,
        ObjectIdError: {
          name: mapErrorName(error.kind),
          objectId: details.objectId
        }
      };
    default:
      return {
        $kind: "Unknown",
        message,
        command,
        Unknown: null
      };
  }
}
function parseMoveAbort(abort) {
  return {
    abortCode: String(abort.abortCode ?? 0n),
    location: { ...abort.location },
    cleverError: abort.cleverError ? {
      errorCode: abort.cleverError.errorCode != null ? Number(abort.cleverError.errorCode) : void 0,
      lineNumber: abort.cleverError.lineNumber != null ? Number(abort.cleverError.lineNumber) : void 0,
      constantName: abort.cleverError.constantName,
      constantType: abort.cleverError.constantType,
      value: abort.cleverError.value?.oneofKind === "rendered" ? abort.cleverError.value.rendered : abort.cleverError.value?.oneofKind === "raw" ? toBase64(abort.cleverError.value.raw) : void 0
    } : void 0
  };
}
function mapErrorName(kind) {
  if (kind == null) return "Unknown";
  const name = CommandArgumentError_CommandArgumentErrorKind[kind];
  if (!name || name.endsWith("_UNKNOWN")) return "Unknown";
  return name.split("_").map((word) => word.charAt(0) + word.slice(1).toLowerCase()).join("");
}
function mapIdOperation(operation) {
  if (operation == null) return null;
  switch (operation) {
    case ChangedObject_IdOperation.CREATED:
      return "Created";
    case ChangedObject_IdOperation.DELETED:
      return "Deleted";
    case ChangedObject_IdOperation.NONE:
    case ChangedObject_IdOperation.ID_OPERATION_UNKNOWN:
      return "None";
    default:
      return "Unknown";
  }
}
function mapInputObjectState(state) {
  if (state == null) return null;
  switch (state) {
    case ChangedObject_InputObjectState.EXISTS:
      return "Exists";
    case ChangedObject_InputObjectState.DOES_NOT_EXIST:
      return "DoesNotExist";
    case ChangedObject_InputObjectState.UNKNOWN:
      return "Unknown";
    default:
      return "Unknown";
  }
}
function mapOutputObjectState(state) {
  if (state == null) return null;
  switch (state) {
    case ChangedObject_OutputObjectState.OBJECT_WRITE:
      return "ObjectWrite";
    case ChangedObject_OutputObjectState.PACKAGE_WRITE:
      return "PackageWrite";
    case ChangedObject_OutputObjectState.DOES_NOT_EXIST:
      return "DoesNotExist";
    case ChangedObject_OutputObjectState.ACCUMULATOR_WRITE:
      return "AccumulatorWriteV1";
    case ChangedObject_OutputObjectState.UNKNOWN:
      return "Unknown";
    default:
      return "Unknown";
  }
}
function mapUnchangedConsensusObjectKind(kind) {
  if (kind == null) return null;
  switch (kind) {
    case UnchangedConsensusObject_UnchangedConsensusObjectKind.UNCHANGED_CONSENSUS_OBJECT_KIND_UNKNOWN:
      return "Unknown";
    case UnchangedConsensusObject_UnchangedConsensusObjectKind.READ_ONLY_ROOT:
      return "ReadOnlyRoot";
    case UnchangedConsensusObject_UnchangedConsensusObjectKind.MUTATE_CONSENSUS_STREAM_ENDED:
      return "MutateConsensusStreamEnded";
    case UnchangedConsensusObject_UnchangedConsensusObjectKind.READ_CONSENSUS_STREAM_ENDED:
      return "ReadConsensusStreamEnded";
    case UnchangedConsensusObject_UnchangedConsensusObjectKind.CANCELED:
      return "Cancelled";
    case UnchangedConsensusObject_UnchangedConsensusObjectKind.PER_EPOCH_CONFIG:
      return "PerEpochConfig";
    default:
      return "Unknown";
  }
}
function parseTransactionEffects({ effects }) {
  if (!effects) return null;
  const changedObjects = effects.changedObjects.map((change) => {
    return {
      objectId: change.objectId,
      inputState: mapInputObjectState(change.inputState),
      inputVersion: change.inputVersion?.toString() ?? null,
      inputDigest: change.inputDigest ?? null,
      inputOwner: mapOwner(change.inputOwner),
      outputState: mapOutputObjectState(change.outputState),
      outputVersion: change.outputVersion?.toString() ?? null,
      outputDigest: change.outputDigest ?? null,
      outputOwner: mapOwner(change.outputOwner),
      idOperation: mapIdOperation(change.idOperation)
    };
  });
  return {
    bcs: effects.bcs?.value,
    version: effects.version ?? 2,
    status: effects.status?.success ? {
      success: true,
      error: null
    } : {
      success: false,
      error: parseGrpcExecutionError(effects.status.error)
    },
    gasUsed: {
      computationCost: effects.gasUsed?.computationCost?.toString(),
      storageCost: effects.gasUsed?.storageCost?.toString(),
      storageRebate: effects.gasUsed?.storageRebate?.toString(),
      nonRefundableStorageFee: effects.gasUsed?.nonRefundableStorageFee?.toString()
    },
    transactionDigest: effects.transactionDigest,
    gasObject: effects.gasObject ? {
      objectId: effects.gasObject.objectId,
      inputState: mapInputObjectState(effects.gasObject.inputState),
      inputVersion: effects.gasObject.inputVersion?.toString() ?? null,
      inputDigest: effects.gasObject.inputDigest ?? null,
      inputOwner: mapOwner(effects.gasObject.inputOwner),
      outputState: mapOutputObjectState(effects.gasObject.outputState),
      outputVersion: effects.gasObject.outputVersion?.toString() ?? null,
      outputDigest: effects.gasObject.outputDigest ?? null,
      outputOwner: mapOwner(effects.gasObject.outputOwner),
      idOperation: mapIdOperation(effects.gasObject.idOperation)
    } : null,
    eventsDigest: effects.eventsDigest ?? null,
    dependencies: effects.dependencies,
    lamportVersion: effects.lamportVersion?.toString() ?? null,
    changedObjects,
    unchangedConsensusObjects: effects.unchangedConsensusObjects.map((object2) => {
      return {
        kind: mapUnchangedConsensusObjectKind(object2.kind),
        objectId: object2.objectId,
        version: object2.version?.toString() ?? null,
        digest: object2.digest ?? null
      };
    }),
    auxiliaryDataDigest: effects.auxiliaryDataDigest ?? null
  };
}
function parseGrpcTransactionResponse(transaction, options) {
  const include = options?.include;
  const objectTypes = {};
  if (include?.objectTypes) transaction.effects?.changedObjects?.forEach((change) => {
    if (change.objectId && change.objectType) objectTypes[change.objectId] = change.objectType;
  });
  let transactionData;
  if (include?.transaction) {
    const tx = transaction.transaction;
    if (!tx) throw new Error("Transaction data is required but missing from gRPC response");
    const resolved = grpcTransactionToTransactionData(tx);
    transactionData = {
      gasData: resolved.gasData,
      sender: resolved.sender,
      expiration: resolved.expiration,
      commands: resolved.commands,
      inputs: resolved.inputs,
      version: resolved.version
    };
  }
  const bcsBytes = include?.bcs ? transaction.transaction?.bcs?.value : void 0;
  const effects = include?.effects ? parseTransactionEffects({ effects: transaction.effects }) : void 0;
  const status = transaction.effects?.status?.success ? {
    success: true,
    error: null
  } : {
    success: false,
    error: transaction.effects?.status?.error ? parseGrpcExecutionError(transaction.effects.status.error) : {
      $kind: "Unknown",
      message: "Transaction failed",
      Unknown: null
    }
  };
  const result = {
    digest: transaction.digest,
    epoch: transaction.effects?.epoch?.toString() ?? null,
    timestampMs: transaction.timestamp ? Number(transaction.timestamp.seconds) * 1e3 + Math.floor(transaction.timestamp.nanos / 1e6) : null,
    checkpoint: transaction.checkpoint?.toString() ?? null,
    status,
    effects,
    objectTypes: include?.objectTypes ? objectTypes : void 0,
    transaction: transactionData,
    bcs: bcsBytes,
    signatures: transaction.signatures?.map((sig) => toBase64(sig.bcs?.value)) ?? [],
    balanceChanges: include?.balanceChanges ? transaction.balanceChanges?.map((change) => ({
      coinType: change.coinType,
      address: change.address,
      amount: change.amount
    })) ?? [] : void 0,
    events: include?.events ? transaction.events?.events.map((event) => ({
      packageId: normalizeSuiAddress(event.packageId),
      module: event.module,
      sender: normalizeSuiAddress(event.sender),
      eventType: event.eventType,
      bcs: event.contents?.value ?? new Uint8Array(),
      json: event.json ? Value.toJson(event.json) : null
    })) ?? [] : void 0
  };
  return status.success ? {
    $kind: "Transaction",
    Transaction: result
  } : {
    $kind: "FailedTransaction",
    FailedTransaction: result
  };
}
function parseGrpcSimulateTransactionResponse(response, options) {
  const include = options?.include;
  const transactionResult = parseGrpcTransactionResponse(response.transaction, { include });
  const gasPaymentMocked = isMockedGasObjectId(response.transaction?.effects?.gasObject?.objectId);
  const commandResults = include?.commandResults && response.commandOutputs ? response.commandOutputs.map((output) => ({
    returnValues: (output.returnValues ?? []).map((rv) => ({ bcs: rv.value?.value ?? null })),
    mutatedReferences: (output.mutatedByRef ?? []).map((mr) => ({ bcs: mr.value?.value ?? null }))
  })) : void 0;
  if (transactionResult.$kind === "Transaction") return {
    $kind: "Transaction",
    Transaction: transactionResult.Transaction,
    commandResults,
    gasPaymentMocked
  };
  return {
    $kind: "FailedTransaction",
    FailedTransaction: transactionResult.FailedTransaction,
    commandResults,
    gasPaymentMocked
  };
}
function parseNormalizedSuiMoveType(type) {
  let reference = null;
  if (type.reference === OpenSignature_Reference.IMMUTABLE) reference = "immutable";
  else if (type.reference === OpenSignature_Reference.MUTABLE) reference = "mutable";
  return {
    reference,
    body: parseNormalizedSuiMoveTypeBody(type.body)
  };
}
function parseNormalizedSuiMoveTypeBody(type) {
  switch (type.type) {
    case OpenSignatureBody_Type.TYPE_UNKNOWN:
      return { $kind: "unknown" };
    case OpenSignatureBody_Type.ADDRESS:
      return { $kind: "address" };
    case OpenSignatureBody_Type.BOOL:
      return { $kind: "bool" };
    case OpenSignatureBody_Type.U8:
      return { $kind: "u8" };
    case OpenSignatureBody_Type.U16:
      return { $kind: "u16" };
    case OpenSignatureBody_Type.U32:
      return { $kind: "u32" };
    case OpenSignatureBody_Type.U64:
      return { $kind: "u64" };
    case OpenSignatureBody_Type.U128:
      return { $kind: "u128" };
    case OpenSignatureBody_Type.U256:
      return { $kind: "u256" };
    case OpenSignatureBody_Type.VECTOR:
      return {
        $kind: "vector",
        vector: parseNormalizedSuiMoveTypeBody(type.typeParameterInstantiation[0])
      };
    case OpenSignatureBody_Type.DATATYPE:
      return {
        $kind: "datatype",
        datatype: {
          typeName: type.typeName,
          typeParameters: type.typeParameterInstantiation.map((t) => parseNormalizedSuiMoveTypeBody(t))
        }
      };
    case OpenSignatureBody_Type.TYPE_PARAMETER:
      return {
        $kind: "typeParameter",
        index: type.typeParameter
      };
    default:
      return { $kind: "unknown" };
  }
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/transaction_execution_service.client.mjs
var import_runtime_rpc4 = __toESM(require_commonjs2(), 1);
var TransactionExecutionServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = TransactionExecutionService.typeName;
    this.methods = TransactionExecutionService.methods;
    this.options = TransactionExecutionService.options;
  }
  /**
  * @generated from protobuf rpc: ExecuteTransaction(sui.rpc.v2.ExecuteTransactionRequest) returns (sui.rpc.v2.ExecuteTransactionResponse);
  */
  executeTransaction(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc4.stackIntercept)("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: SimulateTransaction(sui.rpc.v2.SimulateTransactionRequest) returns (sui.rpc.v2.SimulateTransactionResponse);
  */
  simulateTransaction(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc4.stackIntercept)("unary", this._transport, method, opt, input);
  }
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/filter.mjs
var import_runtime23 = __toESM(require_commonjs(), 1);
var TransactionFilter$Type = class extends import_runtime23.MessageType {
  constructor() {
    super("sui.rpc.v2.TransactionFilter", [{
      no: 1,
      name: "terms",
      kind: "message",
      repeat: 2,
      T: () => TransactionTerm
    }]);
  }
};
var TransactionFilter = new TransactionFilter$Type();
var TransactionTerm$Type = class extends import_runtime23.MessageType {
  constructor() {
    super("sui.rpc.v2.TransactionTerm", [{
      no: 1,
      name: "literals",
      kind: "message",
      repeat: 2,
      T: () => TransactionLiteral
    }]);
  }
};
var TransactionTerm = new TransactionTerm$Type();
var TransactionLiteral$Type = class extends import_runtime23.MessageType {
  constructor() {
    super("sui.rpc.v2.TransactionLiteral", [
      {
        no: 1,
        name: "negated",
        kind: "scalar",
        T: 8
      },
      {
        no: 2,
        name: "sender",
        kind: "message",
        oneof: "predicate",
        T: () => SenderFilter
      },
      {
        no: 3,
        name: "affected_address",
        kind: "message",
        oneof: "predicate",
        T: () => AffectedAddressFilter
      },
      {
        no: 4,
        name: "affected_object",
        kind: "message",
        oneof: "predicate",
        T: () => AffectedObjectFilter
      },
      {
        no: 5,
        name: "move_call",
        kind: "message",
        oneof: "predicate",
        T: () => MoveCallFilter
      },
      {
        no: 6,
        name: "emit_module",
        kind: "message",
        oneof: "predicate",
        T: () => EmitModuleFilter
      },
      {
        no: 7,
        name: "event_type",
        kind: "message",
        oneof: "predicate",
        T: () => EventTypeFilter
      },
      {
        no: 8,
        name: "event_stream_head",
        kind: "message",
        oneof: "predicate",
        T: () => EventStreamHeadFilter
      },
      {
        no: 9,
        name: "package_write",
        kind: "message",
        oneof: "predicate",
        T: () => PackageWriteFilter
      }
    ]);
  }
};
var TransactionLiteral = new TransactionLiteral$Type();
var EventFilter$Type = class extends import_runtime23.MessageType {
  constructor() {
    super("sui.rpc.v2.EventFilter", [{
      no: 1,
      name: "terms",
      kind: "message",
      repeat: 2,
      T: () => EventTerm
    }]);
  }
};
var EventFilter = new EventFilter$Type();
var EventTerm$Type = class extends import_runtime23.MessageType {
  constructor() {
    super("sui.rpc.v2.EventTerm", [{
      no: 1,
      name: "literals",
      kind: "message",
      repeat: 2,
      T: () => EventLiteral
    }]);
  }
};
var EventTerm = new EventTerm$Type();
var EventLiteral$Type = class extends import_runtime23.MessageType {
  constructor() {
    super("sui.rpc.v2.EventLiteral", [
      {
        no: 1,
        name: "negated",
        kind: "scalar",
        T: 8
      },
      {
        no: 2,
        name: "sender",
        kind: "message",
        oneof: "predicate",
        T: () => SenderFilter
      },
      {
        no: 3,
        name: "emit_module",
        kind: "message",
        oneof: "predicate",
        T: () => EmitModuleFilter
      },
      {
        no: 4,
        name: "event_type",
        kind: "message",
        oneof: "predicate",
        T: () => EventTypeFilter
      },
      {
        no: 5,
        name: "event_stream_head",
        kind: "message",
        oneof: "predicate",
        T: () => EventStreamHeadFilter
      }
    ]);
  }
};
var EventLiteral = new EventLiteral$Type();
var SenderFilter$Type = class extends import_runtime23.MessageType {
  constructor() {
    super("sui.rpc.v2.SenderFilter", [{
      no: 1,
      name: "address",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var SenderFilter = new SenderFilter$Type();
var AffectedAddressFilter$Type = class extends import_runtime23.MessageType {
  constructor() {
    super("sui.rpc.v2.AffectedAddressFilter", [{
      no: 1,
      name: "address",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var AffectedAddressFilter = new AffectedAddressFilter$Type();
var AffectedObjectFilter$Type = class extends import_runtime23.MessageType {
  constructor() {
    super("sui.rpc.v2.AffectedObjectFilter", [{
      no: 1,
      name: "object_id",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var AffectedObjectFilter = new AffectedObjectFilter$Type();
var MoveCallFilter$Type = class extends import_runtime23.MessageType {
  constructor() {
    super("sui.rpc.v2.MoveCallFilter", [{
      no: 1,
      name: "function",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var MoveCallFilter = new MoveCallFilter$Type();
var EmitModuleFilter$Type = class extends import_runtime23.MessageType {
  constructor() {
    super("sui.rpc.v2.EmitModuleFilter", [{
      no: 1,
      name: "module",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var EmitModuleFilter = new EmitModuleFilter$Type();
var EventTypeFilter$Type = class extends import_runtime23.MessageType {
  constructor() {
    super("sui.rpc.v2.EventTypeFilter", [{
      no: 1,
      name: "event_type",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var EventTypeFilter = new EventTypeFilter$Type();
var EventStreamHeadFilter$Type = class extends import_runtime23.MessageType {
  constructor() {
    super("sui.rpc.v2.EventStreamHeadFilter", [{
      no: 1,
      name: "stream_id",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var EventStreamHeadFilter = new EventStreamHeadFilter$Type();
var PackageWriteFilter$Type = class extends import_runtime23.MessageType {
  constructor() {
    super("sui.rpc.v2.PackageWriteFilter", []);
  }
};
var PackageWriteFilter = new PackageWriteFilter$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/protocol_config.mjs
var import_runtime24 = __toESM(require_commonjs(), 1);
var ProtocolConfig$Type = class extends import_runtime24.MessageType {
  constructor() {
    super("sui.rpc.v2.ProtocolConfig", [
      {
        no: 1,
        name: "protocol_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "feature_flags",
        kind: "map",
        K: 9,
        V: {
          kind: "scalar",
          T: 8
        }
      },
      {
        no: 3,
        name: "attributes",
        kind: "map",
        K: 9,
        V: {
          kind: "scalar",
          T: 9
        }
      },
      {
        no: 4,
        name: "configs",
        kind: "map",
        K: 9,
        V: {
          kind: "message",
          T: () => Value
        }
      }
    ]);
  }
};
var ProtocolConfig = new ProtocolConfig$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/system_state.mjs
var import_runtime25 = __toESM(require_commonjs(), 1);
var SystemState$Type = class extends import_runtime25.MessageType {
  constructor() {
    super("sui.rpc.v2.SystemState", [
      {
        no: 1,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "protocol_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "validators",
        kind: "message",
        T: () => ValidatorSet
      },
      {
        no: 5,
        name: "storage_fund",
        kind: "message",
        T: () => StorageFund
      },
      {
        no: 6,
        name: "parameters",
        kind: "message",
        T: () => SystemParameters
      },
      {
        no: 7,
        name: "reference_gas_price",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 8,
        name: "validator_report_records",
        kind: "message",
        repeat: 2,
        T: () => ValidatorReportRecord
      },
      {
        no: 9,
        name: "stake_subsidy",
        kind: "message",
        T: () => StakeSubsidy
      },
      {
        no: 10,
        name: "safe_mode",
        kind: "scalar",
        opt: true,
        T: 8
      },
      {
        no: 11,
        name: "safe_mode_storage_rewards",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 12,
        name: "safe_mode_computation_rewards",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 13,
        name: "safe_mode_storage_rebates",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 14,
        name: "safe_mode_non_refundable_storage_fee",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 15,
        name: "epoch_start_timestamp_ms",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 16,
        name: "extra_fields",
        kind: "message",
        T: () => MoveTable
      }
    ]);
  }
};
var SystemState = new SystemState$Type();
var ValidatorReportRecord$Type = class extends import_runtime25.MessageType {
  constructor() {
    super("sui.rpc.v2.ValidatorReportRecord", [{
      no: 1,
      name: "reported",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "reporters",
      kind: "scalar",
      repeat: 2,
      T: 9
    }]);
  }
};
var ValidatorReportRecord = new ValidatorReportRecord$Type();
var SystemParameters$Type = class extends import_runtime25.MessageType {
  constructor() {
    super("sui.rpc.v2.SystemParameters", [
      {
        no: 1,
        name: "epoch_duration_ms",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "stake_subsidy_start_epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "min_validator_count",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "max_validator_count",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "min_validator_joining_stake",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "validator_low_stake_threshold",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "validator_very_low_stake_threshold",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 8,
        name: "validator_low_stake_grace_period",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 9,
        name: "extra_fields",
        kind: "message",
        T: () => MoveTable
      }
    ]);
  }
};
var SystemParameters = new SystemParameters$Type();
var MoveTable$Type = class extends import_runtime25.MessageType {
  constructor() {
    super("sui.rpc.v2.MoveTable", [{
      no: 1,
      name: "id",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "size",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var MoveTable = new MoveTable$Type();
var StakeSubsidy$Type = class extends import_runtime25.MessageType {
  constructor() {
    super("sui.rpc.v2.StakeSubsidy", [
      {
        no: 1,
        name: "balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "distribution_counter",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "current_distribution_amount",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "stake_subsidy_period_length",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "stake_subsidy_decrease_rate",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 6,
        name: "extra_fields",
        kind: "message",
        T: () => MoveTable
      }
    ]);
  }
};
var StakeSubsidy = new StakeSubsidy$Type();
var StorageFund$Type = class extends import_runtime25.MessageType {
  constructor() {
    super("sui.rpc.v2.StorageFund", [{
      no: 1,
      name: "total_object_storage_rebates",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "non_refundable_balance",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var StorageFund = new StorageFund$Type();
var ValidatorSet$Type = class extends import_runtime25.MessageType {
  constructor() {
    super("sui.rpc.v2.ValidatorSet", [
      {
        no: 1,
        name: "total_stake",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "active_validators",
        kind: "message",
        repeat: 2,
        T: () => Validator
      },
      {
        no: 3,
        name: "pending_active_validators",
        kind: "message",
        T: () => MoveTable
      },
      {
        no: 4,
        name: "pending_removals",
        kind: "scalar",
        repeat: 1,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "staking_pool_mappings",
        kind: "message",
        T: () => MoveTable
      },
      {
        no: 6,
        name: "inactive_validators",
        kind: "message",
        T: () => MoveTable
      },
      {
        no: 7,
        name: "validator_candidates",
        kind: "message",
        T: () => MoveTable
      },
      {
        no: 8,
        name: "at_risk_validators",
        kind: "map",
        K: 9,
        V: {
          kind: "scalar",
          T: 4,
          L: 0
        }
      },
      {
        no: 9,
        name: "extra_fields",
        kind: "message",
        T: () => MoveTable
      }
    ]);
  }
};
var ValidatorSet = new ValidatorSet$Type();
var Validator$Type = class extends import_runtime25.MessageType {
  constructor() {
    super("sui.rpc.v2.Validator", [
      {
        no: 1,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "description",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "image_url",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "project_url",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 7,
        name: "protocol_public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 8,
        name: "proof_of_possession",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 10,
        name: "network_public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 12,
        name: "worker_public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 13,
        name: "network_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 14,
        name: "p2p_address",
        kind: "scalar",
        jsonName: "p2pAddress",
        opt: true,
        T: 9
      },
      {
        no: 15,
        name: "primary_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 16,
        name: "worker_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 18,
        name: "next_epoch_protocol_public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 19,
        name: "next_epoch_proof_of_possession",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 21,
        name: "next_epoch_network_public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 23,
        name: "next_epoch_worker_public_key",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 24,
        name: "next_epoch_network_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 25,
        name: "next_epoch_p2p_address",
        kind: "scalar",
        jsonName: "nextEpochP2pAddress",
        opt: true,
        T: 9
      },
      {
        no: 26,
        name: "next_epoch_primary_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 27,
        name: "next_epoch_worker_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 28,
        name: "metadata_extra_fields",
        kind: "message",
        T: () => MoveTable
      },
      {
        no: 29,
        name: "voting_power",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 30,
        name: "operation_cap_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 31,
        name: "gas_price",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 32,
        name: "staking_pool",
        kind: "message",
        T: () => StakingPool
      },
      {
        no: 33,
        name: "commission_rate",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 34,
        name: "next_epoch_stake",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 35,
        name: "next_epoch_gas_price",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 36,
        name: "next_epoch_commission_rate",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 37,
        name: "extra_fields",
        kind: "message",
        T: () => MoveTable
      }
    ]);
  }
};
var Validator = new Validator$Type();
var StakingPool$Type = class extends import_runtime25.MessageType {
  constructor() {
    super("sui.rpc.v2.StakingPool", [
      {
        no: 1,
        name: "id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "activation_epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "deactivation_epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "sui_balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "rewards_pool",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "pool_token_balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "exchange_rates",
        kind: "message",
        T: () => MoveTable
      },
      {
        no: 8,
        name: "pending_stake",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 9,
        name: "pending_total_sui_withdraw",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 10,
        name: "pending_pool_token_withdraw",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 11,
        name: "extra_fields",
        kind: "message",
        T: () => MoveTable
      }
    ]);
  }
};
var StakingPool = new StakingPool$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/epoch.mjs
var import_runtime26 = __toESM(require_commonjs(), 1);
var Epoch$Type = class extends import_runtime26.MessageType {
  constructor() {
    super("sui.rpc.v2.Epoch", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "committee",
        kind: "message",
        T: () => ValidatorCommittee
      },
      {
        no: 3,
        name: "system_state",
        kind: "message",
        T: () => SystemState
      },
      {
        no: 4,
        name: "first_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "last_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "start",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 7,
        name: "end",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 8,
        name: "reference_gas_price",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 9,
        name: "protocol_config",
        kind: "message",
        T: () => ProtocolConfig
      }
    ]);
  }
};
var Epoch = new Epoch$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/checkpoint_contents.mjs
var import_runtime27 = __toESM(require_commonjs(), 1);
var CheckpointContents$Type = class extends import_runtime27.MessageType {
  constructor() {
    super("sui.rpc.v2.CheckpointContents", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 5
      },
      {
        no: 4,
        name: "transactions",
        kind: "message",
        repeat: 2,
        T: () => CheckpointedTransactionInfo
      }
    ]);
  }
};
var CheckpointContents = new CheckpointContents$Type();
var CheckpointedTransactionInfo$Type = class extends import_runtime27.MessageType {
  constructor() {
    super("sui.rpc.v2.CheckpointedTransactionInfo", [
      {
        no: 1,
        name: "transaction",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "effects",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "signatures",
        kind: "message",
        repeat: 2,
        T: () => UserSignature
      },
      {
        no: 4,
        name: "address_aliases_versions",
        kind: "message",
        repeat: 2,
        T: () => AddressAliasesVersion
      }
    ]);
  }
};
var CheckpointedTransactionInfo = new CheckpointedTransactionInfo$Type();
var AddressAliasesVersion$Type = class extends import_runtime27.MessageType {
  constructor() {
    super("sui.rpc.v2.AddressAliasesVersion", [{
      no: 1,
      name: "version",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var AddressAliasesVersion = new AddressAliasesVersion$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/checkpoint_summary.mjs
var import_runtime28 = __toESM(require_commonjs(), 1);
var CheckpointCommitment_CheckpointCommitmentKind = /* @__PURE__ */ (function(CheckpointCommitment_CheckpointCommitmentKind$1) {
  CheckpointCommitment_CheckpointCommitmentKind$1[CheckpointCommitment_CheckpointCommitmentKind$1["CHECKPOINT_COMMITMENT_KIND_UNKNOWN"] = 0] = "CHECKPOINT_COMMITMENT_KIND_UNKNOWN";
  CheckpointCommitment_CheckpointCommitmentKind$1[CheckpointCommitment_CheckpointCommitmentKind$1["ECMH_LIVE_OBJECT_SET"] = 1] = "ECMH_LIVE_OBJECT_SET";
  CheckpointCommitment_CheckpointCommitmentKind$1[CheckpointCommitment_CheckpointCommitmentKind$1["CHECKPOINT_ARTIFACTS"] = 2] = "CHECKPOINT_ARTIFACTS";
  return CheckpointCommitment_CheckpointCommitmentKind$1;
})({});
var CheckpointSummary$Type = class extends import_runtime28.MessageType {
  constructor() {
    super("sui.rpc.v2.CheckpointSummary", [
      {
        no: 1,
        name: "bcs",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "sequence_number",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "total_network_transactions",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 6,
        name: "content_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 7,
        name: "previous_digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 8,
        name: "epoch_rolling_gas_cost_summary",
        kind: "message",
        T: () => GasCostSummary2
      },
      {
        no: 9,
        name: "timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 10,
        name: "commitments",
        kind: "message",
        repeat: 2,
        T: () => CheckpointCommitment
      },
      {
        no: 11,
        name: "end_of_epoch_data",
        kind: "message",
        T: () => EndOfEpochData
      },
      {
        no: 12,
        name: "version_specific_data",
        kind: "scalar",
        opt: true,
        T: 12
      }
    ]);
  }
};
var CheckpointSummary = new CheckpointSummary$Type();
var EndOfEpochData$Type = class extends import_runtime28.MessageType {
  constructor() {
    super("sui.rpc.v2.EndOfEpochData", [
      {
        no: 1,
        name: "next_epoch_committee",
        kind: "message",
        repeat: 2,
        T: () => ValidatorCommitteeMember
      },
      {
        no: 2,
        name: "next_epoch_protocol_version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "epoch_commitments",
        kind: "message",
        repeat: 2,
        T: () => CheckpointCommitment
      }
    ]);
  }
};
var EndOfEpochData = new EndOfEpochData$Type();
var CheckpointCommitment$Type = class extends import_runtime28.MessageType {
  constructor() {
    super("sui.rpc.v2.CheckpointCommitment", [{
      no: 1,
      name: "kind",
      kind: "enum",
      opt: true,
      T: () => ["sui.rpc.v2.CheckpointCommitment.CheckpointCommitmentKind", CheckpointCommitment_CheckpointCommitmentKind]
    }, {
      no: 2,
      name: "digest",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var CheckpointCommitment = new CheckpointCommitment$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/checkpoint.mjs
var import_runtime29 = __toESM(require_commonjs(), 1);
var Checkpoint$Type = class extends import_runtime29.MessageType {
  constructor() {
    super("sui.rpc.v2.Checkpoint", [
      {
        no: 1,
        name: "sequence_number",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "summary",
        kind: "message",
        T: () => CheckpointSummary
      },
      {
        no: 4,
        name: "signature",
        kind: "message",
        T: () => ValidatorAggregatedSignature
      },
      {
        no: 5,
        name: "contents",
        kind: "message",
        T: () => CheckpointContents
      },
      {
        no: 6,
        name: "transactions",
        kind: "message",
        repeat: 2,
        T: () => ExecutedTransaction
      },
      {
        no: 7,
        name: "objects",
        kind: "message",
        T: () => ObjectSet
      }
    ]);
  }
};
var Checkpoint = new Checkpoint$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/google/protobuf/any.mjs
var import_runtime30 = __toESM(require_commonjs(), 1);
var Any$Type = class extends import_runtime30.MessageType {
  constructor() {
    super("google.protobuf.Any", [{
      no: 1,
      name: "type_url",
      kind: "scalar",
      T: 9
    }, {
      no: 2,
      name: "value",
      kind: "scalar",
      T: 12
    }]);
  }
  /**
  * Pack the message into a new `Any`.
  *
  * Uses 'type.googleapis.com/full.type.name' as the type URL.
  */
  pack(message, type) {
    return {
      typeUrl: this.typeNameToUrl(type.typeName),
      value: type.toBinary(message)
    };
  }
  /**
  * Unpack the message from the `Any`.
  */
  unpack(any, type, options) {
    if (!this.contains(any, type)) throw new Error("Cannot unpack google.protobuf.Any with typeUrl '" + any.typeUrl + "' as " + type.typeName + ".");
    return type.fromBinary(any.value, options);
  }
  /**
  * Does the given `Any` contain a packed message of the given type?
  */
  contains(any, type) {
    if (!any.typeUrl.length) return false;
    return (typeof type == "string" ? type : type.typeName) === this.typeUrlToName(any.typeUrl);
  }
  /**
  * Convert the message to canonical JSON value.
  *
  * You have to provide the `typeRegistry` option so that the
  * packed message can be converted to JSON.
  *
  * The `typeRegistry` option is also required to read
  * `google.protobuf.Any` from JSON format.
  */
  internalJsonWrite(any, options) {
    if (any.typeUrl === "") return {};
    let typeName = this.typeUrlToName(any.typeUrl);
    let opt = (0, import_runtime30.jsonWriteOptions)(options);
    let type = opt.typeRegistry?.find((t) => t.typeName === typeName);
    if (!type) throw new globalThis.Error("Unable to convert google.protobuf.Any with typeUrl '" + any.typeUrl + "' to JSON. The specified type " + typeName + " is not available in the type registry.");
    let value = type.fromBinary(any.value, { readUnknownField: false });
    let json = type.internalJsonWrite(value, opt);
    if (typeName.startsWith("google.protobuf.") || !(0, import_runtime30.isJsonObject)(json)) json = { value: json };
    json["@type"] = any.typeUrl;
    return json;
  }
  internalJsonRead(json, options, target) {
    if (!(0, import_runtime30.isJsonObject)(json)) throw new globalThis.Error("Unable to parse google.protobuf.Any from JSON " + (0, import_runtime30.typeofJsonValue)(json) + ".");
    if (typeof json["@type"] != "string" || json["@type"] == "") return this.create();
    let typeName = this.typeUrlToName(json["@type"]);
    let type = options?.typeRegistry?.find((t) => t.typeName == typeName);
    if (!type) throw new globalThis.Error("Unable to parse google.protobuf.Any from JSON. The specified type " + typeName + " is not available in the type registry.");
    let value;
    if (typeName.startsWith("google.protobuf.") && json.hasOwnProperty("value")) value = type.fromJson(json["value"], options);
    else {
      let copy = Object.assign({}, json);
      delete copy["@type"];
      value = type.fromJson(copy, options);
    }
    if (target === void 0) target = this.create();
    target.typeUrl = json["@type"];
    target.value = type.toBinary(value);
    return target;
  }
  typeNameToUrl(name) {
    if (!name.length) throw new Error("invalid type name: " + name);
    return "type.googleapis.com/" + name;
  }
  typeUrlToName(url) {
    if (!url.length) throw new Error("invalid type url: " + url);
    let slash = url.lastIndexOf("/");
    let name = slash > 0 ? url.substring(slash + 1) : url;
    if (!name.length) throw new Error("invalid type url: " + url);
    return name;
  }
};
var Any = new Any$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/google/rpc/status.mjs
var import_runtime31 = __toESM(require_commonjs(), 1);
var Status$Type = class extends import_runtime31.MessageType {
  constructor() {
    super("google.rpc.Status", [
      {
        no: 1,
        name: "code",
        kind: "scalar",
        T: 5
      },
      {
        no: 2,
        name: "message",
        kind: "scalar",
        T: 9
      },
      {
        no: 3,
        name: "details",
        kind: "message",
        repeat: 2,
        T: () => Any
      }
    ]);
  }
};
var Status = new Status$Type();

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/ledger_service.mjs
var import_runtime32 = __toESM(require_commonjs(), 1);
var import_runtime_rpc5 = __toESM(require_commonjs2(), 1);
var GetServiceInfoRequest$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.GetServiceInfoRequest", []);
  }
};
var GetServiceInfoRequest = new GetServiceInfoRequest$Type();
var GetServiceInfoResponse$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.GetServiceInfoResponse", [
      {
        no: 1,
        name: "chain_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "chain",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "epoch",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "checkpoint_height",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 6,
        name: "lowest_available_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 7,
        name: "lowest_available_checkpoint_objects",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 8,
        name: "server",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var GetServiceInfoResponse = new GetServiceInfoResponse$Type();
var GetObjectRequest$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.GetObjectRequest", [
      {
        no: 1,
        name: "object_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "version",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      }
    ]);
  }
};
var GetObjectRequest = new GetObjectRequest$Type();
var GetObjectResponse$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.GetObjectResponse", [{
      no: 1,
      name: "object",
      kind: "message",
      T: () => Object$1
    }]);
  }
};
var GetObjectResponse = new GetObjectResponse$Type();
var BatchGetObjectsRequest$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.BatchGetObjectsRequest", [{
      no: 1,
      name: "requests",
      kind: "message",
      repeat: 2,
      T: () => GetObjectRequest
    }, {
      no: 2,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }]);
  }
};
var BatchGetObjectsRequest = new BatchGetObjectsRequest$Type();
var BatchGetObjectsResponse$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.BatchGetObjectsResponse", [{
      no: 1,
      name: "objects",
      kind: "message",
      repeat: 2,
      T: () => GetObjectResult
    }]);
  }
};
var BatchGetObjectsResponse = new BatchGetObjectsResponse$Type();
var GetObjectResult$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.GetObjectResult", [{
      no: 1,
      name: "object",
      kind: "message",
      oneof: "result",
      T: () => Object$1
    }, {
      no: 2,
      name: "error",
      kind: "message",
      oneof: "result",
      T: () => Status
    }]);
  }
};
var GetObjectResult = new GetObjectResult$Type();
var GetTransactionRequest$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.GetTransactionRequest", [{
      no: 1,
      name: "digest",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }]);
  }
};
var GetTransactionRequest = new GetTransactionRequest$Type();
var GetTransactionResponse$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.GetTransactionResponse", [{
      no: 1,
      name: "transaction",
      kind: "message",
      T: () => ExecutedTransaction
    }]);
  }
};
var GetTransactionResponse = new GetTransactionResponse$Type();
var BatchGetTransactionsRequest$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.BatchGetTransactionsRequest", [{
      no: 1,
      name: "digests",
      kind: "scalar",
      repeat: 2,
      T: 9
    }, {
      no: 2,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }]);
  }
};
var BatchGetTransactionsRequest = new BatchGetTransactionsRequest$Type();
var BatchGetTransactionsResponse$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.BatchGetTransactionsResponse", [{
      no: 1,
      name: "transactions",
      kind: "message",
      repeat: 2,
      T: () => GetTransactionResult
    }]);
  }
};
var BatchGetTransactionsResponse = new BatchGetTransactionsResponse$Type();
var GetTransactionResult$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.GetTransactionResult", [{
      no: 1,
      name: "transaction",
      kind: "message",
      oneof: "result",
      T: () => ExecutedTransaction
    }, {
      no: 2,
      name: "error",
      kind: "message",
      oneof: "result",
      T: () => Status
    }]);
  }
};
var GetTransactionResult = new GetTransactionResult$Type();
var GetCheckpointRequest$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.GetCheckpointRequest", [
      {
        no: 1,
        name: "sequence_number",
        kind: "scalar",
        oneof: "checkpointId",
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "digest",
        kind: "scalar",
        oneof: "checkpointId",
        T: 9
      },
      {
        no: 3,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      }
    ]);
  }
};
var GetCheckpointRequest = new GetCheckpointRequest$Type();
var GetCheckpointResponse$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.GetCheckpointResponse", [{
      no: 1,
      name: "checkpoint",
      kind: "message",
      T: () => Checkpoint
    }]);
  }
};
var GetCheckpointResponse = new GetCheckpointResponse$Type();
var GetEpochRequest$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.GetEpochRequest", [{
      no: 1,
      name: "epoch",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }]);
  }
};
var GetEpochRequest = new GetEpochRequest$Type();
var GetEpochResponse$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.GetEpochResponse", [{
      no: 1,
      name: "epoch",
      kind: "message",
      T: () => Epoch
    }]);
  }
};
var GetEpochResponse = new GetEpochResponse$Type();
var ListCheckpointsRequest$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.ListCheckpointsRequest", [
      {
        no: 1,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      },
      {
        no: 2,
        name: "start_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "end_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "filter",
        kind: "message",
        T: () => TransactionFilter
      },
      {
        no: 5,
        name: "options",
        kind: "message",
        T: () => QueryOptions
      }
    ]);
  }
};
var ListCheckpointsRequest = new ListCheckpointsRequest$Type();
var ListCheckpointsResponse$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.ListCheckpointsResponse", [
      {
        no: 1,
        name: "checkpoint",
        kind: "message",
        T: () => Checkpoint
      },
      {
        no: 2,
        name: "watermark",
        kind: "message",
        T: () => Watermark
      },
      {
        no: 3,
        name: "end",
        kind: "message",
        T: () => QueryEnd
      }
    ]);
  }
};
var ListCheckpointsResponse = new ListCheckpointsResponse$Type();
var ListTransactionsRequest$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.ListTransactionsRequest", [
      {
        no: 1,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      },
      {
        no: 2,
        name: "start_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "end_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "filter",
        kind: "message",
        T: () => TransactionFilter
      },
      {
        no: 5,
        name: "options",
        kind: "message",
        T: () => QueryOptions
      }
    ]);
  }
};
var ListTransactionsRequest = new ListTransactionsRequest$Type();
var ListTransactionsResponse$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.ListTransactionsResponse", [
      {
        no: 1,
        name: "transaction",
        kind: "message",
        T: () => ExecutedTransaction
      },
      {
        no: 2,
        name: "watermark",
        kind: "message",
        T: () => Watermark
      },
      {
        no: 3,
        name: "end",
        kind: "message",
        T: () => QueryEnd
      }
    ]);
  }
};
var ListTransactionsResponse = new ListTransactionsResponse$Type();
var ListEventsRequest$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.ListEventsRequest", [
      {
        no: 1,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      },
      {
        no: 2,
        name: "start_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "end_checkpoint",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "filter",
        kind: "message",
        T: () => EventFilter
      },
      {
        no: 5,
        name: "options",
        kind: "message",
        T: () => QueryOptions
      }
    ]);
  }
};
var ListEventsRequest = new ListEventsRequest$Type();
var ListEventsResponse$Type = class extends import_runtime32.MessageType {
  constructor() {
    super("sui.rpc.v2.ListEventsResponse", [
      {
        no: 1,
        name: "event",
        kind: "message",
        T: () => Event
      },
      {
        no: 2,
        name: "watermark",
        kind: "message",
        T: () => Watermark
      },
      {
        no: 3,
        name: "end",
        kind: "message",
        T: () => QueryEnd
      }
    ]);
  }
};
var ListEventsResponse = new ListEventsResponse$Type();
var LedgerService = new import_runtime_rpc5.ServiceType("sui.rpc.v2.LedgerService", [
  {
    name: "GetServiceInfo",
    options: {},
    I: GetServiceInfoRequest,
    O: GetServiceInfoResponse
  },
  {
    name: "GetObject",
    options: {},
    I: GetObjectRequest,
    O: GetObjectResponse
  },
  {
    name: "BatchGetObjects",
    options: {},
    I: BatchGetObjectsRequest,
    O: BatchGetObjectsResponse
  },
  {
    name: "GetTransaction",
    options: {},
    I: GetTransactionRequest,
    O: GetTransactionResponse
  },
  {
    name: "BatchGetTransactions",
    options: {},
    I: BatchGetTransactionsRequest,
    O: BatchGetTransactionsResponse
  },
  {
    name: "GetCheckpoint",
    options: {},
    I: GetCheckpointRequest,
    O: GetCheckpointResponse
  },
  {
    name: "GetEpoch",
    options: {},
    I: GetEpochRequest,
    O: GetEpochResponse
  },
  {
    name: "ListCheckpoints",
    serverStreaming: true,
    options: {},
    I: ListCheckpointsRequest,
    O: ListCheckpointsResponse
  },
  {
    name: "ListTransactions",
    serverStreaming: true,
    options: {},
    I: ListTransactionsRequest,
    O: ListTransactionsResponse
  },
  {
    name: "ListEvents",
    serverStreaming: true,
    options: {},
    I: ListEventsRequest,
    O: ListEventsResponse
  }
]);

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/ledger_service.client.mjs
var import_runtime_rpc6 = __toESM(require_commonjs2(), 1);
var LedgerServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = LedgerService.typeName;
    this.methods = LedgerService.methods;
    this.options = LedgerService.options;
  }
  /**
  * Query the service for general information about its current state.
  *
  * @generated from protobuf rpc: GetServiceInfo(sui.rpc.v2.GetServiceInfoRequest) returns (sui.rpc.v2.GetServiceInfoResponse);
  */
  getServiceInfo(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc6.stackIntercept)("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetObject(sui.rpc.v2.GetObjectRequest) returns (sui.rpc.v2.GetObjectResponse);
  */
  getObject(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc6.stackIntercept)("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: BatchGetObjects(sui.rpc.v2.BatchGetObjectsRequest) returns (sui.rpc.v2.BatchGetObjectsResponse);
  */
  batchGetObjects(input, options) {
    const method = this.methods[2], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc6.stackIntercept)("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetTransaction(sui.rpc.v2.GetTransactionRequest) returns (sui.rpc.v2.GetTransactionResponse);
  */
  getTransaction(input, options) {
    const method = this.methods[3], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc6.stackIntercept)("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: BatchGetTransactions(sui.rpc.v2.BatchGetTransactionsRequest) returns (sui.rpc.v2.BatchGetTransactionsResponse);
  */
  batchGetTransactions(input, options) {
    const method = this.methods[4], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc6.stackIntercept)("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetCheckpoint(sui.rpc.v2.GetCheckpointRequest) returns (sui.rpc.v2.GetCheckpointResponse);
  */
  getCheckpoint(input, options) {
    const method = this.methods[5], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc6.stackIntercept)("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetEpoch(sui.rpc.v2.GetEpochRequest) returns (sui.rpc.v2.GetEpochResponse);
  */
  getEpoch(input, options) {
    const method = this.methods[6], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc6.stackIntercept)("unary", this._transport, method, opt, input);
  }
  /**
  * List checkpoints matching the provided filters.
  *
  * Checkpoints are returned in ascending or descending checkpoint sequence
  * number order according to the query options ordering.
  * A checkpoint matches if any transaction it contains satisfies the filter.
  *
  * @generated from protobuf rpc: ListCheckpoints(sui.rpc.v2.ListCheckpointsRequest) returns (stream sui.rpc.v2.ListCheckpointsResponse);
  */
  listCheckpoints(input, options) {
    const method = this.methods[7], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc6.stackIntercept)("serverStreaming", this._transport, method, opt, input);
  }
  /**
  * List transactions matching the provided filters.
  *
  * Transactions are returned in ascending or descending transaction sequence
  * order according to the query options ordering.
  *
  * @generated from protobuf rpc: ListTransactions(sui.rpc.v2.ListTransactionsRequest) returns (stream sui.rpc.v2.ListTransactionsResponse);
  */
  listTransactions(input, options) {
    const method = this.methods[8], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc6.stackIntercept)("serverStreaming", this._transport, method, opt, input);
  }
  /**
  * List events matching the provided filters.
  *
  * Events are returned in ascending or descending packed event sequence order
  * according to the query options ordering.
  *
  * @generated from protobuf rpc: ListEvents(sui.rpc.v2.ListEventsRequest) returns (stream sui.rpc.v2.ListEventsResponse);
  */
  listEvents(input, options) {
    const method = this.methods[9], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc6.stackIntercept)("serverStreaming", this._transport, method, opt, input);
  }
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/move_package_service.mjs
var import_runtime33 = __toESM(require_commonjs(), 1);
var import_runtime_rpc7 = __toESM(require_commonjs2(), 1);
var GetPackageRequest$Type = class extends import_runtime33.MessageType {
  constructor() {
    super("sui.rpc.v2.GetPackageRequest", [{
      no: 1,
      name: "package_id",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var GetPackageRequest = new GetPackageRequest$Type();
var GetPackageResponse$Type = class extends import_runtime33.MessageType {
  constructor() {
    super("sui.rpc.v2.GetPackageResponse", [{
      no: 1,
      name: "package",
      kind: "message",
      T: () => Package
    }]);
  }
};
var GetPackageResponse = new GetPackageResponse$Type();
var GetDatatypeRequest$Type = class extends import_runtime33.MessageType {
  constructor() {
    super("sui.rpc.v2.GetDatatypeRequest", [
      {
        no: 1,
        name: "package_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "module_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var GetDatatypeRequest = new GetDatatypeRequest$Type();
var GetDatatypeResponse$Type = class extends import_runtime33.MessageType {
  constructor() {
    super("sui.rpc.v2.GetDatatypeResponse", [{
      no: 1,
      name: "datatype",
      kind: "message",
      T: () => DatatypeDescriptor
    }]);
  }
};
var GetDatatypeResponse = new GetDatatypeResponse$Type();
var GetFunctionRequest$Type = class extends import_runtime33.MessageType {
  constructor() {
    super("sui.rpc.v2.GetFunctionRequest", [
      {
        no: 1,
        name: "package_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "module_name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var GetFunctionRequest = new GetFunctionRequest$Type();
var GetFunctionResponse$Type = class extends import_runtime33.MessageType {
  constructor() {
    super("sui.rpc.v2.GetFunctionResponse", [{
      no: 1,
      name: "function",
      kind: "message",
      T: () => FunctionDescriptor
    }]);
  }
};
var GetFunctionResponse = new GetFunctionResponse$Type();
var ListPackageVersionsRequest$Type = class extends import_runtime33.MessageType {
  constructor() {
    super("sui.rpc.v2.ListPackageVersionsRequest", [
      {
        no: 1,
        name: "package_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "page_size",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "page_token",
        kind: "scalar",
        opt: true,
        T: 12
      }
    ]);
  }
};
var ListPackageVersionsRequest = new ListPackageVersionsRequest$Type();
var ListPackageVersionsResponse$Type = class extends import_runtime33.MessageType {
  constructor() {
    super("sui.rpc.v2.ListPackageVersionsResponse", [{
      no: 1,
      name: "versions",
      kind: "message",
      repeat: 2,
      T: () => PackageVersion
    }, {
      no: 2,
      name: "next_page_token",
      kind: "scalar",
      opt: true,
      T: 12
    }]);
  }
};
var ListPackageVersionsResponse = new ListPackageVersionsResponse$Type();
var PackageVersion$Type = class extends import_runtime33.MessageType {
  constructor() {
    super("sui.rpc.v2.PackageVersion", [{
      no: 1,
      name: "package_id",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "version",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var PackageVersion = new PackageVersion$Type();
var MovePackageService = new import_runtime_rpc7.ServiceType("sui.rpc.v2.MovePackageService", [
  {
    name: "GetPackage",
    options: {},
    I: GetPackageRequest,
    O: GetPackageResponse
  },
  {
    name: "GetDatatype",
    options: {},
    I: GetDatatypeRequest,
    O: GetDatatypeResponse
  },
  {
    name: "GetFunction",
    options: {},
    I: GetFunctionRequest,
    O: GetFunctionResponse
  },
  {
    name: "ListPackageVersions",
    options: {},
    I: ListPackageVersionsRequest,
    O: ListPackageVersionsResponse
  }
]);

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/move_package_service.client.mjs
var import_runtime_rpc8 = __toESM(require_commonjs2(), 1);
var MovePackageServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = MovePackageService.typeName;
    this.methods = MovePackageService.methods;
    this.options = MovePackageService.options;
  }
  /**
  * @generated from protobuf rpc: GetPackage(sui.rpc.v2.GetPackageRequest) returns (sui.rpc.v2.GetPackageResponse);
  */
  getPackage(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc8.stackIntercept)("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetDatatype(sui.rpc.v2.GetDatatypeRequest) returns (sui.rpc.v2.GetDatatypeResponse);
  */
  getDatatype(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc8.stackIntercept)("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetFunction(sui.rpc.v2.GetFunctionRequest) returns (sui.rpc.v2.GetFunctionResponse);
  */
  getFunction(input, options) {
    const method = this.methods[2], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc8.stackIntercept)("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: ListPackageVersions(sui.rpc.v2.ListPackageVersionsRequest) returns (sui.rpc.v2.ListPackageVersionsResponse);
  */
  listPackageVersions(input, options) {
    const method = this.methods[3], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc8.stackIntercept)("unary", this._transport, method, opt, input);
  }
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/signature_verification_service.mjs
var import_runtime34 = __toESM(require_commonjs(), 1);
var import_runtime_rpc9 = __toESM(require_commonjs2(), 1);
var VerifySignatureRequest$Type = class extends import_runtime34.MessageType {
  constructor() {
    super("sui.rpc.v2.VerifySignatureRequest", [
      {
        no: 1,
        name: "message",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 2,
        name: "signature",
        kind: "message",
        T: () => UserSignature
      },
      {
        no: 3,
        name: "address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "jwks",
        kind: "message",
        repeat: 2,
        T: () => ActiveJwk2
      }
    ]);
  }
};
var VerifySignatureRequest = new VerifySignatureRequest$Type();
var VerifySignatureResponse$Type = class extends import_runtime34.MessageType {
  constructor() {
    super("sui.rpc.v2.VerifySignatureResponse", [{
      no: 1,
      name: "is_valid",
      kind: "scalar",
      opt: true,
      T: 8
    }, {
      no: 2,
      name: "reason",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var VerifySignatureResponse = new VerifySignatureResponse$Type();
var SignatureVerificationService = new import_runtime_rpc9.ServiceType("sui.rpc.v2.SignatureVerificationService", [{
  name: "VerifySignature",
  options: {},
  I: VerifySignatureRequest,
  O: VerifySignatureResponse
}]);

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/signature_verification_service.client.mjs
var import_runtime_rpc10 = __toESM(require_commonjs2(), 1);
var SignatureVerificationServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = SignatureVerificationService.typeName;
    this.methods = SignatureVerificationService.methods;
    this.options = SignatureVerificationService.options;
  }
  /**
  * Perform signature verification of a UserSignature against the provided message.
  *
  * @generated from protobuf rpc: VerifySignature(sui.rpc.v2.VerifySignatureRequest) returns (sui.rpc.v2.VerifySignatureResponse);
  */
  verifySignature(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc10.stackIntercept)("unary", this._transport, method, opt, input);
  }
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/state_service.mjs
var import_runtime35 = __toESM(require_commonjs(), 1);
var import_runtime_rpc11 = __toESM(require_commonjs2(), 1);
var CoinMetadata_MetadataCapState = /* @__PURE__ */ (function(CoinMetadata_MetadataCapState$1) {
  CoinMetadata_MetadataCapState$1[CoinMetadata_MetadataCapState$1["METADATA_CAP_STATE_UNKNOWN"] = 0] = "METADATA_CAP_STATE_UNKNOWN";
  CoinMetadata_MetadataCapState$1[CoinMetadata_MetadataCapState$1["CLAIMED"] = 1] = "CLAIMED";
  CoinMetadata_MetadataCapState$1[CoinMetadata_MetadataCapState$1["UNCLAIMED"] = 2] = "UNCLAIMED";
  CoinMetadata_MetadataCapState$1[CoinMetadata_MetadataCapState$1["DELETED"] = 3] = "DELETED";
  return CoinMetadata_MetadataCapState$1;
})({});
var CoinTreasury_SupplyState = /* @__PURE__ */ (function(CoinTreasury_SupplyState$1) {
  CoinTreasury_SupplyState$1[CoinTreasury_SupplyState$1["SUPPLY_STATE_UNKNOWN"] = 0] = "SUPPLY_STATE_UNKNOWN";
  CoinTreasury_SupplyState$1[CoinTreasury_SupplyState$1["FIXED"] = 1] = "FIXED";
  CoinTreasury_SupplyState$1[CoinTreasury_SupplyState$1["BURN_ONLY"] = 2] = "BURN_ONLY";
  return CoinTreasury_SupplyState$1;
})({});
var RegulatedCoinMetadata_CoinRegulatedState = /* @__PURE__ */ (function(RegulatedCoinMetadata_CoinRegulatedState$1) {
  RegulatedCoinMetadata_CoinRegulatedState$1[RegulatedCoinMetadata_CoinRegulatedState$1["COIN_REGULATED_STATE_UNKNOWN"] = 0] = "COIN_REGULATED_STATE_UNKNOWN";
  RegulatedCoinMetadata_CoinRegulatedState$1[RegulatedCoinMetadata_CoinRegulatedState$1["REGULATED"] = 1] = "REGULATED";
  RegulatedCoinMetadata_CoinRegulatedState$1[RegulatedCoinMetadata_CoinRegulatedState$1["UNREGULATED"] = 2] = "UNREGULATED";
  return RegulatedCoinMetadata_CoinRegulatedState$1;
})({});
var DynamicField_DynamicFieldKind = /* @__PURE__ */ (function(DynamicField_DynamicFieldKind$1) {
  DynamicField_DynamicFieldKind$1[DynamicField_DynamicFieldKind$1["DYNAMIC_FIELD_KIND_UNKNOWN"] = 0] = "DYNAMIC_FIELD_KIND_UNKNOWN";
  DynamicField_DynamicFieldKind$1[DynamicField_DynamicFieldKind$1["FIELD"] = 1] = "FIELD";
  DynamicField_DynamicFieldKind$1[DynamicField_DynamicFieldKind$1["OBJECT"] = 2] = "OBJECT";
  return DynamicField_DynamicFieldKind$1;
})({});
var GetCoinInfoRequest$Type = class extends import_runtime35.MessageType {
  constructor() {
    super("sui.rpc.v2.GetCoinInfoRequest", [{
      no: 1,
      name: "coin_type",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var GetCoinInfoRequest = new GetCoinInfoRequest$Type();
var GetCoinInfoResponse$Type = class extends import_runtime35.MessageType {
  constructor() {
    super("sui.rpc.v2.GetCoinInfoResponse", [
      {
        no: 1,
        name: "coin_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "metadata",
        kind: "message",
        T: () => CoinMetadata
      },
      {
        no: 3,
        name: "treasury",
        kind: "message",
        T: () => CoinTreasury
      },
      {
        no: 4,
        name: "regulated_metadata",
        kind: "message",
        T: () => RegulatedCoinMetadata
      }
    ]);
  }
};
var GetCoinInfoResponse = new GetCoinInfoResponse$Type();
var CoinMetadata$Type = class extends import_runtime35.MessageType {
  constructor() {
    super("sui.rpc.v2.CoinMetadata", [
      {
        no: 1,
        name: "id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "decimals",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "symbol",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 5,
        name: "description",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 6,
        name: "icon_url",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 7,
        name: "metadata_cap_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 8,
        name: "metadata_cap_state",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.CoinMetadata.MetadataCapState", CoinMetadata_MetadataCapState]
      }
    ]);
  }
};
var CoinMetadata = new CoinMetadata$Type();
var CoinTreasury$Type = class extends import_runtime35.MessageType {
  constructor() {
    super("sui.rpc.v2.CoinTreasury", [
      {
        no: 1,
        name: "id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "total_supply",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "supply_state",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.CoinTreasury.SupplyState", CoinTreasury_SupplyState]
      }
    ]);
  }
};
var CoinTreasury = new CoinTreasury$Type();
var RegulatedCoinMetadata$Type = class extends import_runtime35.MessageType {
  constructor() {
    super("sui.rpc.v2.RegulatedCoinMetadata", [
      {
        no: 1,
        name: "id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "coin_metadata_object",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "deny_cap_object",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "allow_global_pause",
        kind: "scalar",
        opt: true,
        T: 8
      },
      {
        no: 5,
        name: "variant",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 6,
        name: "coin_regulated_state",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.RegulatedCoinMetadata.CoinRegulatedState", RegulatedCoinMetadata_CoinRegulatedState]
      }
    ]);
  }
};
var RegulatedCoinMetadata = new RegulatedCoinMetadata$Type();
var GetBalanceRequest$Type = class extends import_runtime35.MessageType {
  constructor() {
    super("sui.rpc.v2.GetBalanceRequest", [{
      no: 1,
      name: "owner",
      kind: "scalar",
      opt: true,
      T: 9
    }, {
      no: 2,
      name: "coin_type",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var GetBalanceRequest = new GetBalanceRequest$Type();
var GetBalanceResponse$Type = class extends import_runtime35.MessageType {
  constructor() {
    super("sui.rpc.v2.GetBalanceResponse", [{
      no: 1,
      name: "balance",
      kind: "message",
      T: () => Balance
    }]);
  }
};
var GetBalanceResponse = new GetBalanceResponse$Type();
var ListBalancesRequest$Type = class extends import_runtime35.MessageType {
  constructor() {
    super("sui.rpc.v2.ListBalancesRequest", [
      {
        no: 1,
        name: "owner",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "page_size",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "page_token",
        kind: "scalar",
        opt: true,
        T: 12
      }
    ]);
  }
};
var ListBalancesRequest = new ListBalancesRequest$Type();
var ListBalancesResponse$Type = class extends import_runtime35.MessageType {
  constructor() {
    super("sui.rpc.v2.ListBalancesResponse", [{
      no: 1,
      name: "balances",
      kind: "message",
      repeat: 2,
      T: () => Balance
    }, {
      no: 2,
      name: "next_page_token",
      kind: "scalar",
      opt: true,
      T: 12
    }]);
  }
};
var ListBalancesResponse = new ListBalancesResponse$Type();
var Balance$Type = class extends import_runtime35.MessageType {
  constructor() {
    super("sui.rpc.v2.Balance", [
      {
        no: 1,
        name: "coin_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "address_balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      },
      {
        no: 5,
        name: "coin_balance",
        kind: "scalar",
        opt: true,
        T: 4,
        L: 0
      }
    ]);
  }
};
var Balance = new Balance$Type();
var ListDynamicFieldsRequest$Type = class extends import_runtime35.MessageType {
  constructor() {
    super("sui.rpc.v2.ListDynamicFieldsRequest", [
      {
        no: 1,
        name: "parent",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "page_size",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "page_token",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 4,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      }
    ]);
  }
};
var ListDynamicFieldsRequest = new ListDynamicFieldsRequest$Type();
var ListDynamicFieldsResponse$Type = class extends import_runtime35.MessageType {
  constructor() {
    super("sui.rpc.v2.ListDynamicFieldsResponse", [{
      no: 1,
      name: "dynamic_fields",
      kind: "message",
      repeat: 2,
      T: () => DynamicField
    }, {
      no: 2,
      name: "next_page_token",
      kind: "scalar",
      opt: true,
      T: 12
    }]);
  }
};
var ListDynamicFieldsResponse = new ListDynamicFieldsResponse$Type();
var DynamicField$Type = class extends import_runtime35.MessageType {
  constructor() {
    super("sui.rpc.v2.DynamicField", [
      {
        no: 1,
        name: "kind",
        kind: "enum",
        opt: true,
        T: () => ["sui.rpc.v2.DynamicField.DynamicFieldKind", DynamicField_DynamicFieldKind]
      },
      {
        no: 2,
        name: "parent",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "field_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "field_object",
        kind: "message",
        T: () => Object$1
      },
      {
        no: 5,
        name: "name",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 6,
        name: "value",
        kind: "message",
        T: () => Bcs
      },
      {
        no: 7,
        name: "value_type",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 8,
        name: "child_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 9,
        name: "child_object",
        kind: "message",
        T: () => Object$1
      }
    ]);
  }
};
var DynamicField = new DynamicField$Type();
var ListOwnedObjectsRequest$Type = class extends import_runtime35.MessageType {
  constructor() {
    super("sui.rpc.v2.ListOwnedObjectsRequest", [
      {
        no: 1,
        name: "owner",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "page_size",
        kind: "scalar",
        opt: true,
        T: 13
      },
      {
        no: 3,
        name: "page_token",
        kind: "scalar",
        opt: true,
        T: 12
      },
      {
        no: 4,
        name: "read_mask",
        kind: "message",
        T: () => FieldMask
      },
      {
        no: 5,
        name: "object_type",
        kind: "scalar",
        opt: true,
        T: 9
      }
    ]);
  }
};
var ListOwnedObjectsRequest = new ListOwnedObjectsRequest$Type();
var ListOwnedObjectsResponse$Type = class extends import_runtime35.MessageType {
  constructor() {
    super("sui.rpc.v2.ListOwnedObjectsResponse", [{
      no: 1,
      name: "objects",
      kind: "message",
      repeat: 2,
      T: () => Object$1
    }, {
      no: 2,
      name: "next_page_token",
      kind: "scalar",
      opt: true,
      T: 12
    }]);
  }
};
var ListOwnedObjectsResponse = new ListOwnedObjectsResponse$Type();
var StateService = new import_runtime_rpc11.ServiceType("sui.rpc.v2.StateService", [
  {
    name: "ListDynamicFields",
    options: {},
    I: ListDynamicFieldsRequest,
    O: ListDynamicFieldsResponse
  },
  {
    name: "ListOwnedObjects",
    options: {},
    I: ListOwnedObjectsRequest,
    O: ListOwnedObjectsResponse
  },
  {
    name: "GetCoinInfo",
    options: {},
    I: GetCoinInfoRequest,
    O: GetCoinInfoResponse
  },
  {
    name: "GetBalance",
    options: {},
    I: GetBalanceRequest,
    O: GetBalanceResponse
  },
  {
    name: "ListBalances",
    options: {},
    I: ListBalancesRequest,
    O: ListBalancesResponse
  }
]);

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/state_service.client.mjs
var import_runtime_rpc12 = __toESM(require_commonjs2(), 1);
var StateServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = StateService.typeName;
    this.methods = StateService.methods;
    this.options = StateService.options;
  }
  /**
  * @generated from protobuf rpc: ListDynamicFields(sui.rpc.v2.ListDynamicFieldsRequest) returns (sui.rpc.v2.ListDynamicFieldsResponse);
  */
  listDynamicFields(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc12.stackIntercept)("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: ListOwnedObjects(sui.rpc.v2.ListOwnedObjectsRequest) returns (sui.rpc.v2.ListOwnedObjectsResponse);
  */
  listOwnedObjects(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc12.stackIntercept)("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetCoinInfo(sui.rpc.v2.GetCoinInfoRequest) returns (sui.rpc.v2.GetCoinInfoResponse);
  */
  getCoinInfo(input, options) {
    const method = this.methods[2], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc12.stackIntercept)("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: GetBalance(sui.rpc.v2.GetBalanceRequest) returns (sui.rpc.v2.GetBalanceResponse);
  */
  getBalance(input, options) {
    const method = this.methods[3], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc12.stackIntercept)("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: ListBalances(sui.rpc.v2.ListBalancesRequest) returns (sui.rpc.v2.ListBalancesResponse);
  */
  listBalances(input, options) {
    const method = this.methods[4], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc12.stackIntercept)("unary", this._transport, method, opt, input);
  }
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/subscription_service.mjs
var import_runtime36 = __toESM(require_commonjs(), 1);
var import_runtime_rpc13 = __toESM(require_commonjs2(), 1);
var SubscribeCheckpointsRequest$Type = class extends import_runtime36.MessageType {
  constructor() {
    super("sui.rpc.v2.SubscribeCheckpointsRequest", [{
      no: 1,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }, {
      no: 2,
      name: "filter",
      kind: "message",
      T: () => TransactionFilter
    }]);
  }
};
var SubscribeCheckpointsRequest = new SubscribeCheckpointsRequest$Type();
var SubscribeCheckpointsResponse$Type = class extends import_runtime36.MessageType {
  constructor() {
    super("sui.rpc.v2.SubscribeCheckpointsResponse", [{
      no: 1,
      name: "cursor",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "checkpoint",
      kind: "message",
      T: () => Checkpoint
    }]);
  }
};
var SubscribeCheckpointsResponse = new SubscribeCheckpointsResponse$Type();
var SubscribeTransactionsRequest$Type = class extends import_runtime36.MessageType {
  constructor() {
    super("sui.rpc.v2.SubscribeTransactionsRequest", [{
      no: 1,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }, {
      no: 2,
      name: "filter",
      kind: "message",
      T: () => TransactionFilter
    }]);
  }
};
var SubscribeTransactionsRequest = new SubscribeTransactionsRequest$Type();
var SubscribeTransactionsResponse$Type = class extends import_runtime36.MessageType {
  constructor() {
    super("sui.rpc.v2.SubscribeTransactionsResponse", [{
      no: 1,
      name: "transaction",
      kind: "message",
      T: () => ExecutedTransaction
    }, {
      no: 2,
      name: "watermark",
      kind: "message",
      T: () => Watermark
    }]);
  }
};
var SubscribeTransactionsResponse = new SubscribeTransactionsResponse$Type();
var SubscribeEventsRequest$Type = class extends import_runtime36.MessageType {
  constructor() {
    super("sui.rpc.v2.SubscribeEventsRequest", [{
      no: 1,
      name: "read_mask",
      kind: "message",
      T: () => FieldMask
    }, {
      no: 2,
      name: "filter",
      kind: "message",
      T: () => EventFilter
    }]);
  }
};
var SubscribeEventsRequest = new SubscribeEventsRequest$Type();
var SubscribeEventsResponse$Type = class extends import_runtime36.MessageType {
  constructor() {
    super("sui.rpc.v2.SubscribeEventsResponse", [{
      no: 1,
      name: "event",
      kind: "message",
      T: () => Event
    }, {
      no: 2,
      name: "watermark",
      kind: "message",
      T: () => Watermark
    }]);
  }
};
var SubscribeEventsResponse = new SubscribeEventsResponse$Type();
var SubscriptionService = new import_runtime_rpc13.ServiceType("sui.rpc.v2.SubscriptionService", [
  {
    name: "SubscribeCheckpoints",
    serverStreaming: true,
    options: {},
    I: SubscribeCheckpointsRequest,
    O: SubscribeCheckpointsResponse
  },
  {
    name: "SubscribeTransactions",
    serverStreaming: true,
    options: {},
    I: SubscribeTransactionsRequest,
    O: SubscribeTransactionsResponse
  },
  {
    name: "SubscribeEvents",
    serverStreaming: true,
    options: {},
    I: SubscribeEventsRequest,
    O: SubscribeEventsResponse
  }
]);

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/subscription_service.client.mjs
var import_runtime_rpc14 = __toESM(require_commonjs2(), 1);
var SubscriptionServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = SubscriptionService.typeName;
    this.methods = SubscriptionService.methods;
    this.options = SubscriptionService.options;
  }
  /**
  * Subscribe to the stream of checkpoints.
  *
  * The stream begins at the latest executed checkpoint as seen by the
  * server and yields checkpoints matching the filter as they are executed.
  * A checkpoint matches if any transaction it contains satisfies the
  * filter.
  *
  * @generated from protobuf rpc: SubscribeCheckpoints(sui.rpc.v2.SubscribeCheckpointsRequest) returns (stream sui.rpc.v2.SubscribeCheckpointsResponse);
  */
  subscribeCheckpoints(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc14.stackIntercept)("serverStreaming", this._transport, method, opt, input);
  }
  /**
  * Subscribe to the stream of transactions.
  *
  * The stream begins at the latest executed checkpoint as seen by the
  * server and yields transactions matching the filter as they are executed.
  *
  * @generated from protobuf rpc: SubscribeTransactions(sui.rpc.v2.SubscribeTransactionsRequest) returns (stream sui.rpc.v2.SubscribeTransactionsResponse);
  */
  subscribeTransactions(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc14.stackIntercept)("serverStreaming", this._transport, method, opt, input);
  }
  /**
  * Subscribe to the stream of events.
  *
  * The stream begins at the latest executed checkpoint as seen by the
  * server and yields events matching the filter as they are emitted.
  *
  * @generated from protobuf rpc: SubscribeEvents(sui.rpc.v2.SubscribeEventsRequest) returns (stream sui.rpc.v2.SubscribeEventsResponse);
  */
  subscribeEvents(input, options) {
    const method = this.methods[2], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc14.stackIntercept)("serverStreaming", this._transport, method, opt, input);
  }
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/name_service.mjs
var import_runtime37 = __toESM(require_commonjs(), 1);
var import_runtime_rpc15 = __toESM(require_commonjs2(), 1);
var LookupNameRequest$Type = class extends import_runtime37.MessageType {
  constructor() {
    super("sui.rpc.v2.LookupNameRequest", [{
      no: 1,
      name: "name",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var LookupNameRequest = new LookupNameRequest$Type();
var LookupNameResponse$Type = class extends import_runtime37.MessageType {
  constructor() {
    super("sui.rpc.v2.LookupNameResponse", [{
      no: 1,
      name: "record",
      kind: "message",
      T: () => NameRecord
    }]);
  }
};
var LookupNameResponse = new LookupNameResponse$Type();
var ReverseLookupNameRequest$Type = class extends import_runtime37.MessageType {
  constructor() {
    super("sui.rpc.v2.ReverseLookupNameRequest", [{
      no: 1,
      name: "address",
      kind: "scalar",
      opt: true,
      T: 9
    }]);
  }
};
var ReverseLookupNameRequest = new ReverseLookupNameRequest$Type();
var ReverseLookupNameResponse$Type = class extends import_runtime37.MessageType {
  constructor() {
    super("sui.rpc.v2.ReverseLookupNameResponse", [{
      no: 1,
      name: "record",
      kind: "message",
      T: () => NameRecord
    }]);
  }
};
var ReverseLookupNameResponse = new ReverseLookupNameResponse$Type();
var NameRecord$Type = class extends import_runtime37.MessageType {
  constructor() {
    super("sui.rpc.v2.NameRecord", [
      {
        no: 1,
        name: "id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 2,
        name: "name",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 3,
        name: "registration_nft_id",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 4,
        name: "expiration_timestamp",
        kind: "message",
        T: () => Timestamp
      },
      {
        no: 5,
        name: "target_address",
        kind: "scalar",
        opt: true,
        T: 9
      },
      {
        no: 6,
        name: "data",
        kind: "map",
        K: 9,
        V: {
          kind: "scalar",
          T: 9
        }
      }
    ]);
  }
};
var NameRecord = new NameRecord$Type();
var NameService = new import_runtime_rpc15.ServiceType("sui.rpc.v2.NameService", [{
  name: "LookupName",
  options: {},
  I: LookupNameRequest,
  O: LookupNameResponse
}, {
  name: "ReverseLookupName",
  options: {},
  I: ReverseLookupNameRequest,
  O: ReverseLookupNameResponse
}]);

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/rpc/v2/name_service.client.mjs
var import_runtime_rpc16 = __toESM(require_commonjs2(), 1);
var NameServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = NameService.typeName;
    this.methods = NameService.methods;
    this.options = NameService.options;
  }
  /**
  * @generated from protobuf rpc: LookupName(sui.rpc.v2.LookupNameRequest) returns (sui.rpc.v2.LookupNameResponse);
  */
  lookupName(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc16.stackIntercept)("unary", this._transport, method, opt, input);
  }
  /**
  * @generated from protobuf rpc: ReverseLookupName(sui.rpc.v2.ReverseLookupNameRequest) returns (sui.rpc.v2.ReverseLookupNameResponse);
  */
  reverseLookupName(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc16.stackIntercept)("unary", this._transport, method, opt, input);
  }
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/forking/v1alpha/forking_service.mjs
var import_runtime38 = __toESM(require_commonjs(), 1);
var import_runtime_rpc17 = __toESM(require_commonjs2(), 1);
var AdvanceClockRequest$Type = class extends import_runtime38.MessageType {
  constructor() {
    super("sui.forking.v1alpha.AdvanceClockRequest", [{
      no: 1,
      name: "duration_ms",
      kind: "scalar",
      opt: true,
      T: 4,
      L: 0
    }]);
  }
};
var AdvanceClockRequest = new AdvanceClockRequest$Type();
var AdvanceClockResponse$Type = class extends import_runtime38.MessageType {
  constructor() {
    super("sui.forking.v1alpha.AdvanceClockResponse", [{
      no: 1,
      name: "timestamp_ms",
      kind: "scalar",
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "tx_digest",
      kind: "scalar",
      T: 9
    }]);
  }
};
var AdvanceClockResponse = new AdvanceClockResponse$Type();
var AdvanceCheckpointRequest$Type = class extends import_runtime38.MessageType {
  constructor() {
    super("sui.forking.v1alpha.AdvanceCheckpointRequest", []);
  }
};
var AdvanceCheckpointRequest = new AdvanceCheckpointRequest$Type();
var AdvanceCheckpointResponse$Type = class extends import_runtime38.MessageType {
  constructor() {
    super("sui.forking.v1alpha.AdvanceCheckpointResponse", [{
      no: 1,
      name: "checkpoint_sequence_number",
      kind: "scalar",
      T: 4,
      L: 0
    }, {
      no: 2,
      name: "timestamp_ms",
      kind: "scalar",
      T: 4,
      L: 0
    }]);
  }
};
var AdvanceCheckpointResponse = new AdvanceCheckpointResponse$Type();
var GetStatusRequest$Type = class extends import_runtime38.MessageType {
  constructor() {
    super("sui.forking.v1alpha.GetStatusRequest", []);
  }
};
var GetStatusRequest = new GetStatusRequest$Type();
var GetStatusResponse$Type = class extends import_runtime38.MessageType {
  constructor() {
    super("sui.forking.v1alpha.GetStatusResponse", [
      {
        no: 1,
        name: "epoch",
        kind: "scalar",
        T: 4,
        L: 0
      },
      {
        no: 2,
        name: "checkpoint_sequence_number",
        kind: "scalar",
        T: 4,
        L: 0
      },
      {
        no: 3,
        name: "timestamp_ms",
        kind: "scalar",
        T: 4,
        L: 0
      },
      {
        no: 4,
        name: "forked_at_checkpoint",
        kind: "scalar",
        T: 4,
        L: 0
      }
    ]);
  }
};
var GetStatusResponse = new GetStatusResponse$Type();
var ForkingService = new import_runtime_rpc17.ServiceType("sui.forking.v1alpha.ForkingService", [
  {
    name: "AdvanceClock",
    options: {},
    I: AdvanceClockRequest,
    O: AdvanceClockResponse
  },
  {
    name: "AdvanceCheckpoint",
    options: {},
    I: AdvanceCheckpointRequest,
    O: AdvanceCheckpointResponse
  },
  {
    name: "GetStatus",
    options: {},
    I: GetStatusRequest,
    O: GetStatusResponse
  }
]);

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/proto/sui/forking/v1alpha/forking_service.client.mjs
var import_runtime_rpc18 = __toESM(require_commonjs2(), 1);
var ForkingServiceClient = class {
  constructor(_transport) {
    this._transport = _transport;
    this.typeName = ForkingService.typeName;
    this.methods = ForkingService.methods;
    this.options = ForkingService.options;
  }
  /**
  * Advance the forked network's clock by a given duration.
  *
  * @generated from protobuf rpc: AdvanceClock(sui.forking.v1alpha.AdvanceClockRequest) returns (sui.forking.v1alpha.AdvanceClockResponse);
  */
  advanceClock(input, options) {
    const method = this.methods[0], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc18.stackIntercept)("unary", this._transport, method, opt, input);
  }
  /**
  * Seal pending transactions into a new checkpoint.
  *
  * @generated from protobuf rpc: AdvanceCheckpoint(sui.forking.v1alpha.AdvanceCheckpointRequest) returns (sui.forking.v1alpha.AdvanceCheckpointResponse);
  */
  advanceCheckpoint(input, options) {
    const method = this.methods[1], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc18.stackIntercept)("unary", this._transport, method, opt, input);
  }
  /**
  * Return the current state of the forked network.
  *
  * @generated from protobuf rpc: GetStatus(sui.forking.v1alpha.GetStatusRequest) returns (sui.forking.v1alpha.GetStatusResponse);
  */
  getStatus(input, options) {
    const method = this.methods[2], opt = this._transport.mergeOptions(options);
    return (0, import_runtime_rpc18.stackIntercept)("unary", this._transport, method, opt, input);
  }
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/grpc/client.mjs
var SUI_CLIENT_BRAND = /* @__PURE__ */ Symbol.for("@mysten/SuiGrpcClient");
var SuiGrpcClient = class extends BaseClient {
  get mvr() {
    return this.core.mvr;
  }
  get [SUI_CLIENT_BRAND]() {
    return true;
  }
  constructor(options) {
    super({ network: options.network });
    const { network: _network, mvr: _mvr, abort: _abort, transport: providedTransport, ...transportOptions } = options;
    const transport = withClientProtocolVersion(providedTransport ?? new GrpcWebFetchTransport$1(transportOptions));
    this.transactionExecutionService = new TransactionExecutionServiceClient(transport);
    this.ledgerService = new LedgerServiceClient(transport);
    this.stateService = new StateServiceClient(transport);
    this.subscriptionService = new SubscriptionServiceClient(transport);
    this.movePackageService = new MovePackageServiceClient(transport);
    this.signatureVerificationService = new SignatureVerificationServiceClient(transport);
    this.nameService = new NameServiceClient(transport);
    this.forkingService = new ForkingServiceClient(transport);
    this.core = new GrpcCoreClient({
      client: this,
      base: this,
      network: options.network,
      mvr: options.mvr
    });
  }
  getObjects(input) {
    return this.core.getObjects(input);
  }
  getObject(input) {
    return this.core.getObject(input);
  }
  listCoins(input) {
    return this.core.listCoins(input);
  }
  listOwnedObjects(input) {
    return this.core.listOwnedObjects(input);
  }
  getBalance(input) {
    return this.core.getBalance(input);
  }
  listBalances(input) {
    return this.core.listBalances(input);
  }
  getCoinMetadata(input) {
    return this.core.getCoinMetadata(input);
  }
  getTransaction(input) {
    return this.core.getTransaction(input);
  }
  executeTransaction(input) {
    return this.core.executeTransaction(input);
  }
  signAndExecuteTransaction(input) {
    return this.core.signAndExecuteTransaction(input);
  }
  waitForTransaction(input) {
    return this.core.waitForTransaction(input);
  }
  simulateTransaction(input) {
    return this.core.simulateTransaction(input);
  }
  getReferenceGasPrice(input) {
    return this.core.getReferenceGasPrice(input);
  }
  getCurrentSystemState(input) {
    return this.core.getCurrentSystemState(input);
  }
  getProtocolConfig(input) {
    return this.core.getProtocolConfig(input);
  }
  getChainIdentifier(input) {
    return this.core.getChainIdentifier(input);
  }
  async listDynamicFields(input) {
    const includeValue = input.include?.value ?? false;
    const paths = [
      "field_id",
      "name",
      "value_type",
      "kind",
      "child_id"
    ];
    if (includeValue) paths.push("value");
    const response = await this.stateService.listDynamicFields({
      parent: input.parentId,
      pageToken: input.cursor ? fromBase64(input.cursor) : void 0,
      pageSize: input.limit,
      readMask: { paths }
    }, { abort: input.signal });
    return {
      dynamicFields: response.response.dynamicFields.map((field) => {
        const isDynamicObject = field.kind === DynamicField_DynamicFieldKind.OBJECT;
        const fieldType = isDynamicObject ? `0x2::dynamic_field::Field<0x2::dynamic_object_field::Wrapper<${field.name?.name}>,0x2::object::ID>` : `0x2::dynamic_field::Field<${field.name?.name},${field.valueType}>`;
        return {
          $kind: isDynamicObject ? "DynamicObject" : "DynamicField",
          fieldId: field.fieldId,
          name: {
            type: field.name?.name,
            bcs: field.name?.value
          },
          valueType: field.valueType,
          type: normalizeStructTag(fieldType),
          childId: field.childId,
          value: includeValue ? {
            type: field.valueType,
            bcs: field.value?.value ?? new Uint8Array()
          } : void 0
        };
      }),
      cursor: response.response.nextPageToken ? toBase64(response.response.nextPageToken) : null,
      hasNextPage: response.response.nextPageToken !== void 0
    };
  }
  getDynamicField(input) {
    return this.core.getDynamicField(input);
  }
  getDynamicObjectField(input) {
    return this.core.getDynamicObjectField(input);
  }
  listTransactions(input) {
    return this.core.listTransactions(input);
  }
  listEvents(input) {
    return this.core.listEvents(input);
  }
  getMoveFunction(input) {
    return this.core.getMoveFunction(input);
  }
  resolveTransactionPlugin() {
    return this.core.resolveTransactionPlugin();
  }
  verifyZkLoginSignature(input) {
    return this.core.verifyZkLoginSignature(input);
  }
  defaultNameServiceName(input) {
    return this.core.defaultNameServiceName(input);
  }
  resolveNameServiceAddress(input) {
    return this.core.resolveNameServiceAddress(input);
  }
};

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/constants.mjs
var TESTNET_WALRUS_PACKAGE_CONFIG = {
  systemObjectId: "0x6c2547cbbc38025cf3adac45f63cb0a8d12ecf777cdc75a4971612bf97fdf6af",
  stakingPoolId: "0xbe46180321c30aab2f8b3501e24048377287fa708018a5b7c2792b35fe339ee3",
  exchangeIds: [
    "0xf4d164ea2def5fe07dc573992a029e010dba09b1a8dcbc44c5c2e79567f39073",
    "0x19825121c52080bb1073662231cfea5c0e4d905fd13e95f21e9a018f2ef41862",
    "0x83b454e524c71f30803f4d6c302a86fb6a39e96cdfb873c2d1e93bc1c26a3bc5",
    "0x8d63209cf8589ce7aef8f262437163c67577ed09f3e636a9d8e0813843fb8bf1"
  ]
};
var MAINNET_WALRUS_PACKAGE_CONFIG = {
  systemObjectId: "0x2134d52768ea07e8c43570ef975eb3e4c27a39fa6396bef985b5abc58d03ddd2",
  stakingPoolId: "0x10b9d30c28448939ce6c4d6c6e0ffce4a7f8a4ada8248bdad09ef8b70e4a3904"
};
var SLIVER_STATUS_CHECK_THRESHOLD = 5560;
var statusLifecycleRank = {
  nonexistent: 0,
  deletable: 1,
  permanent: 2,
  invalid: 3
};

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/error.mjs
var WalrusClientError = class extends Error {
};
var RetryableWalrusClientError = class extends WalrusClientError {
};
var NoBlobStatusReceivedError = class extends WalrusClientError {
};
var NoVerifiedBlobStatusReceivedError = class extends WalrusClientError {
};
var NoBlobMetadataReceivedError = class extends RetryableWalrusClientError {
};
var NotEnoughSliversReceivedError = class extends RetryableWalrusClientError {
};
var NotEnoughBlobConfirmationsError = class extends RetryableWalrusClientError {
};
var BehindCurrentEpochError = class extends RetryableWalrusClientError {
};
var BlobNotCertifiedError = class extends RetryableWalrusClientError {
};
var InconsistentBlobError = class extends WalrusClientError {
};
var BlobBlockedError = class extends Error {
};

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/utils/bcs.mjs
var MerkleNode = suiBcs.enum("MerkleNode", {
  Empty: null,
  Digest: suiBcs.bytes(32)
});
var SliverPairMetadata = suiBcs.struct("SliverPairMetadata", {
  primary_hash: MerkleNode,
  secondary_hash: MerkleNode
});
var EncodingType = suiBcs.enum("EncodingType", {
  RedStuff: null,
  RS2: null
}).transform({
  input: (encodingType) => typeof encodingType === "string" ? { [encodingType]: null } : encodingType,
  output: (encodingType) => encodingType
});
var BlobMetadataV1 = suiBcs.struct("BlobMetadataV1", {
  encoding_type: EncodingType,
  unencoded_length: suiBcs.u64(),
  hashes: suiBcs.vector(SliverPairMetadata)
});
var BlobMetadata = suiBcs.enum("BlobMetadata", { V1: BlobMetadataV1 });
var BlobId = suiBcs.u256().transform({
  input: (blobId) => typeof blobId === "string" ? blobIdToInt(blobId) : blobId,
  output: (id) => blobIdFromInt(id)
});
function blobIdFromInt(blobId) {
  return suiBcs.u256().serialize(blobId).toBase64().replace(/=*$/, "").replaceAll("+", "-").replaceAll("/", "_");
}
function blobIdFromBytes(blobId) {
  return blobIdFromInt(suiBcs.u256().parse(blobId));
}
function blobIdToInt(blobId) {
  return BigInt(suiBcs.u256().fromBase64(blobId.replaceAll("-", "+").replaceAll("_", "/")));
}
var BlobMetadataWithId = suiBcs.struct("BlobMetadataWithId", {
  blobId: BlobId,
  metadata: BlobMetadata
});
var Symbols = suiBcs.struct("Symbols", {
  data: suiBcs.byteVector(),
  symbol_size: suiBcs.u16()
});
var SliverData = suiBcs.struct("SliverData", {
  symbols: Symbols,
  index: suiBcs.u16()
});
var Sliver = suiBcs.enum("Sliver", {
  Primary: SliverData,
  Secondary: SliverData
});
var SliverPair = suiBcs.struct("SliverPair", {
  primary: SliverData,
  secondary: SliverData
});
var IntentType = /* @__PURE__ */ (function(IntentType$1) {
  IntentType$1[IntentType$1["PROOF_OF_POSSESSION_MSG"] = 0] = "PROOF_OF_POSSESSION_MSG";
  IntentType$1[IntentType$1["BLOB_CERT_MSG"] = 1] = "BLOB_CERT_MSG";
  IntentType$1[IntentType$1["INVALID_BLOB_ID_MSG"] = 2] = "INVALID_BLOB_ID_MSG";
  IntentType$1[IntentType$1["SYNC_SHARD_MSG"] = 3] = "SYNC_SHARD_MSG";
  return IntentType$1;
})({});
var Intent2 = suiBcs.struct("Intent", {
  type: suiBcs.u8().transform({
    input: (type) => type,
    output: (type) => type
  }),
  version: suiBcs.u8(),
  appId: suiBcs.u8()
}).transform({
  input: (intent) => ({
    type: intent,
    version: 0,
    appId: 3
  }),
  output: (intent) => intent.type
});
function ProtocolMessage(messageContents) {
  return suiBcs.struct(`ProtocolMessage<${messageContents.name}>`, {
    intent: Intent2,
    epoch: suiBcs.u32(),
    messageContents
  });
}
var BlobPersistenceType = suiBcs.enum("BlobPersistenceType", {
  Permanent: null,
  Deletable: suiBcs.struct("Deletable", { objectId: suiBcs.Address })
});
var StorageConfirmationBody = suiBcs.struct("StorageConfirmationBody", {
  blobId: BlobId,
  blobType: BlobPersistenceType
});
var StorageConfirmation = ProtocolMessage(StorageConfirmationBody);
function Field(...typeParameters) {
  return suiBcs.struct("Field", {
    id: suiBcs.Address,
    name: typeParameters[0],
    value: typeParameters[1]
  });
}
var QuiltPatchTags = suiBcs.map(suiBcs.string(), suiBcs.string()).transform({
  input: (tags) => tags instanceof Map ? tags : new Map(Object.entries(tags)),
  output: (tags) => Object.fromEntries(tags)
});
var QuiltPatchV1 = suiBcs.struct("QuiltPatchV1", {
  endIndex: suiBcs.u16(),
  identifier: suiBcs.string(),
  tags: QuiltPatchTags
});
var QuiltIndexV1 = suiBcs.struct("QuiltIndexV1", { patches: suiBcs.vector(QuiltPatchV1) });
var QuiltPatchId = suiBcs.struct("QuiltPatchId", {
  quiltId: BlobId,
  patchId: suiBcs.struct("InternalQuiltPatchId", {
    version: suiBcs.u8(),
    startIndex: suiBcs.u16(),
    endIndex: suiBcs.u16()
  })
});
var QuiltPatchBlobHeader = suiBcs.struct("QuiltPatchBlobHeader", {
  version: suiBcs.u8(),
  length: suiBcs.u32(),
  mask: suiBcs.u8()
});
var CertificateBcs = suiBcs.struct("Certificate", {
  signers: suiBcs.vector(suiBcs.u16()),
  serializedMessage: suiBcs.byteVector(),
  signature: suiBcs.byteVector()
});
function parseCertificateFromBase64(base64) {
  const cert = CertificateBcs.fromBase64(base64);
  return {
    signers: cert.signers,
    serializedMessage: new Uint8Array(cert.serializedMessage),
    signature: new Uint8Array(cert.signature)
  };
}

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/storage-node/error.mjs
var StorageNodeError = class extends Error {
};
var StorageNodeAPIError = class StorageNodeAPIError2 extends StorageNodeError {
  constructor(status, error, message) {
    super(StorageNodeAPIError2.#makeMessage(status, error, message));
    this.status = status;
    this.error = error;
  }
  static #makeMessage(status, error, message) {
    function hasErrorMessage(error$1) {
      return typeof error$1?.error?.message === "string";
    }
    const inferredMessage = hasErrorMessage(error) ? error.error.message : message;
    const finalMessage = inferredMessage ? inferredMessage : JSON.stringify(error);
    if (status && finalMessage) return `${status} ${finalMessage}`;
    else if (finalMessage) return finalMessage;
    else if (status) return `${status} status code (no body)`;
    return "(no status code or body)";
  }
  static generate(status, errorResponse, message) {
    if (!status) return new ConnectionError({ message });
    if (status === 400) return BadRequestError.generate(status, errorResponse, message);
    if (status === 401) return new AuthenticationError(status, errorResponse, message);
    if (status === 403) return new PermissionDeniedError(status, errorResponse, message);
    if (status === 404) return new NotFoundError(status, errorResponse, message);
    if (status === 409) return new ConflictError(status, errorResponse, message);
    if (status === 422) return new UnprocessableEntityError(status, errorResponse, message);
    if (status === 429) return new RateLimitError(status, errorResponse, message);
    if (status === 451) return new LegallyUnavailableError(status, errorResponse, message);
    if (status >= 500) return new InternalServerError(status, errorResponse, message);
    return new StorageNodeAPIError2(status, errorResponse, message);
  }
};
var UserAbortError = class extends StorageNodeAPIError {
  constructor({ message } = {}) {
    super(void 0, void 0, message || "Request was aborted.");
  }
};
var ConnectionError = class extends StorageNodeAPIError {
  constructor({ message }) {
    super(void 0, void 0, message || "Connection error.");
  }
};
var ConnectionTimeoutError = class extends StorageNodeAPIError {
  constructor({ message } = {}) {
    super(void 0, void 0, message ?? "Request timed out.");
  }
};
var BadRequestError = class BadRequestError2 extends StorageNodeAPIError {
  static generate(status, errorResponse, message) {
    if (errorResponse && typeof errorResponse === "object" && "error" in errorResponse) {
      if (errorResponse.error.details?.[0]?.reason === "NOT_REGISTERED") return new BlobNotRegisteredError(errorResponse, message);
    }
    return new BadRequestError2(status, errorResponse, message);
  }
};
var BlobNotRegisteredError = class extends StorageNodeAPIError {
  constructor(error, message) {
    super(400, error, message);
  }
};
var AuthenticationError = class extends StorageNodeAPIError {
};
var PermissionDeniedError = class extends StorageNodeAPIError {
};
var NotFoundError = class extends StorageNodeAPIError {
};
var ConflictError = class extends StorageNodeAPIError {
};
var UnprocessableEntityError = class extends StorageNodeAPIError {
};
var RateLimitError = class extends StorageNodeAPIError {
};
var LegallyUnavailableError = class extends StorageNodeAPIError {
};
var InternalServerError = class extends StorageNodeAPIError {
};

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/utils/index.mjs
var DIGEST_LEN = 32;
var BLOB_ID_LEN = 32;
var REQUIRED_ALIGNMENT_BY_ENCODING_TYPE = {
  RS2: 2,
  RedStuff: 2
};
var MAX_SYMBOL_SIZE_BY_ENCODING_TYPE = {
  RS2: 2 ** 16 - 1,
  RedStuff: 2 ** 16 - 1
};
function encodedBlobLength(unencodedLength, nShards, encodingType = "RS2") {
  const sliverSize = encodedSliverSize(unencodedLength, nShards, encodingType);
  return nShards * (nShards * DIGEST_LEN * 2 + BLOB_ID_LEN) + sliverSize;
}
function encodedSliverSize(unencodedLength, nShards, encodingType = "RS2") {
  const { primarySymbols, secondarySymbols } = getSourceSymbols(nShards, encodingType);
  let symbolSize = Math.floor((Math.max(unencodedLength, 1) - 1) / (primarySymbols * secondarySymbols)) + 1;
  if (encodingType === "RS2" && symbolSize % 2 === 1) symbolSize = symbolSize + 1;
  return (primarySymbols + secondarySymbols) * symbolSize * nShards;
}
function getSourceSymbols(nShards, encodingType = "RS2") {
  const safetyLimit = decodingSafetyLimit(nShards, encodingType);
  const maxFaulty = getMaxFaultyNodes(nShards);
  const minCorrect = nShards - maxFaulty;
  return {
    primarySymbols: minCorrect - maxFaulty - safetyLimit,
    secondarySymbols: minCorrect - safetyLimit
  };
}
function isQuorum(size, nShards) {
  return size > 2 * getMaxFaultyNodes(nShards);
}
function isAboveValidity(size, nShards) {
  return size > getMaxFaultyNodes(nShards);
}
function getMaxFaultyNodes(nShards) {
  return Math.floor((nShards - 1) / 3);
}
function decodingSafetyLimit(nShards, encodingType) {
  switch (encodingType) {
    case "RedStuff":
      return Math.min(5, Math.floor(getMaxFaultyNodes(nShards) / 5));
    case "RS2":
      return 0;
    default:
      throw new Error(`Encountered unknown encoding type of ${encodingType}`);
  }
}
var BYTES_PER_UNIT_SIZE = 1024 * 1024;
function storageUnitsFromSize(size) {
  return Math.ceil(size / BYTES_PER_UNIT_SIZE);
}
function rotationOffset(bytes, modulus) {
  return bytes.reduce((acc, byte) => (acc * 256 + byte) % modulus, 0);
}
function toShardIndex(sliverPairIndex, blobId, numShards) {
  return (sliverPairIndex + rotationOffset(BlobId.serialize(blobId).toBytes(), numShards)) % numShards;
}
function sliverPairIndexFromSecondarySliverIndex(sliverIndex, numShards) {
  return numShards - sliverIndex - 1;
}
function toPairIndex(shardIndex, blobId, numShards) {
  const offset = rotationOffset(BlobId.serialize(blobId).toBytes(), numShards);
  return (numShards + shardIndex - offset) % numShards;
}
function signersToBitmap(signers, committeeSize) {
  const bitmapSize = Math.ceil(committeeSize / 8);
  const bitmap = new Uint8Array(bitmapSize);
  for (const signer of signers) {
    const byteIndex = Math.floor(signer / 8);
    const bitIndex = signer % 8;
    bitmap[byteIndex] |= 1 << bitIndex;
  }
  return bitmap;
}
function getShardIndicesByNodeId(committee) {
  const shardIndicesByNodeId = /* @__PURE__ */ new Map();
  for (const node of committee[0].contents) {
    if (!shardIndicesByNodeId.has(node.key)) shardIndicesByNodeId.set(node.key, []);
    shardIndicesByNodeId.get(node.key).push(...node.value);
  }
  return shardIndicesByNodeId;
}
function urlSafeBase64(bytes) {
  return toBase64(bytes).replace(/=*$/, "").replaceAll("+", "-").replaceAll("/", "_");
}
function fromUrlSafeBase64(base64) {
  return fromBase64(base64.replaceAll("-", "+").replaceAll("_", "/"));
}
function getSizes(blobSize, numShards) {
  const encodedBlobSize = encodedSliverSize(blobSize, numShards);
  const { primarySymbols, secondarySymbols } = getSourceSymbols(numShards);
  const totalSymbols = (primarySymbols + secondarySymbols) * numShards;
  if (encodedBlobSize % totalSymbols !== 0) throw new Error("encoded blob size should be divisible by total symbols");
  const symbolSize = encodedBlobSize / totalSymbols;
  if (encodedBlobSize % totalSymbols !== 0) throw new Error("blob length should be divisible by total symbols");
  return {
    symbolSize,
    rowSize: symbolSize * secondarySymbols,
    columnSize: symbolSize * primarySymbols,
    blobSize
  };
}

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/utils/quilts.mjs
var QUILT_INDEX_SIZE_BYTES_LENGTH = 4;
var QUILT_VERSION_BYTES_LENGTH = 1;
var QUILT_INDEX_PREFIX_SIZE = QUILT_VERSION_BYTES_LENGTH + QUILT_INDEX_SIZE_BYTES_LENGTH;
var QUILT_PATCH_BLOB_HEADER_SIZE = 6;
var BLOB_IDENTIFIER_SIZE_BYTES_LENGTH = 2;
var TAGS_SIZE_BYTES_LENGTH = 2;
var MAX_BLOB_IDENTIFIER_BYTES_LENGTH = (1 << 8 * BLOB_IDENTIFIER_SIZE_BYTES_LENGTH) - 1;
var MAX_NUM_SLIVERS_FOR_QUILT_INDEX = 10;
var HAS_TAGS_FLAG = 1;
function computeSymbolSize(blobsSizes, nColumns, nRows, maxNumColumnsForQuiltIndex, encodingType = "RS2") {
  if (blobsSizes.length > nColumns) throw new Error("Too many blobs, the number of blobs must be less than the number of columns");
  if (blobsSizes.length === 0) throw new Error("No blobs provided");
  let minVal = Math.max(blobsSizes.reduce((acc, size) => acc + size, 0) / (nColumns * nRows), blobsSizes[0] / (nRows * maxNumColumnsForQuiltIndex), Math.ceil(QUILT_INDEX_PREFIX_SIZE / nRows));
  let maxVal = Math.ceil(Math.max(...blobsSizes) / (nColumns / blobsSizes.length) * nRows);
  while (minVal < maxVal) {
    const mid = Math.floor((minVal + maxVal) / 2);
    if (canBlobsFitIntoMatrix(blobsSizes, nColumns, mid * nRows)) maxVal = mid;
    else minVal = mid + 1;
  }
  const symbolSize = Math.ceil(minVal / REQUIRED_ALIGNMENT_BY_ENCODING_TYPE[encodingType]) * REQUIRED_ALIGNMENT_BY_ENCODING_TYPE[encodingType];
  if (!canBlobsFitIntoMatrix(blobsSizes, nColumns, symbolSize * nRows)) throw new Error("Quilt oversize");
  if (symbolSize > MAX_SYMBOL_SIZE_BY_ENCODING_TYPE[encodingType]) throw new Error(`Quilt oversize: the resulting symbol size ${symbolSize} is larger than the maximum symbol size ${MAX_SYMBOL_SIZE_BY_ENCODING_TYPE[encodingType]}; remove some blobs`);
  return symbolSize;
}
function canBlobsFitIntoMatrix(blobsSizes, nColumns, columnSize) {
  return blobsSizes.reduce((acc, size) => acc + Math.ceil(size / columnSize), 0) <= nColumns;
}
function parseQuiltPatchId(id) {
  return QuiltPatchId.parse(fromUrlSafeBase64(id));
}
function encodeQuiltPatchId(id) {
  return urlSafeBase64(QuiltPatchId.serialize(id).toBytes());
}
function parseWalrusId(id) {
  if (fromUrlSafeBase64(id).length === 32) return {
    kind: "blob",
    id
  };
  return {
    kind: "quiltPatch",
    id: parseQuiltPatchId(id)
  };
}
function encodeQuilt({ blobs, numShards, encodingType }) {
  const { primarySymbols: nRows, secondarySymbols: nCols } = getSourceSymbols(numShards, encodingType);
  const sortedBlobs = [...blobs].sort((a, b) => a.identifier < b.identifier ? -1 : 1);
  const identifiers = /* @__PURE__ */ new Set();
  const index = { patches: [] };
  const tags = sortedBlobs.map((blob) => blob.tags && Object.keys(blob.tags).length > 0 ? QuiltPatchTags.serialize(blob.tags).toBytes() : null);
  for (const blob of sortedBlobs) {
    if (identifiers.has(blob.identifier)) throw new Error(`Duplicate blob identifier: ${blob.identifier}`);
    identifiers.add(blob.identifier);
    index.patches.push({
      startIndex: 0,
      endIndex: 0,
      identifier: blob.identifier,
      tags: blob.tags ?? {}
    });
  }
  const indexSize = QUILT_INDEX_PREFIX_SIZE + QuiltIndexV1.serialize(index).toBytes().length;
  const blobMetadata = sortedBlobs.map((blob, i) => {
    const identifierBytes = bcs.string().serialize(blob.identifier).toBytes();
    let metadataSize = QUILT_PATCH_BLOB_HEADER_SIZE + BLOB_IDENTIFIER_SIZE_BYTES_LENGTH + identifierBytes.length;
    let mask = 0;
    let offset = 0;
    if (tags[i]) {
      metadataSize += TAGS_SIZE_BYTES_LENGTH + tags[i].length;
      mask |= HAS_TAGS_FLAG << 0;
    }
    const metadata = new Uint8Array(metadataSize);
    const metadataView = new DataView(metadata.buffer);
    const header = QuiltPatchBlobHeader.serialize({
      version: 1,
      length: metadataSize - QUILT_PATCH_BLOB_HEADER_SIZE + blob.contents.length,
      mask
    }).toBytes();
    metadata.set(header, offset);
    offset += header.length;
    metadataView.setUint16(offset, identifierBytes.length, true);
    offset += BLOB_IDENTIFIER_SIZE_BYTES_LENGTH;
    metadata.set(identifierBytes, offset);
    offset += identifierBytes.length;
    if (tags[i]) {
      metadataView.setUint16(offset, tags[i].length, true);
      offset += TAGS_SIZE_BYTES_LENGTH;
      metadata.set(tags[i], offset);
      offset += tags[i].length;
    }
    return metadata;
  });
  const symbolSize = computeSymbolSize([indexSize, ...sortedBlobs.map((blob, i) => {
    if (blob.identifier.length > MAX_BLOB_IDENTIFIER_BYTES_LENGTH) throw new Error(`Blob identifier too long: ${blob.identifier}`);
    return blobMetadata[i].length + blob.contents.length;
  })], nCols, nRows, MAX_NUM_SLIVERS_FOR_QUILT_INDEX, encodingType);
  const rowSize = symbolSize * nCols;
  const columnSize = symbolSize * nRows;
  const indexColumnsNeeded = Math.ceil(indexSize / columnSize);
  if (indexColumnsNeeded > MAX_NUM_SLIVERS_FOR_QUILT_INDEX) throw new Error("Index too large");
  const quilt = new Uint8Array(rowSize * nRows);
  let currentColumn = indexColumnsNeeded;
  for (let i = 0; i < sortedBlobs.length; i++) {
    const blob = sortedBlobs[i];
    index.patches[i].startIndex = currentColumn;
    currentColumn += writeBlobToQuilt(quilt, blob.contents, rowSize, columnSize, symbolSize, currentColumn, blobMetadata[i]);
    index.patches[i].endIndex = currentColumn;
  }
  const indexBytes = QuiltIndexV1.serialize(index).toBytes();
  const quiltIndex = new Uint8Array(QUILT_INDEX_PREFIX_SIZE + indexBytes.length);
  const view = new DataView(quiltIndex.buffer);
  view.setUint8(0, 1);
  view.setUint32(1, indexBytes.length, true);
  quiltIndex.set(indexBytes, QUILT_INDEX_PREFIX_SIZE);
  writeBlobToQuilt(quilt, quiltIndex, rowSize, columnSize, symbolSize, 0);
  return {
    quilt,
    index
  };
}
function writeBlobToQuilt(quilt, blob, rowSize, columnSize, symbolSize, startColumn, prefix) {
  const nRows = columnSize / symbolSize;
  let bytesWritten = 0;
  if (rowSize % symbolSize !== 0) throw new Error("Row size must be divisible by symbol size");
  if (columnSize % symbolSize !== 0) throw new Error("Column size must be divisible by symbol size");
  if (prefix) writeBytes(prefix);
  writeBytes(blob);
  return Math.ceil(bytesWritten / columnSize);
  function writeBytes(bytes) {
    const offset = bytesWritten;
    const symbolsToSkip = Math.floor(offset / symbolSize);
    let remainingOffset = offset % symbolSize;
    let currentCol = startColumn + Math.floor(symbolsToSkip / nRows);
    let currentRow = symbolsToSkip % nRows;
    let index = 0;
    while (index < bytes.length) {
      const startIndex = currentRow * rowSize + currentCol * symbolSize + remainingOffset;
      const len = Math.min(symbolSize - remainingOffset, bytes.length - index);
      for (let i = 0; i < len; i++) quilt[startIndex + i] = bytes[index + i];
      index += len;
      remainingOffset = 0;
      currentRow = (currentRow + 1) % nRows;
      if (currentRow === 0) currentCol++;
    }
    bytesWritten += bytes.length;
  }
}

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/files/readers/local.mjs
var LocalReader = class {
  #contents;
  #identifier;
  #tags;
  constructor({ contents, identifier, tags }) {
    this.#contents = contents;
    this.#identifier = identifier ?? null;
    this.#tags = tags ?? {};
  }
  async getBytes() {
    if ("arrayBuffer" in this.#contents) return new Uint8Array(await this.#contents.arrayBuffer());
    return this.#contents;
  }
  async getIdentifier() {
    return this.#identifier;
  }
  async getTags() {
    return this.#tags;
  }
};

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/files/file.mjs
var WalrusFile = class WalrusFile2 {
  #reader;
  static from(options) {
    return new WalrusFile2({ reader: new LocalReader(options) });
  }
  constructor({ reader }) {
    this.#reader = reader;
  }
  getIdentifier() {
    return this.#reader.getIdentifier();
  }
  getTags() {
    return this.#reader.getTags();
  }
  bytes() {
    return this.#reader.getBytes();
  }
  async text() {
    const bytes = await this.bytes();
    return new TextDecoder().decode(bytes);
  }
  async json() {
    return JSON.parse(await this.text());
  }
};

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/files/blob.mjs
var WalrusBlob = class {
  #reader;
  #client;
  #cache = new ClientCache();
  constructor({ reader, client }) {
    this.#reader = reader;
    this.#client = client;
  }
  asFile() {
    return new WalrusFile({ reader: this.#reader });
  }
  async blobId() {
    return this.#reader.blobId;
  }
  async files(filters = {}) {
    const quiltReader = await this.#reader.getQuiltReader();
    const index = await quiltReader.readIndex();
    const files = [];
    for (const patch of index) {
      if (filters.ids && !filters.ids.includes(patch.patchId)) continue;
      if (filters.identifiers && !filters.identifiers.includes(patch.identifier)) continue;
      if (filters.tags && !filters.tags.some((tags) => Object.entries(tags).every(([tagName, tagValue]) => patch.tags[tagName] === tagValue))) continue;
      files.push(new WalrusFile({ reader: quiltReader.readerForPatchId(patch.patchId) }));
    }
    return files;
  }
  async #blobStatus() {
    return this.#cache.read(["blobStatus", this.#reader.blobId], () => this.#client.getVerifiedBlobStatus({ blobId: this.#reader.blobId }));
  }
  async exists() {
    const status = await this.#blobStatus();
    return status.type === "permanent" || status.type === "deletable";
  }
  async storedUntil() {
    const status = await this.#blobStatus();
    if (status.type === "permanent") return status.endEpoch;
    return null;
  }
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/Commands.mjs
var TransactionCommands = {
  MoveCall(input) {
    const [pkg, mod = "", fn = ""] = "target" in input ? input.target.split("::") : [
      input.package,
      input.module,
      input.function
    ];
    return {
      $kind: "MoveCall",
      MoveCall: {
        package: pkg,
        module: mod,
        function: fn,
        typeArguments: input.typeArguments ?? [],
        arguments: input.arguments ?? []
      }
    };
  },
  TransferObjects(objects, address) {
    return {
      $kind: "TransferObjects",
      TransferObjects: {
        objects: objects.map((o) => parse(ArgumentSchema, o)),
        address: parse(ArgumentSchema, address)
      }
    };
  },
  SplitCoins(coin, amounts) {
    return {
      $kind: "SplitCoins",
      SplitCoins: {
        coin: parse(ArgumentSchema, coin),
        amounts: amounts.map((o) => parse(ArgumentSchema, o))
      }
    };
  },
  MergeCoins(destination, sources) {
    return {
      $kind: "MergeCoins",
      MergeCoins: {
        destination: parse(ArgumentSchema, destination),
        sources: sources.map((o) => parse(ArgumentSchema, o))
      }
    };
  },
  Publish({ modules, dependencies }) {
    return {
      $kind: "Publish",
      Publish: {
        modules: modules.map((module2) => typeof module2 === "string" ? module2 : toBase64(new Uint8Array(module2))),
        dependencies: dependencies.map((dep) => normalizeSuiObjectId(dep))
      }
    };
  },
  Upgrade({ modules, dependencies, package: packageId, ticket }) {
    return {
      $kind: "Upgrade",
      Upgrade: {
        modules: modules.map((module2) => typeof module2 === "string" ? module2 : toBase64(new Uint8Array(module2))),
        dependencies: dependencies.map((dep) => normalizeSuiObjectId(dep)),
        package: packageId,
        ticket: parse(ArgumentSchema, ticket)
      }
    };
  },
  MakeMoveVec({ type, elements }) {
    return {
      $kind: "MakeMoveVec",
      MakeMoveVec: {
        type: type ?? null,
        elements: elements.map((o) => parse(ArgumentSchema, o))
      }
    };
  },
  Intent({ name, inputs = {}, data = {} }) {
    return {
      $kind: "$Intent",
      $Intent: {
        name,
        inputs: Object.fromEntries(Object.entries(inputs).map(([key, value]) => [key, Array.isArray(value) ? value.map((o) => parse(ArgumentSchema, o)) : parse(ArgumentSchema, value)])),
        data
      }
    };
  }
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/Inputs.mjs
function Pure(data) {
  return {
    $kind: "Pure",
    Pure: { bytes: data instanceof Uint8Array ? toBase64(data) : data.toBase64() }
  };
}
var Inputs = {
  Pure,
  ObjectRef({ objectId, digest: digest2, version }) {
    return {
      $kind: "Object",
      Object: {
        $kind: "ImmOrOwnedObject",
        ImmOrOwnedObject: {
          digest: digest2,
          version,
          objectId: normalizeSuiAddress(objectId)
        }
      }
    };
  },
  SharedObjectRef({ objectId, mutable, initialSharedVersion }) {
    return {
      $kind: "Object",
      Object: {
        $kind: "SharedObject",
        SharedObject: {
          mutable,
          initialSharedVersion,
          objectId: normalizeSuiAddress(objectId)
        }
      }
    };
  },
  ReceivingRef({ objectId, digest: digest2, version }) {
    return {
      $kind: "Object",
      Object: {
        $kind: "Receiving",
        Receiving: {
          digest: digest2,
          version,
          objectId: normalizeSuiAddress(objectId)
        }
      }
    };
  },
  FundsWithdrawal({ reservation, typeArg, withdrawFrom }) {
    return {
      $kind: "FundsWithdrawal",
      FundsWithdrawal: {
        reservation,
        typeArg,
        withdrawFrom
      }
    };
  }
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/serializer.mjs
function parseTypeName(typeName) {
  const parts = typeName.split("::");
  if (parts.length !== 3) throw new Error(`Invalid type name format: ${typeName}`);
  return {
    package: parts[0],
    module: parts[1],
    name: parts[2]
  };
}
function isTxContext(param) {
  if (param.body.$kind !== "datatype") return false;
  const { package: pkg, module: module2, name } = parseTypeName(param.body.datatype.typeName);
  return normalizeSuiAddress(pkg) === SUI_FRAMEWORK_ADDRESS && module2 === "tx_context" && name === "TxContext";
}
function getPureBcsSchema(typeSignature) {
  switch (typeSignature.$kind) {
    case "address":
      return suiBcs.Address;
    case "bool":
      return suiBcs.Bool;
    case "u8":
      return suiBcs.U8;
    case "u16":
      return suiBcs.U16;
    case "u32":
      return suiBcs.U32;
    case "u64":
      return suiBcs.U64;
    case "u128":
      return suiBcs.U128;
    case "u256":
      return suiBcs.U256;
    case "vector": {
      if (typeSignature.vector.$kind === "u8") return suiBcs.byteVector().transform({
        input: (val) => typeof val === "string" ? new TextEncoder().encode(val) : val,
        output: (val) => val
      });
      const type = getPureBcsSchema(typeSignature.vector);
      return type ? suiBcs.vector(type) : null;
    }
    case "datatype": {
      const { package: pkg, module: module2, name } = parseTypeName(typeSignature.datatype.typeName);
      const normalizedPkg = normalizeSuiAddress(pkg);
      if (normalizedPkg === MOVE_STDLIB_ADDRESS) {
        if (module2 === "ascii" && name === "String") return suiBcs.String;
        if (module2 === "string" && name === "String") return suiBcs.String;
        if (module2 === "option" && name === "Option") {
          const type = getPureBcsSchema(typeSignature.datatype.typeParameters[0]);
          return type ? suiBcs.vector(type) : null;
        }
      }
      if (normalizedPkg === SUI_FRAMEWORK_ADDRESS) {
        if (module2 === "object" && name === "ID") return suiBcs.Address;
      }
      return null;
    }
    case "typeParameter":
    case "unknown":
      return null;
  }
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/intents/BalanceIntentNames.mjs
var ALLOWANCE_BALANCE = "AllowanceBalance";
var COIN_WITH_BALANCE = "CoinWithBalance";

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/resolution-utils.mjs
function transactionUsesGasCoin(transactionData) {
  let usesGasCoin = false;
  transactionData.mapArguments((arg) => {
    if (arg.$kind === "GasCoin") usesGasCoin = true;
    return arg;
  });
  return usesGasCoin;
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/utils/coin-reservation.mjs
var SUI_ACCUMULATOR_ROOT_OBJECT_ID = normalizeSuiAddress("0xacc");
var ACCUMULATOR_KEY_TYPE_TAG = TypeTagSerializer.parseFromStr("0x2::accumulator::Key<0x2::balance::Balance<0x2::sui::SUI>>");
var COIN_RESERVATION_MAGIC = new Uint8Array([
  172,
  172,
  172,
  172,
  172,
  172,
  172,
  172,
  172,
  172,
  172,
  172,
  172,
  172,
  172,
  172,
  172,
  172,
  172,
  172
]);
function deriveReservationObjectId(owner, chainIdentifier) {
  const accBytes = fromHex(deriveDynamicFieldID(SUI_ACCUMULATOR_ROOT_OBJECT_ID, ACCUMULATOR_KEY_TYPE_TAG, suiBcs.Address.serialize(owner).toBytes()).slice(2));
  const chainBytes = fromBase58(chainIdentifier);
  if (chainBytes.length !== 32) throw new Error(`Invalid chain identifier length: expected 32 bytes, got ${chainBytes.length}`);
  const xored = new Uint8Array(32);
  for (let i = 0; i < 32; i++) xored[i] = accBytes[i] ^ chainBytes[i];
  return `0x${toHex(xored)}`;
}
function createCoinReservationRef(reservedBalance, owner, chainIdentifier, epoch) {
  const digestBytes = new Uint8Array(32);
  const view = new DataView(digestBytes.buffer);
  view.setBigUint64(0, reservedBalance, true);
  const epochNum = Number(epoch);
  if (!Number.isSafeInteger(epochNum) || epochNum < 0 || epochNum > 4294967295) throw new Error(`Epoch ${epoch} out of u32 range for coin reservation digest`);
  view.setUint32(8, epochNum, true);
  digestBytes.set(COIN_RESERVATION_MAGIC, 12);
  return parse(ObjectRefSchema, {
    objectId: deriveReservationObjectId(owner, chainIdentifier),
    version: "0",
    digest: toBase58(digestBytes)
  });
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/client/core-resolver.mjs
var MAX_OBJECTS_PER_FETCH = 50;
var MAX_GAS_PAYMENT_OBJECTS = 256;
var GAS_SAFE_OVERHEAD = 1000n;
var MAX_GAS = 5e10;
function computeGasBudget(gasUsed, gasPrice = 1n) {
  const safeOverhead = GAS_SAFE_OVERHEAD * BigInt(gasPrice);
  const baseComputationCostWithOverhead = BigInt(gasUsed.computationCost) + safeOverhead;
  const gasBudget = baseComputationCostWithOverhead + BigInt(gasUsed.storageCost) - BigInt(gasUsed.storageRebate);
  return String(gasBudget > baseComputationCostWithOverhead ? gasBudget : baseComputationCostWithOverhead);
}
function getClient(options) {
  if (!options.client) throw new Error(`No sui client passed to Transaction#build, but transaction data was not sufficient to build offline.`);
  return options.client;
}
async function coreClientResolveTransactionPlugin(transactionData, options, next) {
  const client = getClient(options);
  const needsGasPrice = !options.onlyTransactionKind && !transactionData.gasData.price;
  const needsPayment = !options.onlyTransactionKind && !transactionData.gasData.payment;
  const gasPayer = transactionData.gasData.owner ?? transactionData.sender;
  const usesGasCoin = transactionUsesGasCoin(transactionData);
  let withdrawals = 0n;
  const normalizedGasPayer = gasPayer ? normalizeSuiAddress(gasPayer) : null;
  for (const input of transactionData.inputs) {
    if (input.$kind !== "FundsWithdrawal" || !normalizedGasPayer) continue;
    if (normalizeStructTag(input.FundsWithdrawal.typeArg.Balance) !== SUI_TYPE_ARG) continue;
    const source = input.FundsWithdrawal.withdrawFrom;
    const withdrawalOwner = source.SenderAllowance ? source.SenderAllowance.funder : source.Sender ? transactionData.sender : gasPayer;
    if (withdrawalOwner && normalizeSuiAddress(withdrawalOwner) === normalizedGasPayer && input.FundsWithdrawal.reservation.$kind === "MaxAmountU64") withdrawals += BigInt(input.FundsWithdrawal.reservation.MaxAmountU64);
  }
  const needsSimulateExpiration = !options.onlyTransactionKind && !transactionData.expiration && !transactionData.gasData.budget;
  const needsSystemState = needsGasPrice || needsPayment && usesGasCoin || needsSimulateExpiration;
  const needsChainId = needsPayment && usesGasCoin || needsSimulateExpiration;
  const [, systemStateResult, balanceResult, coinsResult, chainIdResult] = await Promise.all([
    normalizeInputs(transactionData, client),
    needsSystemState ? client.core.getCurrentSystemState() : null,
    needsPayment && gasPayer ? client.core.getBalance({ owner: gasPayer }) : null,
    needsPayment && gasPayer ? client.core.listCoins({
      owner: gasPayer,
      coinType: SUI_TYPE_ARG
    }) : null,
    needsChainId ? client.core.getChainIdentifier() : null
  ]);
  await resolveObjectReferences(transactionData, client);
  if (!options.onlyTransactionKind) {
    const systemState = systemStateResult?.systemState ?? null;
    const chainIdentifier = chainIdResult?.chainIdentifier ?? null;
    if (systemState && !transactionData.gasData.price) transactionData.gasData.price = systemState.referenceGasPrice;
    await setGasBudget(transactionData, client, needsSimulateExpiration && systemState && chainIdentifier ? buildValidDuringExpiration(systemState, chainIdentifier) : void 0);
    if (needsPayment) {
      if (!balanceResult || !coinsResult) throw new Error("Could not resolve gas payment: a gas owner or sender must be set to fetch balance and coins.");
      setGasPayment({
        transactionData,
        balance: balanceResult,
        coins: coinsResult,
        usesGasCoin,
        withdrawals,
        gasPayer,
        chainIdentifier,
        epoch: systemState?.epoch ?? null
      });
    }
    if (!transactionData.expiration && transactionData.gasData.payment?.length === 0) await setExpiration(transactionData, client, systemState, chainIdentifier);
  }
  return await next();
}
async function setGasBudget(transactionData, client, simulateExpiration) {
  if (transactionData.gasData.budget) return;
  const simulateResult = await client.core.simulateTransaction({
    transaction: transactionData.build({ overrides: {
      gasData: {
        budget: String(MAX_GAS),
        payment: []
      },
      ...simulateExpiration && { expiration: simulateExpiration }
    } }),
    include: { effects: true },
    doGasSelection: false
  });
  if (simulateResult.$kind === "FailedTransaction") {
    const executionError = simulateResult.FailedTransaction.status.error ?? void 0;
    throw new SimulationError(`Transaction resolution failed: ${executionError?.message ?? "Unknown error"}`, {
      cause: simulateResult,
      executionError
    });
  }
  transactionData.gasData.budget = computeGasBudget(simulateResult.Transaction.effects.gasUsed, transactionData.gasData.price ? String(transactionData.gasData.price) : void 0);
}
function setGasPayment({ transactionData, balance, coins, usesGasCoin, withdrawals, gasPayer, chainIdentifier, epoch }) {
  const budget = BigInt(transactionData.gasData.budget);
  const addressBalance = BigInt(balance.balance.addressBalance);
  if (budget === 0n || !usesGasCoin && addressBalance >= budget + withdrawals) {
    transactionData.gasData.payment = [];
    return;
  }
  const filteredCoins = coins.objects.filter((coin) => {
    return !transactionData.inputs.find((input) => {
      if (input.Object?.ImmOrOwnedObject) return coin.objectId === input.Object.ImmOrOwnedObject.objectId;
      return false;
    });
  });
  const paymentCoins = filteredCoins.map((coin) => ({
    objectId: coin.objectId,
    digest: coin.digest,
    version: coin.version
  }));
  const reservationAmount = addressBalance - withdrawals;
  if (usesGasCoin && reservationAmount > 0n && chainIdentifier && epoch) transactionData.gasData.payment = [createCoinReservationRef(reservationAmount, gasPayer, chainIdentifier, epoch), ...paymentCoins.slice(0, MAX_GAS_PAYMENT_OBJECTS - 1)];
  else if (!filteredCoins.length) throw new Error("No valid gas coins found for the transaction.");
  else transactionData.gasData.payment = paymentCoins.slice(0, MAX_GAS_PAYMENT_OBJECTS);
}
async function setExpiration(transactionData, client, systemState, existingChainIdentifier = null) {
  const [chainIdentifier, resolvedSystemState] = await Promise.all([existingChainIdentifier ?? client.core.getChainIdentifier().then((r) => r.chainIdentifier), systemState ?? client.core.getCurrentSystemState().then((r) => r.systemState)]);
  transactionData.expiration = buildValidDuringExpiration(resolvedSystemState, chainIdentifier);
}
function buildValidDuringExpiration(systemState, chainIdentifier) {
  const currentEpoch = BigInt(systemState.epoch);
  return {
    $kind: "ValidDuring",
    ValidDuring: {
      minEpoch: String(currentEpoch),
      maxEpoch: String(currentEpoch + 1n),
      minTimestamp: null,
      maxTimestamp: null,
      chain: chainIdentifier,
      nonce: Math.random() * 4294967296 >>> 0
    }
  };
}
async function resolveObjectReferences(transactionData, client) {
  const objectsToResolve = transactionData.inputs.filter((input) => {
    return input.UnresolvedObject && !(input.UnresolvedObject.version || input.UnresolvedObject?.initialSharedVersion);
  });
  const dedupedIds = [...new Set(objectsToResolve.map((input) => normalizeSuiObjectId(input.UnresolvedObject.objectId)))];
  const objectChunks = dedupedIds.length ? chunk(dedupedIds, MAX_OBJECTS_PER_FETCH) : [];
  const resolved = (await Promise.all(objectChunks.map((chunkIds) => client.core.getObjects({ objectIds: chunkIds })))).flatMap((result) => result.objects);
  const responsesById = new Map(dedupedIds.map((id, index) => {
    return [id, resolved[index]];
  }));
  const invalidObjects = Array.from(responsesById).filter(([_, obj]) => obj instanceof Error).map(([_, obj]) => obj.message);
  if (invalidObjects.length) throw new Error(`The following input objects are invalid: ${invalidObjects.join(", ")}`);
  const objects = resolved.map((object2) => {
    if (object2 instanceof Error) throw new Error(`Failed to fetch object: ${object2.message}`);
    const owner = object2.owner;
    const initialSharedVersion = owner && typeof owner === "object" ? owner.$kind === "Shared" ? owner.Shared.initialSharedVersion : owner.$kind === "ConsensusAddressOwner" ? owner.ConsensusAddressOwner.startVersion : null : null;
    return {
      objectId: object2.objectId,
      digest: object2.digest,
      version: object2.version,
      initialSharedVersion
    };
  });
  const objectsById = new Map(dedupedIds.map((id, index) => {
    return [id, objects[index]];
  }));
  for (const [index, input] of transactionData.inputs.entries()) {
    if (!input.UnresolvedObject) continue;
    let updated;
    const id = normalizeSuiAddress(input.UnresolvedObject.objectId);
    const object2 = objectsById.get(id);
    if (input.UnresolvedObject.initialSharedVersion ?? object2?.initialSharedVersion) updated = Inputs.SharedObjectRef({
      objectId: id,
      initialSharedVersion: input.UnresolvedObject.initialSharedVersion || object2?.initialSharedVersion,
      mutable: input.UnresolvedObject.mutable || isUsedAsMutable(transactionData, index)
    });
    else if (isUsedAsReceiving(transactionData, index)) updated = Inputs.ReceivingRef({
      objectId: id,
      digest: input.UnresolvedObject.digest ?? object2?.digest,
      version: input.UnresolvedObject.version ?? object2?.version
    });
    transactionData.inputs[transactionData.inputs.indexOf(input)] = updated ?? Inputs.ObjectRef({
      objectId: id,
      digest: input.UnresolvedObject.digest ?? object2?.digest,
      version: input.UnresolvedObject.version ?? object2?.version
    });
  }
}
async function normalizeInputs(transactionData, client) {
  const { inputs, commands } = transactionData;
  const moveCallsToResolve = [];
  const moveFunctionsToResolve = /* @__PURE__ */ new Set();
  commands.forEach((command) => {
    if (command.MoveCall) {
      if (command.MoveCall._argumentTypes) return;
      if (command.MoveCall.arguments.map((arg) => {
        if (arg.$kind === "Input") return transactionData.inputs[arg.Input];
        return null;
      }).some((input) => input?.UnresolvedPure || input?.UnresolvedObject && typeof input?.UnresolvedObject.mutable !== "boolean")) {
        const functionName = `${command.MoveCall.package}::${command.MoveCall.module}::${command.MoveCall.function}`;
        moveFunctionsToResolve.add(functionName);
        moveCallsToResolve.push(command.MoveCall);
      }
    }
  });
  const moveFunctionParameters = /* @__PURE__ */ new Map();
  if (moveFunctionsToResolve.size > 0) await Promise.all([...moveFunctionsToResolve].map(async (functionName) => {
    const [packageId, moduleName, name] = functionName.split("::");
    const { function: def } = await client.core.getMoveFunction({
      packageId,
      moduleName,
      name
    });
    moveFunctionParameters.set(functionName, def.parameters);
  }));
  if (moveCallsToResolve.length) await Promise.all(moveCallsToResolve.map(async (moveCall) => {
    const parameters = moveFunctionParameters.get(`${moveCall.package}::${moveCall.module}::${moveCall.function}`);
    if (!parameters) return;
    moveCall._argumentTypes = parameters.length > 0 && isTxContext(parameters.at(-1)) ? parameters.slice(0, parameters.length - 1) : parameters;
  }));
  commands.forEach((command) => {
    if (!command.MoveCall) return;
    const moveCall = command.MoveCall;
    const fnName = `${moveCall.package}::${moveCall.module}::${moveCall.function}`;
    const params = moveCall._argumentTypes;
    if (!params) return;
    if (params.length !== command.MoveCall.arguments.length) throw new Error(`Incorrect number of arguments for ${fnName}`);
    params.forEach((param, i) => {
      const arg = moveCall.arguments[i];
      if (arg.$kind !== "Input") return;
      const input = inputs[arg.Input];
      if (!input.UnresolvedPure && !input.UnresolvedObject) return;
      const inputValue = input.UnresolvedPure?.value ?? input.UnresolvedObject?.objectId;
      const schema = getPureBcsSchema(param.body);
      if (schema) {
        arg.type = "pure";
        inputs[inputs.indexOf(input)] = Inputs.Pure(schema.serialize(inputValue));
        return;
      }
      if (typeof inputValue !== "string") throw new Error(`Expect the argument to be an object id string, got ${JSON.stringify(inputValue, null, 2)}`);
      arg.type = "object";
      const unresolvedObject = input.UnresolvedPure ? {
        $kind: "UnresolvedObject",
        UnresolvedObject: { objectId: inputValue }
      } : input;
      inputs[arg.Input] = unresolvedObject;
    });
  });
}
function isUsedAsMutable(transactionData, index) {
  let usedAsMutable = false;
  transactionData.getInputUses(index, (arg, tx) => {
    if (tx.MoveCall && tx.MoveCall._argumentTypes) {
      const argIndex = tx.MoveCall.arguments.indexOf(arg);
      usedAsMutable = tx.MoveCall._argumentTypes[argIndex].reference !== "immutable" || usedAsMutable;
    }
    if (tx.$kind === "MakeMoveVec" || tx.$kind === "MergeCoins" || tx.$kind === "SplitCoins" || tx.$kind === "TransferObjects") usedAsMutable = true;
  });
  return usedAsMutable;
}
function isUsedAsReceiving(transactionData, index) {
  let usedAsReceiving = false;
  transactionData.getInputUses(index, (arg, tx) => {
    if (tx.MoveCall && tx.MoveCall._argumentTypes) {
      const argIndex = tx.MoveCall.arguments.indexOf(arg);
      usedAsReceiving = isReceivingType(tx.MoveCall._argumentTypes[argIndex]) || usedAsReceiving;
    }
  });
  return usedAsReceiving;
}
var RECEIVING_TYPE = "0x0000000000000000000000000000000000000000000000000000000000000002::transfer::Receiving";
function isReceivingType(type) {
  if (type.body.$kind !== "datatype") return false;
  return type.body.datatype.typeName === RECEIVING_TYPE;
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/resolve.mjs
function needsTransactionResolution(data, options) {
  if (data.inputs.some((input) => {
    return input.UnresolvedObject || input.UnresolvedPure;
  })) return true;
  if (!options.onlyTransactionKind) {
    if (!data.gasData.price || !data.gasData.budget) return true;
    if (!data.gasData.payment) {
      if (!(options.assumeSufficientAddressBalances && !transactionUsesGasCoin(data)) || data.expiration?.$kind !== "ValidDuring" && data.expiration?.$kind !== "Validity") return true;
    } else if (data.gasData.payment.length === 0 && !data.expiration) return true;
  }
  return false;
}
async function resolveTransactionPlugin(transactionData, options, next) {
  normalizeRawArguments(transactionData);
  if (!needsTransactionResolution(transactionData, options)) {
    if (!options.onlyTransactionKind && !transactionData.gasData.payment) transactionData.gasData.payment = [];
    await validate(transactionData);
    return next();
  }
  return (getClient2(options).core?.resolveTransactionPlugin() ?? coreClientResolveTransactionPlugin)(transactionData, options, async () => {
    await validate(transactionData);
    await next();
  });
}
function validate(transactionData) {
  transactionData.inputs.forEach((input, index) => {
    if (input.$kind !== "Object" && input.$kind !== "Pure" && input.$kind !== "FundsWithdrawal") throw new Error(`Input at index ${index} has not been resolved.  Expected a Pure, Object, or FundsWithdrawal input, but found ${JSON.stringify(input)}`);
  });
}
function getClient2(options) {
  if (!options.client) throw new Error(`No sui client passed to Transaction#build, but transaction data was not sufficient to build offline.`);
  return options.client;
}
function normalizeRawArguments(transactionData) {
  for (const command of transactionData.commands) switch (command.$kind) {
    case "SplitCoins":
      command.SplitCoins.amounts.forEach((amount) => {
        normalizeRawArgument(amount, suiBcs.U64, transactionData);
      });
      break;
    case "TransferObjects":
      normalizeRawArgument(command.TransferObjects.address, suiBcs.Address, transactionData);
      break;
  }
}
function normalizeRawArgument(arg, schema, transactionData) {
  if (arg.$kind !== "Input") return;
  const input = transactionData.inputs[arg.Input];
  if (input.$kind !== "UnresolvedPure") return;
  transactionData.inputs[arg.Input] = Inputs.Pure(schema.serialize(input.UnresolvedPure.value));
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/intents/AllowanceBalance.mjs
var AllowanceBalanceData = object({
  objectId: string(),
  funder: optional(string()),
  appType: optional(string()),
  type: string(),
  amount: string(),
  outputKind: picklist(["coin", "balance"])
});
var AllowanceMetadata = suiBcs.struct("AllowanceMetadata", {
  id: suiBcs.Address,
  funder: suiBcs.Address,
  spender: suiBcs.option(suiBcs.Address),
  app: suiBcs.option(suiBcs.string())
});
function allowanceBalance({ allowance, amount, type = "0x2::sui::SUI", outputKind }) {
  suiBcs.U64.validate(amount);
  const objectId = normalizeSuiAddress(typeof allowance === "string" ? allowance : allowance.objectId);
  const reference = typeof allowance === "string" ? { objectId } : allowance;
  return (tx) => {
    tx.addIntentResolver(ALLOWANCE_BALANCE, resolveBalances);
    return tx.add(TransactionCommands.Intent({
      name: ALLOWANCE_BALANCE,
      inputs: {
        allowance: tx.object(objectId),
        clock: tx.object.clock(),
        ...reference.app ? { permit: tx.object(reference.app.permit) } : {}
      },
      data: {
        objectId,
        funder: reference.funder ? normalizeSuiAddress(reference.funder) : void 0,
        appType: reference.app ? normalizeStructTag(reference.app.type) : void 0,
        type: normalizeStructTag(type),
        amount: String(amount),
        outputKind
      }
    }));
  };
}
var resolveAllowanceBalance = async (transactionData, options, next) => {
  const ids = /* @__PURE__ */ new Set();
  const namedTypes = /* @__PURE__ */ new Set();
  for (const command of transactionData.commands) {
    if (command.$kind !== "$Intent" || command.$Intent.name !== ALLOWANCE_BALANCE) continue;
    const data = parse(AllowanceBalanceData, command.$Intent.data);
    if (!data.funder) ids.add(data.objectId);
    for (const type of [data.type, data.appType]) if (type && hasMvrName(type)) namedTypes.add(type);
  }
  const [resolvedTypes, objects] = await Promise.all([namedTypes.size ? getClient2(options).core.mvr.resolve({ types: [...namedTypes] }) : void 0, ids.size ? getClient2(options).core.getObjects({
    objectIds: [...ids],
    include: { content: true }
  }).then((result) => result.objects) : []]);
  const allowances = /* @__PURE__ */ new Map();
  for (const object$1 of objects) {
    if (object$1 instanceof Error) throw object$1;
    allowances.set(object$1.objectId, object$1);
  }
  for (let index = 0; index < transactionData.commands.length; index++) {
    const command = transactionData.commands[index];
    if (command.$kind !== "$Intent" || command.$Intent.name !== ALLOWANCE_BALANCE) continue;
    const data = parse(AllowanceBalanceData, command.$Intent.data);
    if (hasMvrName(data.type)) {
      const resolved = resolvedTypes?.types[data.type];
      if (!resolved) throw new Error(`No resolution found for type: ${data.type}`);
      data.type = normalizeStructTag(resolved.type);
    }
    if (data.appType && hasMvrName(data.appType)) {
      const resolved = resolvedTypes?.types[data.appType];
      if (!resolved) throw new Error(`No resolution found for type: ${data.appType}`);
      data.appType = normalizeStructTag(resolved.type);
    }
    let funder = data.funder;
    if (!funder) {
      const allowance = allowances.get(data.objectId);
      const expectedType = normalizeStructTag(`0x2::allowance::Allowance<0x2::balance::Balance<${data.type}>>`);
      if (!allowance || allowance.type !== expectedType || allowance.owner.$kind !== "Shared") throw new Error(`Expected a shared ${expectedType} allowance at ${data.objectId}`);
      const metadata = AllowanceMetadata.parse(allowance.content);
      if (metadata.app !== null && !data.appType) throw new Error(`Allowance ${data.objectId} is app-bound; pass allowance.app with the app type and SpendPermit`);
      if (data.appType && (metadata.app === null || normalizeStructTag(metadata.app) !== data.appType)) throw new Error(`Allowance ${data.objectId} is not bound to app ${data.appType}`);
      funder = metadata.funder;
      const input = command.$Intent.inputs.allowance;
      if (input.$kind === "Input") transactionData.inputs[input.Input] = Inputs.SharedObjectRef({
        objectId: data.objectId,
        initialSharedVersion: allowance.owner.Shared.initialSharedVersion,
        mutable: true
      });
    }
    const allowanceArgument = command.$Intent.inputs.allowance;
    if (allowanceArgument.$kind === "Input") {
      const input = transactionData.inputs[allowanceArgument.Input];
      if (input.Object?.SharedObject) input.Object.SharedObject.mutable = true;
      if (input.UnresolvedObject) input.UnresolvedObject.mutable = true;
    }
    const withdrawal = transactionData.addInput("withdrawal", Inputs.FundsWithdrawal({
      reservation: {
        $kind: "MaxAmountU64",
        MaxAmountU64: data.amount
      },
      typeArg: {
        $kind: "Balance",
        Balance: data.type
      },
      withdrawFrom: {
        $kind: "SenderAllowance",
        SenderAllowance: {
          funder,
          allowance: data.objectId
        }
      }
    }));
    const commands = [TransactionCommands.MoveCall({
      target: data.appType ? "0x2::allowance::app_balance_spend" : "0x2::allowance::balance_spend",
      typeArguments: data.appType ? [data.type, data.appType] : [data.type],
      arguments: [
        command.$Intent.inputs.allowance,
        ...data.appType ? [command.$Intent.inputs.permit] : [],
        withdrawal,
        command.$Intent.inputs.clock
      ]
    })];
    if (data.outputKind === "coin") commands.push(TransactionCommands.MoveCall({
      target: "0x2::coin::from_balance",
      typeArguments: [data.type],
      arguments: [{
        $kind: "Result",
        Result: index
      }]
    }));
    transactionData.replaceCommand(index, commands, { NestedResult: [index + commands.length - 1, 0] });
    index += commands.length - 1;
  }
  return next();
};

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/intents/ResolveBalances.mjs
async function resolveBalances(transactionData, options, next) {
  const intents = new Set(options.intentNames ?? [ALLOWANCE_BALANCE, COIN_WITH_BALANCE]);
  const shouldResolve = (name) => intents.has(name) && !options.supportedIntents?.includes(name) && transactionData.commands.some((command) => command.$Intent?.name === name);
  if (shouldResolve(ALLOWANCE_BALANCE)) await resolveAllowanceBalance(transactionData, options, async () => {
  });
  if (shouldResolve(COIN_WITH_BALANCE)) await resolveCoinBalance(transactionData, options, async () => {
  });
  await next();
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/intents/CoinWithBalance.mjs
var SUI_TYPE = normalizeStructTag("0x2::sui::SUI");
function coinWithBalance({ type = SUI_TYPE, balance, useGasCoin = true }) {
  let coinResult = null;
  return (tx) => {
    if (coinResult) return coinResult;
    tx.addIntentResolver(COIN_WITH_BALANCE, resolveBalances);
    const coinType = type === "gas" ? type : normalizeStructTag(type);
    coinResult = tx.add(TransactionCommands.Intent({
      name: COIN_WITH_BALANCE,
      inputs: {},
      data: {
        type: coinType === SUI_TYPE && useGasCoin ? "gas" : coinType,
        balance: BigInt(balance),
        outputKind: "coin"
      }
    }));
    return coinResult;
  };
}
function createBalance({ type = SUI_TYPE, balance, useGasCoin = true }) {
  let balanceResult = null;
  return (tx) => {
    if (balanceResult) return balanceResult;
    tx.addIntentResolver(COIN_WITH_BALANCE, resolveBalances);
    const coinType = type === "gas" ? type : normalizeStructTag(type);
    balanceResult = tx.add(TransactionCommands.Intent({
      name: COIN_WITH_BALANCE,
      inputs: {},
      data: {
        type: coinType === SUI_TYPE && useGasCoin ? "gas" : coinType,
        balance: BigInt(balance),
        outputKind: "balance"
      }
    }));
    return balanceResult;
  };
}
var CoinWithBalanceData = object({
  type: string(),
  balance: pipe(union([
    bigint(),
    string(),
    pipe(number(), integer())
  ]), transform((value) => BigInt(value))),
  outputKind: optional(picklist(["coin", "balance"]))
});
async function resolveCoinBalance(transactionData, buildOptions, next) {
  const coinTypes = /* @__PURE__ */ new Set();
  const totalByType = /* @__PURE__ */ new Map();
  const intentsByType = /* @__PURE__ */ new Map();
  if (!transactionData.sender) throw new Error("Sender must be set to resolve CoinWithBalance");
  if (transactionData.commands.some((command) => command.$Intent?.name === ALLOWANCE_BALANCE)) throw new Error("Resolve AllowanceBalance together with CoinWithBalance, or preserve both intents");
  const reservedByType = /* @__PURE__ */ new Map();
  for (const input of transactionData.inputs) {
    if (!input.FundsWithdrawal) continue;
    const { withdrawFrom, typeArg, reservation } = input.FundsWithdrawal;
    if (normalizeSuiAddress(withdrawFrom.SenderAllowance?.funder ?? (withdrawFrom.Sender ? transactionData.sender : transactionData.gasData.owner ?? transactionData.sender)) !== normalizeSuiAddress(transactionData.sender)) continue;
    const type = normalizeStructTag(typeArg.Balance);
    reservedByType.set(type, (reservedByType.get(type) ?? 0n) + BigInt(reservation.MaxAmountU64));
  }
  for (const [i, command] of transactionData.commands.entries()) {
    if (command.$kind !== "$Intent" || command.$Intent.name !== COIN_WITH_BALANCE) continue;
    const { type, balance, outputKind } = parse(CoinWithBalanceData, command.$Intent.data);
    if (balance === 0n) {
      const coinType = type === "gas" ? SUI_TYPE : type;
      transactionData.replaceCommand(i, TransactionCommands.MoveCall({
        target: (outputKind ?? "coin") === "balance" ? "0x2::balance::zero" : "0x2::coin::zero",
        typeArguments: [coinType]
      }));
      continue;
    }
    if (type !== "gas") coinTypes.add(type);
    totalByType.set(type, (totalByType.get(type) ?? 0n) + balance);
    if (!intentsByType.has(type)) intentsByType.set(type, []);
    intentsByType.get(type).push({
      balance,
      outputKind: outputKind ?? "coin"
    });
  }
  if (totalByType.has("gas") && totalByType.has(SUI_TYPE)) throw new Error("Cannot mix SUI CoinWithBalance intents that use the gas coin with ones that do not (useGasCoin: false). Use one or the other.");
  const usedIds = /* @__PURE__ */ new Set();
  for (const input of transactionData.inputs) {
    if (input.Object?.ImmOrOwnedObject) usedIds.add(input.Object.ImmOrOwnedObject.objectId);
    if (input.UnresolvedObject?.objectId) usedIds.add(input.UnresolvedObject.objectId);
  }
  const coinsByType = /* @__PURE__ */ new Map();
  const addressBalanceByType = /* @__PURE__ */ new Map();
  const client = buildOptions.client;
  const assumeSufficientAddressBalances = buildOptions.assumeSufficientAddressBalances;
  if (!client && !assumeSufficientAddressBalances) throw new Error("Client must be provided to build or serialize transactions with CoinWithBalance intents");
  if (assumeSufficientAddressBalances) for (const [coinType, balance] of totalByType) addressBalanceByType.set(coinType, balance);
  else await Promise.all([...[...coinTypes].map(async (coinType) => {
    const { coins, addressBalance } = await getCoinsAndBalanceOfType({
      coinType,
      balance: totalByType.get(coinType),
      client,
      owner: transactionData.sender,
      usedIds,
      reserved: reservedByType.get(coinType) ?? 0n
    });
    coinsByType.set(coinType, coins);
    addressBalanceByType.set(coinType, addressBalance);
  }), totalByType.has("gas") ? await client.core.getBalance({
    owner: transactionData.sender,
    coinType: SUI_TYPE
  }).then(({ balance }) => {
    addressBalanceByType.set("gas", availableAddressBalance(balance.addressBalance, reservedByType.get(SUI_TYPE) ?? 0n));
  }) : null]);
  const exactBalanceByType = /* @__PURE__ */ new Map();
  const usedAddressBalance = /* @__PURE__ */ new Set();
  const typeState = /* @__PURE__ */ new Map();
  let index = 0;
  while (index < transactionData.commands.length) {
    const transaction = transactionData.commands[index];
    if (transaction.$kind !== "$Intent" || transaction.$Intent.name !== COIN_WITH_BALANCE) {
      index++;
      continue;
    }
    const { type, balance } = parse(CoinWithBalanceData, transaction.$Intent.data);
    const coinType = type === "gas" ? SUI_TYPE : type;
    const totalRequired = totalByType.get(type);
    const addressBalance = addressBalanceByType.get(type) ?? 0n;
    const commands = [];
    let intentResult;
    const intentsForType = intentsByType.get(type) ?? [];
    if (intentsForType.every((i) => i.outputKind === "balance") && addressBalance >= totalRequired) {
      commands.push(TransactionCommands.MoveCall({
        target: "0x2::balance::redeem_funds",
        typeArguments: [coinType],
        arguments: [transactionData.addInput("withdrawal", Inputs.FundsWithdrawal({
          reservation: {
            $kind: "MaxAmountU64",
            MaxAmountU64: String(balance)
          },
          typeArg: {
            $kind: "Balance",
            Balance: coinType
          },
          withdrawFrom: {
            $kind: "Sender",
            Sender: true
          }
        }))]
      }));
      intentResult = {
        $kind: "NestedResult",
        NestedResult: [index + commands.length - 1, 0]
      };
    } else {
      if (!typeState.has(type)) {
        const intents = intentsForType;
        const sources = [];
        if (addressBalance >= totalRequired) {
          usedAddressBalance.add(type);
          commands.push(TransactionCommands.MoveCall({
            target: "0x2::coin::redeem_funds",
            typeArguments: [coinType],
            arguments: [transactionData.addInput("withdrawal", Inputs.FundsWithdrawal({
              reservation: {
                $kind: "MaxAmountU64",
                MaxAmountU64: String(totalRequired)
              },
              typeArg: {
                $kind: "Balance",
                Balance: coinType
              },
              withdrawFrom: {
                $kind: "Sender",
                Sender: true
              }
            }))]
          }));
          sources.push({
            $kind: "Result",
            Result: index + commands.length - 1
          });
        } else if (type === "gas") sources.push({
          $kind: "GasCoin",
          GasCoin: true
        });
        else {
          const coins = coinsByType.get(type);
          const loadedCoinBalance = coins.reduce((sum, c) => sum + BigInt(c.balance), 0n);
          const abNeeded = totalRequired > loadedCoinBalance ? totalRequired - loadedCoinBalance : 0n;
          exactBalanceByType.set(type, loadedCoinBalance + abNeeded === totalRequired);
          for (const coin of coins) sources.push(transactionData.addInput("object", Inputs.ObjectRef({
            objectId: coin.objectId,
            digest: coin.digest,
            version: coin.version
          })));
          if (abNeeded > 0n) {
            usedAddressBalance.add(type);
            commands.push(TransactionCommands.MoveCall({
              target: "0x2::coin::redeem_funds",
              typeArguments: [coinType],
              arguments: [transactionData.addInput("withdrawal", Inputs.FundsWithdrawal({
                reservation: {
                  $kind: "MaxAmountU64",
                  MaxAmountU64: String(abNeeded)
                },
                typeArg: {
                  $kind: "Balance",
                  Balance: coinType
                },
                withdrawFrom: {
                  $kind: "Sender",
                  Sender: true
                }
              }))]
            }));
            sources.push({
              $kind: "Result",
              Result: index + commands.length - 1
            });
          }
        }
        const baseCoin = sources[0];
        const rest = sources.slice(1);
        for (let i = 0; i < rest.length; i += 500) commands.push(TransactionCommands.MergeCoins(baseCoin, rest.slice(i, i + 500)));
        const splitCmdIndex = index + commands.length;
        commands.push(TransactionCommands.SplitCoins(baseCoin, intents.map((i) => transactionData.addInput("pure", Inputs.Pure(suiBcs.u64().serialize(i.balance))))));
        const results = [];
        for (let i = 0; i < intents.length; i++) {
          const splitResult = {
            $kind: "NestedResult",
            NestedResult: [splitCmdIndex, i]
          };
          if (intents[i].outputKind === "balance") {
            commands.push(TransactionCommands.MoveCall({
              target: "0x2::coin::into_balance",
              typeArguments: [coinType],
              arguments: [splitResult]
            }));
            results.push({
              $kind: "NestedResult",
              NestedResult: [index + commands.length - 1, 0]
            });
          } else results.push(splitResult);
        }
        if (type !== "gas" || usedAddressBalance.has(type)) {
          const hasBalanceIntent = intents.some((intent) => intent.outputKind === "balance");
          const sourcedFromAB = usedAddressBalance.has(type);
          if (hasBalanceIntent || sourcedFromAB) commands.push(TransactionCommands.MoveCall({
            target: "0x2::coin::send_funds",
            typeArguments: [coinType],
            arguments: [baseCoin, transactionData.addInput("pure", Inputs.Pure(suiBcs.Address.serialize(transactionData.sender)))]
          }));
          else if (exactBalanceByType.get(type)) commands.push(TransactionCommands.MoveCall({
            target: "0x2::coin::destroy_zero",
            typeArguments: [coinType],
            arguments: [baseCoin]
          }));
        }
        typeState.set(type, {
          results,
          nextIntent: 0
        });
      }
      const state = typeState.get(type);
      intentResult = state.results[state.nextIntent++];
    }
    transactionData.replaceCommand(index, commands, intentResult);
    index += commands.length;
  }
  return next();
}
async function getCoinsAndBalanceOfType({ coinType, balance, client, owner, usedIds, reserved }) {
  let remainingBalance = balance;
  const coins = [];
  const balanceRequest = client.core.getBalance({
    owner,
    coinType
  }).then(({ balance: balance$1 }) => {
    const addressBalance = availableAddressBalance(balance$1.addressBalance, reserved);
    remainingBalance -= addressBalance;
    return {
      ...balance$1,
      addressBalance: String(addressBalance),
      balance: String(BigInt(balance$1.balance) - reserved)
    };
  });
  const [allCoins, balanceResponse] = await Promise.all([loadMoreCoins(), balanceRequest]);
  if (BigInt(balanceResponse.balance) < balance) throw new Error(`Insufficient balance of ${coinType} for owner ${owner}. Required: ${balance}, Available: ${balance - remainingBalance}`);
  return {
    coins: allCoins,
    balance: BigInt(balanceResponse.coinBalance),
    addressBalance: BigInt(balanceResponse.addressBalance),
    coinBalance: BigInt(balanceResponse.coinBalance)
  };
  async function loadMoreCoins(cursor = null) {
    const { objects, hasNextPage, cursor: nextCursor } = await client.core.listCoins({
      owner,
      coinType,
      cursor
    });
    await balanceRequest;
    for (const coin of objects) {
      if (usedIds.has(coin.objectId)) continue;
      coins.push(coin);
      remainingBalance -= BigInt(coin.balance);
    }
    if (remainingBalance > 0n && hasNextPage) return loadMoreCoins(nextCursor);
    return coins;
  }
}
function availableAddressBalance(balance, reserved) {
  const available = BigInt(balance) - reserved;
  if (available < 0n) throw new Error(`Insufficient address balance for existing withdrawals. Required: ${reserved}, Available: ${balance}`);
  return available;
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/data/v2.mjs
function enumUnion(options) {
  return union(Object.entries(options).map(([key, value]) => object({ [key]: value })));
}
var Argument3 = enumUnion({
  GasCoin: literal(true),
  Input: pipe(number(), integer()),
  Result: pipe(number(), integer()),
  NestedResult: tuple([pipe(number(), integer()), pipe(number(), integer())])
});
var GasData2 = object({
  budget: nullable(JsonU64),
  price: nullable(JsonU64),
  owner: nullable(SuiAddress),
  payment: nullable(array(ObjectRefSchema))
});
var ProgrammableMoveCall2 = object({
  package: ObjectID,
  module: string(),
  function: string(),
  typeArguments: array(string()),
  arguments: array(Argument3)
});
var $Intent2 = object({
  name: string(),
  inputs: record(string(), union([Argument3, array(Argument3)])),
  data: record(string(), unknown())
});
var Command3 = enumUnion({
  MoveCall: ProgrammableMoveCall2,
  TransferObjects: object({
    objects: array(Argument3),
    address: Argument3
  }),
  SplitCoins: object({
    coin: Argument3,
    amounts: array(Argument3)
  }),
  MergeCoins: object({
    destination: Argument3,
    sources: array(Argument3)
  }),
  Publish: object({
    modules: array(BCSBytes),
    dependencies: array(ObjectID)
  }),
  MakeMoveVec: object({
    type: nullable(string()),
    elements: array(Argument3)
  }),
  Upgrade: object({
    modules: array(BCSBytes),
    dependencies: array(ObjectID),
    package: ObjectID,
    ticket: Argument3
  }),
  $Intent: $Intent2
});
var CallArg2 = enumUnion({
  Object: enumUnion({
    ImmOrOwnedObject: ObjectRefSchema,
    SharedObject: object({
      objectId: ObjectID,
      initialSharedVersion: JsonU64,
      mutable: boolean()
    }),
    Receiving: ObjectRefSchema
  }),
  Pure: object({ bytes: BCSBytes }),
  UnresolvedPure: object({ value: unknown() }),
  UnresolvedObject: object({
    objectId: ObjectID,
    version: optional(nullable(JsonU64)),
    digest: optional(nullable(string())),
    initialSharedVersion: optional(nullable(JsonU64)),
    mutable: optional(nullable(boolean()))
  }),
  FundsWithdrawal: FundsWithdrawalArgSchema
});
var TransactionExpiration5 = enumUnion({
  None: literal(true),
  Epoch: JsonU64,
  ValidDuring: ValidDuringSchema,
  Validity: ValiditySchema
});
var SerializedTransactionDataV2Schema = object({
  version: literal(2),
  sender: nullish(SuiAddress),
  expiration: nullish(TransactionExpiration5),
  gasData: GasData2,
  inputs: array(CallArg2),
  commands: array(Command3),
  digest: optional(nullable(string()))
});

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/object.mjs
function createObjectMethods(makeObject) {
  function object2(value) {
    return makeObject(value);
  }
  object2.system = (options) => {
    const mutable = options?.mutable;
    if (mutable !== void 0) return object2(Inputs.SharedObjectRef({
      objectId: SUI_SYSTEM_STATE_OBJECT_ID,
      initialSharedVersion: 1,
      mutable
    }));
    return object2({
      $kind: "UnresolvedObject",
      UnresolvedObject: {
        objectId: SUI_SYSTEM_STATE_OBJECT_ID,
        initialSharedVersion: 1
      }
    });
  };
  object2.clock = () => object2(Inputs.SharedObjectRef({
    objectId: SUI_CLOCK_OBJECT_ID,
    initialSharedVersion: 1,
    mutable: false
  }));
  object2.random = () => object2({
    $kind: "UnresolvedObject",
    UnresolvedObject: {
      objectId: SUI_RANDOM_OBJECT_ID,
      mutable: false
    }
  });
  object2.denyList = (options) => {
    return object2({
      $kind: "UnresolvedObject",
      UnresolvedObject: {
        objectId: SUI_DENY_LIST_OBJECT_ID,
        mutable: options?.mutable
      }
    });
  };
  object2.option = ({ type, value }) => (tx) => tx.moveCall({
    typeArguments: [type],
    target: `${MOVE_STDLIB_ADDRESS}::option::${value === null ? "none" : "some"}`,
    arguments: value === null ? [] : [tx.object(value)]
  });
  return object2;
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/pure.mjs
function createPure(makePure) {
  function pure(typeOrSerializedValue, value) {
    if (typeof typeOrSerializedValue === "string") return makePure(pureBcsSchemaFromTypeName(typeOrSerializedValue).serialize(value));
    if (typeOrSerializedValue instanceof Uint8Array || isSerializedBcs(typeOrSerializedValue)) return makePure(typeOrSerializedValue);
    throw new Error("tx.pure must be called either a bcs type name, or a serialized bcs value");
  }
  pure.u8 = (value) => makePure(suiBcs.U8.serialize(value));
  pure.u16 = (value) => makePure(suiBcs.U16.serialize(value));
  pure.u32 = (value) => makePure(suiBcs.U32.serialize(value));
  pure.u64 = (value) => makePure(suiBcs.U64.serialize(value));
  pure.u128 = (value) => makePure(suiBcs.U128.serialize(value));
  pure.u256 = (value) => makePure(suiBcs.U256.serialize(value));
  pure.bool = (value) => makePure(suiBcs.Bool.serialize(value));
  pure.string = (value) => makePure(suiBcs.String.serialize(value));
  pure.address = (value) => makePure(suiBcs.Address.serialize(value));
  pure.id = pure.address;
  pure.vector = (type, value) => {
    return makePure(suiBcs.vector(pureBcsSchemaFromTypeName(type)).serialize(value));
  };
  pure.option = (type, value) => {
    return makePure(suiBcs.option(pureBcsSchemaFromTypeName(type)).serialize(value));
  };
  return pure;
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/plugins/NamedPackagesPlugin.mjs
function namedPackagesPlugin() {
  return async (transactionData, buildOptions, next) => {
    const names = findNamesInTransaction(transactionData);
    if (names.types.length === 0 && names.packages.length === 0) return next();
    if (!buildOptions.client) throw new Error(`Transaction contains MVR names but no client was provided to resolve them. Please pass a client to Transaction#build()`);
    replaceNames(transactionData, await buildOptions.client.core.mvr.resolve({
      types: names.types,
      packages: names.packages
    }));
    await next();
  };
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/intents/BalanceOptions.mjs
function normalizeBalance(options) {
  if (options.allowance !== void 0 && options.useGasCoin !== void 0) throw new Error("useGasCoin cannot be combined with allowance");
  const amount = options.balance;
  if (typeof amount === "string" && !/^[0-9]+$/.test(amount)) throw new Error("Amount must be a non-empty string of decimal digits");
  if (typeof amount === "number" && !Number.isSafeInteger(amount)) throw new Error("Amount must be a safe integer; use bigint or a string for larger amounts");
  return BigInt(amount);
}

// dapp/node_modules/.pnpm/@mysten+sui@2.36.0_typescript@5.9.3/node_modules/@mysten/sui/dist/transactions/Transaction.mjs
function createTransactionResult(index, length = Infinity) {
  const baseResult = {
    $kind: "Result",
    get Result() {
      return typeof index === "function" ? index() : index;
    }
  };
  const nestedResults = [];
  const nestedResultFor = (resultIndex) => nestedResults[resultIndex] ??= {
    $kind: "NestedResult",
    get NestedResult() {
      return [typeof index === "function" ? index() : index, resultIndex];
    }
  };
  return new Proxy(baseResult, {
    set() {
      throw new Error("The transaction result is a proxy, and does not support setting properties directly");
    },
    get(target, property) {
      if (property in target) return Reflect.get(target, property);
      if (property === Symbol.iterator) return function* () {
        let i = 0;
        while (i < length) {
          yield nestedResultFor(i);
          i++;
        }
      };
      if (typeof property === "symbol") return;
      const resultIndex = parseInt(property, 10);
      if (Number.isNaN(resultIndex) || resultIndex < 0) return;
      return nestedResultFor(resultIndex);
    }
  });
}
var TRANSACTION_BRAND = /* @__PURE__ */ Symbol.for("@mysten/transaction");
var Transaction2 = class Transaction3 {
  #serializationPlugins;
  #buildPlugins;
  #intentResolvers = /* @__PURE__ */ new Map();
  #inputSection = [];
  #commandSection = [];
  #availableResults = /* @__PURE__ */ new Set();
  #pendingPromises = /* @__PURE__ */ new Set();
  #added = /* @__PURE__ */ new Map();
  /**
  * Converts from a serialize transaction kind (built with `build({ onlyTransactionKind: true })`) to a `Transaction` class.
  * Supports either a byte array, or base64-encoded bytes.
  */
  static fromKind(serialized) {
    const tx = new Transaction3();
    tx.#data = TransactionDataBuilder.fromKindBytes(typeof serialized === "string" ? fromBase64(serialized) : serialized);
    tx.#inputSection = tx.#data.inputs.slice();
    tx.#commandSection = tx.#data.commands.slice();
    tx.#availableResults = new Set(tx.#commandSection.map((_, i) => i));
    return tx;
  }
  /**
  * Converts from a serialized transaction format to a `Transaction` class.
  * There are two supported serialized formats:
  * - A string returned from `Transaction#serialize`. The serialized format must be compatible, or it will throw an error.
  * - A byte array (or base64-encoded bytes) containing BCS transaction data.
  *
  * It can also copy an existing `Transaction` or `TransactionDataBuilder` instance. The data is
  * copied, so changes to the new transaction do not affect the original.
  *
  * When copying an in-memory transaction that uses custom intents, pass resolvers for those intents
  * via `options.intentResolvers` so the copy can be created synchronously without first awaiting
  * `prepareForSerialization`. Built-in intents (such as `CoinWithBalance`) are handled automatically.
  */
  static from(transaction, options = {}) {
    const newTransaction = new Transaction3();
    if (typeof transaction === "object" && "getData" in transaction) newTransaction.#data = TransactionDataBuilder.restore(transaction.getData());
    else if (typeof transaction !== "string" || !transaction.startsWith("{")) newTransaction.#data = TransactionDataBuilder.fromBytes(typeof transaction === "string" ? fromBase64(transaction) : transaction);
    else newTransaction.#data = TransactionDataBuilder.restore(JSON.parse(transaction));
    newTransaction.#inputSection = newTransaction.#data.inputs.slice();
    newTransaction.#commandSection = newTransaction.#data.commands.slice();
    newTransaction.#availableResults = new Set(newTransaction.#commandSection.map((_, i) => i));
    const intentResolvers = new Map([
      [COIN_WITH_BALANCE, resolveBalances],
      [ALLOWANCE_BALANCE, resolveBalances],
      ...Object.entries(options.intentResolvers ?? {})
    ]);
    if (!newTransaction.isPreparedForSerialization({ supportedIntents: [...intentResolvers.keys()] })) throw new Error("Transaction has unresolved intents or async thunks. Provide resolvers for any custom intents via the `intentResolvers` option, or call `prepareForSerialization` before copying.");
    for (const [intent, resolver] of intentResolvers) newTransaction.addIntentResolver(intent, resolver);
    return newTransaction;
  }
  addSerializationPlugin(step) {
    this.#serializationPlugins.push(step);
  }
  addBuildPlugin(step) {
    this.#buildPlugins.push(step);
  }
  addIntentResolver(intent, resolver) {
    if (this.#intentResolvers.has(intent) && this.#intentResolvers.get(intent) !== resolver) throw new Error(`Intent resolver for ${intent} already exists`);
    this.#intentResolvers.set(intent, resolver);
  }
  setSender(sender) {
    this.#data.sender = sender;
  }
  /**
  * Sets the sender only if it has not already been set.
  * This is useful for sponsored transaction flows where the sender may not be the same as the signer address.
  */
  setSenderIfNotSet(sender) {
    if (!this.#data.sender) this.#data.sender = sender;
  }
  setExpiration(expiration) {
    this.#data.expiration = expiration ? parse(TransactionExpiration2, expiration) : null;
  }
  setGasPrice(price) {
    this.#data.gasData.price = String(price);
  }
  setGasBudget(budget) {
    this.#data.gasData.budget = String(budget);
  }
  setGasBudgetIfNotSet(budget) {
    if (this.#data.gasData.budget == null) this.#data.gasData.budget = String(budget);
  }
  setGasOwner(owner) {
    this.#data.gasData.owner = owner;
  }
  setGasPayment(payments) {
    this.#data.gasData.payment = payments.map((payment) => parse(ObjectRefSchema, payment));
  }
  #data;
  /** Get a snapshot of the transaction data, in JSON form: */
  getData() {
    return this.#data.snapshot();
  }
  get [TRANSACTION_BRAND]() {
    return true;
  }
  get pure() {
    Object.defineProperty(this, "pure", {
      enumerable: false,
      value: createPure((value) => {
        if (isSerializedBcs(value)) return this.#addInput("pure", {
          $kind: "Pure",
          Pure: { bytes: value.toBase64() }
        });
        return this.#addInput("pure", is(NormalizedCallArg, value) ? parse(NormalizedCallArg, value) : value instanceof Uint8Array ? Inputs.Pure(value) : {
          $kind: "UnresolvedPure",
          UnresolvedPure: { value }
        });
      })
    });
    return this.pure;
  }
  constructor() {
    this.object = createObjectMethods((value) => {
      if (typeof value === "function") return this.object(this.add(value));
      if (typeof value === "object" && is(ArgumentSchema, value)) return value;
      const id = getIdFromCallArg(value);
      const inserted = this.#data.inputs.find((i) => id === getIdFromCallArg(i));
      if (inserted?.Object?.SharedObject && typeof value === "object" && value.Object?.SharedObject) inserted.Object.SharedObject.mutable = inserted.Object.SharedObject.mutable || value.Object.SharedObject.mutable;
      return inserted ? {
        $kind: "Input",
        Input: this.#data.inputs.indexOf(inserted),
        type: "object"
      } : this.#addInput("object", typeof value === "string" ? {
        $kind: "UnresolvedObject",
        UnresolvedObject: { objectId: normalizeSuiAddress(value) }
      } : value);
    });
    this.#data = new TransactionDataBuilder();
    this.#buildPlugins = [];
    this.#serializationPlugins = [];
  }
  /** Returns an argument for the gas coin, to be used in a transaction. */
  get gas() {
    return {
      $kind: "GasCoin",
      GasCoin: true
    };
  }
  /**
  * Creates a Coin<T> of the specified type and amount (defaults to SUI).
  * Sourced from address balance when available, falling back to owned coins. For SUI, falls back
  * to the gas coin instead unless `useGasCoin` is `false`.
  * With `allowance`, spends only from the funder's address balance under that allowance.
  * Allowance IDs are resolved using the build client; app-bound allowances also require an app type and SpendPermit.
  */
  coin(options) {
    const amount = normalizeBalance(options);
    return this.add(options.allowance !== void 0 ? allowanceBalance({
      ...options,
      amount,
      outputKind: "coin"
    }) : coinWithBalance({
      ...options,
      balance: amount
    }));
  }
  /**
  * Creates a Balance<T> of the specified type and amount (defaults to SUI).
  * Sourced from address balance when available, falling back to owned coins. For SUI, falls back
  * to the gas coin instead unless `useGasCoin` is `false`.
  * With `allowance`, spends only from the funder's address balance under that allowance.
  * Allowance IDs are resolved using the build client; app-bound allowances also require an app type and SpendPermit.
  */
  balance(options) {
    const amount = normalizeBalance(options);
    return this.add(options.allowance !== void 0 ? allowanceBalance({
      ...options,
      amount,
      outputKind: "balance"
    }) : createBalance({
      ...options,
      balance: amount
    }));
  }
  /**
  * Add a new object input to the transaction using the fully-resolved object reference.
  * If you only have an object ID, use `builder.object(id)` instead.
  */
  objectRef(...args) {
    return this.object(Inputs.ObjectRef(...args));
  }
  /**
  * Add a new receiving input to the transaction using the fully-resolved object reference.
  * If you only have an object ID, use `builder.object(id)` instead.
  */
  receivingRef(...args) {
    return this.object(Inputs.ReceivingRef(...args));
  }
  /**
  * Add a new shared object input to the transaction using the fully-resolved shared object reference.
  * If you only have an object ID, use `builder.object(id)` instead.
  */
  sharedObjectRef(...args) {
    return this.object(Inputs.SharedObjectRef(...args));
  }
  #fork() {
    const fork = new Transaction3();
    fork.#data = this.#data;
    fork.#serializationPlugins = this.#serializationPlugins;
    fork.#buildPlugins = this.#buildPlugins;
    fork.#intentResolvers = this.#intentResolvers;
    fork.#pendingPromises = this.#pendingPromises;
    fork.#availableResults = new Set(this.#availableResults);
    fork.#added = this.#added;
    this.#inputSection.push(fork.#inputSection);
    this.#commandSection.push(fork.#commandSection);
    return fork;
  }
  add(command) {
    if (typeof command === "function") {
      if (this.#added.has(command)) return this.#added.get(command);
      const fork = this.#fork();
      const result = command(fork);
      if (!(result && typeof result === "object" && "then" in result)) {
        this.#availableResults = fork.#availableResults;
        this.#added.set(command, result);
        return result;
      }
      const placeholder = this.#addCommand({
        $kind: "$Intent",
        $Intent: {
          name: "AsyncTransactionThunk",
          inputs: {},
          data: {
            resultIndex: this.#data.commands.length,
            result: null
          }
        }
      });
      this.#pendingPromises.add(Promise.resolve(result).then((result$1) => {
        placeholder.$Intent.data.result = result$1;
      }));
      const txResult = createTransactionResult(() => placeholder.$Intent.data.resultIndex);
      this.#added.set(command, txResult);
      return txResult;
    } else this.#addCommand(command);
    return createTransactionResult(this.#data.commands.length - 1);
  }
  #addCommand(command) {
    const resultIndex = this.#data.commands.length;
    this.#commandSection.push(command);
    this.#availableResults.add(resultIndex);
    this.#data.commands.push(command);
    this.#data.mapCommandArguments(resultIndex, (arg) => {
      if (arg.$kind === "Result" && !this.#availableResults.has(arg.Result)) throw new Error(`Result { Result: ${arg.Result} } is not available to use in the current transaction`);
      if (arg.$kind === "NestedResult" && !this.#availableResults.has(arg.NestedResult[0])) throw new Error(`Result { NestedResult: [${arg.NestedResult[0]}, ${arg.NestedResult[1]}] } is not available to use in the current transaction`);
      if (arg.$kind === "Input" && arg.Input >= this.#data.inputs.length) throw new Error(`Input { Input: ${arg.Input} } references an input that does not exist in the current transaction`);
      return arg;
    });
    return command;
  }
  #addInput(type, input) {
    this.#inputSection.push(input);
    return this.#data.addInput(type, input);
  }
  #normalizeTransactionArgument(arg) {
    if (isSerializedBcs(arg)) return this.pure(arg);
    return this.#resolveArgument(arg);
  }
  #resolveArgument(arg) {
    if (typeof arg === "function") {
      const resolved = this.add(arg);
      if (typeof resolved === "function") return this.#resolveArgument(resolved);
      return parse(ArgumentSchema, resolved);
    }
    return parse(ArgumentSchema, arg);
  }
  splitCoins(coin, amounts) {
    const command = TransactionCommands.SplitCoins(typeof coin === "string" ? this.object(coin) : this.#resolveArgument(coin), amounts.map((amount) => typeof amount === "number" || typeof amount === "bigint" || typeof amount === "string" ? this.pure.u64(amount) : this.#normalizeTransactionArgument(amount)));
    this.#addCommand(command);
    return createTransactionResult(this.#data.commands.length - 1, amounts.length);
  }
  mergeCoins(destination, sources) {
    return this.add(TransactionCommands.MergeCoins(this.object(destination), sources.map((src) => this.object(src))));
  }
  publish({ modules, dependencies }) {
    return this.add(TransactionCommands.Publish({
      modules,
      dependencies
    }));
  }
  upgrade({ modules, dependencies, package: packageId, ticket }) {
    return this.add(TransactionCommands.Upgrade({
      modules,
      dependencies,
      package: packageId,
      ticket: this.object(ticket)
    }));
  }
  moveCall({ arguments: args, ...input }) {
    return this.add(TransactionCommands.MoveCall({
      ...input,
      arguments: args?.map((arg) => this.#normalizeTransactionArgument(arg))
    }));
  }
  transferObjects(objects, address) {
    return this.add(TransactionCommands.TransferObjects(objects.map((obj) => this.object(obj)), typeof address === "string" ? this.pure.address(address) : this.#normalizeTransactionArgument(address)));
  }
  makeMoveVec({ type, elements }) {
    return this.add(TransactionCommands.MakeMoveVec({
      type,
      elements: elements.map((obj) => this.object(obj))
    }));
  }
  /**
  * Creates a FundsWithdrawal input for withdrawing Balance<T> from an address balance.
  *
  * @param options.amount - The amount to withdraw (u64).
  * @param options.type - The coin type T (e.g., "0x2::sui::SUI"), not Balance<T>. Defaults to SUI.
  * @param options.from - The withdrawal source. Defaults to the transaction sender.
  * @param options.allowance - The allowance ID, required when from is 'allowance'.
  * @param options.funder - The funder's address, required when from is 'allowance'.
  */
  withdrawal(options) {
    const input = {
      $kind: "FundsWithdrawal",
      FundsWithdrawal: {
        reservation: {
          $kind: "MaxAmountU64",
          MaxAmountU64: String(options.amount)
        },
        typeArg: {
          $kind: "Balance",
          Balance: options.type ?? "0x2::sui::SUI"
        },
        withdrawFrom: options.from === "allowance" ? {
          $kind: "SenderAllowance",
          SenderAllowance: {
            funder: normalizeSuiAddress(options.funder),
            allowance: normalizeSuiAddress(options.allowance)
          }
        } : options.from === "sponsor" ? {
          $kind: "Sponsor",
          Sponsor: true
        } : {
          $kind: "Sender",
          Sender: true
        }
      }
    };
    return this.#addInput("object", input);
  }
  /**
  * @deprecated Use toJSON instead.
  * For synchronous serialization, you can use `getData()`
  * */
  serialize() {
    return JSON.stringify(serializeV1TransactionData(this.#data.snapshot()));
  }
  async toJSON(options = {}) {
    await this.prepareForSerialization(options);
    const fullyResolved = this.isFullyResolved();
    return JSON.stringify(parse(SerializedTransactionDataV2Schema, fullyResolved ? {
      ...this.#data.snapshot(),
      digest: this.#data.getDigest()
    } : this.#data.snapshot()), (_key, value) => typeof value === "bigint" ? value.toString() : value, 2);
  }
  /** Build the transaction to BCS bytes, and sign it with the provided keypair. */
  async sign(options) {
    const { signer, ...buildOptions } = options;
    const bytes = await this.build(buildOptions);
    return signer.signTransaction(bytes);
  }
  /**
  * Checks if the transaction is prepared for serialization to JSON.
  * This means:
  *  - All async thunks have been fully resolved
  *  - All transaction intents have been resolved (unless in supportedIntents)
  *
  * Unlike `isFullyResolved()`, this does not require the sender, gas payment,
  * budget, or object versions to be set.
  */
  isPreparedForSerialization(options = {}) {
    if (this.#pendingPromises.size > 0) return false;
    if (this.#data.commands.some((cmd) => cmd.$Intent && !options.supportedIntents?.includes(cmd.$Intent.name))) return false;
    return true;
  }
  /**
  *  Ensures that:
  *  - All objects have been fully resolved to a specific version
  *  - All pure inputs have been serialized to bytes
  *  - All async thunks have been fully resolved
  *  - All transaction intents have been resolved
  * 	- The gas payment, budget, and price have been set
  *  - The transaction sender has been set
  *
  *  When true, the transaction will always be built to the same bytes and digest (unless the transaction is mutated)
  */
  isFullyResolved() {
    if (!this.isPreparedForSerialization()) return false;
    if (!this.#data.sender) return false;
    if (needsTransactionResolution(this.#data, {})) return false;
    return true;
  }
  /** Build the transaction to BCS bytes. */
  async build(options = {}) {
    await this.prepareForSerialization(options);
    await this.#prepareBuild(options);
    return this.#data.build({ onlyTransactionKind: options.onlyTransactionKind });
  }
  /** Derive transaction digest */
  async getDigest(options = {}) {
    await this.prepareForSerialization(options);
    await this.#prepareBuild(options);
    return this.#data.getDigest();
  }
  /**
  * Prepare the transaction by validating the transaction data and resolving all inputs
  * so that it can be built into bytes.
  */
  async #prepareBuild(options) {
    if (!options.onlyTransactionKind && !this.#data.sender) throw new Error("Missing transaction sender");
    await this.#runPlugins([...this.#buildPlugins, resolveTransactionPlugin], options);
  }
  async #runPlugins(plugins, options) {
    try {
      const createNext = (i) => {
        if (i >= plugins.length) return () => {
        };
        const plugin = plugins[i];
        return async () => {
          const next = createNext(i + 1);
          let calledNext = false;
          let nextResolved = false;
          await plugin(this.#data, options, async () => {
            if (calledNext) throw new Error(`next() was call multiple times in TransactionPlugin ${i}`);
            calledNext = true;
            await next();
            nextResolved = true;
          });
          if (!calledNext) throw new Error(`next() was not called in TransactionPlugin ${i}`);
          if (!nextResolved) throw new Error(`next() was not awaited in TransactionPlugin ${i}`);
        };
      };
      await createNext(0)();
    } finally {
      this.#inputSection = this.#data.inputs.slice();
      this.#commandSection = this.#data.commands.slice();
      this.#availableResults = new Set(this.#commandSection.map((_, i) => i));
    }
  }
  async #waitForPendingTasks() {
    while (this.#pendingPromises.size > 0) {
      const newPromise = Promise.all(this.#pendingPromises);
      this.#pendingPromises.clear();
      this.#pendingPromises.add(newPromise);
      await newPromise;
      this.#pendingPromises.delete(newPromise);
    }
  }
  #sortCommandsAndInputs() {
    const unorderedCommands = this.#data.commands;
    const unorderedInputs = this.#data.inputs;
    const orderedCommands = this.#commandSection.flat(Infinity);
    const orderedInputs = this.#inputSection.flat(Infinity);
    if (orderedCommands.length !== unorderedCommands.length) throw new Error("Unexpected number of commands found in transaction data");
    if (orderedInputs.length !== unorderedInputs.length) throw new Error("Unexpected number of inputs found in transaction data");
    const filteredCommands = orderedCommands.filter((cmd) => cmd.$Intent?.name !== "AsyncTransactionThunk");
    this.#data.commands = filteredCommands;
    this.#data.inputs = orderedInputs;
    this.#commandSection = filteredCommands;
    this.#inputSection = orderedInputs;
    this.#availableResults = new Set(filteredCommands.map((_, i) => i));
    function getOriginalIndex(index) {
      const command = unorderedCommands[index];
      if (command.$Intent?.name === "AsyncTransactionThunk") {
        const result = command.$Intent.data.result;
        if (result == null) throw new Error("AsyncTransactionThunk has not been resolved");
        return getOriginalIndex(result.Result);
      }
      const updated = filteredCommands.indexOf(command);
      if (updated === -1) throw new Error("Unable to find original index for command");
      return updated;
    }
    this.#data.mapArguments((arg) => {
      if (arg.$kind === "Input") {
        const updated = orderedInputs.indexOf(unorderedInputs[arg.Input]);
        if (updated === -1) throw new Error("Input has not been resolved");
        return {
          ...arg,
          Input: updated
        };
      } else if (arg.$kind === "Result") {
        const updated = getOriginalIndex(arg.Result);
        return {
          ...arg,
          Result: updated
        };
      } else if (arg.$kind === "NestedResult") {
        const updated = getOriginalIndex(arg.NestedResult[0]);
        return {
          ...arg,
          NestedResult: [updated, arg.NestedResult[1]]
        };
      }
      return arg;
    });
    for (const [i, cmd] of unorderedCommands.entries()) if (cmd.$Intent?.name === "AsyncTransactionThunk") try {
      cmd.$Intent.data.resultIndex = getOriginalIndex(i);
    } catch {
    }
  }
  async prepareForSerialization(options) {
    await this.#waitForPendingTasks();
    this.#sortCommandsAndInputs();
    const intents = /* @__PURE__ */ new Set();
    for (const command of this.#data.commands) if (command.$Intent) intents.add(command.$Intent.name);
    const steps = [...this.#serializationPlugins];
    const resolverIntents = /* @__PURE__ */ new Map();
    for (const intent of intents) {
      if (options.supportedIntents?.includes(intent)) continue;
      const resolver = this.#intentResolvers.get(intent);
      if (!resolver) throw new Error(`Missing intent resolver for ${intent}`);
      const names = resolverIntents.get(resolver) ?? [];
      names.push(intent);
      resolverIntents.set(resolver, names);
    }
    for (const [resolver, intentNames] of resolverIntents) steps.push((data, buildOptions, next) => {
      return resolver(data, {
        ...buildOptions,
        intentNames
      }, next);
    });
    steps.push(namedPackagesPlugin());
    await this.#runPlugins(steps, options);
  }
};

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/utils/index.mjs
var MOVE_STDLIB_ADDRESS2 = normalizeSuiAddress("0x1");
var SUI_FRAMEWORK_ADDRESS2 = normalizeSuiAddress("0x2");
function getPureBcsSchema2(typeTag) {
  const parsedTag = typeof typeTag === "string" ? TypeTagSerializer.parseFromStr(typeTag) : typeTag;
  if ("u8" in parsedTag) return suiBcs.U8;
  else if ("u16" in parsedTag) return suiBcs.U16;
  else if ("u32" in parsedTag) return suiBcs.U32;
  else if ("u64" in parsedTag) return suiBcs.U64;
  else if ("u128" in parsedTag) return suiBcs.U128;
  else if ("u256" in parsedTag) return suiBcs.U256;
  else if ("address" in parsedTag) return suiBcs.Address;
  else if ("bool" in parsedTag) return suiBcs.Bool;
  else if ("vector" in parsedTag) {
    const type = getPureBcsSchema2(parsedTag.vector);
    return type ? suiBcs.vector(type) : null;
  } else if ("struct" in parsedTag) {
    const structTag = parsedTag.struct;
    const pkg = normalizeSuiAddress(structTag.address);
    if (pkg === MOVE_STDLIB_ADDRESS2) {
      if ((structTag.module === "ascii" || structTag.module === "string") && structTag.name === "String") return suiBcs.String;
      if (structTag.module === "option" && structTag.name === "Option") {
        const inner = structTag.typeParams[0];
        const type = inner ? getPureBcsSchema2(inner) : null;
        return type ? suiBcs.option(type) : null;
      }
    }
    if (pkg === SUI_FRAMEWORK_ADDRESS2 && structTag.module === "object" && (structTag.name === "ID" || structTag.name === "UID")) return suiBcs.Address;
  }
  return null;
}
function normalizeMoveArguments(args, argTypes, parameterNames) {
  const argLen = Array.isArray(args) ? args.length : Object.keys(args).length;
  if (parameterNames && argLen !== parameterNames.length) throw new Error(`Invalid number of arguments, expected ${parameterNames.length}, got ${argLen}`);
  const normalizedArgs = [];
  let index = 0;
  for (const argType of argTypes) {
    if (argType === "0x2::clock::Clock") {
      normalizedArgs.push((tx) => tx.object.clock());
      continue;
    }
    if (argType === "0x2::random::Random") {
      normalizedArgs.push((tx) => tx.object.random());
      continue;
    }
    if (argType === "0x2::deny_list::DenyList") {
      normalizedArgs.push((tx) => tx.object.denyList());
      continue;
    }
    if (argType === "0x2::accumulator::AccumulatorRoot") {
      normalizedArgs.push((tx) => tx.object("0xacc"));
      continue;
    }
    if (argType === "0x3::sui_system::SuiSystemState") {
      normalizedArgs.push((tx) => tx.object.system());
      continue;
    }
    let arg;
    if (Array.isArray(args)) {
      if (index >= args.length) throw new Error(`Invalid number of arguments, expected at least ${index + 1}, got ${args.length}`);
      arg = args[index];
    } else {
      if (!parameterNames) throw new Error(`Expected arguments to be passed as an array`);
      const name = parameterNames[index];
      arg = name !== void 0 && Object.prototype.hasOwnProperty.call(args, name) ? args[name] : void 0;
      if (arg === void 0) throw new Error(`Parameter ${name} is required`);
    }
    index += 1;
    if (typeof arg === "function" || isArgument(arg)) {
      normalizedArgs.push(arg);
      continue;
    }
    const bcsType = argType === null ? null : getPureBcsSchema2(argType);
    if (bcsType) {
      const bytes = bcsType.serialize(arg);
      normalizedArgs.push((tx) => tx.pure(bytes));
      continue;
    }
    if (typeof arg === "string") {
      normalizedArgs.push((tx) => tx.object(arg));
      continue;
    }
    throw new Error(`Invalid argument ${stringify(arg)} for type ${argType}`);
  }
  return normalizedArgs;
}
var HAS_PHANTOM_REGEX = /phantom [A-Za-z_$][A-Za-z0-9_$]*/;
function splitTopLevelTypeArgs(inner) {
  const parts = [];
  let depth = 0;
  let current = "";
  for (const char of inner) {
    if (char === "," && depth === 0) {
      parts.push(current.trim());
      current = "";
      continue;
    }
    if (char === "<") depth++;
    if (char === ">") depth--;
    current += char;
  }
  if (current) parts.push(current.trim());
  return parts;
}
function buildTypeTag(name, options) {
  const lt = name.indexOf("<");
  const base = lt === -1 ? name : name.slice(0, lt);
  if (base.split("::").length !== 3) throw new Error(`${name} is not a top-level Move type`);
  let result = name;
  if (options?.typeArguments) {
    const baked = lt === -1 ? [] : splitTopLevelTypeArgs(name.slice(lt + 1, -1));
    const supplied = options.typeArguments.map((arg) => {
      if (typeof arg === "string") return arg;
      if (arg && typeof arg.serialize === "function" && typeof arg.name === "string") return arg.name;
      throw new Error(`Invalid type argument ${stringify(arg)}`);
    });
    if (supplied.length !== baked.length) throw new Error(`Expected ${baked.length} type arguments for ${base}, got ${supplied.length}`);
    result = supplied.length === 0 ? base : `${base}<${supplied.join(", ")}>`;
  }
  if (HAS_PHANTOM_REGEX.test(result)) throw new Error(options?.typeArguments ? `A type argument contains an unfilled phantom parameter in ${result}` : `Missing type arguments for ${result}`);
  if (options?.package) {
    const [, ...rest] = result.split("::");
    result = [options.package, ...rest].join("::");
  }
  if (!HAS_PHANTOM_REGEX.test(result) && !/[@/]/.test(result)) TypeTagSerializer.parseFromStr(result);
  return result;
}
async function resolveBuiltTypeTag(name, options) {
  const { client, ...rest } = options;
  const { type } = await client.core.mvr.resolveType({ type: buildTypeTag(name, rest) });
  return normalizeStructTag(type);
}
var MoveStruct = class extends BcsStruct {
  /**
  * Build the type tag for this struct.
  *
  * `typeArguments` is the full positional list, in Move declaration order, and
  * is required when the struct has unfilled phantom parameters. The result may
  * contain MVR names: those are valid in transaction `typeArguments`, but for
  * queries or comparisons against on-chain data use `resolveTypeTag` instead.
  */
  typeTag(...args) {
    return buildTypeTag(this.name, args[0]);
  }
  /**
  * Build the type tag for this struct, then resolve any MVR names through the
  * client (using its configured overrides and the MVR API) and return the
  * normalized, address-only form suitable for queries and comparisons against
  * on-chain data.
  */
  async resolveTypeTag(options) {
    return resolveBuiltTypeTag(this.name, options);
  }
  async get({ objectId, ...options }) {
    const [res] = await this.getMany({
      ...options,
      objectIds: [objectId]
    });
    if (!res) throw new Error(`No object found for id ${objectId}`);
    return res;
  }
  async getMany({ client, ...options }) {
    return (await client.core.getObjects({
      ...options,
      include: {
        ...options.include,
        content: true
      }
    })).objects.map((obj) => {
      if (obj instanceof Error) throw obj;
      return {
        ...obj,
        json: this.parse(obj.content)
      };
    });
  }
};
var MoveEnum = class extends BcsEnum {
  /** Build the type tag for this enum. See `MoveStruct.typeTag` for semantics. */
  typeTag(...args) {
    return buildTypeTag(this.name, args[0]);
  }
  /** Build and resolve the type tag for this enum. See `MoveStruct.resolveTypeTag`. */
  async resolveTypeTag(options) {
    return resolveBuiltTypeTag(this.name, options);
  }
};
var MoveTuple = class extends BcsTuple {
  /** Build the type tag for this struct. See `MoveStruct.typeTag` for semantics. */
  typeTag(...args) {
    return buildTypeTag(this.name, args[0]);
  }
  /** Build and resolve the type tag for this struct. See `MoveStruct.resolveTypeTag`. */
  async resolveTypeTag(options) {
    return resolveBuiltTypeTag(this.name, options);
  }
};
function stringify(val) {
  if (typeof val === "object") return JSON.stringify(val, (_key, value) => typeof value === "bigint" ? value.toString() : value);
  if (typeof val === "bigint") return val.toString();
  return val;
}

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/storage_resource.mjs
var $moduleName = "@local-pkg/walrus::storage_resource";
var Storage = new MoveStruct({
  name: `${$moduleName}::Storage`,
  fields: {
    id: suiBcs.Address,
    start_epoch: suiBcs.u32(),
    end_epoch: suiBcs.u32(),
    storage_size: suiBcs.u64()
  }
});

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/blob.mjs
var $moduleName2 = "@local-pkg/walrus::blob";
var Blob2 = new MoveStruct({
  name: `${$moduleName2}::Blob`,
  fields: {
    id: suiBcs.Address,
    registered_epoch: suiBcs.u32(),
    blob_id: suiBcs.u256(),
    size: suiBcs.u64(),
    encoding_type: suiBcs.u8(),
    certified_epoch: suiBcs.option(suiBcs.u32()),
    storage: Storage,
    deletable: suiBcs.bool()
  }
});
var BlobIdDerivation = new MoveStruct({
  name: `${$moduleName2}::BlobIdDerivation`,
  fields: {
    encoding_type: suiBcs.u8(),
    size: suiBcs.u64(),
    root_hash: suiBcs.u256()
  }
});
function addMetadata(options) {
  const packageAddress = options.package ?? "@local-pkg/walrus";
  const argumentsTypes = [null, null];
  const parameterNames = ["self", "metadata"];
  return (tx) => tx.moveCall({
    package: packageAddress,
    module: "blob",
    function: "add_metadata",
    arguments: normalizeMoveArguments(options.arguments, argumentsTypes, parameterNames)
  });
}
function insertOrUpdateMetadataPair(options) {
  const packageAddress = options.package ?? "@local-pkg/walrus";
  const argumentsTypes = [
    null,
    "0x1::string::String",
    "0x1::string::String"
  ];
  const parameterNames = [
    "self",
    "key",
    "value"
  ];
  return (tx) => tx.moveCall({
    package: packageAddress,
    module: "blob",
    function: "insert_or_update_metadata_pair",
    arguments: normalizeMoveArguments(options.arguments, argumentsTypes, parameterNames)
  });
}
function removeMetadataPair(options) {
  const packageAddress = options.package ?? "@local-pkg/walrus";
  const argumentsTypes = [null, "0x1::string::String"];
  const parameterNames = ["self", "key"];
  return (tx) => tx.moveCall({
    package: packageAddress,
    module: "blob",
    function: "remove_metadata_pair",
    arguments: normalizeMoveArguments(options.arguments, argumentsTypes, parameterNames)
  });
}

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/deps/sui/vec_map.mjs
var $moduleName3 = "0x2::vec_map";
function Entry(...typeParameters) {
  return new MoveStruct({
    name: `${$moduleName3}::Entry<${typeParameters[0].name}, ${typeParameters[1].name}>`,
    fields: {
      key: typeParameters[0],
      value: typeParameters[1]
    }
  });
}
function VecMap(...typeParameters) {
  return new MoveStruct({
    name: `${$moduleName3}::VecMap<${typeParameters[0].name}, ${typeParameters[1].name}>`,
    fields: { contents: suiBcs.vector(Entry(typeParameters[0], typeParameters[1])) }
  });
}

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/metadata.mjs
var $moduleName4 = "@local-pkg/walrus::metadata";
var Metadata = new MoveStruct({
  name: `${$moduleName4}::Metadata`,
  fields: { metadata: VecMap(suiBcs.string(), suiBcs.string()) }
});
function _new(options = {}) {
  const packageAddress = options.package ?? "@local-pkg/walrus";
  return (tx) => tx.moveCall({
    package: packageAddress,
    module: "metadata",
    function: "new"
  });
}

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/deps/sui/object_table.mjs
var $moduleName5 = "0x2::object_table";
var ObjectTable = new MoveStruct({
  name: `${$moduleName5}::ObjectTable<phantom K, phantom V>`,
  fields: {
    id: suiBcs.Address,
    size: suiBcs.u64()
  }
});

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/extended_field.mjs
var $moduleName6 = "@local-pkg/walrus::extended_field";
var ExtendedField = new MoveStruct({
  name: `${$moduleName6}::ExtendedField<phantom T>`,
  fields: { id: suiBcs.Address }
});
var Key = new MoveTuple({
  name: `${$moduleName6}::Key`,
  fields: [suiBcs.bool()]
});

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/committee.mjs
var $moduleName7 = "@local-pkg/walrus::committee";
var Committee = new MoveTuple({
  name: `${$moduleName7}::Committee`,
  fields: [VecMap(suiBcs.Address, suiBcs.vector(suiBcs.u16()))]
});

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/epoch_parameters.mjs
var $moduleName8 = "@local-pkg/walrus::epoch_parameters";
var EpochParams = new MoveStruct({
  name: `${$moduleName8}::EpochParams`,
  fields: {
    total_capacity_size: suiBcs.u64(),
    storage_price_per_unit_size: suiBcs.u64(),
    write_price_per_unit_size: suiBcs.u64()
  }
});

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/staking_inner.mjs
var $moduleName9 = "@local-pkg/walrus::staking_inner";
var EpochState = new MoveEnum({
  name: `${$moduleName9}::EpochState`,
  fields: {
    EpochChangeSync: suiBcs.u16(),
    EpochChangeDone: suiBcs.u64(),
    NextParamsSelected: suiBcs.u64()
  }
});
var StakingInnerV1 = new MoveStruct({
  name: `${$moduleName9}::StakingInnerV1`,
  fields: {
    n_shards: suiBcs.u16(),
    epoch_duration: suiBcs.u64(),
    first_epoch_start: suiBcs.u64(),
    pools: ObjectTable,
    epoch: suiBcs.u32(),
    active_set: ExtendedField,
    next_committee: suiBcs.option(Committee),
    committee: Committee,
    previous_committee: Committee,
    next_epoch_params: suiBcs.option(EpochParams),
    epoch_state: EpochState,
    next_epoch_public_keys: ExtendedField
  }
});

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/deps/sui/group_ops.mjs
var $moduleName10 = "0x2::group_ops";
var Element = new MoveStruct({
  name: `${$moduleName10}::Element<phantom T>`,
  fields: { bytes: suiBcs.vector(suiBcs.u8()) }
});

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/event_blob.mjs
var $moduleName11 = "@local-pkg/walrus::event_blob";
var EventBlobAttestation = new MoveStruct({
  name: `${$moduleName11}::EventBlobAttestation`,
  fields: {
    checkpoint_sequence_num: suiBcs.u64(),
    epoch: suiBcs.u32()
  }
});
var EventBlob = new MoveStruct({
  name: `${$moduleName11}::EventBlob`,
  fields: {
    blob_id: suiBcs.u256(),
    ending_checkpoint_sequence_number: suiBcs.u64()
  }
});
var EventBlobCertificationState = new MoveStruct({
  name: `${$moduleName11}::EventBlobCertificationState`,
  fields: {
    latest_certified_blob: suiBcs.option(EventBlob),
    aggregate_weight_per_blob: VecMap(EventBlob, suiBcs.u16())
  }
});

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/storage_node.mjs
var $moduleName12 = "@local-pkg/walrus::storage_node";
var StorageNodeInfo = new MoveStruct({
  name: `${$moduleName12}::StorageNodeInfo`,
  fields: {
    name: suiBcs.string(),
    node_id: suiBcs.Address,
    network_address: suiBcs.string(),
    public_key: Element,
    next_epoch_public_key: suiBcs.option(Element),
    network_public_key: suiBcs.vector(suiBcs.u8()),
    metadata: ExtendedField
  }
});
var StorageNodeCap = new MoveStruct({
  name: `${$moduleName12}::StorageNodeCap`,
  fields: {
    id: suiBcs.Address,
    node_id: suiBcs.Address,
    last_epoch_sync_done: suiBcs.u32(),
    last_event_blob_attestation: suiBcs.option(EventBlobAttestation),
    deny_list_root: suiBcs.u256(),
    deny_list_sequence: suiBcs.u64(),
    deny_list_size: suiBcs.u64()
  }
});

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/pending_values.mjs
var $moduleName13 = "@local-pkg/walrus::pending_values";
var PendingValues = new MoveTuple({
  name: `${$moduleName13}::PendingValues`,
  fields: [VecMap(suiBcs.u32(), suiBcs.u64())]
});

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/deps/sui/table.mjs
var $moduleName14 = "0x2::table";
var Table = new MoveStruct({
  name: `${$moduleName14}::Table<phantom K, phantom V>`,
  fields: {
    id: suiBcs.Address,
    size: suiBcs.u64()
  }
});

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/deps/sui/balance.mjs
var $moduleName15 = "0x2::balance";
var Balance2 = new MoveStruct({
  name: `${$moduleName15}::Balance<phantom T>`,
  fields: { value: suiBcs.u64() }
});

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/auth.mjs
var $moduleName16 = "@local-pkg/walrus::auth";
var Authenticated = new MoveEnum({
  name: `${$moduleName16}::Authenticated`,
  fields: {
    Sender: suiBcs.Address,
    Object: suiBcs.Address
  }
});
var Authorized = new MoveEnum({
  name: `${$moduleName16}::Authorized`,
  fields: {
    Address: suiBcs.Address,
    ObjectID: suiBcs.Address
  }
});

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/deps/sui/bag.mjs
var $moduleName17 = "0x2::bag";
var Bag = new MoveStruct({
  name: `${$moduleName17}::Bag`,
  fields: {
    id: suiBcs.Address,
    size: suiBcs.u64()
  }
});

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/staking_pool.mjs
var $moduleName18 = "@local-pkg/walrus::staking_pool";
var NewEpochCommissionBlockedForCollection = new MoveStruct({
  name: `${$moduleName18}::NewEpochCommissionBlockedForCollection`,
  fields: { dummy_field: suiBcs.bool() }
});
var VotingParams = new MoveStruct({
  name: `${$moduleName18}::VotingParams`,
  fields: {
    storage_price: suiBcs.u64(),
    write_price: suiBcs.u64(),
    node_capacity: suiBcs.u64()
  }
});
var PoolState = new MoveEnum({
  name: `${$moduleName18}::PoolState`,
  fields: {
    Active: null,
    Withdrawing: suiBcs.u32(),
    Withdrawn: null
  }
});
var StakingPool2 = new MoveStruct({
  name: `${$moduleName18}::StakingPool`,
  fields: {
    id: suiBcs.Address,
    state: PoolState,
    voting_params: VotingParams,
    node_info: StorageNodeInfo,
    activation_epoch: suiBcs.u32(),
    latest_epoch: suiBcs.u32(),
    wal_balance: suiBcs.u64(),
    num_shares: suiBcs.u64(),
    pending_shares_withdraw: PendingValues,
    pre_active_withdrawals: PendingValues,
    pending_commission_rate: PendingValues,
    commission_rate: suiBcs.u16(),
    exchange_rates: Table,
    pending_stake: PendingValues,
    rewards_pool: Balance2,
    commission: Balance2,
    commission_receiver: Authorized,
    governance_authorized: Authorized,
    extra_fields: Bag
  }
});

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/staking.mjs
var $moduleName19 = "@local-pkg/walrus::staking";
var Staking = new MoveStruct({
  name: `${$moduleName19}::Staking`,
  fields: {
    id: suiBcs.Address,
    version: suiBcs.u64(),
    package_id: suiBcs.Address,
    new_package_id: suiBcs.option(suiBcs.Address)
  }
});

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/bls_aggregate.mjs
var $moduleName20 = "@local-pkg/walrus::bls_aggregate";
var BlsCommitteeMember = new MoveStruct({
  name: `${$moduleName20}::BlsCommitteeMember`,
  fields: {
    public_key: Element,
    weight: suiBcs.u16(),
    node_id: suiBcs.Address
  }
});
var BlsCommittee = new MoveStruct({
  name: `${$moduleName20}::BlsCommittee`,
  fields: {
    members: suiBcs.vector(BlsCommitteeMember),
    n_shards: suiBcs.u16(),
    epoch: suiBcs.u32(),
    total_aggregated_key: Element
  }
});
var RequiredWeight = new MoveEnum({
  name: `${$moduleName20}::RequiredWeight`,
  fields: {
    Quorum: null,
    OneCorrectNode: null
  }
});

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/storage_accounting.mjs
var $moduleName21 = "@local-pkg/walrus::storage_accounting";
var FutureAccounting = new MoveStruct({
  name: `${$moduleName21}::FutureAccounting`,
  fields: {
    epoch: suiBcs.u32(),
    used_capacity: suiBcs.u64(),
    rewards_to_distribute: Balance2
  }
});
var FutureAccountingRingBuffer = new MoveStruct({
  name: `${$moduleName21}::FutureAccountingRingBuffer`,
  fields: {
    current_index: suiBcs.u32(),
    length: suiBcs.u32(),
    ring_buffer: suiBcs.vector(FutureAccounting)
  }
});

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/system_state_inner.mjs
var $moduleName22 = "@local-pkg/walrus::system_state_inner";
var SystemStateInnerV1 = new MoveStruct({
  name: `${$moduleName22}::SystemStateInnerV1`,
  fields: {
    committee: BlsCommittee,
    total_capacity_size: suiBcs.u64(),
    used_capacity_size: suiBcs.u64(),
    storage_price_per_unit_size: suiBcs.u64(),
    write_price_per_unit_size: suiBcs.u64(),
    future_accounting: FutureAccountingRingBuffer,
    event_blob_certification_state: EventBlobCertificationState,
    deny_list_sizes: ExtendedField
  }
});

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/contracts/walrus/system.mjs
var $moduleName23 = "@local-pkg/walrus::system";
var System = new MoveStruct({
  name: `${$moduleName23}::System`,
  fields: {
    id: suiBcs.Address,
    version: suiBcs.u64(),
    package_id: suiBcs.Address,
    new_package_id: suiBcs.option(suiBcs.Address)
  }
});
function reserveSpace(options) {
  const packageAddress = options.package ?? "@local-pkg/walrus";
  const argumentsTypes = [
    null,
    "u64",
    "u32",
    null
  ];
  const parameterNames = [
    "self",
    "storageAmount",
    "epochsAhead",
    "payment"
  ];
  return (tx) => tx.moveCall({
    package: packageAddress,
    module: "system",
    function: "reserve_space",
    arguments: normalizeMoveArguments(options.arguments, argumentsTypes, parameterNames)
  });
}
function registerBlob(options) {
  const packageAddress = options.package ?? "@local-pkg/walrus";
  const argumentsTypes = [
    null,
    null,
    "u256",
    "u256",
    "u64",
    "u8",
    "bool",
    null
  ];
  const parameterNames = [
    "self",
    "storage",
    "blobId",
    "rootHash",
    "size",
    "encodingType",
    "deletable",
    "writePayment"
  ];
  return (tx) => tx.moveCall({
    package: packageAddress,
    module: "system",
    function: "register_blob",
    arguments: normalizeMoveArguments(options.arguments, argumentsTypes, parameterNames)
  });
}
function certifyBlob(options) {
  const packageAddress = options.package ?? "@local-pkg/walrus";
  const argumentsTypes = [
    null,
    null,
    "vector<u8>",
    "vector<u8>",
    "vector<u8>"
  ];
  const parameterNames = [
    "self",
    "blob",
    "signature",
    "signersBitmap",
    "message"
  ];
  return (tx) => tx.moveCall({
    package: packageAddress,
    module: "system",
    function: "certify_blob",
    arguments: normalizeMoveArguments(options.arguments, argumentsTypes, parameterNames)
  });
}
function deleteBlob(options) {
  const packageAddress = options.package ?? "@local-pkg/walrus";
  const argumentsTypes = [null, null];
  const parameterNames = ["self", "blob"];
  return (tx) => tx.moveCall({
    package: packageAddress,
    module: "system",
    function: "delete_blob",
    arguments: normalizeMoveArguments(options.arguments, argumentsTypes, parameterNames)
  });
}
function extendBlob(options) {
  const packageAddress = options.package ?? "@local-pkg/walrus";
  const argumentsTypes = [
    null,
    null,
    "u32",
    null
  ];
  const parameterNames = [
    "self",
    "blob",
    "extendedEpochs",
    "payment"
  ];
  return (tx) => tx.moveCall({
    package: packageAddress,
    module: "system",
    function: "extend_blob",
    arguments: normalizeMoveArguments(options.arguments, argumentsTypes, parameterNames)
  });
}

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/storage-node/utils.mjs
function mergeHeaders(...headers) {
  const mergedHeaders = new Headers();
  for (const header of headers) {
    if (!header || typeof header !== "object") continue;
    for (const [key, value] of Object.entries(header)) if (value === null) mergedHeaders.delete(key);
    else if (Array.isArray(value)) for (const v of value) mergedHeaders.append(key, v);
    else if (value !== void 0) mergedHeaders.set(key, value);
  }
  return mergedHeaders;
}

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/storage-node/client.mjs
var StorageNodeClient = class {
  #fetch;
  #timeout;
  #onError;
  constructor({ fetch: overriddenFetch, timeout, onError } = {}) {
    this.#fetch = overriddenFetch ?? globalThis.fetch;
    this.#timeout = timeout ?? 3e4;
    this.#onError = onError;
  }
  /**
  * Gets the metadata associated with a Walrus blob.
  */
  async getBlobMetadata({ blobId }, options) {
    const bcsBytes = await (await this.#request(`/v1/blobs/${blobId}/metadata`, {
      ...options,
      headers: mergeHeaders({ Accept: "application/octet-stream" }, options.headers)
    })).arrayBuffer();
    return BlobMetadataWithId.parse(new Uint8Array(bcsBytes));
  }
  /**
  * Gets the status associated with a Walrus blob.
  */
  async getBlobStatus({ blobId }, options) {
    const blobStatus = (await (await this.#request(`/v1/blobs/${blobId}/status`, options)).json()).success.data;
    if (blobStatus === "nonexistent") return { type: "nonexistent" };
    if ("invalid" in blobStatus) return {
      type: "invalid",
      ...blobStatus.invalid
    };
    if ("permanent" in blobStatus) return {
      type: "permanent",
      ...blobStatus.permanent
    };
    if ("deletable" in blobStatus) return {
      type: "deletable",
      ...blobStatus.deletable
    };
    throw new StorageNodeError(`Unknown blob status received: ${blobStatus}`);
  }
  /**
  * Stores the metadata associated with a registered Walrus blob at this storage
  * node. This is a pre-requisite for storing the encoded slivers of the blob. The
  * ID of the blob must first be registered on Sui, after which storing the metadata
  * becomes possible.
  *
  * This endpoint may return an error if the node has not yet received the
  * registration event from the chain.
  */
  async storeBlobMetadata({ blobId, metadata }, options) {
    const body = typeof metadata === "object" && "V1" in metadata ? BlobMetadata.serialize(metadata).toBytes() : metadata;
    return await (await this.#request(`/v1/blobs/${blobId}/metadata`, {
      ...options,
      method: "PUT",
      body,
      headers: mergeHeaders({ "Content-Type": "application/octet-stream" }, options.headers)
    })).json();
  }
  /**
  * Gets the primary or secondary sliver identified by the specified blob ID and
  * index. The index should represent a sliver that is assigned to be stored at one
  * of the shards managed by this storage node during this epoch.
  */
  async getSliver({ blobId, sliverPairIndex, sliverType }, options) {
    const bcsBytes = await (await this.#request(`/v1/blobs/${blobId}/slivers/${sliverPairIndex}/${sliverType}`, {
      ...options,
      headers: mergeHeaders({ Accept: "application/octet-stream" }, options.headers)
    })).arrayBuffer();
    return new Uint8Array(bcsBytes);
  }
  /**
  * Stores a primary or secondary blob sliver at the storage node.
  */
  async storeSliver({ blobId, sliverPairIndex, sliverType, sliver }, options) {
    const body = typeof sliver === "object" && "symbols" in sliver ? SliverData.serialize(sliver).toBytes() : sliver;
    return await (await this.#request(`/v1/blobs/${blobId}/slivers/${sliverPairIndex}/${sliverType}`, {
      ...options,
      method: "PUT",
      body,
      headers: mergeHeaders({ "Content-Type": "application/octet-stream" }, options.headers)
    })).json();
  }
  /**
  * Gets a signed storage confirmation from this storage node, indicating that all shards
  * assigned to this storage node for the current epoch have stored their respective slivers.
  */
  async getDeletableBlobConfirmation({ blobId, objectId }, options) {
    return await (await this.#request(`/v1/blobs/${blobId}/confirmation/deletable/${objectId}`, options)).json();
  }
  /**
  * Gets a signed storage confirmation from this storage node, indicating that all shards
  * assigned to this storage node for the current epoch have stored their respective slivers.
  */
  async getPermanentBlobConfirmation({ blobId }, options) {
    return await (await this.#request(`/v1/blobs/${blobId}/confirmation/permanent`, options)).json();
  }
  /**
  * Gets the storage status of a sliver at this storage node.
  * Returns whether the sliver is stored, buffered (pending registration), or nonexistent.
  */
  async getSliverStatus({ blobId, sliverPairIndex, sliverType }, options) {
    return (await (await this.#request(`/v1/blobs/${blobId}/slivers/${sliverPairIndex}/${sliverType}/status`, options)).json()).success.data;
  }
  /**
  * Gets the storage status of blob metadata at this storage node.
  * Returns whether the metadata is stored, buffered (pending registration), or nonexistent.
  */
  async getMetadataStatus({ blobId }, options) {
    return (await (await this.#request(`/v1/blobs/${blobId}/metadata/status`, options)).json()).success.data;
  }
  async #request(path, options) {
    const { nodeUrl, signal, timeout, ...init2 } = options;
    if (signal?.aborted) throw new UserAbortError();
    const timeoutSignal = AbortSignal.timeout(timeout ?? this.#timeout);
    let response;
    try {
      const fetch2 = this.#fetch;
      response = await fetch2(`${nodeUrl}${path}`, {
        ...init2,
        signal: signal ? AbortSignal.any([timeoutSignal, signal]) : timeoutSignal
      });
    } catch (error) {
      if (signal?.aborted) throw new UserAbortError();
      if (error instanceof Error && error.name === "AbortError") {
        const error$1 = new ConnectionTimeoutError();
        this.#onError?.(error$1);
        throw error$1;
      }
      this.#onError?.(error);
      throw error;
    }
    if (!response.ok) {
      const errorText = await response.text().catch((reason) => reason);
      const errorJSON = safeParseJSON(errorText);
      const errorMessage = errorJSON ? void 0 : errorText;
      const error = StorageNodeAPIError.generate(response.status, errorJSON, errorMessage);
      this.#onError?.(error);
      throw error;
    }
    return response;
  }
};
function safeParseJSON(value) {
  try {
    return JSON.parse(value);
  } catch {
    return;
  }
}

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/utils/object-loader.mjs
var import_dataloader2 = __toESM(require_dataloader(), 1);
var SuiObjectDataLoader = class extends import_dataloader2.default {
  #dynamicFieldCache = /* @__PURE__ */ new Map();
  constructor(suiClient) {
    super(async (ids) => {
      const { objects } = await suiClient.core.getObjects({
        objectIds: ids,
        include: { content: true }
      });
      return objects;
    });
  }
  async load(id, schema) {
    const data = await super.load(id);
    if (schema) return schema.parse(data.content);
    return data;
  }
  async loadMany(ids, schema) {
    const data = await super.loadMany(ids);
    if (!schema) return data;
    return data.map((d) => {
      if (d instanceof Error) return d;
      return schema.parse(d.content);
    });
  }
  async loadManyOrThrow(ids, schema) {
    const data = await this.loadMany(ids, schema);
    for (const d of data) if (d instanceof Error) throw d;
    return data;
  }
  clearAll() {
    this.#dynamicFieldCache.clear();
    return super.clearAll();
  }
  clear(key) {
    this.#dynamicFieldCache.delete(key);
    return super.clear(key);
  }
  async loadFieldObject(parent, name, type) {
    const schema = pureBcsSchemaFromTypeName(name.type);
    const id = deriveDynamicFieldID(parent, "u64", schema.serialize(name.value).toBytes());
    return (await this.load(id, Field(schema, type))).value;
  }
};

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/utils/randomness.mjs
function weightedShuffle(arr) {
  return arr.map(({ value, weight }) => ({
    value,
    weight: Math.pow(Math.random(), 1 / weight)
  })).sort((a, b) => b.weight - a.weight).map((item) => item.value);
}
function shuffle(arr) {
  const result = [...arr];
  for (let i = result.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

// dapp/node_modules/.pnpm/@mysten+walrus-wasm@0.3.1/node_modules/@mysten/walrus-wasm/index.mjs
var walrus_wasm_exports = {};
__export(walrus_wasm_exports, {
  default: () => init
});
__reExport(walrus_wasm_exports, __toESM(require_walrus_wasm(), 1));
function init() {
}

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/wasm.mjs
async function getWasmBindings(url) {
  await init({ module_or_path: url });
  function encodeBlob(nShards, bytes, encodingType = "RS2") {
    const encoder = new walrus_wasm_exports.BlobEncoder(nShards);
    if (encodingType !== "RS2") throw new Error(`Unsupported encoding type: ${encodingType}`);
    const bufferSizes = computeBcsBufferSizes(bytes.length, nShards);
    const primaryBuffers = Array.from({ length: nShards }).map(() => new Uint8Array(bufferSizes.primary));
    const secondaryBuffers = Array.from({ length: nShards }).map(() => new Uint8Array(bufferSizes.secondary));
    const [metadata, rootHash] = encoder.encode(bytes, primaryBuffers, secondaryBuffers);
    return {
      primarySlivers: primaryBuffers,
      secondarySlivers: secondaryBuffers,
      blobId: blobIdFromBytes(new Uint8Array(metadata.blob_id)),
      metadata: metadata.metadata,
      rootHash: new Uint8Array(rootHash.Digest)
    };
  }
  function combineSignatures(confirmations, signerIndices) {
    const signature = (0, walrus_wasm_exports.bls12381_min_pk_aggregate)(confirmations.map((confirmation) => fromBase64(confirmation.signature)));
    return {
      signers: signerIndices,
      serializedMessage: fromBase64(confirmations[0].serializedMessage),
      signature
    };
  }
  function decodePrimarySlivers(blobId, nShards, size, slivers, encodingType = "RS2") {
    const encoder = new walrus_wasm_exports.BlobEncoder(nShards);
    if (encodingType !== "RS2") throw new Error(`Unsupported encoding type: ${encodingType}`);
    const blobSize = BigInt(size);
    const outputBuffer = new Uint8Array(Number(blobSize));
    encoder.decode(BlobId.serialize(blobId).toBytes(), blobSize, slivers, outputBuffer);
    return outputBuffer;
  }
  function getVerifySignature() {
    return (confirmation, publicKey) => (0, walrus_wasm_exports.bls12381_min_pk_verify)(fromBase64(confirmation.signature), publicKey, fromBase64(confirmation.serializedMessage));
  }
  function computeMetadata(nShards, bytes, encodingType = "RS2") {
    const [blobId, rootHash, unencodedLength, encType] = new walrus_wasm_exports.BlobEncoder(nShards).compute_metadata(bytes);
    if (encodingType !== "RS2") throw new Error(`Unsupported encoding type: ${encodingType}`);
    return {
      blobId: blobIdFromBytes(new Uint8Array(blobId)),
      rootHash: new Uint8Array(rootHash.Digest),
      unencodedLength: BigInt(unencodedLength),
      encodingType: encType
    };
  }
  return {
    encodeBlob,
    combineSignatures,
    decodePrimarySlivers,
    getVerifySignature,
    computeMetadata
  };
}
function uleb128Size(value) {
  let size = 1;
  value >>= 7;
  while (value !== 0) {
    size++;
    value >>= 7;
  }
  return size;
}
function computeBcsBufferSize(dataLength) {
  return uleb128Size(dataLength) + dataLength + 2 + 2;
}
function computeBcsBufferSizes(blobSize, nShards) {
  const { primarySymbols, secondarySymbols } = getSourceSymbols(nShards);
  let symbolSize = Math.floor((Math.max(blobSize, 1) - 1) / (primarySymbols * secondarySymbols)) + 1;
  if (symbolSize % 2 === 1) symbolSize = symbolSize + 1;
  const primarySliverSize = secondarySymbols * symbolSize;
  const secondarySliverSize = primarySymbols * symbolSize;
  return {
    nShards,
    primary: computeBcsBufferSize(primarySliverSize),
    secondary: computeBcsBufferSize(secondarySliverSize)
  };
}

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/upload-relay/client.mjs
var UploadRelayClient = class {
  #fetch;
  #timeout;
  #onError;
  constructor({ host, fetch: overriddenFetch, timeout, onError }) {
    this.host = host;
    this.#fetch = overriddenFetch ?? globalThis.fetch;
    this.#timeout = timeout ?? 3e4;
    this.#onError = onError;
  }
  async tipConfig() {
    const data = await (await this.#request({
      method: "GET",
      path: "/v1/tip-config"
    })).json();
    if (typeof data === "string") return null;
    if ("const" in data.send_tip.kind) return {
      address: data.send_tip.address,
      kind: { const: data.send_tip.kind.const }
    };
    return {
      address: data.send_tip.address,
      kind: { linear: {
        base: data.send_tip.kind.linear.base,
        perEncodedKib: data.send_tip.kind.linear.encoded_size_mul_per_kib
      } }
    };
  }
  async writeBlob({ blobId, nonce, txDigest, blob, deletable, blobObjectId, requiresTip, encodingType, ...options }) {
    const query = new URLSearchParams({ blob_id: blobId });
    if (requiresTip) {
      query.set("nonce", urlSafeBase64(nonce));
      query.set("tx_id", txDigest);
    }
    if (deletable) query.set("deletable_blob_object", blobObjectId);
    if (encodingType) query.set("encoding_type", encodingType);
    const data = await (await this.#request({
      method: "POST",
      path: `/v1/blob-upload-relay?${query.toString()}`,
      body: blob,
      ...options
    })).json();
    return {
      blobId,
      certificate: {
        signers: data.confirmation_certificate.signers,
        serializedMessage: new Uint8Array(data.confirmation_certificate.serialized_message),
        signature: fromUrlSafeBase64(data.confirmation_certificate.signature)
      }
    };
  }
  async #request(options) {
    const { signal, timeout, ...init2 } = options;
    if (signal?.aborted) throw new UserAbortError();
    const timeoutSignal = AbortSignal.timeout(timeout ?? this.#timeout);
    let response;
    try {
      const fetch2 = this.#fetch;
      response = await fetch2(`${this.host}${options.path}`, {
        ...init2,
        signal: signal ? AbortSignal.any([timeoutSignal, signal]) : timeoutSignal
      });
    } catch (error) {
      if (signal?.aborted) throw new UserAbortError();
      if (error instanceof Error && error.name === "AbortError") {
        const error$1 = new ConnectionTimeoutError();
        this.#onError?.(error$1);
        throw error$1;
      }
      this.#onError?.(error);
      throw error;
    }
    if (!response.ok) {
      const errorText = await response.text().catch((reason) => reason);
      const errorJSON = safeParseJSON2(errorText);
      const errorMessage = errorJSON ? void 0 : errorText;
      const error = StorageNodeAPIError.generate(response.status, errorJSON, errorMessage);
      this.#onError?.(error);
      throw error;
    }
    return response;
  }
};
function safeParseJSON2(value) {
  try {
    return JSON.parse(value);
  } catch {
    return;
  }
}

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/files/readers/quilt-file.mjs
var QuiltFileReader = class {
  #quilt;
  #sliverIndex;
  #identifier;
  #tags;
  constructor({ quilt, sliverIndex, identifier, tags }) {
    this.#quilt = quilt;
    this.#sliverIndex = sliverIndex;
    this.#identifier = identifier ?? null;
    this.#tags = tags;
  }
  async getBytes() {
    const { blobContents, identifier, tags } = await this.#quilt.readBlob(this.#sliverIndex);
    this.#identifier = identifier;
    this.#tags = tags ?? {};
    return blobContents;
  }
  async getIdentifier() {
    if (this.#identifier !== null) return this.#identifier;
    this.#identifier = (await this.#quilt.getBlobHeader(this.#sliverIndex)).identifier;
    return this.#identifier;
  }
  async getTags() {
    if (this.#tags !== void 0) return this.#tags;
    this.#tags = (await this.#quilt.getBlobHeader(this.#sliverIndex)).tags ?? {};
    return this.#tags;
  }
};

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/files/readers/quilt.mjs
var QuiltReader = class {
  #blob;
  #cache = new ClientCache();
  constructor({ blob }) {
    this.#blob = blob;
  }
  async #readBytesFromSlivers(sliver, length, offset = 0, columnSize) {
    if (!length) return new Uint8Array(0);
    this.#blob.getSecondarySliver({ sliverIndex: sliver }).catch(() => {
    });
    columnSize = columnSize ?? await this.#blob.getColumnSize();
    const columnOffset = Math.floor(offset / columnSize);
    let remainingOffset = offset % columnSize;
    const bytes = new Uint8Array(length);
    let bytesRead = 0;
    const nSlivers = Math.ceil((remainingOffset + length) / columnSize);
    const slivers = new Array(nSlivers).fill(0).map((_, i) => this.#blob.getSecondarySliver({ sliverIndex: sliver + columnOffset + i }));
    slivers.forEach((p) => p.catch(() => {
    }));
    for (const sliverPromise of slivers) {
      const sliver$1 = await sliverPromise;
      let chunk3 = remainingOffset > 0 ? sliver$1.subarray(remainingOffset) : sliver$1;
      remainingOffset = 0;
      if (chunk3.length > length - bytesRead) chunk3 = chunk3.subarray(0, length - bytesRead);
      bytes.set(chunk3, bytesRead);
      bytesRead += chunk3.length;
      if (bytesRead >= length) break;
    }
    return bytes;
  }
  async #readBytesFromBlob(startColumn, length, offset = 0) {
    const result = new Uint8Array(length);
    if (!length) return result;
    const blob = await this.#blob.getBytes();
    const [rowSize, symbolSize] = await Promise.all([this.#blob.getRowSize(), this.#blob.getSymbolSize()]);
    const nRows = blob.length / rowSize;
    const symbolsToSkip = Math.floor(offset / symbolSize);
    let remainingOffset = offset % symbolSize;
    let currentCol = startColumn + Math.floor(symbolsToSkip / nRows);
    let currentRow = symbolsToSkip % nRows;
    let bytesRead = 0;
    while (bytesRead < length) {
      const baseIndex = currentRow * rowSize + currentCol * symbolSize;
      const startIndex = baseIndex + remainingOffset;
      const endIndex = Math.min(baseIndex + symbolSize, startIndex + length - bytesRead, blob.length);
      if (startIndex >= blob.length) throw new Error("Index out of bounds");
      const size = endIndex - startIndex;
      for (let i = 0; i < size; i++) result[bytesRead + i] = blob[startIndex + i];
      bytesRead += size;
      remainingOffset = 0;
      currentRow = (currentRow + 1) % nRows;
      if (currentRow === 0) currentCol += 1;
    }
    return result;
  }
  async #readBytes(sliver, length, offset = 0, columnSize) {
    if (this.#blob.hasStartedLoadingFullBlob) return this.#readBytesFromBlob(sliver, length, offset);
    try {
      return await this.#readBytesFromSlivers(sliver, length, offset, columnSize);
    } catch {
      return this.#readBytesFromBlob(sliver, length, offset);
    }
  }
  async getBlobHeader(sliverIndex) {
    return this.#cache.read(["getBlobHeader", sliverIndex.toString()], async () => {
      const blobHeader = QuiltPatchBlobHeader.parse(await this.#readBytes(sliverIndex, QUILT_PATCH_BLOB_HEADER_SIZE));
      let offset = QUILT_PATCH_BLOB_HEADER_SIZE;
      let blobSize = blobHeader.length;
      const identifierLength = new DataView((await this.#readBytes(sliverIndex, 2, offset)).buffer).getUint16(0, true);
      blobSize -= 2 + identifierLength;
      offset += 2;
      const identifier = bcs.string().parse(await this.#readBytes(sliverIndex, identifierLength, offset));
      offset += identifierLength;
      let tags = null;
      if (blobHeader.mask & HAS_TAGS_FLAG) {
        const tagsSize = new DataView((await this.#readBytes(sliverIndex, 2, offset)).buffer).getUint16(0, true);
        offset += 2;
        tags = QuiltPatchTags.parse(await this.#readBytes(sliverIndex, tagsSize, offset));
        blobSize -= tagsSize + 2;
        offset += tagsSize;
      }
      return {
        identifier,
        tags,
        blobSize,
        contentOffset: offset
      };
    });
  }
  async readBlob(sliverIndex) {
    const { identifier, tags, blobSize, contentOffset } = await this.getBlobHeader(sliverIndex);
    return {
      identifier,
      tags,
      blobContents: await this.#readBytes(sliverIndex, blobSize, contentOffset)
    };
  }
  readerForPatchId(id) {
    const { quiltId, patchId } = parseQuiltPatchId(id);
    if (quiltId !== this.#blob.blobId) throw new Error(`The requested patch ${patchId} is not part of the quilt ${this.#blob.blobId}`);
    return new QuiltFileReader({
      quilt: this,
      sliverIndex: patchId.startIndex
    });
  }
  async readIndex() {
    const header = new DataView((await this.#readBytes(0, 5)).buffer);
    const version = header.getUint8(0);
    if (version !== 1) throw new Error(`Unsupported quilt version ${version}`);
    const indexSize = header.getUint32(1, true);
    const indexBytes = await this.#readBytes(0, indexSize, 5);
    const columnSize = await this.#blob.getColumnSize();
    const indexSlivers = Math.ceil(indexSize / columnSize);
    const index = QuiltIndexV1.parse(indexBytes);
    return index.patches.map((patch, i) => {
      const startIndex = i === 0 ? indexSlivers : index.patches[i - 1].endIndex;
      const reader = new QuiltFileReader({
        quilt: this,
        sliverIndex: startIndex,
        identifier: patch.identifier,
        tags: patch.tags
      });
      return {
        identifier: patch.identifier,
        patchId: urlSafeBase64(QuiltPatchId.serialize({
          quiltId: this.#blob.blobId,
          patchId: {
            version: 1,
            startIndex,
            endIndex: patch.endIndex
          }
        }).toBytes()),
        tags: patch.tags,
        reader
      };
    });
  }
};

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/files/readers/blob.mjs
var BlobReader = class {
  #cache = new ClientCache();
  #client;
  #secondarySlivers = /* @__PURE__ */ new Map();
  #numShards;
  constructor({ client, blobId, numShards }) {
    this.hasStartedLoadingFullBlob = false;
    this.#client = client;
    this.blobId = blobId;
    this.#numShards = numShards;
  }
  async getIdentifier() {
    return null;
  }
  async getTags() {
    return {};
  }
  getQuiltReader() {
    return new QuiltReader({ blob: this });
  }
  async getBytes() {
    return this.#cache.read(["getBytes"], async () => {
      this.hasStartedLoadingFullBlob = true;
      try {
        return await this.#client.readBlob({ blobId: this.blobId });
      } catch (error) {
        this.hasStartedLoadingFullBlob = false;
        throw error;
      }
    });
  }
  getMetadata() {
    return this.#cache.read(["getMetadata"], () => this.#client.getBlobMetadata({ blobId: this.blobId }));
  }
  async getColumnSize() {
    return this.#cache.read(["getColumnSize"], async () => {
      const loadingSlivers = [...this.#secondarySlivers.values()];
      if (loadingSlivers.length > 0) {
        const sliver = await Promise.any(loadingSlivers).catch(() => null);
        if (sliver) return sliver.length;
      }
      if (this.hasStartedLoadingFullBlob) {
        const { columnSize: columnSize$1 } = getSizes((await this.getBytes()).length, this.#numShards);
        return columnSize$1;
      }
      const metadata = await this.getMetadata();
      const { columnSize } = getSizes(Number(metadata.metadata.V1.unencoded_length), this.#numShards);
      return columnSize;
    });
  }
  async getSymbolSize() {
    const columnSize = await this.getColumnSize();
    const { primarySymbols } = getSourceSymbols(this.#numShards);
    if (columnSize % primarySymbols !== 0) throw new Error("column size should be divisible by primary symbols");
    return columnSize / primarySymbols;
  }
  async getRowSize() {
    const symbolSize = await this.getSymbolSize();
    const { secondarySymbols } = getSourceSymbols(this.#numShards);
    return symbolSize * secondarySymbols;
  }
  async getSecondarySliver({ sliverIndex, signal }) {
    if (this.#secondarySlivers.has(sliverIndex)) return this.#secondarySlivers.get(sliverIndex);
    const sliverPromise = this.#client.getSecondarySliver({
      blobId: this.blobId,
      index: sliverIndex,
      signal
    }).then((sliver) => SliverData.parse(sliver).symbols.data);
    this.#secondarySlivers.set(sliverIndex, sliverPromise);
    try {
      const sliver = await sliverPromise;
      this.#secondarySlivers.set(sliverIndex, sliver);
      return sliver;
    } catch (error) {
      this.#secondarySlivers.delete(sliverIndex);
      throw error;
    }
  }
};

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/utils/retry.mjs
async function retry(fn, options) {
  let remaining = options.count ?? 3;
  while (remaining > 0) try {
    remaining -= 1;
    return await fn();
  } catch (error) {
    if (remaining <= 0 || options.condition && !options.condition(error)) throw error;
    if (options.delay) await new Promise((resolve) => setTimeout(resolve, (options.delay ?? 1e3) + (options.jitter ? Math.random() * options.jitter : 0)));
  }
  throw new Error("Retry count exceeded");
}

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/flows/write-blob.mjs
function createWriteBlobFlow(client, ctx, options) {
  const { resume } = options;
  let encodeState;
  let registerState;
  let uploadState;
  let certifyState;
  const resumeBlobObjectId = resume && "blobObjectId" in resume ? resume.blobObjectId : void 0;
  const resumeTxDigest = resume && "txDigest" in resume ? resume.txDigest : void 0;
  const resumeNonce = resume && "nonce" in resume && resume.nonce ? fromBase64(resume.nonce) : void 0;
  const resumeBlobId = resume ? resume.blobId : void 0;
  const encode = async () => {
    if (!encodeState) {
      const { blob } = options;
      const hasUploadRelay = ctx.hasUploadRelay();
      const metadata$1 = hasUploadRelay ? await client.computeBlobMetadata({
        bytes: blob,
        nonce: resumeNonce
      }) : await client.encodeBlob(blob);
      if (resumeBlobId && metadata$1.blobId !== resumeBlobId) throw new WalrusClientError(`Resume blobId mismatch: expected ${resumeBlobId}, got ${metadata$1.blobId}. The blob content may have changed.`);
      encodeState = {
        metadata: metadata$1,
        size: blob.length,
        data: hasUploadRelay ? blob : void 0
      };
    }
    const { metadata, size } = encodeState;
    return {
      step: "encoded",
      blobId: metadata.blobId,
      rootHash: toBase64(metadata.rootHash),
      unencodedSize: size,
      ..."nonce" in metadata ? { nonce: toBase64(metadata.nonce) } : {}
    };
  };
  const register = ({ epochs, deletable, owner, attributes }) => {
    if (!encodeState) throw new Error("encode must be executed before calling register");
    const { metadata, size } = encodeState;
    const transaction = new Transaction2();
    transaction.setSenderIfNotSet(owner);
    if (ctx.hasUploadRelay()) {
      const meta = metadata;
      transaction.add(client.sendUploadRelayTip({
        size,
        blobDigest: meta.blobDigest,
        nonce: meta.nonce
      }));
    }
    transaction.transferObjects([client.registerBlob({
      size,
      epochs,
      blobId: metadata.blobId,
      rootHash: metadata.rootHash,
      deletable,
      attributes
    })], owner);
    registerState = {
      ...encodeState,
      deletable
    };
    return transaction;
  };
  const upload = async (options$1) => {
    if (!encodeState) throw new Error("encode must be executed before calling upload");
    const { metadata, data } = encodeState;
    const deletable = options$1?.deletable ?? registerState?.deletable ?? false;
    let blobObject;
    if (resumeBlobObjectId) blobObject = await client.getBlobObject(resumeBlobObjectId);
    else if (options$1?.digest) blobObject = await ctx.getCreatedBlob(options$1.digest);
    else throw new Error("Either resume.blobObjectId or upload digest must be provided");
    let certificate;
    if (ctx.hasUploadRelay()) {
      const meta = metadata;
      certificate = (await client.writeBlobToUploadRelay({
        blobId: metadata.blobId,
        blob: data,
        nonce: meta.nonce,
        txDigest: options$1?.digest ?? resumeTxDigest,
        blobObjectId: blobObject.id,
        deletable,
        encodingType: meta.metadata.encodingType,
        signal: options$1?.signal
      })).certificate;
    } else {
      const meta = metadata;
      const confirmations = await client.writeEncodedBlobToNodes({
        blobId: metadata.blobId,
        objectId: blobObject.id,
        metadata: meta.metadata,
        sliversByNode: meta.sliversByNode,
        deletable,
        signal: options$1?.signal
      });
      certificate = await client.certificateFromConfirmations({
        confirmations,
        blobId: metadata.blobId,
        blobObjectId: blobObject.id,
        deletable
      });
    }
    uploadState = {
      blobObject,
      blobId: metadata.blobId,
      deletable,
      certificate
    };
    const txDigest = options$1?.digest ?? resumeTxDigest;
    return {
      step: "uploaded",
      blobId: metadata.blobId,
      blobObjectId: blobObject.id,
      ...txDigest ? { txDigest } : {},
      certificate: CertificateBcs.serialize(certificate).toBase64()
    };
  };
  const certify = () => {
    if (!uploadState) throw new Error("upload must be executed before calling certify");
    const { blobObject, blobId, deletable, certificate } = uploadState;
    const transaction = client.certifyBlobTransaction({
      certificate,
      blobId,
      blobObjectId: blobObject.id,
      deletable
    });
    certifyState = {
      blobObject,
      blobId,
      transaction
    };
    return transaction;
  };
  const executeRegister = async ({ signer, ...options$1 }) => {
    const transaction = register(options$1);
    const { digest: digest2 } = await ctx.executeTransaction(transaction, signer, "register blob");
    return {
      step: "registered",
      blobId: encodeState.metadata.blobId,
      blobObjectId: (await ctx.getCreatedBlob(digest2)).id,
      txDigest: digest2,
      ..."nonce" in encodeState.metadata ? { nonce: toBase64(encodeState.metadata.nonce) } : {}
    };
  };
  const executeCertify = async ({ signer }) => {
    const transaction = certify();
    await ctx.executeTransaction(transaction, signer, "certify blob");
    const blobObject = await ctx.loadBlobObject(uploadState.blobObject.id);
    return {
      step: "certified",
      blobId: uploadState.blobId,
      blobObjectId: blobObject.id,
      blobObject
    };
  };
  const getBlob = async () => {
    if (!certifyState && !uploadState) throw new Error("upload or certify must be executed before calling getBlob");
    const state = certifyState ?? uploadState;
    const blobObject = await ctx.loadBlobObject(state.blobObject.id);
    return {
      step: "certified",
      blobId: state.blobId,
      blobObjectId: blobObject.id,
      blobObject
    };
  };
  const restoreUploadState = async (resumeData, deletable) => {
    uploadState = {
      blobObject: await client.getBlobObject(resumeData.blobObjectId),
      blobId: resumeData.blobId,
      deletable,
      certificate: parseCertificateFromBase64(resumeData.certificate)
    };
  };
  async function* run(options$1) {
    const resumeStep = resume?.step;
    const stepOrder = [
      "encoded",
      "registered",
      "uploaded",
      "certified"
    ];
    const resumeIndex = resumeStep ? stepOrder.indexOf(resumeStep) : -1;
    if (resumeIndex >= stepOrder.indexOf("certified")) return;
    if (resumeIndex < stepOrder.indexOf("encoded")) yield await encode();
    else if (resumeIndex < stepOrder.indexOf("uploaded")) await encode();
    let registerDigest;
    if (!resumeBlobObjectId) {
      const regResult = await executeRegister({
        signer: options$1.signer,
        epochs: options$1.epochs,
        deletable: options$1.deletable,
        owner: options$1.owner ?? options$1.signer.toSuiAddress(),
        attributes: options$1.attributes
      });
      registerDigest = regResult.txDigest;
      yield regResult;
    } else registerState = {
      ...encodeState,
      deletable: options$1.deletable
    };
    if (resumeIndex < stepOrder.indexOf("uploaded")) yield await upload({
      digest: registerDigest ?? resumeTxDigest,
      signal: options$1.signal
    });
    else await restoreUploadState(resume, options$1.deletable);
    yield await executeCertify({ signer: options$1.signer });
  }
  return {
    encode,
    register,
    upload,
    certify,
    getBlob,
    executeRegister,
    executeCertify,
    run
  };
}

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/flows/write-files.mjs
function createWriteFilesFlow(client, { files, resume }) {
  let quiltBytes;
  let quiltIndex;
  const blobFlow = client.writeBlobFlow({
    get blob() {
      if (!quiltBytes) throw new Error("encode must be executed before accessing blob");
      return quiltBytes;
    },
    resume
  });
  const encodeQuilt2 = async () => {
    if (!quiltBytes) {
      const { quilt, index } = await client.encodeQuilt({ blobs: await Promise.all(files.map(async (file, i) => ({
        contents: await file.bytes(),
        identifier: await file.getIdentifier() ?? `file-${i}`,
        tags: await file.getTags() ?? {}
      }))) });
      if (resume?.step === "uploaded" || resume?.step === "certified") {
        const { blobId } = await client.computeBlobMetadata({ bytes: quilt });
        if (blobId !== resume.blobId) throw new WalrusClientError(`Resume blobId mismatch: expected ${resume.blobId}, got ${blobId}. The blob content may have changed.`);
      }
      quiltBytes = quilt;
      quiltIndex = index;
    }
  };
  const encode = async () => {
    await encodeQuilt2();
    return blobFlow.encode();
  };
  const register = (options) => {
    if (!quiltBytes) throw new Error("encode must be executed before calling register");
    return blobFlow.register({
      ...options,
      attributes: {
        _walrusBlobType: "quilt",
        ...options.attributes
      }
    });
  };
  const listFiles = async () => {
    if (!quiltIndex) throw new Error("encode must be executed before calling listFiles");
    const certResult = resume?.step === "certified" ? resume : await blobFlow.getBlob();
    return quiltIndex.patches.map((patch) => ({
      id: encodeQuiltPatchId({
        quiltId: certResult.blobId,
        patchId: {
          version: 1,
          startIndex: patch.startIndex,
          endIndex: patch.endIndex
        }
      }),
      blobId: certResult.blobId,
      blobObject: certResult.blobObject
    }));
  };
  async function* run(options) {
    await encodeQuilt2();
    yield* blobFlow.run({
      ...options,
      attributes: {
        _walrusBlobType: "quilt",
        ...options.attributes
      }
    });
  }
  return {
    encode,
    register,
    upload: blobFlow.upload,
    certify: blobFlow.certify,
    listFiles,
    executeRegister: async (options) => {
      const { signer, ...rest } = options;
      return blobFlow.executeRegister({
        signer,
        ...rest,
        attributes: {
          _walrusBlobType: "quilt",
          ...rest.attributes
        }
      });
    },
    executeCertify: blobFlow.executeCertify,
    run
  };
}

// dapp/node_modules/.pnpm/@mysten+utils@0.4.2/node_modules/@mysten/utils/dist/chunk.mjs
function chunk2(array2, size) {
  return Array.from({ length: Math.ceil(array2.length / size) }, (_, i) => {
    return array2.slice(i * size, (i + 1) * size);
  });
}

// dapp/node_modules/.pnpm/@mysten+walrus@1.2.35_@mysten+sui@2.36.0_typescript@5.9.3_/node_modules/@mysten/walrus/dist/client.mjs
function walrus({ packageConfig, name = "walrus", ...options } = {}) {
  return {
    name,
    register: (client) => {
      const walrusNetwork = client.network;
      if (walrusNetwork !== "mainnet" && walrusNetwork !== "testnet") throw new WalrusClientError("Walrus client only supports mainnet and testnet");
      return new WalrusClient(packageConfig ? {
        packageConfig,
        suiClient: client,
        ...options
      } : {
        network: walrusNetwork,
        suiClient: client,
        ...options
      });
    }
  };
}
var WalrusClient = class {
  #storageNodeClient;
  #storageNodeUrlScheme;
  #wasmUrl;
  #packageConfig;
  #suiClient;
  #objectLoader;
  #blobMetadataConcurrencyLimit = 10;
  #readCommittee;
  #cache;
  #uploadRelayConfig = null;
  #uploadRelayClient = null;
  constructor(config) {
    this.readBlob = this.#retryOnPossibleEpochChange(this.#internalReadBlob);
    this.getSecondarySliver = this.#retryOnPossibleEpochChange(this.internalGetSecondarySliver);
    if (config.network && !config.packageConfig) {
      const network = config.network;
      switch (network) {
        case "testnet":
          this.#packageConfig = TESTNET_WALRUS_PACKAGE_CONFIG;
          break;
        case "mainnet":
          this.#packageConfig = MAINNET_WALRUS_PACKAGE_CONFIG;
          break;
        default:
          throw new WalrusClientError(`Unsupported network: ${network}`);
      }
    } else this.#packageConfig = config.packageConfig;
    this.#wasmUrl = config.wasmUrl;
    this.#storageNodeUrlScheme = config.storageNodeUrlScheme ?? "https";
    this.#uploadRelayConfig = config.uploadRelay ?? null;
    if (this.#uploadRelayConfig) this.#uploadRelayClient = new UploadRelayClient(this.#uploadRelayConfig);
    this.#suiClient = config.suiClient;
    this.#storageNodeClient = new StorageNodeClient(config.storageNodeClientOptions);
    this.#objectLoader = new SuiObjectDataLoader(this.#suiClient);
    this.#cache = this.#suiClient.cache.scope("@mysten/walrus");
  }
  /** The Move type for a WAL coin */
  #walType() {
    return this.#cache.read(["walType"], async () => {
      const toStake = (await this.#suiClient.core.getMoveFunction({
        packageId: await this.#getPackageId(),
        moduleName: "staking",
        name: "stake_with_pool"
      })).function.parameters[1];
      const toStakeCoin = toStake.body.$kind === "datatype" ? toStake.body.datatype : null;
      const toStakeCoinType = toStakeCoin?.typeParameters[0]?.$kind === "datatype" ? toStakeCoin.typeParameters[0] : null;
      if (toStakeCoinType?.$kind !== "datatype") throw new WalrusClientError("WAL type not found");
      return normalizeStructTag(toStakeCoinType.datatype.typeName);
    });
  }
  #getPackageId() {
    return this.#cache.read(["getPackageId"], async () => {
      return parseStructTag((await this.#objectLoader.load(this.#packageConfig.systemObjectId)).type).address;
    });
  }
  /** The Move type for a Blob object */
  getBlobType() {
    return this.#cache.read(["getBlobType"], async () => {
      return `${await this.#getPackageId()}::blob::Blob`;
    });
  }
  #getWalrusPackageId() {
    return this.#cache.read(["getSystemPackageId"], async () => {
      const { package_id } = await this.systemObject();
      return package_id;
    });
  }
  #wasmBindings() {
    return this.#cache.read(["wasmBindings"], async () => {
      return getWasmBindings(this.#wasmUrl);
    });
  }
  /** The cached system object for the walrus package */
  systemObject() {
    return this.#objectLoader.load(this.#packageConfig.systemObjectId, System);
  }
  /** The cached staking pool object for the walrus package */
  stakingObject() {
    return this.#objectLoader.load(this.#packageConfig.stakingPoolId, Staking);
  }
  /** The system state for the current version of walrus contract  */
  async systemState() {
    return await this.#objectLoader.loadFieldObject(this.#packageConfig.systemObjectId, {
      type: "u64",
      value: (await this.systemObject()).version
    }, SystemStateInnerV1);
  }
  /** The staking state for the current version of walrus contract */
  async stakingState() {
    return this.#objectLoader.loadFieldObject(this.#packageConfig.stakingPoolId, {
      type: "u64",
      value: (await this.stakingObject()).version
    }, StakingInnerV1);
  }
  async #internalReadBlob({ blobId, signal }) {
    const systemState = await this.systemState();
    const numShards = systemState.committee.n_shards;
    const blobMetadata = await this.getBlobMetadata({
      blobId,
      signal
    });
    const slivers = await this.getSlivers({
      blobId,
      signal
    });
    const bindings = await this.#wasmBindings();
    const blobBytes = bindings.decodePrimarySlivers(blobId, numShards, blobMetadata.metadata.V1.unencoded_length, slivers);
    if (bindings.computeMetadata(systemState.committee.n_shards, blobBytes).blobId !== blobId) throw new InconsistentBlobError("The specified blob was encoded incorrectly.");
    return blobBytes;
  }
  async computeBlobMetadata({ bytes, numShards, nonce: providedNonce }) {
    let shardCount;
    if (typeof numShards === "number") shardCount = numShards;
    else shardCount = (await this.systemState()).committee.n_shards;
    const { blobId, rootHash, unencodedLength, encodingType } = (await this.#wasmBindings()).computeMetadata(shardCount, bytes);
    let sha256Hash;
    const nonce = providedNonce ?? crypto.getRandomValues(new Uint8Array(32));
    return {
      rootHash,
      blobId,
      metadata: {
        encodingType,
        unencodedLength
      },
      nonce,
      blobDigest: () => {
        if (!sha256Hash) sha256Hash = crypto.subtle.digest("SHA-256", bytes).then((hash) => new Uint8Array(hash));
        return sha256Hash;
      }
    };
  }
  async getBlobMetadata({ blobId, signal }) {
    const randomizedNodes = shuffle((await this.#getReadCommittee({
      blobId,
      signal
    })).nodes);
    const numShards = (await this.stakingState()).n_shards;
    let numNotFoundWeight = 0;
    let numBlockedWeight = 0;
    let totalErrorCount = 0;
    const controller = new AbortController();
    const metadataExecutors = randomizedNodes.map((node) => async () => {
      try {
        return await this.#storageNodeClient.getBlobMetadata({ blobId }, {
          nodeUrl: node.networkUrl,
          signal: signal ? AbortSignal.any([controller.signal, signal]) : controller.signal
        });
      } catch (error) {
        if (error instanceof NotFoundError) numNotFoundWeight += node.shardIndices.length;
        else if (error instanceof LegallyUnavailableError) numBlockedWeight += node.shardIndices.length;
        totalErrorCount += 1;
        throw error;
      }
    });
    try {
      return await metadataExecutors.shift()();
    } catch {
      const chunkedExecutors = chunk2(metadataExecutors, Math.floor(metadataExecutors.length / this.#blobMetadataConcurrencyLimit));
      return await new Promise((resolve, reject) => {
        chunkedExecutors.forEach(async (executors) => {
          for (const executor of executors) try {
            const result = await executor();
            controller.abort("Blob metadata successfully retrieved.");
            resolve(result);
          } catch (error) {
            if (error instanceof UserAbortError) {
              reject(error);
              return;
            } else if (isQuorum(numBlockedWeight + numNotFoundWeight, numShards)) {
              const abortError = numNotFoundWeight > numBlockedWeight ? new BlobNotCertifiedError(`The specified blob ${blobId} is not certified.`) : new BlobBlockedError(`The specified blob ${blobId} is blocked.`);
              controller.abort(abortError);
              reject(abortError);
              return;
            }
            if (totalErrorCount === metadataExecutors.length) reject(new NoBlobMetadataReceivedError("No valid blob metadata could be retrieved from any storage node."));
          }
        });
      });
    }
  }
  async internalGetSecondarySliver({ blobId, index, signal }) {
    const committee = await this.#getActiveCommittee();
    const numShards = (await this.stakingState()).n_shards;
    const sliverPairIndex = sliverPairIndexFromSecondarySliverIndex(index, numShards);
    const shardIndex = toShardIndex(sliverPairIndex, blobId, numShards);
    const node = await this.#getNodeByShardIndex(committee, shardIndex);
    if (!node) throw new Error(`No node found for shard index ${shardIndex}`);
    return await this.#storageNodeClient.getSliver({
      blobId,
      sliverPairIndex,
      sliverType: "secondary"
    }, {
      nodeUrl: node.networkUrl,
      signal
    });
  }
  async getSlivers({ blobId, signal }) {
    const randomizedNodes = weightedShuffle((await this.#getReadCommittee({
      blobId,
      signal
    })).nodes.map((node) => ({
      value: node,
      weight: node.shardIndices.length
    })));
    const numShards = (await this.stakingState()).n_shards;
    const { primarySymbols: minSymbols } = getSourceSymbols(numShards);
    const sliverPairIndices = randomizedNodes.flatMap((node) => node.shardIndices.map((shardIndex) => ({
      url: node.networkUrl,
      sliverPairIndex: toPairIndex(shardIndex, blobId, numShards)
    })));
    const controller = new AbortController();
    const chunkedSliverPairIndices = chunk2(sliverPairIndices, minSymbols);
    const slivers = [];
    const failedNodes = /* @__PURE__ */ new Set();
    let numNotFoundWeight = 0;
    let numBlockedWeight = 0;
    let totalErrorCount = 0;
    return new Promise((resolve, reject) => {
      chunkedSliverPairIndices[0].forEach(async (_, colIndex) => {
        for (let rowIndex = 0; rowIndex < chunkedSliverPairIndices.length; rowIndex += 1) {
          const value = chunkedSliverPairIndices.at(rowIndex)?.at(colIndex);
          if (!value) break;
          const { url, sliverPairIndex } = value;
          try {
            if (failedNodes.has(url)) throw new Error(`Skipping node at ${url} due to previous failure.`);
            const sliver = await this.#storageNodeClient.getSliver({
              blobId,
              sliverPairIndex,
              sliverType: "primary"
            }, {
              nodeUrl: url,
              signal: signal ? AbortSignal.any([controller.signal, signal]) : controller.signal
            });
            if (slivers.length === minSymbols) {
              controller.abort("Enough slivers successfully retrieved.");
              resolve(slivers);
              return;
            }
            slivers.push(sliver);
          } catch (error) {
            if (error instanceof NotFoundError) numNotFoundWeight += 1;
            else if (error instanceof LegallyUnavailableError) numBlockedWeight += 1;
            else if (error instanceof UserAbortError) {
              reject(error);
              return;
            }
            if (isQuorum(numBlockedWeight + numNotFoundWeight, numShards)) {
              const abortError = numNotFoundWeight > numBlockedWeight ? new BlobNotCertifiedError(`The specified blob ${blobId} is not certified.`) : new BlobBlockedError(`The specified blob ${blobId} is blocked.`);
              controller.abort(abortError);
              reject(abortError);
              return;
            }
            failedNodes.add(url);
            totalErrorCount += 1;
            const remainingTasks = sliverPairIndices.length - (slivers.length + totalErrorCount);
            if (slivers.length + remainingTasks < minSymbols) {
              const abortError = new NotEnoughSliversReceivedError(`Unable to retrieve enough slivers to decode blob ${blobId}.`);
              controller.abort(abortError);
              reject(abortError);
            }
          }
        }
      });
    });
  }
  /**
  * Gets the blob status from multiple storage nodes and returns the latest status that can be verified.
  */
  async getVerifiedBlobStatus({ blobId, signal }) {
    const committee = await this.#getActiveCommittee();
    const numShards = (await this.stakingState()).n_shards;
    const controller = new AbortController();
    const sortedStatuses = [...(await new Promise((resolve, reject) => {
      const results = [];
      let successWeight = 0;
      let numNotFoundWeight = 0;
      let settledCount = 0;
      committee.nodes.forEach(async (node) => {
        const weight = node.shardIndices.length;
        try {
          const status = await this.#storageNodeClient.getBlobStatus({ blobId }, {
            nodeUrl: node.networkUrl,
            signal: signal ? AbortSignal.any([controller.signal, signal]) : controller.signal
          });
          if (isQuorum(successWeight, numShards)) {
            controller.abort("Quorum of blob statuses retrieved successfully.");
            resolve(results);
          } else {
            successWeight += weight;
            results.push({
              status,
              weight
            });
          }
        } catch (error) {
          if (error instanceof NotFoundError) numNotFoundWeight += weight;
          else if (error instanceof UserAbortError) reject(error);
          if (isQuorum(numNotFoundWeight, numShards)) {
            const abortError = new BlobNotCertifiedError("The blob does not exist.");
            controller.abort(abortError);
            reject(abortError);
          }
        } finally {
          settledCount += 1;
          if (settledCount === committee.nodes.length) reject(new NoBlobStatusReceivedError("Not enough statuses were retrieved to achieve quorum."));
        }
      });
    })).reduce((accumulator, value) => {
      const { status, weight } = value;
      const key = JSON.stringify(status);
      const existing = accumulator.get(key);
      if (existing) existing.totalWeight += weight;
      else accumulator.set(key, {
        status,
        totalWeight: weight
      });
      return accumulator;
    }, /* @__PURE__ */ new Map()).values()].toSorted((a, b) => statusLifecycleRank[b.status.type] - statusLifecycleRank[a.status.type]);
    for (const value of sortedStatuses) if (isAboveValidity(value.totalWeight, numShards)) return value.status;
    throw new NoVerifiedBlobStatusReceivedError(`The blob status could not be verified for blob ${blobId},`);
  }
  async #getCertificationEpoch({ blobId, signal }) {
    const stakingState = await this.stakingState();
    const currentEpoch = stakingState.epoch;
    if (stakingState.epoch_state.$kind === "EpochChangeSync") {
      const status = await this.getVerifiedBlobStatus({
        blobId,
        signal
      });
      if (status.type === "nonexistent" || status.type === "invalid") throw new BlobNotCertifiedError(`The specified blob ${blobId} is ${status.type}.`);
      if (typeof status.initialCertifiedEpoch !== "number") throw new BlobNotCertifiedError(`The specified blob ${blobId} is not certified.`);
      if (status.initialCertifiedEpoch > currentEpoch) throw new BehindCurrentEpochError(`The client is at epoch ${currentEpoch} while the specified blob was certified at epoch ${status.initialCertifiedEpoch}.`);
      return status.initialCertifiedEpoch;
    }
    return currentEpoch;
  }
  /**
  * Retrieves the node committee responsible for serving reads.
  *
  * During an epoch change, reads should be served by the previous committee if the blob was
  * certified in an earlier epoch. This ensures that we read from nodes with the most accurate
  * information as nodes from the current committee might still be receiving transferred shards
  * from the previous committee.
  */
  async #getReadCommittee(options) {
    if (!this.#readCommittee) this.#readCommittee = this.#forceGetReadCommittee(options);
    return this.#readCommittee;
  }
  async #forceGetReadCommittee({ blobId, signal }) {
    const stakingState = await this.stakingState();
    const isTransitioning = stakingState.epoch_state.$kind === "EpochChangeSync";
    const certificationEpoch = await this.#getCertificationEpoch({
      blobId,
      signal
    });
    if (isTransitioning && certificationEpoch < stakingState.epoch) return await this.#getCommittee(stakingState.previous_committee);
    return await this.#getActiveCommittee();
  }
  /**
  * Calculate the cost of storing a blob for a given a size and number of epochs.
  */
  async storageCost(size, epochs) {
    const encodedSize = encodedBlobLength(size, (await this.systemState()).committee.n_shards);
    return this.#storageCostFromEncodedSize(encodedSize, epochs);
  }
  async #storageCostFromEncodedSize(encodedSize, epochs) {
    const systemState = await this.systemState();
    const storageUnits = storageUnitsFromSize(encodedSize);
    const storageCost = BigInt(storageUnits) * BigInt(systemState.storage_price_per_unit_size) * BigInt(epochs);
    const writeCost = BigInt(storageUnits) * BigInt(systemState.write_price_per_unit_size);
    return {
      storageCost,
      writeCost,
      totalCost: storageCost + writeCost
    };
  }
  /**
  * A utility for creating a storage object in a transaction.
  *
  * @example
  * ```ts
  * tx.transferObjects([client.createStorage({ size: 1000, epochs: 3 })], owner);
  * ```
  */
  createStorage({ size, epochs, walCoin }) {
    return async (tx) => {
      const systemObject = await this.systemObject();
      const encodedSize = encodedBlobLength(size, (await this.systemState()).committee.n_shards);
      const [{ storageCost }, walrusPackageId] = await Promise.all([this.storageCost(size, epochs), this.#getWalrusPackageId()]);
      return tx.add(this.#withWal(storageCost, walCoin ?? null, (coin, tx$1) => {
        return tx$1.add(reserveSpace({
          package: walrusPackageId,
          arguments: {
            self: systemObject.id,
            storageAmount: encodedSize,
            epochsAhead: epochs,
            payment: coin
          }
        }));
      }));
    };
  }
  #withWal(amount, source, fn) {
    return async (tx) => {
      const walType = await this.#walType();
      const coin = source ? tx.splitCoins(source, [amount])[0] : tx.add(coinWithBalance({
        balance: amount,
        type: walType
      }));
      const result = await fn(coin, tx);
      tx.moveCall({
        target: "0x2::coin::destroy_zero",
        typeArguments: [walType],
        arguments: [coin]
      });
      return result;
    };
  }
  /**
  * Create a transaction that creates a storage object
  *
  * @example
  * ```ts
  * const tx = client.createStorageTransaction({ size: 1000, epochs: 3, owner: signer.toSuiAddress() });
  * ```
  */
  createStorageTransaction({ transaction = new Transaction2(), size, epochs, owner }) {
    transaction.transferObjects([this.createStorage({
      size,
      epochs
    })], owner);
    return transaction;
  }
  /**
  * Execute a transaction that creates a storage object
  *
  * @example
  * ```ts
  * const { digest, storage } = await client.executeCreateStorageTransaction({ size: 1000, epochs: 3, signer });
  * ```
  */
  async executeCreateStorageTransaction({ signer, ...options }) {
    const transaction = this.createStorageTransaction({
      ...options,
      owner: options.transaction?.getData().sender ?? signer.toSuiAddress()
    });
    const blobType = await this.getBlobType();
    const { digest: digest2, effects } = await this.#executeTransaction(transaction, signer, "create storage");
    const createdObjectIds = effects?.changedObjects.filter((object2) => object2.idOperation === "Created").map((object2) => object2.objectId);
    const suiBlobObject = (await this.#suiClient.core.getObjects({
      objectIds: createdObjectIds,
      include: { content: true }
    })).objects.find((object2) => !(object2 instanceof Error) && object2.type === blobType);
    if (suiBlobObject instanceof Error || !suiBlobObject) throw new WalrusClientError(`Storage object not found in transaction effects for transaction (${digest2})`);
    return {
      digest: digest2,
      storage: Storage.parse(suiBlobObject.content)
    };
  }
  /**
  * Register a blob in a transaction
  *
  * @example
  * ```ts
  * tx.transferObjects([client.registerBlob({ size: 1000, epochs: 3, blobId, rootHash, deletable: true })], owner);
  * ```
  */
  registerBlob({ size, epochs, blobId, rootHash, deletable, walCoin, attributes }) {
    return async (tx) => {
      const { writeCost } = await this.storageCost(size, epochs);
      const walrusPackageId = await this.#getWalrusPackageId();
      return tx.add(this.#withWal(writeCost, walCoin ?? null, async (writeCoin, tx$1) => {
        const blob = tx$1.add(registerBlob({
          package: walrusPackageId,
          arguments: {
            self: tx$1.object(this.#packageConfig.systemObjectId),
            storage: this.createStorage({
              size,
              epochs,
              walCoin
            }),
            blobId: blobIdToInt(blobId),
            rootHash: BigInt(bcs.u256().parse(rootHash)),
            size,
            encodingType: 1,
            deletable,
            writePayment: writeCoin
          }
        }));
        if (attributes) tx$1.add(this.#writeBlobAttributesForRef({
          attributes,
          existingAttributes: null,
          blob
        }));
        return blob;
      }));
    };
  }
  addAuthPayload({ size, blobDigest, nonce }) {
    return async (transaction) => {
      const nonceDigest = await crypto.subtle.digest("SHA-256", nonce);
      const lengthBytes = bcs.u64().serialize(size).toBytes();
      const digest2 = typeof blobDigest === "function" ? await blobDigest() : blobDigest;
      const authPayload = new Uint8Array(nonceDigest.byteLength + digest2.byteLength + lengthBytes.byteLength);
      authPayload.set(digest2, 0);
      authPayload.set(new Uint8Array(nonceDigest), digest2.byteLength);
      authPayload.set(lengthBytes, nonceDigest.byteLength + digest2.byteLength);
      transaction.pure(authPayload);
    };
  }
  #loadTipConfig() {
    return this.#cache.read(["upload-relay-tip-config"], async () => {
      if (!this.#uploadRelayConfig?.sendTip || !this.#uploadRelayClient) return null;
      if ("kind" in this.#uploadRelayConfig.sendTip) return this.#uploadRelayConfig.sendTip;
      const tipConfig = await this.#uploadRelayClient.tipConfig();
      if (!tipConfig) return null;
      return {
        ...tipConfig,
        max: this.#uploadRelayConfig.sendTip.max
      };
    });
  }
  async calculateUploadRelayTip(options) {
    const systemState = await this.systemState();
    const encodedSize = encodedBlobLength(options.size, systemState.committee.n_shards);
    const tipConfig = await this.#loadTipConfig();
    if (!tipConfig) return 0n;
    const { max, kind } = tipConfig;
    const amount = "const" in kind ? kind.const : BigInt(kind.linear.base) + BigInt(kind.linear.perEncodedKib) * ((BigInt(encodedSize) + 1023n) / 1024n);
    if (max != null && amount > max) throw new WalrusClientError(`Tip amount (${amount}) exceeds the maximum allowed tip (${max})`);
    return amount;
  }
  sendUploadRelayTip({ size, blobDigest, nonce }) {
    return async (transaction) => {
      const tipConfig = await this.#loadTipConfig();
      if (tipConfig) {
        transaction.add(this.addAuthPayload({
          size,
          blobDigest,
          nonce
        }));
        const amount = await this.calculateUploadRelayTip({ size });
        const { address } = tipConfig;
        transaction.transferObjects([coinWithBalance({ balance: amount })], address);
      }
    };
  }
  /**
  * Create a transaction that registers a blob
  *
  * @example
  * ```ts
  * const tx = client.registerBlobTransaction({ size: 1000, epochs: 3, blobId, rootHash, deletable: true });
  * ```
  */
  registerBlobTransaction({ transaction = new Transaction2(), ...options }) {
    const registration = transaction.add(this.registerBlob(options));
    transaction.transferObjects([registration], options.owner);
    return transaction;
  }
  /**
  * Execute a transaction that registers a blob
  *
  * @example
  * ```ts
  * const { digest, blob } = await client.executeRegisterBlobTransaction({ size: 1000, epochs: 3, signer });
  * ```
  */
  async executeRegisterBlobTransaction({ signer, ...options }) {
    const transaction = this.registerBlobTransaction({
      ...options,
      owner: options.owner ?? options.transaction?.getData().sender ?? signer.toSuiAddress()
    });
    const blobType = await this.getBlobType();
    const { digest: digest2, effects } = await this.#executeTransaction(transaction, signer, "register blob");
    const createdObjectIds = effects?.changedObjects.filter((object2) => object2.idOperation === "Created").map((object2) => object2.objectId);
    const suiBlobObject = (await this.#suiClient.core.getObjects({
      objectIds: createdObjectIds,
      include: { content: true }
    })).objects.find((object2) => !(object2 instanceof Error) && object2.type === blobType);
    if (suiBlobObject instanceof Error || !suiBlobObject) throw new WalrusClientError(`Blob object not found in transaction effects for transaction (${digest2})`);
    return {
      digest: digest2,
      blob: Blob2.parse(suiBlobObject.content)
    };
  }
  async #getCreatedBlob(digest2) {
    const blobType = await this.getBlobType();
    const result = await this.#suiClient.core.waitForTransaction({
      digest: digest2,
      include: { effects: true }
    });
    const createdObjectIds = (result.Transaction ?? result.FailedTransaction).effects?.changedObjects.filter((object2) => object2.idOperation === "Created").map((object2) => object2.objectId);
    const suiBlobObject = (await this.#suiClient.core.getObjects({
      objectIds: createdObjectIds,
      include: { content: true }
    })).objects.find((object2) => !(object2 instanceof Error) && object2.type === blobType);
    if (suiBlobObject instanceof Error || !suiBlobObject) throw new WalrusClientError(`Blob object not found in transaction effects for transaction (${digest2})`);
    return Blob2.parse(suiBlobObject.content);
  }
  async certificateFromConfirmations({ confirmations, blobId, deletable, blobObjectId }) {
    const systemState = await this.systemState();
    const committee = await this.#getActiveCommittee();
    if (confirmations.length !== systemState.committee.members.length) throw new WalrusClientError("Invalid number of confirmations. Confirmations array must contain an entry for each node");
    const confirmationMessage = StorageConfirmation.serialize({
      intent: IntentType.BLOB_CERT_MSG,
      epoch: systemState.committee.epoch,
      messageContents: {
        blobId,
        blobType: deletable ? { Deletable: { objectId: blobObjectId } } : { Permanent: null }
      }
    }).toBase64();
    const bindings = await this.#wasmBindings();
    const verifySignature = bindings.getVerifySignature();
    const filteredConfirmations = confirmations.map((confirmation, index) => {
      return confirmation?.serializedMessage === confirmationMessage && verifySignature(confirmation, new Uint8Array(committee.nodes[index].info.public_key.bytes)) ? {
        index,
        ...confirmation
      } : null;
    }).filter((confirmation) => confirmation !== null);
    if (!isQuorum(filteredConfirmations.length, systemState.committee.members.length)) throw new NotEnoughBlobConfirmationsError(`Too many invalid confirmations received for blob (${filteredConfirmations.length} of ${systemState.committee.members.length})`);
    return bindings.combineSignatures(filteredConfirmations, filteredConfirmations.map(({ index }) => index));
  }
  /**
  * Certify a blob in a transaction
  *
  * @example
  * ```ts
  * tx.add(client.certifyBlob({ blobId, blobObjectId, confirmations }));
  * ```
  */
  certifyBlob({ blobId, blobObjectId, confirmations, certificate, deletable }) {
    return async (tx) => {
      const systemState = await this.systemState();
      const combinedSignature = (typeof certificate === "string" ? parseCertificateFromBase64(certificate) : certificate) ?? await this.certificateFromConfirmations({
        confirmations,
        blobId,
        deletable,
        blobObjectId
      });
      const walrusPackageId = await this.#getWalrusPackageId();
      tx.add(certifyBlob({
        package: walrusPackageId,
        arguments: {
          self: this.#packageConfig.systemObjectId,
          blob: blobObjectId,
          signature: tx.pure.vector("u8", combinedSignature.signature),
          signersBitmap: tx.pure.vector("u8", signersToBitmap(combinedSignature.signers, systemState.committee.members.length)),
          message: tx.pure.vector("u8", combinedSignature.serializedMessage)
        }
      }));
    };
  }
  /**
  * Create a transaction that certifies a blob
  *
  * @example
  * ```ts
  * const tx = client.certifyBlobTransaction({ blobId, blobObjectId, confirmations });
  * ```
  */
  certifyBlobTransaction({ transaction = new Transaction2(), ...options }) {
    transaction.add(this.certifyBlob(options));
    return transaction;
  }
  /**
  * Execute a transaction that certifies a blob
  *
  * @example
  * ```ts
  * const { digest } = await client.executeCertifyBlobTransaction({ blobId, blobObjectId, confirmations, signer });
  * ```
  */
  async executeCertifyBlobTransaction({ signer, ...options }) {
    const transaction = this.certifyBlobTransaction(options);
    const { digest: digest2 } = await this.#executeTransaction(transaction, signer, "certify blob");
    return { digest: digest2 };
  }
  /**
  * Delete a blob in a transaction
  *
  * @example
  * ```ts
  * const storage = await client.deleteBlob({ blobObjectId });
  * tx.transferObjects([storage], owner);
  * ```
  */
  deleteBlob({ blobObjectId }) {
    return async (tx) => {
      const walrusPackageId = await this.#getWalrusPackageId();
      return tx.add(deleteBlob({
        package: walrusPackageId,
        arguments: {
          self: this.#packageConfig.systemObjectId,
          blob: blobObjectId
        }
      }));
    };
  }
  /**
  * Create a transaction that deletes a blob
  *
  * @example
  * ```ts
  * const tx = client.deleteBlobTransaction({ blobObjectId, owner });
  * ```
  */
  deleteBlobTransaction({ owner, blobObjectId, transaction = new Transaction2() }) {
    const storage = transaction.add(this.deleteBlob({ blobObjectId }));
    transaction.transferObjects([storage], owner);
    return transaction;
  }
  /**
  * Execute a transaction that deletes a blob
  *
  * @example
  * ```ts
  * const { digest } = await client.executeDeleteBlobTransaction({ blobObjectId, signer });
  * ```
  */
  async executeDeleteBlobTransaction({ signer, transaction = new Transaction2(), blobObjectId }) {
    const { digest: digest2 } = await this.#executeTransaction(this.deleteBlobTransaction({
      blobObjectId,
      transaction,
      owner: transaction.getData().sender ?? signer.toSuiAddress()
    }), signer, "delete blob");
    return { digest: digest2 };
  }
  /**
  * Extend a blob in a transaction
  *
  * @example
  * ```ts
  * const tx = client.extendBlobTransaction({ blobObjectId, epochs });
  * ```
  */
  extendBlob({ blobObjectId, epochs, endEpoch, walCoin }) {
    return async (tx) => {
      const blob = await this.#objectLoader.load(blobObjectId, Blob2);
      const numEpochs = typeof epochs === "number" ? epochs : endEpoch - blob.storage.end_epoch;
      if (numEpochs <= 0) return;
      const { storageCost } = await this.#storageCostFromEncodedSize(Number(blob.storage.storage_size), numEpochs);
      const walrusPackageId = await this.#getWalrusPackageId();
      return tx.add(this.#withWal(storageCost, walCoin ?? null, async (coin, tx$1) => {
        tx$1.add(extendBlob({
          package: walrusPackageId,
          arguments: {
            self: this.#packageConfig.systemObjectId,
            blob: blobObjectId,
            extendedEpochs: numEpochs,
            payment: coin
          }
        }));
      }));
    };
  }
  /**
  * Create a transaction that extends a blob
  *
  * @example
  * ```ts
  * const tx = client.extendBlobTransaction({ blobObjectId, epochs });
  * ```
  */
  async extendBlobTransaction({ transaction = new Transaction2(), ...options }) {
    transaction.add(this.extendBlob(options));
    return transaction;
  }
  /**
  * Execute a transaction that extends a blob
  *
  * @example
  * ```ts
  * const { digest } = await client.executeExtendBlobTransaction({ blobObjectId, signer });
  * ```
  */
  async executeExtendBlobTransaction({ signer, ...options }) {
    const { digest: digest2 } = await this.#executeTransaction(await this.extendBlobTransaction(options), signer, "extend blob");
    return { digest: digest2 };
  }
  async readBlobAttributes({ blobObjectId }) {
    let response;
    try {
      response = await this.#suiClient.core.getDynamicField({
        parentId: blobObjectId,
        name: {
          type: "vector<u8>",
          bcs: bcs.string().serialize("metadata").toBytes()
        }
      });
    } catch (error) {
      if (error instanceof ObjectError && (error.reason === "notFound" || error.reason === "deleted")) return null;
      throw error;
    }
    const parsedMetadata = Metadata.parse(response.dynamicField.value.bcs);
    return Object.fromEntries(parsedMetadata.metadata.contents.map(({ key, value }) => [key, value]));
  }
  #writeBlobAttributesForRef({ attributes, existingAttributes, blob }) {
    return async (tx) => {
      const walrusPackageId = await this.#getWalrusPackageId();
      if (!existingAttributes) tx.add(addMetadata({
        package: walrusPackageId,
        arguments: {
          self: blob,
          metadata: _new({ package: walrusPackageId })
        }
      }));
      Object.keys(attributes).forEach((key) => {
        const value = attributes[key];
        if (value === null) {
          if (existingAttributes && key in existingAttributes) tx.add(removeMetadataPair({
            package: walrusPackageId,
            arguments: {
              self: blob,
              key
            }
          }));
        } else tx.add(insertOrUpdateMetadataPair({
          package: walrusPackageId,
          arguments: {
            self: blob,
            key,
            value
          }
        }));
      });
    };
  }
  /**
  * Write attributes to a blob
  *
  * If attributes already exists, their previous values will be overwritten
  * If an attribute is set to `null`, it will be removed from the blob
  *
  * @example
  * ```ts
  * tx.add(client.writeBlobAttributes({ blobObjectId, attributes: { key: 'value', keyToRemove: null } }));
  * ```
  */
  writeBlobAttributes({ blobObject, blobObjectId, attributes }) {
    return async (tx) => {
      const existingAttributes = blobObjectId ? await this.readBlobAttributes({ blobObjectId }) : null;
      const blob = blobObject ?? tx.object(blobObjectId);
      tx.add(this.#writeBlobAttributesForRef({
        attributes,
        existingAttributes,
        blob
      }));
    };
  }
  /**
  * Create a transaction that writes attributes to a blob
  *
  * If attributes already exists, their previous values will be overwritten
  * If an attribute is set to `null`, it will be removed from the blob
  *
  * @example
  * ```ts
  * const tx = client.writeBlobAttributesTransaction({ blobObjectId, attributes: { key: 'value', keyToRemove: null } });
  * ```
  */
  async writeBlobAttributesTransaction({ transaction = new Transaction2(), ...options }) {
    transaction.add(await this.writeBlobAttributes(options));
    return transaction;
  }
  /**
  * Execute a transaction that writes attributes to a blob
  *
  * If attributes already exists, their previous values will be overwritten
  * If an attribute is set to `null`, it will be removed from the blob
  *
  * @example
  * ```ts
  * const { digest } = await client.executeWriteBlobAttributesTransaction({ blobObjectId, signer });
  * ```
  */
  async executeWriteBlobAttributesTransaction({ signer, ...options }) {
    const { digest: digest2 } = await this.#executeTransaction(await this.writeBlobAttributesTransaction(options), signer, "write blob attributes");
    return { digest: digest2 };
  }
  /**
  * Write a sliver to a storage node
  *
  * @example
  * ```ts
  * const res = await client.writeSliver({ blobId, sliverPairIndex, sliverType, sliver });
  * ```
  */
  async writeSliver({ blobId, sliverPairIndex, sliverType, sliver, signal }) {
    const systemState = await this.systemState();
    const committee = await this.#getActiveCommittee();
    const shardIndex = toShardIndex(sliverPairIndex, blobId, systemState.committee.n_shards);
    const node = await this.#getNodeByShardIndex(committee, shardIndex);
    return this.#storageNodeClient.storeSliver({
      blobId,
      sliverPairIndex,
      sliverType,
      sliver
    }, {
      nodeUrl: node.networkUrl,
      signal
    });
  }
  /**
  * Write metadata to a storage node
  *
  * @example
  * ```ts
  * const res = await client.writeMetadataToNode({ nodeIndex, blobId, metadata });
  * ```
  */
  async writeMetadataToNode({ nodeIndex, blobId, metadata, signal }) {
    const node = (await this.#getActiveCommittee()).nodes[nodeIndex];
    return retry(() => this.#storageNodeClient.storeBlobMetadata({
      blobId,
      metadata
    }, {
      nodeUrl: node.networkUrl,
      signal
    }), {
      count: 3,
      delay: 1e3,
      condition: (error) => error instanceof BlobNotRegisteredError
    });
  }
  /**
  * Get a storage confirmation from a storage node
  *
  * @example
  * ```ts
  * const confirmation = await client.getStorageConfirmationFromNode({ nodeIndex, blobId, deletable, objectId });
  * ```
  */
  async getStorageConfirmationFromNode({ nodeIndex, blobId, deletable, objectId, signal }) {
    const node = (await this.#getActiveCommittee()).nodes[nodeIndex];
    return (deletable ? await this.#storageNodeClient.getDeletableBlobConfirmation({
      blobId,
      objectId
    }, {
      nodeUrl: node.networkUrl,
      signal
    }) : await this.#storageNodeClient.getPermanentBlobConfirmation({ blobId }, {
      nodeUrl: node.networkUrl,
      signal
    }))?.success?.data?.signed ?? null;
  }
  /**
  * Get storage confirmations from all active committee nodes for a blob.
  *
  * @example
  * ```ts
  * const confirmations = await client.getStorageConfirmations({
  *   blobId: savedState.blobId,
  *   deletable: true,
  *   objectId: savedState.blobObjectId,
  * });
  * const tx = client.certifyBlobTransaction({ blobId, blobObjectId, confirmations, deletable: true });
  * ```
  */
  async getStorageConfirmations({ blobId, deletable, objectId, signal }) {
    const committee = await this.#getActiveCommittee();
    return Promise.all(committee.nodes.map((_, nodeIndex) => this.getStorageConfirmationFromNode({
      nodeIndex,
      blobId,
      ...deletable ? {
        deletable: true,
        objectId
      } : { deletable: false },
      signal
    }).catch(() => null)));
  }
  /**
  * Load a parsed Blob object from chain by its Sui object ID.
  *
  * @example
  * ```ts
  * const blobObject = await client.getBlobObject('0x...');
  * console.log(blobObject.id, blobObject.blob_id);
  * ```
  */
  async getBlobObject(blobObjectId) {
    return this.#objectLoader.load(blobObjectId, Blob2);
  }
  /**
  * Encode a blob into slivers for each node
  *
  * @example
  * ```ts
  * const { blobId, metadata, sliversByNode, rootHash } = await client.encodeBlob(blob);
  * ```
  */
  async encodeBlob(blob) {
    const systemState = await this.systemState();
    const committee = await this.#getActiveCommittee();
    const numShards = systemState.committee.n_shards;
    const { blobId, metadata, primarySlivers, secondarySlivers, rootHash } = (await this.#wasmBindings()).encodeBlob(numShards, blob);
    const sliversByNodeMap = /* @__PURE__ */ new Map();
    for (let sliverPairIndex = 0; sliverPairIndex < primarySlivers.length; sliverPairIndex++) {
      const primarySliver = primarySlivers[sliverPairIndex];
      const secondarySliver = secondarySlivers[sliverPairIndex];
      const shardIndex = toShardIndex(sliverPairIndex, blobId, numShards);
      const node = await this.#getNodeByShardIndex(committee, shardIndex);
      if (!sliversByNodeMap.has(node.nodeIndex)) sliversByNodeMap.set(node.nodeIndex, {
        primary: [],
        secondary: []
      });
      sliversByNodeMap.get(node.nodeIndex).primary.push({
        sliverIndex: sliverPairIndex,
        sliverPairIndex,
        shardIndex,
        sliver: primarySliver
      });
      sliversByNodeMap.get(node.nodeIndex).secondary.push({
        sliverIndex: sliverPairIndex,
        sliverPairIndex,
        shardIndex,
        sliver: secondarySliver
      });
    }
    const sliversByNode = new Array();
    for (let i = 0; i < systemState.committee.members.length; i++) sliversByNode.push(sliversByNodeMap.get(i) ?? {
      primary: [],
      secondary: []
    });
    return {
      blobId,
      metadata,
      rootHash,
      sliversByNode
    };
  }
  /**
  * Write slivers to a storage node
  *
  * @example
  * ```ts
  * await client.writeSliversToNode({ blobId, slivers, signal });
  * ```
  */
  async writeSliversToNode({ blobId, slivers, signal }) {
    const controller = new AbortController();
    const combinedSignal = signal ? AbortSignal.any([controller.signal, signal]) : controller.signal;
    const primarySliverWrites = slivers.primary.map(({ sliverPairIndex, sliver }) => {
      return this.writeSliver({
        blobId,
        sliverPairIndex,
        sliverType: "primary",
        sliver,
        signal: combinedSignal
      });
    });
    const secondarySliverWrites = slivers.secondary.map(({ sliverPairIndex, sliver }) => {
      return this.writeSliver({
        blobId,
        sliverPairIndex,
        sliverType: "secondary",
        sliver,
        signal: combinedSignal
      });
    });
    await Promise.all([...primarySliverWrites, ...secondarySliverWrites]).catch((error) => {
      controller.abort(error);
      throw error;
    });
  }
  /**
  * Write a blob to all storage nodes
  *
  * @example
  * ```ts
  * await client.writeEncodedBlobToNodes({ blob, deletable, epochs, signer });
  * ```
  */
  async writeEncodedBlobToNodes({ blobId, metadata, sliversByNode, signal, ...options }) {
    const systemState = await this.systemState();
    const committee = await this.#getActiveCommittee();
    const controller = new AbortController();
    let failures = 0;
    return await Promise.all(sliversByNode.map((slivers, nodeIndex) => {
      return this.writeEncodedBlobToNode({
        blobId,
        nodeIndex,
        metadata,
        slivers,
        signal: signal ? AbortSignal.any([controller.signal, signal]) : controller.signal,
        ...options
      }).catch(() => {
        failures += committee.nodes[nodeIndex].shardIndices.length;
        if (isAboveValidity(failures, systemState.committee.n_shards)) {
          const error = new NotEnoughBlobConfirmationsError(`Too many failures while writing blob ${blobId} to nodes`);
          controller.abort(error);
          throw error;
        }
        return null;
      });
    }));
  }
  /**
  * Writes a blob to to an upload relay
  *
  * @example
  * ```ts
  * await client.writeBlobToUploadRelay({ blob, deletable, epochs, signer });
  * ```
  */
  async writeBlobToUploadRelay(options) {
    if (!this.#uploadRelayClient) throw new WalrusClientError("Upload relay not configured");
    return this.#uploadRelayClient.writeBlob({
      ...options,
      requiresTip: !!this.#uploadRelayConfig?.sendTip
    });
  }
  /**
  * Write encoded blob to a storage node
  *
  * @example
  * ```ts
  * const res = await client.writeEncodedBlobToNode({ nodeIndex, blobId, metadata, slivers });
  * ```
  */
  async writeEncodedBlobToNode({ nodeIndex, blobId, metadata, slivers, signal, ...options }) {
    const node = (await this.#getActiveCommittee()).nodes[nodeIndex];
    let metaDataExists = false;
    try {
      const metadataStatus = await this.#storageNodeClient.getMetadataStatus({ blobId }, {
        nodeUrl: node.networkUrl,
        signal
      });
      if (metadataStatus === "Stored" || metadataStatus === "Buffered") metaDataExists = true;
    } catch {
    }
    if (!metaDataExists) await this.writeMetadataToNode({
      nodeIndex,
      blobId,
      metadata,
      signal
    });
    if (!metaDataExists) await this.writeSliversToNode({
      blobId,
      slivers,
      signal,
      nodeIndex
    });
    else await this.#writeSliversWithStatusCheck({
      blobId,
      slivers,
      signal,
      nodeIndex
    });
    return this.getStorageConfirmationFromNode({
      nodeIndex,
      blobId,
      ...options
    });
  }
  async #writeSliversWithStatusCheck({ blobId, slivers, signal, nodeIndex }) {
    const node = (await this.#getActiveCommittee()).nodes[nodeIndex];
    const controller = new AbortController();
    const combinedSignal = signal ? AbortSignal.any([controller.signal, signal]) : controller.signal;
    const sliverWrites = [...slivers.primary.map((s) => ({
      ...s,
      sliverType: "primary"
    })), ...slivers.secondary.map((s) => ({
      ...s,
      sliverType: "secondary"
    }))].map(async ({ sliverPairIndex, sliver, sliverType }) => {
      if (sliver.byteLength >= SLIVER_STATUS_CHECK_THRESHOLD) try {
        const status = await this.#storageNodeClient.getSliverStatus({
          blobId,
          sliverPairIndex,
          sliverType
        }, {
          nodeUrl: node.networkUrl,
          signal: combinedSignal
        });
        if (status === "Stored" || status === "Buffered") return;
      } catch {
      }
      return this.writeSliver({
        blobId,
        sliverPairIndex,
        sliverType,
        sliver,
        signal: combinedSignal
      });
    });
    await Promise.all(sliverWrites).catch((error) => {
      controller.abort(error);
      throw error;
    });
  }
  /**
  * Write a blob to all storage nodes
  *
  * @example
  * ```ts
  * const { blobId, blobObject } = await client.writeBlob({ blob, deletable, epochs, signer });
  * ```
  */
  async writeBlob({ blob, deletable, epochs, signer, owner, attributes, onStep, resume, signal }) {
    const flow = this.writeBlobFlow({
      blob,
      resume
    });
    for await (const step of flow.run({
      signer,
      epochs,
      deletable,
      owner: owner ?? signer.toSuiAddress(),
      attributes,
      signal
    })) await onStep?.(step);
    const result = await flow.getBlob();
    return {
      blobId: result.blobId,
      blobObject: result.blobObject
    };
  }
  async writeQuilt({ blobs, ...options }) {
    const encoded = await this.encodeQuilt({ blobs });
    const result = await this.writeBlob({
      ...options,
      blob: encoded.quilt,
      attributes: {
        _walrusBlobType: "quilt",
        ...options.attributes
      }
    });
    return {
      ...result,
      index: {
        ...encoded.index,
        patches: encoded.index.patches.map((patch) => ({
          ...patch,
          patchId: encodeQuiltPatchId({
            quiltId: result.blobId,
            patchId: {
              version: 1,
              startIndex: patch.startIndex,
              endIndex: patch.endIndex
            }
          })
        }))
      }
    };
  }
  async encodeQuilt({ blobs }) {
    return encodeQuilt({
      blobs,
      numShards: (await this.systemState()).committee.n_shards
    });
  }
  async #executeTransaction(transaction, signer, action) {
    transaction.setSenderIfNotSet(signer.toSuiAddress());
    const result = await signer.signAndExecuteTransaction({
      transaction,
      client: this.#suiClient
    });
    if (result.FailedTransaction) throw new WalrusClientError(`Failed to ${action} (${result.FailedTransaction.digest}): ${result.FailedTransaction.status.error?.message}`);
    const { digest: digest2, effects } = result.Transaction;
    await this.#suiClient.core.waitForTransaction({ digest: digest2 });
    return {
      digest: digest2,
      effects
    };
  }
  async #getCommittee(committee) {
    const stakingPool = await this.#stakingPool(committee);
    const shardIndicesByNodeId = getShardIndicesByNodeId(committee);
    const byShardIndex = /* @__PURE__ */ new Map();
    return {
      byShardIndex,
      nodes: stakingPool.map(({ node_info }, nodeIndex) => {
        const shardIndices = shardIndicesByNodeId.get(node_info.node_id) ?? [];
        const node = {
          id: node_info.node_id,
          info: node_info,
          networkUrl: `${this.#storageNodeUrlScheme}://${node_info.network_address}`,
          shardIndices,
          nodeIndex
        };
        for (const shardIndex of shardIndices) byShardIndex.set(shardIndex, node);
        return node;
      })
    };
  }
  #getActiveCommittee() {
    return this.#cache.read(["getActiveCommittee", this.#storageNodeUrlScheme], async () => {
      const stakingState = await this.stakingState();
      return this.#getCommittee(stakingState.committee);
    });
  }
  async #stakingPool(committee) {
    const nodeIds = committee[0].contents.map((node) => node.key);
    return this.#objectLoader.loadManyOrThrow(nodeIds, StakingPool2);
  }
  async #getNodeByShardIndex(committeeInfo, index) {
    const node = committeeInfo.byShardIndex.get(index);
    if (!node) throw new WalrusClientError(`Node for shard index ${index} not found`);
    return node;
  }
  /**
  * Reset cached data in the client
  *
  * @example
  * ```ts
  * client.reset();
  * ```
  */
  reset() {
    this.#objectLoader.clearAll();
    this.#cache.clear();
  }
  #retryOnPossibleEpochChange(fn) {
    return (async (...args) => {
      try {
        return await fn.apply(this, args);
      } catch (error) {
        if (error instanceof RetryableWalrusClientError) {
          this.reset();
          return await fn.apply(this, args);
        }
        throw error;
      }
    });
  }
  async getBlob({ blobId }) {
    return new WalrusBlob({
      reader: new BlobReader({
        client: this,
        blobId,
        numShards: (await this.systemState()).committee.n_shards
      }),
      client: this
    });
  }
  async getFiles({ ids }) {
    const readersByBlobId = /* @__PURE__ */ new Map();
    const quiltReadersByBlobId = /* @__PURE__ */ new Map();
    const parsedIds = ids.map((id) => parseWalrusId(id));
    const numShards = (await this.systemState()).committee.n_shards;
    for (const id of parsedIds) {
      const blobId = id.kind === "blob" ? id.id : id.id.quiltId;
      if (!readersByBlobId.has(blobId)) readersByBlobId.set(blobId, new BlobReader({
        client: this,
        blobId,
        numShards
      }));
      if (id.kind === "quiltPatch") {
        if (!quiltReadersByBlobId.has(blobId)) quiltReadersByBlobId.set(blobId, new QuiltReader({ blob: readersByBlobId.get(blobId) }));
      }
    }
    return parsedIds.map((id) => {
      if (id.kind === "blob") return new WalrusFile({ reader: readersByBlobId.get(id.id) });
      return new WalrusFile({ reader: new QuiltFileReader({
        quilt: quiltReadersByBlobId.get(id.id.quiltId),
        sliverIndex: id.id.patchId.startIndex
      }) });
    });
  }
  async writeFiles({ files, onStep, resume, ...options }) {
    const flow = this.writeFilesFlow({
      files,
      resume
    });
    for await (const step of flow.run({
      signer: options.signer,
      epochs: options.epochs,
      deletable: options.deletable,
      owner: options.owner ?? options.signer.toSuiAddress(),
      attributes: options.attributes
    })) await onStep?.(step);
    return flow.listFiles();
  }
  /**
  * Create a step-by-step files upload flow with resume support.
  *
  * Encodes files into a quilt blob and delegates to `writeBlobFlow()` internally.
  * Supports the same resume, step methods, and `run()` async iterator as `writeBlobFlow()`.
  *
  * @example
  * ```ts
  * const flow = client.writeFilesFlow({ files });
  * for await (const step of flow.run({ signer, epochs: 3, deletable: true })) {
  *   await db.save(fileId, step);
  * }
  * const fileRefs = await flow.listFiles();
  * ```
  */
  writeFilesFlow(options) {
    return createWriteFilesFlow(this, options);
  }
  /**
  * Create a step-by-step blob upload flow with resume support.
  *
  * Returns an object with individual step methods (`encode`, `register`, `upload`, `certify`)
  * for manual control, convenience methods (`executeRegister`, `executeCertify`) that handle
  * signing, and a `run()` async iterator that executes the full pipeline.
  *
  * Each step returns a `WriteBlobStep` result that can be persisted and passed as `resume`
  * to recover from crashes.
  *
  * @example
  * ```ts
  * // Async iterator with checkpoints:
  * const flow = client.writeBlobFlow({ blob });
  * for await (const step of flow.run({ signer, epochs: 3, deletable: true })) {
  *   await db.save(fileId, step);
  * }
  *
  * // Resume from saved state:
  * const saved = await db.load(fileId);
  * const flow = client.writeBlobFlow({ blob, resume: saved });
  * for await (const step of flow.run({ signer, epochs: 3, deletable: true })) {
  *   await db.save(fileId, step);
  * }
  * ```
  */
  writeBlobFlow(options) {
    return createWriteBlobFlow(this, this.#flowContext(), options);
  }
  #flowContext() {
    return {
      hasUploadRelay: () => !!this.#uploadRelayClient,
      executeTransaction: (transaction, signer, action) => this.#executeTransaction(transaction, signer, action),
      getCreatedBlob: (digest2) => this.#getCreatedBlob(digest2),
      loadBlobObject: (objectId) => this.#objectLoader.load(objectId, Blob2)
    };
  }
};

// dapp/scripts/archive-quilt.mjs
var import_node_crypto = require("node:crypto");
var import_promises = require("node:fs/promises");

// dapp/src/lib/archive-quilt.ts
function readArchiveQuilt(bytes) {
  const rows = 334, columns = 667, limit = 4 * 1024 * 1024;
  const symbol = bytes.length / (rows * columns), column = rows * symbol;
  if (!bytes.length || bytes.length > limit || !Number.isInteger(symbol) || symbol < 2 || symbol % 2) throw Error("Unsupported Quilt geometry");
  function read(start2, offset2, length) {
    if (![start2, offset2, length].every(Number.isSafeInteger) || start2 < 0 || offset2 < 0 || length < 0 || length > limit || start2 * column + offset2 + length > bytes.length) throw Error("Quilt range exceeds parent");
    const out = new Uint8Array(length);
    for (let n = 0; n < length; ) {
      const position = offset2 + n, col = start2 + Math.floor(position / column);
      const within = position % column, row = Math.floor(within / symbol), inside = within % symbol;
      const count2 = Math.min(symbol - inside, length - n);
      const physical = row * columns * symbol + col * symbol + inside;
      out.set(bytes.subarray(physical, physical + count2), n);
      n += count2;
    }
    return out;
  }
  const header = read(0, 0, 5), view = new DataView(header.buffer);
  const size = view.getUint32(1, true);
  if (header[0] !== 1 || size < 1 || size > 4096 || size + 5 > bytes.length) throw Error("Quilt index bounds");
  const index = read(0, 5, size);
  let offset = 0;
  const byte = () => {
    if (offset >= index.length) throw Error("Truncated Quilt index");
    return index[offset++];
  };
  const uleb = () => {
    let value = 0;
    for (let n = 0; n < 4; n++) {
      const b = byte();
      value += (b & 127) * 2 ** (7 * n);
      if (b < 128) return value;
    }
    throw Error("Quilt integer bounds");
  };
  const text = () => {
    const length = uleb();
    if (length < 1 || length > 64 || offset + length > index.length) throw Error("Quilt identifier bounds");
    const value = new TextDecoder("utf-8", { fatal: true }).decode(index.subarray(offset, offset + length));
    offset += length;
    if (!/^[a-zA-Z0-9_-]{1,64}$/.test(value)) throw Error("Invalid Quilt identifier");
    return value;
  };
  const count = uleb();
  if (count < 2 || count > 17) throw Error("Quilt item count bounds");
  let start = Math.ceil((size + 5) / column);
  const result = /* @__PURE__ */ new Map();
  for (let n = 0; n < count; n++) {
    const end = byte() + 256 * byte(), identifier = text(), tags = uleb();
    if (tags !== 0 || end <= start || end > columns || result.has(identifier)) throw Error("Quilt patch/index bounds");
    const part = read(start, 0, 8), h = new DataView(part.buffer);
    const length = h.getUint32(1, true), nameSize = h.getUint16(6, true);
    if (part[0] !== 1 || part[5] !== 0 || nameSize < 2 || nameSize > 65 || length < 2 + nameSize || length + 6 > (end - start) * column) throw Error("Quilt patch header bounds");
    const name = read(start, 8, nameSize);
    if (name[0] !== nameSize - 1 || new TextDecoder("utf-8", { fatal: true }).decode(name.subarray(1)) !== identifier) throw Error("Quilt patch identifier mismatch");
    result.set(identifier, read(start, 8 + nameSize, length - 2 - nameSize));
    start = end;
  }
  if (offset !== index.length || !result.has("manifest")) throw Error("Invalid Quilt index framing");
  return result;
}

// dapp/scripts/archive-quilt.mjs
var MAX_ITEMS = 17;
var MAX_BYTES = 4 * 1024 * 1024;
var digest = (bytes) => (0, import_node_crypto.createHash)("sha256").update(bytes).digest("hex");
async function readBounded(path, limit = MAX_BYTES) {
  const file = await (0, import_promises.open)(path, "r");
  try {
    const stat = await file.stat();
    if (!stat.isFile() || stat.size < 1 || stat.size > limit) throw Error("Spool file size");
    const bytes = Buffer.alloc(stat.size);
    let offset = 0;
    while (offset < bytes.length) {
      const { bytesRead } = await file.read(bytes, offset, bytes.length - offset, offset);
      if (!bytesRead) throw Error("Truncated spool file");
      offset += bytesRead;
    }
    const extra = Buffer.alloc(1);
    if ((await file.read(extra, 0, 1, offset)).bytesRead) throw Error("Growing spool file");
    return bytes;
  } finally {
    await file.close();
  }
}
function validateItems(items) {
  if (!Array.isArray(items) || items.length < 2 || items.length > MAX_ITEMS) throw Error("Quilt item count");
  const identifiers = /* @__PURE__ */ new Set();
  let total = 0;
  for (const item of items) {
    if (!item || !/^[a-zA-Z0-9_-]{1,64}$/.test(item.identifier) || identifiers.has(item.identifier) || !(item.contents instanceof Uint8Array) || !item.contents.length || (total += item.contents.length) > MAX_BYTES) throw Error("Quilt item bounds");
    identifiers.add(item.identifier);
  }
}
async function prepareQuilt(storage, items) {
  validateItems(items);
  const { quilt, index } = await storage.encodeQuilt({ blobs: items });
  if (quilt.length > MAX_BYTES) throw Error("Encoded Quilt exceeds archive quota");
  if (index.patches.length !== items.length) throw Error("Incomplete Quilt index");
  readArchiveQuilt(quilt);
  const encoded = await storage.encodeBlob(quilt);
  return { encoded, size: quilt.length, items: items.map((item) => ({
    identifier: item.identifier,
    size: item.contents.length,
    sha256: digest(item.contents)
  })) };
}

// dapp/scripts/walrus-device-codec.mjs
async function main() {
  const input = (0, import_node_readline.createInterface)({ input: process.stdin, crlfDelay: Infinity })[Symbol.asyncIterator]();
  try {
    const first = await input.next();
    if (first.done || first.value.length > 16384) throw Error("Invalid codec request");
    const request = JSON.parse(first.value);
    if (request.chain !== "4c78adac") throw Error("Only the pinned testnet Walrus deployment is supported");
    const bytes = new Uint8Array(await readBounded(request.ciphertext_path));
    if (!bytes.length || bytes.length > 4 * 1024 * 1024) throw Error("Archive size out of bounds");
    const client = new SuiGrpcClient({ network: "testnet", baseUrl: request.rpc_url });
    const info = await client.getChainIdentifier();
    const genesis = fromBase58(info.chainIdentifier);
    if (genesis.length !== 32 || toHex(genesis.slice(0, 4)) !== request.chain) throw Error("Foreign Sui chain");
    const storage = client.$extend(walrus({ packageConfig: TESTNET_WALRUS_PACKAGE_CONFIG })).walrus;
    if (normalizeSuiAddress(TESTNET_WALRUS_PACKAGE_CONFIG.systemObjectId) !== normalizeSuiAddress(request.system_id) || normalizeSuiAddress((await storage.systemObject()).package_id) !== normalizeSuiAddress(request.walrus_package)) throw Error("Unsupported Walrus deployment");
    const committee = (await storage.systemState()).committee;
    let encoded, size = bytes.length, items;
    if (request.items !== void 0) {
      if (!Array.isArray(request.items) || request.items.length < 1 || request.items.length >= MAX_ITEMS) throw Error("Invalid item list");
      const blobs = [{ identifier: "manifest", contents: bytes }];
      let total = bytes.length;
      for (const item of request.items) {
        if (!item || !Number.isSafeInteger(item.size) || item.size < 1 || (total += item.size) > MAX_BYTES) throw Error("Item quota exceeded");
        const contents = new Uint8Array(await readBounded(item.path, item.size));
        if (contents.length !== item.size || digest(contents) !== item.sha256) throw Error("Changed pending item");
        blobs.push({ identifier: item.identifier, contents });
      }
      ({ encoded, size, items } = await prepareQuilt(storage, blobs));
    } else encoded = await storage.encodeBlob(bytes);
    const prepared = {
      blob_id: blobIdToInt(encoded.blobId).toString(),
      root_hash: suiBcs.u256().parse(encoded.rootHash).toString(),
      size,
      ...items ? { items } : {}
    };
    if (request.operation === "prepare") console.log(JSON.stringify(prepared));
    else if (request.operation === "registered") {
      const result = await client.waitForTransaction({ digest: request.digest, include: { effects: true, events: true } });
      if (result.FailedTransaction || !result.Transaction.status.success) throw Error("Registration did not succeed");
      const record2 = suiBcs.struct("UploadRegistered", {
        storage_id: suiBcs.Address,
        device_id: suiBcs.Address,
        blob_object_id: suiBcs.Address,
        blob_id: suiBcs.u256(),
        size: suiBcs.u64(),
        encoded_size: suiBcs.u64(),
        write_fee: suiBcs.u64(),
        end_epoch: suiBcs.u32(),
        encoded_bytes_in_period: suiBcs.u64(),
        uploads_in_period: suiBcs.u64(),
        pool_size: suiBcs.u64(),
        wal_balance: suiBcs.u64(),
        at_limit: suiBcs.bool()
      });
      let found;
      for (const event of result.Transaction.events ?? []) {
        if (event.eventType !== `${normalizeSuiAddress(request.storage_type_origin)}::fleet_storage::UploadRegistered`) continue;
        const v = record2.parse(event.bcs);
        if (normalizeSuiAddress(v.storage_id) === normalizeSuiAddress(request.storage_id) && normalizeSuiAddress(v.device_id) === normalizeSuiAddress(request.device_id) && v.blob_id === prepared.blob_id) found = v;
      }
      if (!found) throw Error("Registration event not found");
      console.log(JSON.stringify({ blob_object_id: found.blob_object_id, end_epoch: found.end_epoch, encoded_size: found.encoded_size, write_fee: found.write_fee }));
    } else if (request.operation === "write") {
      if (prepared.blob_id !== request.blob_id || prepared.root_hash !== request.root_hash) throw Error("Changed archive encoding");
      const confirmations = await writeBounded(storage, encoded, request.blob_object_id);
      const cert = await storage.certificateFromConfirmations({ confirmations, blobId: encoded.blobId, deletable: false, blobObjectId: request.blob_object_id });
      const certificateCommittee = (await storage.systemState()).committee;
      requireWeightedQuorum(certificateCommittee, cert.signers);
      const bitmap = new Uint8Array(Math.ceil(certificateCommittee.members.length / 8));
      for (const n of cert.signers) {
        if (!Number.isInteger(n) || n < 0 || n >= certificateCommittee.members.length) throw Error("Invalid signer");
        bitmap[n >> 3] |= 1 << n % 8;
      }
      console.log(JSON.stringify({ signature: Buffer.from(cert.signature).toString("base64"), bitmap: Buffer.from(bitmap).toString("base64"), message: Buffer.from(cert.serializedMessage).toString("base64") }));
    } else throw Error("Unknown codec operation");
  } catch {
    console.error("Walrus codec operation failed");
    process.exitCode = 1;
  }
}
main().catch(() => {
  console.error("Walrus codec initialization failed");
  process.exitCode = 1;
});
/*! Bundled license information:

@scure/base/index.js:
  (*! scure-base - MIT License (c) 2022 Paul Miller (paulmillr.com) *)
*/
